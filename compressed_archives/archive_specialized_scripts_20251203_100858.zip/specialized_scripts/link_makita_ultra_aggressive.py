"""
ULTRA-AGGRESSIVE Makita Image Linking
======================================
Link images using ALL extreme strategies to reach 95%+ coverage
WARNING: Some matches may be incorrect - trades accuracy for coverage
"""
import json
from pathlib import Path
from collections import defaultdict
from difflib import SequenceMatcher
import re

def similar(a, b):
    """Calculate similarity ratio between two strings"""
    return SequenceMatcher(None, a.upper(), b.upper()).ratio()

def find_ultra_fuzzy_match(sku, available_skus, threshold=0.60):
    """ULTRA fuzzy match - 60% threshold (very permissive)"""
    best_match = None
    best_ratio = 0
    
    for candidate in available_skus:
        ratio = similar(sku, candidate)
        if ratio > best_ratio and ratio >= threshold:
            best_ratio = ratio
            best_match = candidate
    
    return best_match, best_ratio if best_match else (None, 0)

def find_base_sku_match(sku, available_skus):
    """Try to match SKU variants to base SKU"""
    suffixes = ['ZJ', 'ZK', 'RT', 'RTJ', 'TJ', 'Z', 'GZ', 'LZ', 'MP', 'G', 'PT', 'SAX', 'RFX', 'RMJ']
    
    for suffix in suffixes:
        if sku.endswith(suffix):
            base = sku[:-len(suffix)]
            if base in available_skus:
                return base, suffix
    
    return None, None

def find_partial_match(sku, available_skus):
    """Match partial SKUs (prefix matching)"""
    if len(sku) >= 5:
        prefix = sku[:5]
        for candidate in available_skus:
            if len(candidate) >= 5 and candidate.startswith(prefix):
                return candidate, 'prefix'
    return None, None

def extract_numbers(sku):
    """Extract numeric part of SKU"""
    return ''.join(c for c in sku if c.isdigit())

def find_numeric_match(sku, available_skus):
    """Match based on numeric codes"""
    sku_nums = extract_numbers(sku)
    if len(sku_nums) >= 4:
        for candidate in available_skus:
            cand_nums = extract_numbers(candidate)
            if sku_nums == cand_nums and len(sku_nums) >= 4:
                return candidate, 'numeric'
    return None, None

def find_substring_match(sku, available_skus):
    """Match if one SKU contains the other"""
    if len(sku) >= 6:
        for candidate in available_skus:
            if sku in candidate or candidate in sku:
                if sku != candidate:
                    return candidate, 'substring'
    return None, None

PROJECT_ROOT = Path(__file__).parent
PRODUCTS_JSON = PROJECT_ROOT / "output" / "products_ready_for_webshop.json"
EXTRACTED_JSON = PROJECT_ROOT / "output" / "makita_extracted_products.json"
CATALOG_NAME = "makita-catalogus-2022-nl"
OUTPUT_JSON = PROJECT_ROOT / "output" / "products_with_makita_ultra_aggressive.json"

def main():
    print("=" * 80)
    print("ULTRA-AGGRESSIVE MAKITA IMAGE LINKING - TARGET: 95%+ COVERAGE")
    print("=" * 80)
    print("⚠️  WARNING: Trades accuracy for coverage - some matches may be incorrect")
    
    # Load data
    print("\n📦 Loading data...")
    with open(PRODUCTS_JSON, 'r', encoding='utf-8') as f:
        all_products = json.load(f)
    
    with open(EXTRACTED_JSON, 'r', encoding='utf-8') as f:
        extracted_images = json.load(f)
    
    makita_products = [p for p in all_products if 'makita-catalogus-2022-nl' in p.get('pdf_source', '')]
    print(f"   {len(makita_products)} Makita products")
    print(f"   {len(extracted_images)} extracted image entries")
    
    # Build mappings
    print("\n🔗 Building SKU and page mappings...")
    sku_to_images = defaultdict(list)
    page_to_images = defaultdict(list)
    
    for entry in extracted_images:
        sku_to_images[entry['sku']].append(entry)
        page_to_images[entry['page_num']].append(entry)
    
    print(f"   {len(sku_to_images)} unique SKUs have images")
    print(f"   {len(page_to_images)} pages have images")
    
    # Link with ALL strategies
    print("\n🎯 Matching with ULTRA-AGGRESSIVE strategies...")
    stats = {
        'matched': 0,
        'exact_match': 0,
        'fuzzy_75_plus': 0,
        'fuzzy_60_75': 0,
        'base_sku': 0,
        'partial': 0,
        'numeric': 0,
        'substring': 0,
        'page_fallback': 0,
        'unmatched': 0,
        'gallery_added': 0
    }
    
    updated_products = []
    
    for product in all_products:
        if 'makita-catalogus-2022-nl' not in product.get('pdf_source', ''):
            updated_products.append(product)
            continue
        
        sku = product.get('sku', '')
        product_pages = product.get('source', {}).get('pages', [])
        
        matched_sku = None
        match_method = None
        match_confidence = 100
        
        # Strategy 1: Exact match
        if sku in sku_to_images:
            matched_sku = sku
            match_method = 'exact'
            stats['exact_match'] += 1
        
        # Strategy 2: High fuzzy match (75%+)
        if not matched_sku:
            fuzzy_sku, ratio = find_ultra_fuzzy_match(sku, sku_to_images.keys(), 0.75)
            if fuzzy_sku:
                matched_sku = fuzzy_sku
                match_method = 'fuzzy_high'
                match_confidence = int(ratio * 100)
                stats['fuzzy_75_plus'] += 1
        
        # Strategy 3: Medium fuzzy match (60-75%)
        if not matched_sku:
            fuzzy_sku, ratio = find_ultra_fuzzy_match(sku, sku_to_images.keys(), 0.60)
            if fuzzy_sku:
                matched_sku = fuzzy_sku
                match_method = 'fuzzy_medium'
                match_confidence = int(ratio * 100)
                stats['fuzzy_60_75'] += 1
                print(f"   ⚠️  Medium fuzzy: {sku} → {fuzzy_sku} ({ratio*100:.1f}%)")
        
        # Strategy 4: Base SKU
        if not matched_sku:
            base_sku, suffix = find_base_sku_match(sku, sku_to_images.keys())
            if base_sku:
                matched_sku = base_sku
                match_method = 'base_sku'
                match_confidence = 85
                stats['base_sku'] += 1
        
        # Strategy 5: Partial match
        if not matched_sku:
            partial_sku, _ = find_partial_match(sku, sku_to_images.keys())
            if partial_sku:
                matched_sku = partial_sku
                match_method = 'partial'
                match_confidence = 70
                stats['partial'] += 1
                print(f"   🔍 Partial: {sku} → {partial_sku}")
        
        # Strategy 6: Numeric match
        if not matched_sku:
            num_sku, _ = find_numeric_match(sku, sku_to_images.keys())
            if num_sku:
                matched_sku = num_sku
                match_method = 'numeric'
                match_confidence = 65
                stats['numeric'] += 1
                print(f"   🔢 Numeric: {sku} → {num_sku}")
        
        # Strategy 7: Substring match
        if not matched_sku:
            sub_sku, _ = find_substring_match(sku, sku_to_images.keys())
            if sub_sku:
                matched_sku = sub_sku
                match_method = 'substring'
                match_confidence = 60
                stats['substring'] += 1
                print(f"   📝 Substring: {sku} → {sub_sku}")
        
        # Strategy 8: Page fallback (use any image from same page)
        if not matched_sku and product_pages:
            for page in product_pages:
                if page in page_to_images and len(page_to_images[page]) > 0:
                    # Use first available image from page
                    fallback_entry = page_to_images[page][0]
                    matched_sku = fallback_entry['sku']
                    match_method = 'page_fallback'
                    match_confidence = 50
                    stats['page_fallback'] += 1
                    print(f"   📄 Page fallback: {sku} (page {page}) → {matched_sku}")
                    break
        
        # Link the image
        if matched_sku and matched_sku in sku_to_images:
            images = sku_to_images[matched_sku]
            
            # Choose best image
            best_image = None
            for img in images:
                if product_pages and img['page_num'] in product_pages:
                    best_image = img
                    break
            if not best_image:
                best_image = images[0]
            
            # Update product
            product['image_url'] = f"/product-images/{CATALOG_NAME}/{best_image['image_filename']}"
            product['image_source'] = 'ultra_aggressive_extraction'
            product['match_method'] = match_method
            product['match_confidence'] = match_confidence
            
            if matched_sku != sku:
                product['matched_sku'] = matched_sku
            
            product['image_quality'] = {
                'color_variance': best_image['color_variance'],
                'edge_density': best_image['edge_density']
            }
            
            # Add gallery
            if len(images) > 1:
                gallery_images = []
                for img in images[:5]:
                    if img != best_image:
                        gallery_images.append(f"/product-images/{CATALOG_NAME}/{img['image_filename']}")
                if gallery_images:
                    product['gallery_images'] = gallery_images
                    stats['gallery_added'] += 1
            
            stats['matched'] += 1
        else:
            stats['unmatched'] += 1
        
        updated_products.append(product)
    
    # Save
    print("\n💾 Saving ultra-aggressive matched products...")
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(updated_products, f, indent=2)
    
    # Summary
    print("\n" + "=" * 80)
    print("ULTRA-AGGRESSIVE LINKING COMPLETE")
    print("=" * 80)
    
    coverage = stats['matched'] / len(makita_products) * 100
    
    print(f"\n📊 FINAL RESULTS:")
    print(f"   Total Makita products:     {len(makita_products)}")
    print(f"   ✅ Matched with images:    {stats['matched']} ({coverage:.1f}%)")
    print(f"   ❌ Still unmatched:        {stats['unmatched']} ({stats['unmatched']/len(makita_products)*100:.1f}%)")
    
    print(f"\n🎯 Match Method Breakdown:")
    print(f"   Exact matches:             {stats['exact_match']:4d} (100% confidence)")
    print(f"   Fuzzy 75%+:                {stats['fuzzy_75_plus']:4d} (75-100% confidence)")
    print(f"   Fuzzy 60-75%:              {stats['fuzzy_60_75']:4d} (60-75% confidence) ⚠️")
    print(f"   Base SKU:                  {stats['base_sku']:4d} (85% confidence)")
    print(f"   Partial match:             {stats['partial']:4d} (70% confidence) ⚠️")
    print(f"   Numeric match:             {stats['numeric']:4d} (65% confidence) ⚠️")
    print(f"   Substring match:           {stats['substring']:4d} (60% confidence) ⚠️")
    print(f"   Page fallback:             {stats['page_fallback']:4d} (50% confidence) ⚠️")
    
    print(f"\n🖼️  Image Galleries:")
    print(f"   Products with galleries:   {stats['gallery_added']}")
    
    # Confidence breakdown
    high_conf = stats['exact_match'] + stats['fuzzy_75_plus'] + stats['base_sku']
    medium_conf = stats['fuzzy_60_75'] + stats['partial']
    low_conf = stats['numeric'] + stats['substring'] + stats['page_fallback']
    
    print(f"\n📈 Confidence Distribution:")
    print(f"   High (75-100%):            {high_conf:4d} ({high_conf/stats['matched']*100:.1f}% of matched)")
    print(f"   Medium (60-75%):           {medium_conf:4d} ({medium_conf/stats['matched']*100:.1f}% of matched) ⚠️")
    print(f"   Low (50-60%):              {low_conf:4d} ({low_conf/stats['matched']*100:.1f}% of matched) ⚠️⚠️")
    
    print(f"\n💾 Results saved to: {OUTPUT_JSON}")
    
    if coverage >= 95:
        print(f"\n🎉 SUCCESS! Achieved {coverage:.1f}% coverage (target: 95%)")
    else:
        print(f"\n📊 Coverage: {coverage:.1f}% (target: 95%, {int(1734 * 0.95 - stats['matched'])} more needed)")
    
    print(f"\n⚠️  IMPORTANT:")
    print(f"   - {medium_conf + low_conf} matches have <75% confidence")
    print(f"   - Recommend manual verification of medium/low confidence matches")
    print(f"   - Some matches may be incorrect (traded accuracy for coverage)")

if __name__ == '__main__':
    main()
