#!/usr/bin/env python3
"""
Clean grouped JSON files by removing header SKUs like "Bestelnr", "Code", etc.
"""

import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"
WEBSHOP_DATA = PROJECT_ROOT.parent / "DemaWebshop" / "dema-webshop" / "public" / "data"

# Header keywords to remove
HEADER_KEYWORDS = [
    'bestelnr', 'code', 'artikel', 'artnr', 'artikelnummer',
    'maat', 'size', 'afmeting', 'dimension', 'omschrijving',
    'description', 'type', 'model', 'variant', 'uitvoering'
]

def is_header_sku(sku):
    """Check if SKU is actually a header"""
    if not sku or not isinstance(sku, str):
        return True
    
    sku_lower = sku.lower().strip()
    
    # Check if it's a header keyword
    for keyword in HEADER_KEYWORDS:
        if sku_lower == keyword or keyword in sku_lower:
            return True
    
    # Check if it's too short (< 3 chars)
    if len(sku_lower) < 3:
        return True
    
    # Check if it's all spaces or special chars
    if not any(c.isalnum() for c in sku):
        return True
    
    return False

def clean_group(group):
    """Remove invalid variants from a product group"""
    if 'variants' not in group:
        return group
    
    # Filter out header SKUs
    valid_variants = []
    for variant in group['variants']:
        sku = variant.get('sku', '')
        if not is_header_sku(sku):
            valid_variants.append(variant)
    
    # Update group
    group['variants'] = valid_variants
    group['variant_count'] = len(valid_variants)
    
    # Update default variant if needed
    if valid_variants:
        if 'default_variant_sku' not in group or is_header_sku(group.get('default_variant_sku', '')):
            group['default_variant_sku'] = valid_variants[0]['sku']
    
    return group

def clean_catalog(catalog_file):
    """Clean a single catalog file"""
    print(f"\n🔧 Cleaning: {catalog_file.name}")
    
    try:
        with open(catalog_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if not isinstance(data, list):
            print(f"   ⚠️  Not a list, skipping")
            return False
        
        original_count = sum(len(g.get('variants', [])) for g in data)
        
        # Clean each group
        cleaned_data = []
        for group in data:
            cleaned_group = clean_group(group)
            # Only keep groups with variants
            if cleaned_group.get('variant_count', 0) > 0:
                cleaned_data.append(cleaned_group)
        
        cleaned_count = sum(len(g.get('variants', [])) for g in cleaned_data)
        removed = original_count - cleaned_count
        
        if removed > 0:
            # Save cleaned data
            with open(catalog_file, 'w', encoding='utf-8') as f:
                json.dump(cleaned_data, f, indent=2, ensure_ascii=False)
            
            print(f"   ✅ Cleaned: Removed {removed} invalid variants")
            print(f"   Groups: {len(data)} → {len(cleaned_data)}")
            print(f"   Variants: {original_count} → {cleaned_count}")
            return True
        else:
            print(f"   ✅ Already clean (no invalid variants)")
            return False
            
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False

def main():
    print("="*80)
    print("CLEANING GROUPED DATA")
    print("="*80)
    
    # Find all grouped JSON files
    grouped_files = []
    
    # Check both locations
    for directory in [OUTPUT_DIR, WEBSHOP_DATA]:
        if directory.exists():
            grouped_files.extend(directory.glob("*_grouped.json"))
    
    if not grouped_files:
        print("\n❌ No grouped JSON files found!")
        return
    
    print(f"\nFound {len(grouped_files)} grouped files")
    
    cleaned_count = 0
    for file in grouped_files:
        if clean_catalog(file):
            cleaned_count += 1
    
    print("\n" + "="*80)
    print(f"✅ COMPLETE: Cleaned {cleaned_count}/{len(grouped_files)} files")
    print("="*80)
    
    if cleaned_count > 0:
        print("\n⚠️  IMPORTANT: Rebuild the frontend:")
        print("   cd ../DemaWebshop/dema-webshop")
        print("   npm run build")

if __name__ == "__main__":
    main()
