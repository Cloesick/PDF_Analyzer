"""
Property Translation and Icon Mapping Configuration
Maps Dutch property names to English with appropriate icons
"""

# Dutch to English property translations
PROPERTY_TRANSLATIONS = {
    # Power and Performance
    "Spanning": "Voltage",
    "Vermogen": "Power",
    "Max. uitgangsvermogen": "Max. output power",
    "Max. vermogen": "Max. power",
    "Onbelast toerental": "No-load speed",
    "Toerental": "Speed",
    "Max. koppel": "Max. torque",
    "Max. koppel zacht / hard": "Max. torque soft/hard",
    "Koppel": "Torque",
    "Trillingen": "Vibration",
    "Geluidsniveau": "Noise level",
    "Geluidsdruk": "Sound pressure",
    "Geluidsvermogen": "Sound power",
    
    # Dimensions and Capacity
    "Gewicht": "Weight",
    "Afmetingen": "Dimensions",
    "Lengte": "Length",
    "Breedte": "Width",
    "Hoogte": "Height",
    "Diameter": "Diameter",
    "Capaciteit": "Capacity",
    "Inhoud": "Volume",
    "Inhoud opvangbak": "Collection bag capacity",
    "Tankinhoud": "Tank capacity",
    
    # Cutting and Drilling
    "Maaibreedte": "Cutting width",
    "Maailengte": "Cutting length",
    "Zaagdiepte": "Cutting depth",
    "Snijdiepte": "Cutting depth",
    "Boorkop": "Chuck size",
    "Boorbereik": "Drilling range",
    "Boorcapaciteit": "Drilling capacity",
    "Max. boordiameter": "Max. drill diameter",
    "Zaagblad": "Saw blade",
    "Bladdiameter": "Blade diameter",
    "Tanden": "Teeth",
    
    # Features and Functions
    "Klopboorfunctie": "Hammer drill function",
    "Mulching": "Mulching",
    "Variabel toerental": "Variable speed",
    "Elektronische snelheidsregeling": "Electronic speed control",
    "LED-lamp": "LED light",
    "Softstart": "Soft start",
    "Overbelastingsbeveiliging": "Overload protection",
    "Stofinzuiging": "Dust extraction",
    "Stofafzuiging": "Dust collection",
    
    # Battery and Power Supply
    "Bijgeleverde accu's": "Included batteries",
    "Accu": "Battery",
    "Batterij": "Battery",
    "Lader": "Charger",
    "Laadtijd": "Charging time",
    "Accuspanning": "Battery voltage",
    "Batterijspanning": "Battery voltage",
    "Accucapaciteit": "Battery capacity",
    
    # Materials and Build
    "Chassis": "Chassis",
    "Materiaal": "Material",
    "Behuizing": "Housing",
    "Handgreep": "Handle",
    "Kabellengte": "Cable length",
    "Snoerlengte": "Cord length",
    
    # Other
    "Prijs excl. BTW": "Price excl. VAT",
    "Prijs incl. BTW": "Price incl. VAT",
    "Kleur": "Color",
    "Waterdicht": "Waterproof",
    "Beschermingsklasse": "Protection class",
    "IP-classificatie": "IP rating",
}

# Icon mappings for property types
PROPERTY_ICONS = {
    # Power and Performance
    "Voltage": "⚡",
    "Power": "💪",
    "Max. output power": "⚡",
    "Max. power": "⚡",
    "No-load speed": "🔄",
    "Speed": "⚡",
    "Max. torque": "🔧",
    "Max. torque soft/hard": "🔧",
    "Torque": "🔧",
    "Vibration": "📳",
    "Noise level": "🔊",
    "Sound pressure": "🔊",
    "Sound power": "🔊",
    
    # Dimensions and Capacity
    "Weight": "⚖️",
    "Dimensions": "📏",
    "Length": "📏",
    "Width": "📏",
    "Height": "📏",
    "Diameter": "⭕",
    "Capacity": "📦",
    "Volume": "📦",
    "Collection bag capacity": "🗑️",
    "Tank capacity": "⛽",
    
    # Cutting and Drilling
    "Cutting width": "✂️",
    "Cutting length": "✂️",
    "Cutting depth": "📐",
    "Chuck size": "🔩",
    "Drilling range": "🔨",
    "Drilling capacity": "🔨",
    "Max. drill diameter": "⭕",
    "Saw blade": "⚙️",
    "Blade diameter": "⭕",
    "Teeth": "⚙️",
    
    # Features and Functions
    "Hammer drill function": "🔨",
    "Mulching": "🌿",
    "Variable speed": "🎚️",
    "Electronic speed control": "🎛️",
    "LED light": "💡",
    "Soft start": "▶️",
    "Overload protection": "🛡️",
    "Dust extraction": "💨",
    "Dust collection": "💨",
    
    # Battery and Power Supply
    "Included batteries": "🔋",
    "Battery": "🔋",
    "Charger": "🔌",
    "Charging time": "⏱️",
    "Battery voltage": "⚡",
    "Battery capacity": "🔋",
    
    # Materials and Build
    "Chassis": "🏗️",
    "Material": "🧱",
    "Housing": "📦",
    "Handle": "✋",
    "Cable length": "🔌",
    "Cord length": "🔌",
    
    # Other
    "Price excl. VAT": "💰",
    "Price incl. VAT": "💰",
    "Color": "🎨",
    "Waterproof": "💧",
    "Protection class": "🛡️",
    "IP rating": "🛡️",
}

# Unit-specific icons
UNIT_ICONS = {
    "V": "⚡",      # Voltage
    "W": "⚡",      # Watts
    "Nm": "🔧",     # Newton-meters (torque)
    "rpm": "🔄",    # Revolutions per minute
    "kg": "⚖️",    # Kilograms
    "g": "⚖️",     # Grams
    "mm": "📏",     # Millimeters
    "cm": "📏",     # Centimeters
    "m": "📏",      # Meters
    "l": "📦",      # Liters
    "ml": "📦",     # Milliliters
    "dB": "🔊",     # Decibels
    "Ah": "🔋",     # Amp-hours
    "mAh": "🔋",    # Milliamp-hours
    "min": "⏱️",   # Minutes
    "h": "⏱️",     # Hours
    "°C": "🌡️",   # Celsius
}

# Value-specific icons
VALUE_ICONS = {
    # Boolean/Yes-No values
    "yes": "✅",
    "no": "❌",
    "ja": "✅",
    "nee": "❌",
    "✓": "✅",
    "✗": "❌",
    "-": "➖",
    "standard": "📦",
    "optioneel": "⚙️",
    "optional": "⚙️",
    
    # Material types
    "polypropyleen": "🧱",
    "polypropylene": "🧱",
    "staal": "🔩",
    "steel": "🔩",
    "aluminium": "⚙️",
    "aluminum": "⚙️",
    "kunststof": "🧱",
    "plastic": "🧱",
    
    # Battery codes
    "BL1830": "🔋",
    "BL1840": "🔋",
    "BL1850": "🔋",
    "BL1860": "🔋",
    "BL4020": "🔋",
    "BL4025": "🔋",
    "BL4040": "🔋",
    "BL4050": "🔋",
    
    # Charger codes
    "DC18RC": "🔌",
    "DC18RD": "🔌",
    "DC18RE": "🔌",
    "DC40RA": "🔌",
    "DC18SD": "🔌",
}

def translate_property_name(dutch_name):
    """Translate Dutch property name to English"""
    # Remove " None" suffix if present
    clean_name = dutch_name.replace(" None", "").strip()
    
    # Try exact match
    if clean_name in PROPERTY_TRANSLATIONS:
        return PROPERTY_TRANSLATIONS[clean_name]
    
    # Try partial match (for composite properties)
    for dutch, english in PROPERTY_TRANSLATIONS.items():
        if dutch.lower() in clean_name.lower():
            return clean_name.replace(dutch, english)
    
    # If no translation found, return cleaned name
    return clean_name

def get_property_icon(english_name, value=None):
    """Get icon for a property based on name or value"""
    # Try exact property name match
    if english_name in PROPERTY_ICONS:
        return PROPERTY_ICONS[english_name]
    
    # Try value-specific icon
    if value:
        value_str = str(value).strip().lower()
        if value_str in VALUE_ICONS:
            return VALUE_ICONS[value_str]
        
        # Check if value contains a battery or charger code
        for code, icon in VALUE_ICONS.items():
            if code.upper() in str(value).upper():
                return icon
    
    # Try unit-based icon
    if value:
        for unit, icon in UNIT_ICONS.items():
            if f" {unit}" in str(value) or str(value).endswith(unit):
                return icon
    
    # Default icon
    return "📋"

def get_value_icon(value):
    """Get icon specifically for a value"""
    if not value:
        return "➖"
    
    value_str = str(value).strip().lower()
    
    # Check exact matches
    if value_str in VALUE_ICONS:
        return VALUE_ICONS[value_str]
    
    # Check for battery codes
    if "bl" in value_str and any(c.isdigit() for c in value_str):
        return "🔋"
    
    # Check for charger codes
    if "dc" in value_str and any(c.isdigit() for c in value_str):
        return "🔌"
    
    # Check for units
    for unit, icon in UNIT_ICONS.items():
        if unit.lower() in value_str:
            return icon
    
    return ""

if __name__ == '__main__':
    # Test translations
    print("Testing translations:")
    test_props = [
        "Bijgeleverde accu's None",
        "Max. uitgangsvermogen None",
        "Gewicht None",
        "Maaibreedte None"
    ]
    
    for prop in test_props:
        english = translate_property_name(prop)
        icon = get_property_icon(english)
        print(f"  {icon} {prop} → {english}")
    
    print("\nTesting value icons:")
    test_values = ["BL4040", "DC18RC", "450 W", "33 cm", "-", "Polypropyleen"]
    for val in test_values:
        icon = get_value_icon(val)
        print(f"  {icon} {val}")
