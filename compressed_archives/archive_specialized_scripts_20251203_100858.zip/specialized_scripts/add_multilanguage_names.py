"""
Add Multi-Language Product Names
=================================
Add English, French, and Dutch translations for all products

Strategy:
1. Detect current language (usually Dutch from PDF)
2. Generate English translation (category-based)
3. Generate French translation
4. Add to product data structure
"""

import json
from pathlib import Path
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
PRODUCTS_JSON = PROJECT_ROOT / "output" / "products_ready_for_webshop.json"
OUTPUT_JSON = PROJECT_ROOT / "output" / "products_multilanguage.json"

# Category translations
CATEGORY_TRANSLATIONS = {
    'nl': {
        'Elektrisch Gereedschap Makita': {
            'en': 'Makita Power Tools',
            'fr': 'Outils Électriques Makita',
            'nl': 'Elektrisch Gereedschap Makita'
        },
        'RVS Fittingen': {
            'en': 'Stainless Steel Fittings',
            'fr': 'Raccords en Acier Inoxydable',
            'nl': 'RVS Fittingen'
        },
        'Pneumatische Gereedschappen': {
            'en': 'Pneumatic Tools',
            'fr': 'Outils Pneumatiques',
            'nl': 'Pneumatische Gereedschappen'
        },
        'Compressoren': {
            'en': 'Compressors',
            'fr': 'Compresseurs',
            'nl': 'Compressoren'
        },
        'Slangen en Koppelingen': {
            'en': 'Hoses and Couplings',
            'fr': 'Tuyaux et Raccords',
            'nl': 'Slangen en Koppelingen'
        },
    }
}

# Common technical terms translations
TECHNICAL_TERMS = {
    # Dutch -> English, French
    'draad': {'en': 'thread', 'fr': 'filetage'},
    'fitting': {'en': 'fitting', 'fr': 'raccord'},
    'koppeling': {'en': 'coupling', 'fr': 'couplage'},
    'slang': {'en': 'hose', 'fr': 'tuyau'},
    'buis': {'en': 'pipe', 'fr': 'tuyau'},
    'rvs': {'en': 'stainless steel', 'fr': 'acier inoxydable'},
    'ventiel': {'en': 'valve', 'fr': 'vanne'},
    'compressor': {'en': 'compressor', 'fr': 'compresseur'},
    'pomp': {'en': 'pump', 'fr': 'pompe'},
    'druk': {'en': 'pressure', 'fr': 'pression'},
    'lucht': {'en': 'air', 'fr': 'air'},
    'elektrisch': {'en': 'electric', 'fr': 'électrique'},
    'gereedschap': {'en': 'tool', 'fr': 'outil'},
    'accu': {'en': 'battery', 'fr': 'batterie'},
    'lader': {'en': 'charger', 'fr': 'chargeur'},
    'boor': {'en': 'drill', 'fr': 'perceuse'},
    'schroef': {'en': 'screw', 'fr': 'vis'},
    'zaag': {'en': 'saw', 'fr': 'scie'},
    'slijp': {'en': 'grind', 'fr': 'meule'},
    'hamer': {'en': 'hammer', 'fr': 'marteau'},
}

def detect_language(text):
    """Detect if text is Dutch, English, or French"""
    dutch_indicators = ['de', 'het', 'een', 'van', 'voor', 'met', 'mm', 'draad']
    english_indicators = ['the', 'a', 'with', 'for', 'inch', 'thread']
    french_indicators = ['le', 'la', 'un', 'une', 'pour', 'avec', 'de']
    
    text_lower = text.lower()
    
    dutch_score = sum(1 for word in dutch_indicators if word in text_lower)
    english_score = sum(1 for word in english_indicators if word in text_lower)
    french_score = sum(1 for word in french_indicators if word in text_lower)
    
    if dutch_score > english_score and dutch_score > french_score:
        return 'nl'
    elif english_score > french_score:
        return 'en'
    else:
        return 'fr'

def translate_name(name, from_lang, to_lang):
    """Translate product name using term dictionary"""
    if from_lang == to_lang:
        return name
    
    translated = name
    name_lower = name.lower()
    
    # Replace technical terms
    for dutch_term, translations in TECHNICAL_TERMS.items():
        if dutch_term in name_lower and to_lang in translations:
            # Case-insensitive replacement preserving original case
            import re
            pattern = re.compile(re.escape(dutch_term), re.IGNORECASE)
            translated = pattern.sub(translations[to_lang], translated)
    
    return translated

def generate_multilanguage_name(product):
    """Generate name in all 3 languages"""
    original_name = product.get('name', product.get('sku', 'Unknown'))
    category = product.get('product_category', '')
    
    # Detect original language (usually Dutch from PDFs)
    original_lang = detect_language(original_name)
    
    # If name is just a SKU, create descriptive names from category
    if original_name == product.get('sku') or len(original_name) < 5:
        # Use category for translation
        if category in CATEGORY_TRANSLATIONS.get('nl', {}):
            cat_trans = CATEGORY_TRANSLATIONS['nl'][category]
            return {
                'nl': f"{original_name} - {category}",
                'en': f"{original_name} - {cat_trans['en']}",
                'fr': f"{original_name} - {cat_trans['fr']}"
            }
    
    # Generate translations
    multilanguage_name = {}
    
    if original_lang == 'nl':
        multilanguage_name['nl'] = original_name
        multilanguage_name['en'] = translate_name(original_name, 'nl', 'en')
        multilanguage_name['fr'] = translate_name(original_name, 'nl', 'fr')
    elif original_lang == 'en':
        multilanguage_name['en'] = original_name
        multilanguage_name['nl'] = original_name  # Keep original if can't translate back
        multilanguage_name['fr'] = translate_name(original_name, 'en', 'fr')
    else:  # French
        multilanguage_name['fr'] = original_name
        multilanguage_name['en'] = original_name
        multilanguage_name['nl'] = original_name
    
    return multilanguage_name

def add_multilanguage_support():
    """Add multi-language names to all products"""
    
    print("=" * 80)
    print("ADDING MULTI-LANGUAGE PRODUCT NAMES")
    print("=" * 80)
    
    # Load products
    print("\n📦 Loading products...")
    with open(PRODUCTS_JSON, 'r', encoding='utf-8') as f:
        products = json.load(f)
    
    print(f"   Found {len(products)} products")
    
    # Add translations
    print("\n🌍 Adding translations...")
    stats = {
        'total': len(products),
        'translated': 0,
        'categories': defaultdict(int)
    }
    
    for i, product in enumerate(products):
        # Generate multilanguage names
        multilanguage_names = generate_multilanguage_name(product)
        
        # Add to product
        product['name_multilang'] = multilanguage_names
        
        # Keep original name as default
        if 'name' not in product or not product['name']:
            product['name'] = multilanguage_names.get('nl', product.get('sku', 'Unknown'))
        
        stats['translated'] += 1
        stats['categories'][product.get('product_category', 'Unknown')] += 1
        
        # Progress
        if (i + 1) % 500 == 0:
            print(f"   Processed {i + 1}/{len(products)} products...")
    
    # Save
    print("\n💾 Saving...")
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(products, f, indent=2, ensure_ascii=False)
    
    # Summary
    print("\n" + "=" * 80)
    print("TRANSLATION COMPLETE")
    print("=" * 80)
    
    print(f"\n📊 Statistics:")
    print(f"   Total products:       {stats['total']}")
    print(f"   Translated:           {stats['translated']}")
    
    print(f"\n🏷️  Categories processed:")
    for category, count in sorted(stats['categories'].items(), key=lambda x: x[1], reverse=True)[:10]:
        print(f"   - {category}: {count} products")
    
    # Sample
    print(f"\n🔍 Sample Translations:")
    for product in products[:5]:
        names = product.get('name_multilang', {})
        print(f"\n   SKU: {product.get('sku')}")
        print(f"   🇳🇱 NL: {names.get('nl', 'N/A')}")
        print(f"   🇬🇧 EN: {names.get('en', 'N/A')}")
        print(f"   🇫🇷 FR: {names.get('fr', 'N/A')}")
    
    print(f"\n💾 Saved to: {OUTPUT_JSON}")
    
    print(f"\n✅ All products now have multi-language names!")
    print(f"   Structure: product.name_multilang = {{nl: '...', en: '...', fr: '...'}}")

if __name__ == '__main__':
    add_multilanguage_support()
