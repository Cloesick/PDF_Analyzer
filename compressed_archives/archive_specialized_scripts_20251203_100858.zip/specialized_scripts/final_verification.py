"""
Final verification that only actual tools remain
"""
from pathlib import Path
import re

PROJECT_ROOT = Path(__file__).parent
IMAGE_DIR = PROJECT_ROOT / "product-images-by-pdf"

CATALOGS = ["makita-catalogus-2022-nl", "makita-tuinfolder-2022-nl"]

# Problematic SKUs from user's original report
PROBLEMATIC_SKUS = [
    "BL4020", "BL4025", "BL4040", "BL4050F", "BL4080F", "BL1860B", "BL1850B", "BL1840B", "BL1830B",
    "DC40RA", "DC40RB", "DC18R", "DC18RD", "DC18RE", "DC18RC", "DC40",
    "ADP001", "ADP10", "DEAADP001G", "BEAPDC1200A01", "AD88",
    "PDC01", "BPS01", "81-6", "933-6", "624-2", "198720-9", "190778", "198091-4"
]

# Actual tool SKU patterns (from user examples)
CONFIRMED_TOOL_PATTERNS = [
    "DDG460ZX7", "DDG460T2X7", "UR002GZ01", "UR007GM101", "UR006GM101",
    "HR005G", "TW04GD201", "TW004GZ", "TW007GD201", "GA005G", "GA037GM201",
    "PT001GD101", "JR001GD201", "FN001GA202", "RT001GZ16", "KP001GZ01",
    "LS004GZ01", "LS003GZ01", "HS010G", "HS009G", "HS003G"
]

def check_problematic_skus(images):
    """Check if any problematic SKUs remain"""
    found = []
    for img in images:
        name_upper = img.name.upper()
        for sku in PROBLEMATIC_SKUS:
            if sku.upper() in name_upper:
                found.append((img.name, sku))
    return found

def check_tool_skus(images):
    """Check how many confirmed tool SKUs are present"""
    found = []
    for img in images:
        name_upper = img.name.upper()
        for sku in CONFIRMED_TOOL_PATTERNS:
            if sku.upper() in name_upper:
                found.append((img.name, sku))
    return found

def main():
    print("="*80)
    print("FINAL VERIFICATION - TOOL-ONLY EXTRACTION")
    print("="*80)
    
    total_images = 0
    total_problematic = 0
    total_confirmed_tools = 0
    
    for catalog in CATALOGS:
        catalog_dir = IMAGE_DIR / catalog
        
        if not catalog_dir.exists():
            print(f"\n[SKIP] {catalog}")
            continue
        
        images = list(catalog_dir.glob("*.webp"))
        
        print(f"\n{catalog}:")
        print(f"  Total images: {len(images)}")
        
        # Check for problematic SKUs
        problematic = check_problematic_skus(images)
        
        if problematic:
            print(f"\n  [WARNING] Found {len(problematic)} problematic SKUs:")
            for filename, sku in problematic[:10]:
                print(f"    - {sku}: {filename}")
        else:
            print(f"  [OK] No problematic SKUs found!")
        
        # Check for confirmed tools
        confirmed_tools = check_tool_skus(images)
        
        if confirmed_tools:
            print(f"\n  [OK] Found {len(confirmed_tools)} confirmed tool SKUs:")
            for filename, sku in confirmed_tools[:10]:
                print(f"    - {sku}: {filename}")
        
        total_images += len(images)
        total_problematic += len(problematic)
        total_confirmed_tools += len(confirmed_tools)
    
    print("\n" + "="*80)
    print("VERIFICATION SUMMARY")
    print("="*80)
    print(f"\nTotal tool images: {total_images}")
    print(f"Problematic SKUs found: {total_problematic}")
    print(f"Confirmed tool SKUs found: {total_confirmed_tools}")
    
    if total_problematic == 0:
        print("\n[SUCCESS] All batteries, chargers, and accessories removed!")
        print("[SUCCESS] Only actual power tools remain!")
    else:
        print(f"\n[WARNING] {total_problematic} problematic images still present")
        print("[ACTION] Additional cleanup needed")

if __name__ == '__main__':
    main()
