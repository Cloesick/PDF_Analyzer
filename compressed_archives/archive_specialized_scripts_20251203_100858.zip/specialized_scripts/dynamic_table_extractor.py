"""
Dynamic PDF Table Extractor
Reads any table headers and automatically maps to properties and icons
"""
import fitz
import json
import re
from pathlib import Path

# Universal header mapping dictionary
HEADER_MAPPING = {
    # SKU / Order number
    'bestelnr': {'property': 'sku', 'icon': None, 'unit': None},
    'code': {'property': 'sku', 'icon': None, 'unit': None},
    'artikelnr': {'property': 'sku', 'icon': None, 'unit': None},
    
    # Dimensions
    'maat': {'property': 'diameter_mm', 'icon': '📏', 'unit': 'mm'},
    'maten': {'property': 'dimensions', 'icon': '◯⊙', 'unit': 'mm'},
    'diameter': {'property': 'diameter_mm', 'icon': '📏', 'unit': 'mm'},
    'binnen dia': {'property': 'inner_diameter_mm', 'icon': '⊙', 'unit': 'mm'},
    'buiten dia': {'property': 'outer_diameter_mm', 'icon': '◯', 'unit': 'mm'},
    'breedte': {'property': 'width_mm', 'icon': '↔️', 'unit': 'mm'},
    'lengte': {'property': 'length_m', 'icon': '📐', 'unit': 'm'},
    'rollengte': {'property': 'length_m', 'icon': '📐', 'unit': 'm'},
    'hoek': {'property': 'angle_degrees', 'icon': '📐', 'unit': '°'},
    
    # Pressure
    'werkdruk': {'property': 'pressure_work_bar', 'icon': '🔧', 'unit': 'bar'},
    'barstdruk': {'property': 'pressure_burst_bar', 'icon': '💥', 'unit': 'bar'},
    'max druk': {'property': 'pressure_max_bar', 'icon': '🔧', 'unit': 'bar'},
    'opv.hoogte': {'property': 'pressure_height_m', 'icon': '🔧', 'unit': 'm'},
    'opvoerhoogte': {'property': 'pressure_height_m', 'icon': '🔧', 'unit': 'm'},
    
    # Power
    'vermogen pk': {'property': 'power_hp', 'icon': '⚡', 'unit': 'HP'},
    'vermogen kw': {'property': 'power_kw', 'icon': '⚡', 'unit': 'kW'},
    'vermogen': {'property': 'power', 'icon': '⚡', 'unit': None},  # Needs unit detection
    
    # Flow & Speed
    'toeren': {'property': 'rpm', 'icon': '🔄', 'unit': 'RPM'},
    'rpm': {'property': 'rpm', 'icon': '🔄', 'unit': 'RPM'},
    'debiet': {'property': 'flow_m3_per_h', 'icon': '💨', 'unit': 'm³/h'},
    'capaciteit': {'property': 'flow_m3_per_h', 'icon': '💨', 'unit': 'm³/h'},
    
    # Weight & Volume
    'gewicht': {'property': 'weight_kg', 'icon': '⚖️', 'unit': 'kg'},
    'volume': {'property': 'volume_l', 'icon': '🗜️', 'unit': 'L'},
    'inhoud': {'property': 'volume_l', 'icon': '🗜️', 'unit': 'L'},
    
    # Material & Type
    'materiaal': {'property': 'material', 'icon': '🔬', 'unit': None},
    'type': {'property': 'type', 'icon': '🏭', 'unit': None},
    'model': {'property': 'model', 'icon': '🏭', 'unit': None},
    
    # Temperature
    'temperatuur': {'property': 'temperature', 'icon': '🌡️', 'unit': '°C'},
    'min temp': {'property': 'min_temp_c', 'icon': '🌡️', 'unit': '°C'},
    'max temp': {'property': 'max_temp_c', 'icon': '🌡️', 'unit': '°C'},
    
    # Bearings
    'lagerhuis': {'property': 'bearing_housing', 'icon': '🏠', 'unit': None},
    'spanlager': {'property': 'pillow_block_bearing', 'icon': '🔩', 'unit': None},
    'lager': {'property': 'bearing_type', 'icon': '🏷️', 'unit': None},
    
    # Other
    'toepassing': {'property': 'application', 'icon': '🔧', 'unit': None},
    'spanning': {'property': 'voltage_v', 'icon': '🔌', 'unit': 'V'},
    'voltage': {'property': 'voltage_v', 'icon': '🔌', 'unit': 'V'},
}

def normalize_header(header_text):
    """Normalize header text for matching"""
    if not header_text:
        return ''
    
    # Convert to lowercase, remove newlines, extra spaces
    text = str(header_text).lower()
    text = text.replace('\n', ' ')
    text = re.sub(r'\s+', ' ', text)
    text = text.strip()
    
    return text

def detect_header_mapping(headers):
    """
    Automatically detect what each column represents based on headers
    Returns: list of column mappings
    """
    mappings = []
    
    for i, header in enumerate(headers):
        normalized = normalize_header(header)
        
        # Try to find exact match
        mapping = None
        for key, value in HEADER_MAPPING.items():
            if key in normalized:
                mapping = {
                    'index': i,
                    'header': header,
                    'property': value['property'],
                    'icon': value['icon'],
                    'unit': value['unit']
                }
                break
        
        mappings.append(mapping)
    
    return mappings

def extract_table_dynamically(table, pdf_name, page_num):
    """
    Extract products from a table using dynamic header detection
    """
    extracted = table.extract()
    if not extracted or len(extracted) < 2:
        return []
    
    headers = extracted[0]
    
    # Detect what each column represents
    column_mappings = detect_header_mapping(headers)
    
    # Find SKU column
    sku_mapping = next((m for m in column_mappings if m and m['property'] == 'sku'), None)
    if not sku_mapping:
        return []  # Can't process without SKU
    
    print(f"      📋 Table on page {page_num + 1}:")
    print(f"         Headers: {headers}")
    print(f"         Detected columns:")
    for m in column_mappings:
        if m:
            icon = m['icon'] or '-'
            unit = m['unit'] or ''
            print(f"            {icon} {m['property']} {unit}")
    
    # Extract products
    products = []
    for row in extracted[1:]:
        if not row or len(row) < 2:
            continue
        
        # Get SKU
        sku = str(row[sku_mapping['index']]).strip()
        if not sku or len(sku) < 2:
            continue
        
        # Build product
        product = {
            'sku': sku,
            'pdf_source': pdf_name,
            'page_in_pdf': page_num + 1
        }
        
        # Extract all other properties
        for mapping in column_mappings:
            if not mapping or mapping['property'] == 'sku':
                continue
            
            col_index = mapping['index']
            if col_index >= len(row):
                continue
            
            value = row[col_index]
            if not value or str(value).strip() in ['-', '', 'N/A']:
                continue
            
            # Store raw value (extraction functions can be added later)
            product[mapping['property']] = str(value).strip()
            
            # Store metadata for frontend
            if 'display_metadata' not in product:
                product['display_metadata'] = {}
            
            product['display_metadata'][mapping['property']] = {
                'icon': mapping['icon'],
                'unit': mapping['unit']
            }
        
        products.append(product)
    
    return products

def process_pdf_dynamically(pdf_path):
    """
    Process any PDF with dynamic table detection
    """
    print("=" * 80)
    print("DYNAMIC PDF TABLE EXTRACTION")
    print("=" * 80)
    
    doc = fitz.open(pdf_path)
    pdf_name = Path(pdf_path).name
    
    all_products = []
    tables_found = 0
    
    print(f"\n📄 Processing: {pdf_name}")
    print(f"   Pages: {len(doc)}")
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        
        try:
            tables = list(page.find_tables())
            
            for table in tables:
                tables_found += 1
                products = extract_table_dynamically(table, pdf_name, page_num)
                all_products.extend(products)
                
                if products:
                    print(f"         ✓ Extracted {len(products)} products")
        
        except Exception as e:
            continue
    
    doc.close()
    
    print(f"\n📊 EXTRACTION SUMMARY:")
    print(f"   Tables found:          {tables_found}")
    print(f"   Products extracted:    {len(all_products)}")
    
    # Show sample
    if all_products:
        print(f"\n📋 SAMPLE PRODUCT:")
        sample = all_products[0]
        print(f"   SKU: {sample.get('sku')}")
        for key, value in sample.items():
            if key not in ['sku', 'pdf_source', 'page_in_pdf', 'display_metadata']:
                metadata = sample.get('display_metadata', {}).get(key, {})
                icon = metadata.get('icon', '')
                unit = metadata.get('unit', '')
                print(f"   {icon} {key}: {value} {unit}")
    
    return all_products

if __name__ == '__main__':
    # Example usage
    pdf_path = "input_pdfs/pomp-specials.pdf"
    products = process_pdf_dynamically(pdf_path)
    
    # Save to JSON
    output_path = Path("output/dynamic_extraction.json")
    output_path.parent.mkdir(exist_ok=True)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(products, f, ensure_ascii=False, indent=2)
    
    print(f"\n💾 Saved to: {output_path}")
    print("=" * 80)
