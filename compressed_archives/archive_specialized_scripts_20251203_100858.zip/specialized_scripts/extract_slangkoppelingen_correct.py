"""
Extract slangkoppelingen with correct column structure:
- Column 0: Bestelnr (SKU)
- Column 1: Maten (Size: exterior mm x interior mm)

Format: "50 mm x 40 mm" means outer=50mm, inner=40mm
"""
import fitz
import json
import re
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "slangkoppelingen.pdf"
OUTPUT_JSON = PROJECT_ROOT / "output" / "slangkoppelingen_specs.json"

def parse_maten(maten_str):
    """
    Parse 'Maten' column: '50 mm x 40 mm'
    Returns: (outer_diameter, inner_diameter) in mm
    """
    if not maten_str:
        return None, None
    
    # Pattern: "50 mm x 40 mm" or "50x40" or "50 x 40"
    pattern = r'(\d+(?:[.,]\d+)?)\s*(?:mm)?\s*[xX×]\s*(\d+(?:[.,]\d+)?)\s*(?:mm)?'
    match = re.search(pattern, str(maten_str))
    
    if match:
        outer = float(match.group(1).replace(',', '.'))
        inner = float(match.group(2).replace(',', '.'))
        return outer, inner
    
    return None, None

def process_pdf():
    """Process slangkoppelingen PDF"""
    print("=" * 80)
    print("EXTRACTING SLANGKOPPELINGEN WITH CORRECT STRUCTURE")
    print("=" * 80)
    
    doc = fitz.open(PDF_PATH)
    
    all_products = []
    stats = {
        'pages_processed': 0,
        'tables_found': 0,
        'products_extracted': 0,
        'with_sizes': 0,
        'without_sizes': 0
    }
    
    print(f"\n📄 Processing: {PDF_PATH.name}")
    print(f"   Total pages: {len(doc)}")
    print(f"\n⚡ Extracting products...")
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        stats['pages_processed'] += 1
        
        if (page_num + 1) % 10 == 0:
            print(f"   Processing page {page_num + 1}... ({stats['products_extracted']} products found)")
        
        # Extract tables
        try:
            tables = page.find_tables()
            for table in tables:
                stats['tables_found'] += 1
                extracted = table.extract()
                
                if not extracted or len(extracted) < 2:
                    continue
                
                # Check if this is a slangkoppelingen table
                # Should have headers: Bestelnr | Maten
                headers = extracted[0]
                if not any('bestelnr' in str(h).lower() for h in headers):
                    continue
                
                # Fixed column structure
                BESTELNR_COL = 0  # SKU
                MATEN_COL = 1     # Sizes (outer x inner)
                
                # Process rows
                for row in extracted[1:]:
                    if not row or len(row) < 2:
                        continue
                    
                    # Column 0: SKU (Bestelnr)
                    sku = str(row[BESTELNR_COL]).strip()
                    if not sku or len(sku) < 3:
                        continue
                    
                    # Build product
                    product = {
                        'sku': sku,
                        'page_in_pdf': page_num + 1
                    }
                    
                    # Column 1: Maten (outer x inner)
                    if len(row) > MATEN_COL:
                        maten = str(row[MATEN_COL]).strip()
                        outer, inner = parse_maten(maten)
                        
                        if outer and inner:
                            product['outer_diameter_mm'] = outer
                            product['inner_diameter_mm'] = inner
                            # Also set diameter_mm to the average or outer
                            product['diameter_mm'] = outer  # Use outer as main diameter
                            stats['with_sizes'] += 1
                        else:
                            stats['without_sizes'] += 1
                    
                    all_products.append(product)
                    stats['products_extracted'] += 1
                    
                    if stats['products_extracted'] <= 10:
                        outer = product.get('outer_diameter_mm', 'N/A')
                        inner = product.get('inner_diameter_mm', 'N/A')
                        print(f"      ✓ {sku:20} | Outer: {outer:6} mm | Inner: {inner:6} mm")
                        
        except Exception as e:
            continue
    
    doc.close()
    
    # Save results
    OUTPUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(all_products, f, ensure_ascii=False, indent=2)
    
    # Statistics
    print(f"\n📊 EXTRACTION STATISTICS:")
    print(f"   Pages processed:       {stats['pages_processed']}")
    print(f"   Tables found:          {stats['tables_found']}")
    print(f"   Products extracted:    {stats['products_extracted']}")
    print(f"   With outer/inner:      {stats['with_sizes']}")
    print(f"   Without sizes:         {stats['without_sizes']}")
    print(f"   Coverage:              {stats['with_sizes']/max(1,stats['products_extracted'])*100:.1f}%")
    
    # Show samples
    print(f"\n📋 SAMPLE PRODUCTS:")
    for product in all_products[:5]:
        print(f"\n   SKU: {product['sku']}")
        if 'outer_diameter_mm' in product:
            print(f"      Outer diameter: {product['outer_diameter_mm']} mm")
            print(f"      Inner diameter: {product['inner_diameter_mm']} mm")
    
    print(f"\n💾 Output saved to: {OUTPUT_JSON}")
    print(f"\n{'='*80}")
    print("✅ EXTRACTION COMPLETE")
    print("="*80)
    
    return all_products

if __name__ == '__main__':
    process_pdf()
