"""
Universal Product Grouping Script
Groups products from the same table/page into product families with shared images.
Works with any catalog that has table-based products.
"""

import json
import re
from pathlib import Path
from typing import Dict, List, Any, Optional
from collections import defaultdict
import sys

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"


def extract_product_family(sku: str) -> str:
    """
    Extract the product family from SKU.
    Examples:
    - ABSBU016 -> ABSBU
    - DEMAC04520 -> DEMAC
    - B77050040 -> B77
    """
    # Match letters at the start (and optionally some digits that are part of the family)
    match = re.match(r'^([A-Z]+\d*)', sku)
    if match:
        family = match.group(1)
        # For families like B77, keep the digits
        # For families like ABSBU, keep only letters
        return family
    return sku[:4]  # Fallback


def find_image_for_group(page_num: int, family: str, group_skus: List[str], catalog_name: str) -> Optional[str]:
    """
    Find the best image for a product group by looking for actual image files.
    IMPROVED: Better matching for table-based products where one image represents multiple SKUs.
    """
    images_dir = PROJECT_ROOT / "product-images-by-pdf" / catalog_name
    
    if not images_dir.exists():
        return None
    
    # Get all images in the directory for pattern matching
    all_images = list(images_dir.glob("*.webp"))
    
    if not all_images:
        return None
    
    # Strategy 1: Exact SKU match at start of filename
    # This works for images like "9B77050040_slangkoppelingen_p004.webp"
    for sku in group_skus:
        for img in all_images:
            img_name_upper = img.name.upper()
            sku_upper = sku.upper()
            
            # Try exact match or partial match (some SKUs may have prefixes removed in filenames)
            if img_name_upper.startswith(sku_upper):
                rel_path = img.relative_to(PROJECT_ROOT)
                return str(rel_path).replace('\\', '/')
            
            # Try without leading letters (e.g., "B77050040" matches "77050040_...")
            sku_numbers = ''.join(c for c in sku if c.isdigit())
            if len(sku_numbers) >= 4 and img_name_upper.startswith(sku_numbers):
                rel_path = img.relative_to(PROJECT_ROOT)
                return str(rel_path).replace('\\', '/')
    
    # Strategy 2: Match by page and family/SKU partial match
    # This handles cases where image filename contains partial SKU or family code
    page_patterns = [
        f"_p{page_num:03d}",  # e.g., _p005
        f"_p{page_num:02d}",  # e.g., _p05  
        f"_page{page_num:03d}",  # e.g., _page005
        f"_page{page_num}",   # e.g., _page5
    ]
    
    # Try each SKU with page patterns
    for sku in sorted(group_skus):  # Sort to get consistent results
        sku_part = sku[:6] if len(sku) >= 6 else sku  # First 6 chars of SKU
        
        for pattern in page_patterns:
            for img in all_images:
                img_name = img.name.upper()
                if pattern.upper() in img_name and sku_part.upper() in img_name:
                    rel_path = img.relative_to(PROJECT_ROOT)
                    return str(rel_path).replace('\\', '/')
    
    # Strategy 3: Match by page and family code
    # For groups like "9B77 Series", try matching "B77" or "9B77"
    family_codes = [
        family,
        family.lstrip('0-9'),  # Remove leading numbers
        ''.join(c for c in family if c.isalpha()),  # Only letters
    ]
    
    for family_code in family_codes:
        if len(family_code) < 2:
            continue
        
        for pattern in page_patterns:
            for img in all_images:
                img_name_upper = img.name.upper()
                if pattern.upper() in img_name_upper and family_code.upper() in img_name_upper:
                    rel_path = img.relative_to(PROJECT_ROOT)
                    return str(rel_path).replace('\\', '/')
    
    # Strategy 4: Just match by page (last resort)
    # Get the first image from this page
    for pattern in page_patterns:
        for img in all_images:
            if pattern.upper() in img.name.upper():
                rel_path = img.relative_to(PROJECT_ROOT)
                return str(rel_path).replace('\\', '/')
    
    return None


def build_variant_properties(product: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract variant-specific properties from a product.
    """
    props = {}
    
    # Common properties to extract
    property_mappings = {
        'diameter_mm': ('diameter_mm', 'diameter_display'),
        'inner_diameter_mm': ('inner_diameter_mm', 'inner_diameter_display'),
        # Pressure variations (normalize to pressure_bar for consistency)
        'pressure_bar': ('pressure_bar', 'pressure_display', 'bar'),
        'pressure_work_bar': ('pressure_bar', 'pressure_display', 'bar'),  # Normalize work pressure to standard
        'pressure_burst_bar': ('pressure_burst_bar', 'pressure_burst_display', 'bar'),
        'pressure_max_bar': ('pressure_max_bar', 'pressure_max_display', 'bar'),
        'pressure_min_bar': ('pressure_min_bar', 'pressure_min_display', 'bar'),
        'length_m': ('length_m', 'length_display'),
        'weight_kg': ('weight_kg', 'weight_display'),
        'wall_thickness_mm': ('wall_thickness_mm', 'wall_thickness_display'),
        'material': ('material', None),
        'connection_type': ('connection_type', None),
    }
    
    for key, mapping in property_mappings.items():
        if key in product and product[key] is not None:
            # Handle both 2-tuple and 3-tuple mappings
            if len(mapping) == 3:
                prop_key, display_key, unit = mapping
            else:
                prop_key, display_key = mapping
                unit = None
            
            props[prop_key] = product[key]
            if display_key:
                # Create display format
                if unit:
                    props[display_key] = f"{product[key]} {unit}"
                elif 'mm' in key:
                    props[display_key] = f"{product[key]} mm"
                elif 'bar' in key:
                    props[display_key] = f"{product[key]} bar"
                elif 'm' in key and 'mm' not in key:
                    props[display_key] = f"{product[key]} m"
                elif 'kg' in key:
                    props[display_key] = f"{product[key]} kg"
                else:
                    props[display_key] = str(product[key])
    
    return props


def create_variant_label(sku: str, properties: Dict[str, Any]) -> str:
    """
    Create a human-readable label for a variant.
    """
    parts = [sku]
    
    # Add key differentiating properties
    if 'diameter_display' in properties:
        parts.append(f"ø {properties['diameter_display']}")
    elif 'inner_diameter_display' in properties:
        parts.append(f"ø {properties['inner_diameter_display']}")
    
    if 'pressure_display' in properties:
        parts.append(properties['pressure_display'])
    elif 'pressure_work_display' in properties:
        parts.append(properties['pressure_work_display'])
    
    if 'length_display' in properties:
        parts.append(properties['length_display'])
    
    return " - ".join(parts)


def find_common_properties(variants: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Find properties that are common across all variants.
    """
    if not variants:
        return {}
    
    common = {}
    first_variant = variants[0]
    
    for key, value in first_variant.items():
        if value is None:
            continue
        
        # Check if this property is the same for all variants
        if all(v.get(key) == value for v in variants[1:]):
            common[key] = value
    
    return common


def group_products_by_table(products: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    """
    Group products by page and SKU family.
    """
    groups = defaultdict(list)
    
    for product in products:
        page = product.get("page_in_pdf")
        sku = product.get("sku")
        
        if not page or not sku:
            continue
        
        family = extract_product_family(sku)
        group_key = f"page{page}_{family}"
        groups[group_key].append(product)
    
    return groups


def create_product_group(group_id: str, products: List[Dict[str, Any]], catalog_name: str) -> Dict[str, Any]:
    """
    Create a product group with variants from a list of products.
    """
    if not products:
        return None
    
    # Sort products by SKU for consistent ordering
    products = sorted(products, key=lambda p: p.get("sku", ""))
    
    # Use first product as template for shared data
    template = products[0]
    page = template.get("page_in_pdf")
    catalog = template.get("catalog", catalog_name)
    family = extract_product_family(template.get("sku", ""))
    
    # Get all SKUs for image matching
    group_skus = [p.get("sku") for p in products if p.get("sku")]
    
    # Find shared image for this group
    image_path = find_image_for_group(page, family, group_skus, catalog_name)
    media = []
    if image_path:
        media.append({
            "url": image_path,
            "role": "main"
        })
    
    # Create variants
    variants = []
    variant_props_list = []
    for product in products:
        sku = product.get("sku")
        props = build_variant_properties(product)
        variant_label = create_variant_label(sku, props)
        variant_props_list.append(props)
        
        variants.append({
            "sku": sku,
            "label": variant_label,
            "properties": props,
            "attributes": props,  # Alias for compatibility
            "page_in_pdf": product.get("page_in_pdf")
        })
    
    # Find common properties across all variants
    common_properties = find_common_properties(variant_props_list)
    
    # Determine the main differentiating property
    differentiator = "variants"
    if any('length_m' in v['properties'] for v in variants):
        differentiator = "length"
    elif any('diameter_mm' in v['properties'] for v in variants):
        differentiator = "diameter"
    
    # Create group name
    pressure_str = ""
    if 'pressure_work_bar' in common_properties:
        pressure_str = f" - {common_properties['pressure_work_bar']} bar"
    elif 'pressure_bar' in common_properties:
        pressure_str = f" - {common_properties['pressure_bar']} bar"
    
    group_name = f"{family} Series{pressure_str}"
    
    return {
        "group_id": group_id,
        "type": "product_group",
        "catalog": catalog,
        "family": family,
        "name": group_name,
        "page_in_pdf": page,
        "media": media,
        "common_properties": common_properties,
        "variants": variants,
        "variant_count": len(variants),
        "default_variant_sku": variants[0]["sku"],
        "brand": template.get("brand", "Dema"),
        "description": f"{group_name} - Available in {len(variants)} variants"
    }


def process_catalog(catalog_name: str, input_json_path: Path, output_json_path: Path):
    """
    Process a catalog and create product groups.
    """
    print(f"\n{'='*80}")
    print(f"GROUPING PRODUCTS FOR: {catalog_name.upper()}")
    print(f"{'='*80}\n")
    
    # Load products
    if not input_json_path.exists():
        print(f"❌ Input JSON not found: {input_json_path}")
        return None
    
    with input_json_path.open("r", encoding="utf-8") as f:
        products = json.load(f)
    
    print(f"📦 Loaded {len(products)} products from {input_json_path.name}")
    
    # Check for images directory
    images_dir = PROJECT_ROOT / "product-images-by-pdf" / catalog_name
    if images_dir.exists():
        image_count = len(list(images_dir.glob("*.webp")))
        print(f"🖼️  Found {image_count} images in {catalog_name}")
    else:
        print(f"⚠️  No images directory found at {images_dir}")
    
    # Group products by table
    print("\n🔍 Grouping products by table...")
    groups_dict = group_products_by_table(products)
    print(f"   Found {len(groups_dict)} potential product groups")
    
    # Create product groups
    print("\n🏗️  Building product groups...")
    product_groups = []
    stats = {
        "total_groups": 0,
        "total_variants": 0,
        "groups_with_images": 0,
    }
    
    for group_id, group_products in sorted(groups_dict.items()):
        if len(group_products) < 2:
            # Skip single products (not part of a table)
            continue
        
        group = create_product_group(group_id, group_products, catalog_name)
        if group:
            product_groups.append(group)
            stats["total_groups"] += 1
            stats["total_variants"] += len(group["variants"])
            if group["media"]:
                stats["groups_with_images"] += 1
            
            # Show first few groups
            if stats["total_groups"] <= 5:
                print(f"\n   ✓ {group['name']}")
                print(f"      Family: {group['family']}, Page: {group['page_in_pdf']}")
                print(f"      Variants: {len(group['variants'])}")
                print(f"      SKUs: {', '.join([v['sku'] for v in group['variants'][:3]])}")
                if len(group['variants']) > 3:
                    print(f"            ... and {len(group['variants']) - 3} more")
    
    # Save output
    print(f"\n📊 GROUPING STATISTICS:")
    print(f"   Product groups created:     {stats['total_groups']}")
    print(f"   Total variants:             {stats['total_variants']}")
    print(f"   Groups with images:         {stats['groups_with_images']}")
    if stats['total_groups'] > 0:
        print(f"   Avg variants per group:     {stats['total_variants'] / stats['total_groups']:.1f}")
    
    if product_groups:
        # Sort by group_id for consistency
        product_groups.sort(key=lambda x: x['group_id'])
        
        with output_json_path.open("w", encoding="utf-8") as f:
            json.dump(product_groups, f, indent=2, ensure_ascii=False)
        
        print(f"\n💾 Output saved to: {output_json_path}")
        
        # Show sample
        print(f"\n📋 SAMPLE PRODUCT GROUPS:\n")
        for group in product_groups[:3]:
            print(f"   {group['name']}")
            print(f"   └─ {group['variant_count']} variants:")
            for variant in group['variants'][:3]:
                print(f"      • {variant['label']}")
            if len(group['variants']) > 3:
                print(f"      ... and {len(group['variants']) - 3} more\n")
    else:
        print("\n⚠️  No product groups created (all products are singles)")
    
    print(f"\n{'='*80}")
    print("✅ GROUPING COMPLETE")
    print(f"{'='*80}\n")
    
    return product_groups


# Catalog configurations
CATALOGS = {
    "slangkoppelingen": {
        "input": "slangkoppelingen_dynamic.json",
        "output": "slangkoppelingen_grouped.json",
        "catalog_name": "slangkoppelingen"
    },
    "plat-oprolbare-slangen": {
        "input": "plat_oprolbare_slangen_dynamic.json",
        "output": "plat_oprolbare_slangen_grouped.json",
        "catalog_name": "plat-oprolbare-slangen"
    },
    "pomp-specials": {
        "input": "pomp_specials_dynamic.json",
        "output": "pomp_specials_grouped.json",
        "catalog_name": "pomp-specials"
    },
    "aandrijftechniek": {
        "input": "aandrijftechniek_dynamic.json",
        "output": "aandrijftechniek_grouped.json",
        "catalog_name": "catalogus-aandrijftechniek-150922"
    },
    "rubber-slangen": {
        "input": "rubber_slangen_dynamic.json",
        "output": "rubber_slangen_grouped.json",
        "catalog_name": "rubber-slangen"
    },
    "pu-afzuigslangen": {
        "input": "pu_afzuigslangen_dynamic.json",
        "output": "pu_afzuigslangen_grouped.json",
        "catalog_name": "pu-afzuigslangen"
    },
    "slangklemmen": {
        "input": "slangklemmen_dynamic.json",
        "output": "slangklemmen_grouped.json",
        "catalog_name": "slangklemmen"
    },
    "drukbuizen": {
        "input": "drukbuizen_dynamic.json",
        "output": "drukbuizen_grouped.json",
        "catalog_name": "drukbuizen"
    },
    "pe-buizen": {
        "input": "pe_buizen_dynamic.json",
        "output": "pe_buizen_grouped.json",
        "catalog_name": "pe-buizen"
    },
    "verzinkte-buizen": {
        "input": "verzinkte_buizen_dynamic.json",
        "output": "verzinkte_buizen_grouped.json",
        "catalog_name": "verzinkte-buizen"
    },
    # Phase 2: Fittings
    "messing-draadfittingen": {
        "input": "messing_draadfittingen_dynamic.json",
        "output": "messing_draadfittingen_grouped.json",
        "catalog_name": "messing-draadfittingen"
    },
    "rvs-draadfittingen": {
        "input": "rvs_draadfittingen_dynamic.json",
        "output": "rvs_draadfittingen_grouped.json",
        "catalog_name": "rvs-draadfittingen"
    },
    "zwarte-draad-en-lasfittingen": {
        "input": "zwarte_draad_en_lasfittingen_dynamic.json",
        "output": "zwarte_draad_en_lasfittingen_grouped.json",
        "catalog_name": "zwarte-draad-en-lasfittingen"
    },
    "kunststof-afvoerleidingen": {
        "input": "kunststof_afvoerleidingen_dynamic.json",
        "output": "kunststof_afvoerleidingen_grouped.json",
        "catalog_name": "kunststof-afvoerleidingen"
    },
    # Phase 3: Pumps
    "centrifugaalpompen": {
        "input": "centrifugaalpompen_dynamic.json",
        "output": "centrifugaalpompen_grouped.json",
        "catalog_name": "centrifugaalpompen"
    },
    "dompelpompen": {
        "input": "dompelpompen_dynamic.json",
        "output": "dompelpompen_grouped.json",
        "catalog_name": "dompelpompen"
    },
    "bronpompen": {
        "input": "bronpompen_dynamic.json",
        "output": "bronpompen_grouped.json",
        "catalog_name": "bronpompen"
    },
    "zuigerpompen": {
        "input": "zuigerpompen_dynamic.json",
        "output": "zuigerpompen_grouped.json",
        "catalog_name": "zuigerpompen"
    },
    "pompentoebehoren": {
        "input": "pompentoebehoren_dynamic.json",
        "output": "pompentoebehoren_grouped.json",
        "catalog_name": "pompentoebehoren"
    },
    # Phase 4: Brand Catalogs
    "makita-catalogus": {
        "input": "makita_catalogus_dynamic.json",
        "output": "makita_catalogus_grouped.json",
        "catalog_name": "makita-catalogus"
    },
    "makita-tuinfolder": {
        "input": "makita_tuinfolder_dynamic.json",
        "output": "makita_tuinfolder_grouped.json",
        "catalog_name": "makita-tuinfolder"
    },
    "kranzle-catalogus": {
        "input": "kranzle_catalogus_dynamic.json",
        "output": "kranzle_catalogus_grouped.json",
        "catalog_name": "kranzle-catalogus"
    },
    "airpress-catalogus-nl": {
        "input": "airpress_catalogus_nl_dynamic.json",
        "output": "airpress_catalogus_nl_grouped.json",
        "catalog_name": "airpress-catalogus-nl"
    }
}


if __name__ == "__main__":
    # Check if specific catalog requested
    if len(sys.argv) > 1:
        catalog_key = sys.argv[1]
        if catalog_key not in CATALOGS:
            print(f"❌ Unknown catalog: {catalog_key}")
            print(f"Available catalogs: {', '.join(CATALOGS.keys())}")
            sys.exit(1)
        
        catalogs_to_process = [catalog_key]
    else:
        # Process all catalogs
        catalogs_to_process = list(CATALOGS.keys())
    
    results = {}
    for catalog_key in catalogs_to_process:
        config = CATALOGS[catalog_key]
        input_path = OUTPUT_DIR / "archive" / "catalog_extractions" / config["input"]
        output_path = OUTPUT_DIR / f"{config['output']}"
        
        result = process_catalog(config["catalog_name"], input_path, output_path)
        results[catalog_key] = result
    
    # Summary
    print(f"\n{'='*80}")
    print("SUMMARY OF ALL CATALOGS")
    print(f"{'='*80}\n")
    for catalog_key, groups in results.items():
        if groups:
            total_variants = sum(g['variant_count'] for g in groups)
            print(f"✓ {catalog_key.upper()}")
            print(f"   Groups: {len(groups)}, Variants: {total_variants}")
        else:
            print(f"⚠️  {catalog_key.upper()}: No groups created")
    print()
