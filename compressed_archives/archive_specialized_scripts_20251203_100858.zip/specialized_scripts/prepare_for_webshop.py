"""
Prepare products for webshop: convert image paths and add missing fields
"""

import json
from pathlib import Path

INPUT_FILE = Path("output/products_relinked.json")
OUTPUT_FILE = Path("output/products_ready_for_webshop.json")

CATALOG_CATEGORIES = {
    "abs-persluchtbuizen": "Persluchtbuizen",
    "airpress-catalogus-eng": "Compressoren & Accessoires",
    "airpress-catalogus-nl-fr": "Compressoren & Accessoires",
    "bronpompen": "Bronpompen",
    "catalogus-aandrijftechniek-150922": "Aandrijftechniek",
    "centrifugaalpompen": "Centrifugaalpompen",
    "dompelpompen": "Dompelpompen",
    "drukbuizen": "Drukbuizen",
    "gardena-assortiment": "Tuinartikelen",
    "hogedrukreiniger": "Hogedrukreinigers",
    "industrile-slangen": "Industriële Slangen",
    "kranzle-catalogus-2021-nl-1": "Hogedrukreinigers Kränzle",
    "kunststof-afvoerleidingen": "Kunststof Afvoerleidingen",
    "makita-catalogus-2022-nl": "Elektrisch Gereedschap Makita",
    "makita-tuinfolder-2022-nl": "Tuingereedschap Makita",
    "messing-draadfittingen": "Messing Fittingen",
    "pe-buizen": "PE Buizen & Hulpstukken",
    "plat-oprolbare-slangen": "Plat Oprolbare Slangen",
    "pomp-specials": "Pomp Specials",
    "pu-afzuigslangen": "PU Afzuigslangen",
    "rvs-draadfittingen": "RVS Fittingen",
    "slangklemmen": "Slangklemmen",
    "slangkoppelingen": "Slangkoppelingen",
    "verzinkte-buizen": "Verzinkte Buizen",
    "zwarte-draad-en-lasfittingen": "Zwarte Draad- & Lasfittingen",
    "digitale-versie-pompentoebehoren-compressed": "Pomp Toebehoren",
}

CATALOG_BRANDS = {
    "airpress-catalogus-eng": "Airpress",
    "airpress-catalogus-nl-fr": "Airpress",
    "kranzle-catalogus-2021-nl-1": "Kränzle",
    "makita-catalogus-2022-nl": "Makita",
    "makita-tuinfolder-2022-nl": "Makita",
    "gardena-assortiment": "Gardena",
}

print("🔧 Preparing products for webshop...")

with INPUT_FILE.open("r", encoding="utf-8") as f:
    products = json.load(f)

print(f"   Loaded {len(products)} products")

for product in products:
    # Fix image paths: ../product-images/ -> /product-images/
    if product.get("image_paths"):
        product["image_paths"] = [
            path.replace("../product-images/", "/product-images/")
            for path in product["image_paths"]
        ]
    
    # Fix media URLs
    if product.get("media"):
        for media_item in product["media"]:
            if media_item.get("url"):
                media_item["url"] = media_item["url"].replace("../product-images/", "/product-images/")
    
    # Add imageUrl (first image)
    if product.get("image_paths"):
        product["imageUrl"] = product["image_paths"][0]
    
    # Add proper category
    catalog = product.get("catalog", "")
    proper_category = CATALOG_CATEGORIES.get(catalog, product.get("category", ""))
    product["product_category"] = proper_category
    product["category"] = proper_category  # Keep both for compatibility
    
    # Add brand
    brand = CATALOG_BRANDS.get(catalog, product.get("brand"))
    product["brand"] = brand
    
    # Add pdf_source from source
    if product.get("source") and product["source"].get("pdf_sources"):
        product["pdf_source"] = product["source"]["pdf_sources"][0]
    
    # Add source_pages from source
    if product.get("source") and product["source"].get("pages"):
        product["source_pages"] = product["source"]["pages"]
    
    # Add price fields for compatibility
    price_data = product.get("price", {})
    if isinstance(price_data, dict):
        product["priceMode"] = price_data.get("mode", "request_quote")
        product["price"] = price_data.get("amount")
        product["inStock"] = True if price_data.get("amount") else None

with OUTPUT_FILE.open("w", encoding="utf-8") as f:
    json.dump(products, f, ensure_ascii=False, indent=2)

with_images = len([p for p in products if p.get("image_paths")])

print(f"\n✅ Done!")
print(f"   Saved to: {OUTPUT_FILE}")
print(f"   Products: {len(products)}")
print(f"   With images: {with_images} ({with_images/len(products)*100:.1f}%)")

# Show sample
sample = next((p for p in products if p.get("image_paths")), products[0])
print(f"\n📋 Sample product:")
print(f"   SKU: {sample['sku']}")
print(f"   Name: {sample.get('name')}")
print(f"   Category: {sample.get('product_category')}")
print(f"   Images: {len(sample.get('image_paths', []))}")
if sample.get("image_paths"):
    print(f"   First image: {sample['image_paths'][0][:80]}...")
