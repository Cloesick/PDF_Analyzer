"""
Integrate Exhaustive Extraction Results
Merges all 1,160 SKUs with images and data into the webshop
"""
import json
import shutil
from pathlib import Path
from datetime import datetime
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"
IMAGE_DIR = PROJECT_ROOT / "product-images-by-pdf"

# Source files
EXHAUSTIVE_DATA = OUTPUT_DIR / "exhaustive_makita_extraction.json"
TRANSLATED_CATALOG = OUTPUT_DIR / "makita-catalogus-2022-nl_products_translated.json"
TRANSLATED_TUINFOLDER = OUTPUT_DIR / "makita-tuinfolder-2022-nl_products_translated.json"
WEBSHOP_PRODUCTS = OUTPUT_DIR / "products_ready_for_webshop.json"

# Translation config
from property_translation_config import (
    translate_property_name,
    get_property_icon,
    get_value_icon
)

def load_json(filepath):
    """Load JSON file"""
    if not filepath.exists():
        return None
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_json(filepath, data):
    """Save JSON file"""
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def extract_price_from_text(prices_list):
    """Extract clean price from price mentions"""
    if not prices_list:
        return None
    
    for price_str in prices_list:
        # Remove € and convert to float
        try:
            price_clean = price_str.replace('€', '').replace('.', '').replace(',', '.').strip()
            price_float = float(price_clean)
            if 10 < price_float < 10000:  # Reasonable range
                return price_float
        except:
            continue
    
    return None

def create_specs_from_properties(properties, sku):
    """Create specs array with icons from properties"""
    specs = []
    
    for key, value in properties.items():
        if not value or str(value).strip() in ['None', '', '-']:
            continue
        
        # Skip column identifiers
        if key.startswith('col_') and key != 'col_0':
            # Try to get property name from translated data
            prop_name = translate_property_name(str(value).split()[0] if ' ' in str(value) else str(value))
        else:
            prop_name = translate_property_name(key)
        
        value_str = str(value).strip()
        
        # Get icons
        prop_icon = get_property_icon(prop_name)
        value_icon = get_value_icon(value_str)
        
        icon_value = f"{prop_icon} {value_str} {value_icon}".strip()
        
        specs.append({
            'name': prop_name,
            'value': icon_value,
            'value_plain': value_str,
            'icon_display': True
        })
    
    return specs

def get_best_image_for_sku(sku_data):
    """Get the best representative image for a SKU"""
    images = sku_data.get('images', [])
    
    if not images:
        return None
    
    # Prefer images with SKU in filename
    sku_clean = sku_data['sku'].upper()
    for img in images:
        if sku_clean in Path(img).stem.upper():
            return img
    
    # Otherwise return first image
    return images[0] if images else None

def integrate_exhaustive_data():
    """Integrate exhaustive extraction into webshop"""
    
    print("="*80)
    print("INTEGRATING EXHAUSTIVE EXTRACTION")
    print("="*80)
    
    # Load all data
    print("\n📂 Loading data...")
    exhaustive = load_json(EXHAUSTIVE_DATA)
    translated_catalog = load_json(TRANSLATED_CATALOG)
    translated_tuinfolder = load_json(TRANSLATED_TUINFOLDER)
    webshop_products = load_json(WEBSHOP_PRODUCTS)
    
    if not exhaustive:
        print("❌ Exhaustive extraction data not found!")
        print("   Run: python exhaustive_makita_extraction.py")
        return
    
    print(f"  ✅ Exhaustive: {len(exhaustive['skus'])} SKUs")
    print(f"  ✅ Translated catalog: {len(translated_catalog or [])} products")
    print(f"  ✅ Translated tuinfolder: {len(translated_tuinfolder or [])} products")
    print(f"  ✅ Webshop: {len(webshop_products or [])} products")
    
    # Create lookup for existing translated data
    translated_lookup = {}
    
    if translated_catalog:
        for product in translated_catalog:
            sku = product.get('sku', '').upper().replace(' ', '').replace('-', '')
            if sku:
                translated_lookup[sku] = product
    
    if translated_tuinfolder:
        for product in translated_tuinfolder:
            sku = product.get('sku', '').upper().replace(' ', '').replace('-', '')
            if sku:
                translated_lookup[sku] = product
    
    print(f"\n📋 Translated data available for: {len(translated_lookup)} SKUs")
    
    # Create lookup for existing webshop products
    existing_makita = {}
    other_products = []
    
    if webshop_products:
        for product in webshop_products:
            if product.get('brand') == 'Makita' or 'makita' in product.get('catalog', '').lower():
                sku = product.get('sku', '').upper().replace(' ', '').replace('-', '')
                if sku:
                    existing_makita[sku] = product
            else:
                other_products.append(product)
    
    print(f"  Existing Makita in webshop: {len(existing_makita)}")
    print(f"  Other products: {len(other_products)}")
    
    # Process exhaustive data
    print(f"\n🔄 Processing {len(exhaustive['skus'])} SKUs...")
    
    integrated_products = []
    new_skus = 0
    updated_skus = 0
    skipped_skus = 0
    
    for sku, sku_data in exhaustive['skus'].items():
        sku_clean = sku.upper().replace(' ', '').replace('-', '')
        
        # Check if we have translated data
        if sku_clean in translated_lookup:
            # Use high-quality translated data
            product = translated_lookup[sku_clean].copy()
            updated_skus += 1
        elif sku_clean in existing_makita:
            # Use existing webshop data
            product = existing_makita[sku_clean].copy()
            updated_skus += 1
        else:
            # Create new product from exhaustive data
            product = {
                'id': f"makita_{sku_clean.lower()}",
                'sku': sku,
                'brand': 'Makita',
                'category': 'Power Tools',
                'catalog': sku_data['pdf_source'],
                'name': sku,
                'description': f"Makita {sku}",
            }
            new_skus += 1
        
        # Add/update images
        best_image = get_best_image_for_sku(sku_data)
        if best_image:
            # Convert to webshop path
            rel_path = Path(best_image).relative_to(PROJECT_ROOT)
            image_url = f"/product-images/{rel_path.as_posix()}"
            
            product['media'] = [{
                'url': image_url,
                'role': 'main',
                'type': 'image'
            }]
            
            # Add all images
            for img_path in sku_data['images'][:5]:  # Limit to 5 images
                rel_path = Path(img_path).relative_to(PROJECT_ROOT)
                if rel_path.as_posix() != product['media'][0]['url']:
                    product['media'].append({
                        'url': f"/product-images/{rel_path.as_posix()}",
                        'role': 'gallery',
                        'type': 'image'
                    })
        
        # Add/update price
        if sku_data.get('prices'):
            price = extract_price_from_text(sku_data['prices'])
            if price:
                product['price'] = {
                    'amount': price,
                    'currency': 'EUR',
                    'excl_vat': price,
                    'display': f"€{price:.2f}"
                }
        
        # Add specs if not already present
        if 'specs' not in product or not product['specs']:
            if sku_data.get('properties'):
                specs = create_specs_from_properties(sku_data['properties'], sku)
                if specs:
                    product['specs'] = specs
        
        # Add source info
        product['source_pages'] = sku_data.get('pages', [])
        product['pdf_source'] = sku_data['pdf_source']
        
        integrated_products.append(product)
        
        if len(integrated_products) % 100 == 0:
            print(f"  Processed {len(integrated_products)}/{len(exhaustive['skus'])} SKUs...")
    
    # Combine with other products
    print(f"\n📦 Combining with existing products...")
    final_products = other_products + integrated_products
    
    # Create backup
    if WEBSHOP_PRODUCTS.exists():
        backup_name = f"products_ready_for_webshop_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        backup_path = OUTPUT_DIR / backup_name
        shutil.copy(WEBSHOP_PRODUCTS, backup_path)
        print(f"  ✅ Backup created: {backup_name}")
    
    # Save integrated data
    save_json(WEBSHOP_PRODUCTS, final_products)
    
    # Also save Makita-only file for reference
    makita_only_file = OUTPUT_DIR / "makita_integrated_all.json"
    save_json(makita_only_file, integrated_products)
    
    # Statistics
    print("\n" + "="*80)
    print("INTEGRATION COMPLETE")
    print("="*80)
    
    print(f"\n📊 PROCESSING SUMMARY:")
    print(f"  New SKUs added: {new_skus}")
    print(f"  Existing SKUs updated: {updated_skus}")
    print(f"  Total Makita products: {len(integrated_products)}")
    print(f"  Other products: {len(other_products)}")
    print(f"  Final total: {len(final_products)}")
    
    # Coverage stats
    with_images = sum(1 for p in integrated_products if p.get('media'))
    with_specs = sum(1 for p in integrated_products if p.get('specs'))
    with_prices = sum(1 for p in integrated_products if p.get('price'))
    
    print(f"\n📸 COVERAGE:")
    print(f"  Products with images: {with_images}/{len(integrated_products)} ({with_images/len(integrated_products)*100:.1f}%)")
    print(f"  Products with specs: {with_specs}/{len(integrated_products)} ({with_specs/len(integrated_products)*100:.1f}%)")
    print(f"  Products with prices: {with_prices}/{len(integrated_products)} ({with_prices/len(integrated_products)*100:.1f}%)")
    
    print(f"\n💾 OUTPUT FILES:")
    print(f"  Main: {WEBSHOP_PRODUCTS}")
    print(f"  Makita only: {makita_only_file}")
    print(f"  Backup: {backup_path}")
    
    # Sample products
    print(f"\n📋 SAMPLE INTEGRATED PRODUCTS:")
    for i, product in enumerate(integrated_products[:10]):
        img_count = len(product.get('media', []))
        spec_count = len(product.get('specs', []))
        price = product.get('price', {}).get('display', 'N/A')
        print(f"  {product['sku']}: {img_count} images, {spec_count} specs, {price}")
    
    if len(integrated_products) > 10:
        print(f"  ... and {len(integrated_products) - 10} more")
    
    print(f"\n✅ Integration complete!")
    print(f"📂 Ready to copy to webshop: {WEBSHOP_PRODUCTS}")

if __name__ == '__main__':
    integrate_exhaustive_data()
