#!/usr/bin/env python3
"""
Rename ALL aandrijftechniek images to use catalog prefix.

Strategy:
1. Images mapped to groups: catalogus-aandrijftechniek_pXXX_GroupName.jpeg
2. Images not mapped to groups: catalogus-aandrijftechniek_pXXX_imgYY.jpeg

This ensures ALL images have a consistent, professional naming convention.
"""

import json
import re
from pathlib import Path

def rename_all_images():
    """Rename all images in the folder to use catalog prefix"""
    
    print(f"\n{'='*80}")
    print(f"RENAMING ALL AANDRIJFTECHNIEK IMAGES")
    print(f"{'='*80}\n")
    
    # Image folder
    image_folder = Path('../DemaWebshop/dema-webshop/public/images/products/aandrijftechniek')
    if not image_folder.exists():
        print(f"❌ Image folder not found: {image_folder}")
        return
    
    # Get all image files
    all_images = list(image_folder.glob('page*.*'))
    print(f"📊 Found {len(all_images)} images with generic names (page*.*):\n")
    
    # Group by extension
    by_ext = {}
    for img in all_images:
        ext = img.suffix
        if ext not in by_ext:
            by_ext[ext] = []
        by_ext[ext].append(img)
    
    for ext, imgs in by_ext.items():
        print(f"   {ext}: {len(imgs)} files")
    
    print(f"\n{'='*80}")
    print(f"RENAME PLAN")
    print(f"{'='*80}\n")
    
    rename_map = {}
    
    for img_file in all_images:
        # Parse filename: pageXXX_imgYY.ext
        match = re.match(r'page(\d+)_img(\d+)', img_file.stem)
        if match:
            page = int(match.group(1))
            img_num = int(match.group(2))
            ext = img_file.suffix
            
            # New semantic filename
            new_filename = f"catalogus-aandrijftechniek_p{page:03d}_img{img_num:02d}{ext}"
            
            rename_map[img_file.name] = new_filename
            
            if len(rename_map) <= 10:  # Show first 10 as examples
                print(f"  {img_file.name:<25} → {new_filename}")
    
    if len(rename_map) > 10:
        print(f"  ... and {len(rename_map) - 10} more files")
    
    print(f"\n{'='*80}")
    print(f"EXECUTING RENAMES")
    print(f"{'='*80}\n")
    
    renamed_count = 0
    skipped_count = 0
    
    for old_filename, new_filename in sorted(rename_map.items()):
        old_file = image_folder / old_filename
        new_file = image_folder / new_filename
        
        if old_file.exists():
            if new_file.exists():
                print(f"  ⚠️  SKIP: {new_filename} already exists")
                skipped_count += 1
            else:
                # Rename the file
                old_file.rename(new_file)
                renamed_count += 1
                
                # Show progress every 10 files
                if renamed_count % 10 == 0:
                    print(f"  ✅ Renamed {renamed_count} files...")
        else:
            print(f"  ⚠️  NOT FOUND: {old_filename}")
            skipped_count += 1
    
    print(f"\n  ✅ Completed! Renamed {renamed_count} files total.")
    
    print(f"\n{'='*80}")
    print(f"SUMMARY")
    print(f"{'='*80}\n")
    print(f"✅ Renamed: {renamed_count} files")
    print(f"⚠️  Skipped: {skipped_count} files")
    print(f"\n📁 Location: {image_folder}")
    
    # Show current state
    print(f"\n{'='*80}")
    print(f"FINAL IMAGE INVENTORY")
    print(f"{'='*80}\n")
    
    catalog_images = list(image_folder.glob('catalogus-aandrijftechniek_*.*'))
    generic_images = list(image_folder.glob('page*.*'))
    
    print(f"  📦 Semantic (catalogus-aandrijftechniek_*): {len(catalog_images)} files")
    print(f"  📄 Generic (page*): {len(generic_images)} files")
    print(f"  📊 Total: {len(catalog_images) + len(generic_images)} files")
    
    if len(generic_images) == 0:
        print(f"\n  🎉 SUCCESS! All images now use semantic naming!")
    
    # Sample of new filenames
    print(f"\n{'='*80}")
    print(f"SAMPLE OF RENAMED FILES")
    print(f"{'='*80}\n")
    
    samples = sorted(catalog_images, key=lambda x: x.name)[:15]
    for f in samples:
        size_kb = f.stat().st_size / 1024
        print(f"  ✓ {f.name} ({size_kb:.1f} KB)")
    
    if len(catalog_images) > 15:
        print(f"  ... and {len(catalog_images) - 15} more")
    
    print(f"\n✨ SUCCESS! All images renamed to semantic catalog-prefixed names.\n")
    
    return {
        'renamed': renamed_count,
        'skipped': skipped_count,
        'total_semantic': len(catalog_images),
        'total_generic': len(generic_images)
    }

if __name__ == '__main__':
    result = rename_all_images()
    
    if result:
        if result['total_generic'] == 0:
            print(f"🎯 Perfect! All {result['total_semantic']} images now have semantic names.")
            print(f"   Format: catalogus-aandrijftechniek_pXXX_GroupName.jpeg")
            print(f"   or:     catalogus-aandrijftechniek_pXXX_imgYY.jpeg")
        print(f"\n   Visit: http://localhost:3000/catalog/aandrijftechniek-grouped\n")
