#!/usr/bin/env python3
"""
Create grouped data for the products page from products_for_shop.json
Groups products by image (same as catalog grouping)
"""

import json
from pathlib import Path
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
WEBSHOP_ROOT = PROJECT_ROOT.parent / "DemaWebshop" / "dema-webshop"
PRODUCTS_FILE = WEBSHOP_ROOT / "public" / "data" / "products_for_shop.json"
OUTPUT_FILE = WEBSHOP_ROOT / "public" / "data" / "products_all_grouped.json"

def get_image_url(product):
    """Extract the main image URL"""
    if 'imageUrl' in product and product['imageUrl']:
        return product['imageUrl']
    
    if 'media' in product and isinstance(product['media'], list):
        for media in product['media']:
            if isinstance(media, dict) and media.get('role') == 'main':
                return media.get('url')
    
    if 'image_paths' in product and isinstance(product['image_paths'], list) and product['image_paths']:
        return product['image_paths'][0]
    
    return None

def extract_properties(product):
    """Extract all properties from a product"""
    props = {}
    
    if 'attributes' in product and isinstance(product['attributes'], dict):
        props.update(product['attributes'])
    
    if 'specs' in product and isinstance(product['specs'], list):
        for spec in product['specs']:
            if isinstance(spec, dict) and 'label' in spec and 'value' in spec:
                props[spec['label']] = spec['value']
    
    for key in ['diameter', 'diameter_mm', 'length', 'length_m', 'width', 'height', 
                'weight', 'weight_kg', 'pressure', 'pressure_bar', 'pressure_max_bar',
                'material', 'connection', 'thread', 'size', 'temperature',
                'power_kw', 'voltage_v', 'flow_rate']:
        if key in product:
            props[key] = product[key]
    
    return props

def group_products_by_image(products):
    """Group products that share the same image"""
    groups = defaultdict(list)
    
    for product in products:
        image_url = get_image_url(product)
        catalog = product.get('catalog', 'unknown')
        page = product.get('page_in_pdf') or (product.get('source_pages', [0])[0] if product.get('source_pages') else 0)
        
        # Group by image + catalog + page
        key = f"{image_url}_{catalog}_{page}"
        groups[key].append(product)
    
    return groups

def create_product_group(products, group_index):
    """Create a product group from multiple products"""
    if not products:
        return None
    
    first = products[0]
    image_url = get_image_url(first)
    catalog = first.get('catalog', 'unknown')
    page = first.get('page_in_pdf') or (first.get('source_pages', [0])[0] if first.get('source_pages') else 0)
    
    # Extract properties from all products
    all_props = [extract_properties(p) for p in products]
    
    # Find common properties (same value across all products)
    common_props = {}
    variant_props = set()
    
    if all_props:
        first_props = all_props[0]
        for key, value in first_props.items():
            if all(props.get(key) == value for props in all_props):
                common_props[key] = value
            else:
                variant_props.add(key)
    
    # Create variants
    variants = []
    for product in products:
        props = extract_properties(product)
        var_props = {k: v for k, v in props.items() if k in variant_props}
        
        variant = {
            "sku": product.get('sku', product.get('id', 'UNKNOWN')),
            "label": product.get('name') or product.get('sku', 'Product'),
            "properties": var_props,
            "attributes": var_props,
            "page_in_pdf": page
        }
        variants.append(variant)
    
    # Determine group name
    if len(variants) == 1:
        group_name = variants[0]['sku']
    else:
        skus = [v['sku'] for v in variants]
        prefix = ""
        if skus:
            min_len = min(len(s) for s in skus)
            for i in range(min_len):
                if all(s[i] == skus[0][i] for s in skus):
                    prefix += skus[0][i]
                else:
                    break
        
        if prefix and len(prefix) >= 3:
            group_name = f"{prefix} Series"
        else:
            group_name = f"{catalog.replace('-', ' ').title()} Products"
    
    # Create group
    group = {
        "group_id": f"{catalog}_page{page}_group{group_index}",
        "type": "product_group",
        "catalog": catalog,
        "name": group_name,
        "page_in_pdf": page,
        "media": [],
        "common_properties": common_props,
        "variants": variants,
        "variant_count": len(variants),
        "default_variant_sku": variants[0]['sku'] if variants else None,
        "brand": first.get('brand', 'Dema'),
        "description": f"{group_name} - Available in {len(variants)} variant{'s' if len(variants) > 1 else ''}"
    }
    
    # Add image
    if image_url:
        group["media"] = [{
            "url": image_url.lstrip('/'),
            "role": "main"
        }]
    
    return group

def main():
    print("="*80)
    print("CREATING GROUPED DATA FOR PRODUCTS PAGE")
    print("="*80)
    
    # Load products
    print(f"\n📖 Loading products from: {PRODUCTS_FILE.name}")
    
    if not PRODUCTS_FILE.exists():
        print(f"❌ Products file not found!")
        return
    
    with open(PRODUCTS_FILE, 'r', encoding='utf-8') as f:
        all_products = json.load(f)
    
    print(f"✅ Loaded {len(all_products)} products")
    
    # Group by image
    print(f"\n🔗 Grouping products by image...")
    grouped = group_products_by_image(all_products)
    print(f"   Created {len(grouped)} potential groups")
    
    # Create product groups
    print(f"\n🏗️  Building product groups...")
    product_groups = []
    for idx, (key, products) in enumerate(grouped.items(), 1):
        group = create_product_group(products, idx)
        if group:
            product_groups.append(group)
    
    print(f"✅ Generated {len(product_groups)} product groups")
    
    total_variants = sum(g['variant_count'] for g in product_groups)
    print(f"   Total variants: {total_variants}")
    
    # Save
    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
        json.dump(product_groups, f, indent=2, ensure_ascii=False)
    
    print(f"\n💾 Saved to: {OUTPUT_FILE}")
    
    # Stats by catalog
    catalog_stats = defaultdict(lambda: {'groups': 0, 'variants': 0})
    for group in product_groups:
        cat = group['catalog']
        catalog_stats[cat]['groups'] += 1
        catalog_stats[cat]['variants'] += group['variant_count']
    
    print(f"\n📊 Statistics by Catalog:")
    for catalog, stats in sorted(catalog_stats.items()):
        print(f"   {catalog:35s} {stats['groups']:4d} groups, {stats['variants']:5d} variants")
    
    print(f"\n{'='*80}")
    print(f"✅ Complete! Created {len(product_groups)} groups with {total_variants} variants")
    print(f"{'='*80}")

if __name__ == "__main__":
    main()
