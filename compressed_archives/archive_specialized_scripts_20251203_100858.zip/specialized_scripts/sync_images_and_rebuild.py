"""
Sync images from PDF_Analyzer to DemaWebshop and rebuild product feed
Scans actual image files and matches them to products
"""

import json
import shutil
from pathlib import Path
from typing import Dict, List
from collections import defaultdict

PDF_ANALYZER = Path(__file__).parent
WEBSHOP = Path(r"C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop")

SOURCE_IMAGES = PDF_ANALYZER / "product-images"
DEST_IMAGES = WEBSHOP / "public" / "product-images"
PRODUCTS_JSON = WEBSHOP / "public" / "data" / "products_for_shop.json"

def scan_available_images():
    """Scan all available image files and build SKU mapping"""
    print("🔍 Scanning available images...")
    
    sku_to_images = defaultdict(list)
    total_images = 0
    
    if not SOURCE_IMAGES.exists():
        print(f"❌ Source images folder not found: {SOURCE_IMAGES}")
        return sku_to_images
    
    for catalog_dir in SOURCE_IMAGES.iterdir():
        if not catalog_dir.is_dir():
            continue
        
        catalog_name = catalog_dir.name
        
        for image_file in catalog_dir.glob("*.webp"):
            total_images += 1
            filename = image_file.name
            
            # Try to extract SKU from filename
            # Format: {SKU}_{catalog}_{page}_img{index}.webp
            # Or: {catalog}_{category}_{page}_img{index}.webp
            parts = filename.split("_")
            
            if len(parts) >= 2:
                # First part might be SKU
                potential_sku = parts[0]
                
                # Build relative URL
                relative_url = f"/product-images/{catalog_name}/{filename}"
                
                sku_to_images[potential_sku].append({
                    "url": relative_url,
                    "filename": filename,
                    "catalog": catalog_name
                })
    
    print(f"   Found {total_images} images")
    print(f"   Mapped to {len(sku_to_images)} unique SKUs")
    
    return sku_to_images


def sync_images():
    """Copy images from PDF_Analyzer to webshop"""
    print("\n📦 Syncing images...")
    
    if not SOURCE_IMAGES.exists():
        print(f"❌ Source not found: {SOURCE_IMAGES}")
        return False
    
    # Create destination if needed
    DEST_IMAGES.mkdir(parents=True, exist_ok=True)
    
    copied = 0
    skipped = 0
    
    for catalog_dir in SOURCE_IMAGES.iterdir():
        if not catalog_dir.is_dir():
            continue
        
        dest_catalog = DEST_IMAGES / catalog_dir.name
        dest_catalog.mkdir(exist_ok=True)
        
        for image_file in catalog_dir.glob("*.webp"):
            dest_file = dest_catalog / image_file.name
            
            # Only copy if doesn't exist or is different size
            if not dest_file.exists() or dest_file.stat().st_size != image_file.stat().st_size:
                shutil.copy2(image_file, dest_file)
                copied += 1
            else:
                skipped += 1
    
    print(f"   Copied: {copied} images")
    print(f"   Skipped: {skipped} (already exist)")
    return True


def update_products_with_images(sku_to_images: Dict):
    """Update products JSON with actual image paths"""
    print("\n🔧 Updating product data...")
    
    if not PRODUCTS_JSON.exists():
        print(f"❌ Products file not found: {PRODUCTS_JSON}")
        return
    
    with PRODUCTS_JSON.open("r", encoding="utf-8") as f:
        products = json.load(f)
    
    updated = 0
    with_images = 0
    
    for product in products:
        sku = product.get("sku")
        if not sku:
            continue
        
        # Check if we have images for this SKU
        if sku in sku_to_images:
            images = sku_to_images[sku]
            
            # Update media array
            media = []
            image_paths = []
            
            for idx, img in enumerate(images):
                media.append({
                    "url": img["url"],
                    "role": "main" if idx == 0 else "gallery",
                    "type": "image",
                    "format": "webp"
                })
                image_paths.append(img["url"])
            
            product["media"] = media
            product["image_paths"] = image_paths
            product["imageUrl"] = media[0]["url"] if media else None
            
            updated += 1
            with_images += 1
    
    # Save updated products
    with PRODUCTS_JSON.open("w", encoding="utf-8") as f:
        json.dump(products, f, ensure_ascii=False, indent=2)
    
    print(f"   Updated {updated} products with images")
    print(f"   Total products: {len(products)}")
    print(f"   With images: {with_images} ({with_images/len(products)*100:.1f}%)")


def main():
    print("🚀 Syncing Images and Rebuilding Product Feed\n")
    
    # Step 1: Scan available images
    sku_to_images = scan_available_images()
    
    if not sku_to_images:
        print("\n❌ No images found!")
        return
    
    # Step 2: Copy images to webshop
    if not sync_images():
        print("\n❌ Image sync failed!")
        return
    
    # Step 3: Update products with actual image paths
    update_products_with_images(sku_to_images)
    
    print("\n✅ Done!")
    print(f"\n🌐 Images are now available at:")
    print(f"   http://localhost:3000/product-images/")
    print(f"\n📱 Access from phone:")
    print(f"   http://192.168.1.156:3000/products?hasImages=true")


if __name__ == "__main__":
    main()
