#!/usr/bin/env python3
"""
Extract images for catalogs that don't have images yet
"""

import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent

# Catalogs missing images
CATALOGS_TO_EXTRACT = [
    ("catalogus-aandrijftechniek-150922", "catalogus-aandrijftechniek-150922.pdf"),
    ("digitale-versie-pompentoebehoren-compressed", "digitale-versie-pompentoebehoren-compressed.pdf")
]

def extract_images(catalog_key, pdf_name):
    """Extract images from PDF"""
    print(f"\n{'='*80}")
    print(f"EXTRACTING IMAGES: {catalog_key}")
    print(f"{'='*80}")
    
    cmd = [
        sys.executable,
        "extract_all_images_universal.py",
        pdf_name,
        catalog_key
    ]
    
    try:
        subprocess.run(cmd, cwd=PROJECT_ROOT, check=True)
        print(f"  ✅ Extracted images for {catalog_key}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"  ❌ Failed: {e}")
        return False

def main():
    print("="*80)
    print("EXTRACTING MISSING IMAGES")
    print("="*80)
    
    success_count = 0
    for catalog_key, pdf_name in CATALOGS_TO_EXTRACT:
        if extract_images(catalog_key, pdf_name):
            success_count += 1
    
    print(f"\n{'='*80}")
    print(f"✅ Extracted images for {success_count}/{len(CATALOGS_TO_EXTRACT)} catalogs")
    print(f"{'='*80}")
    
    if success_count > 0:
        print("\nNow run: python link_images_to_grouped.py")

if __name__ == "__main__":
    main()
