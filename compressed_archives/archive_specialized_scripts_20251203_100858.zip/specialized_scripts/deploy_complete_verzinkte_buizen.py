#!/usr/bin/env python3
"""
Complete deployment for verzinkte-buizen catalog.

Note: Images are already in webshop's public folder, so we just need to:
1. Create image mapping
2. Enrich with properties
3. Update frontend
"""

import json
from pathlib import Path
from collections import defaultdict
import re

def deploy_verzinkte_buizen():
    """Deploy verzinkte-buizen with image mapping and properties"""
    
    print(f"\n{'='*80}")
    print(f"COMPLETE VERZINKTE-BUIZEN DEPLOYMENT")
    print(f"{'='*80}\n")
    
    # ===================
    # STEP 1: ANALYZE IMAGES
    # ===================
    print(f"{'='*80}")
    print(f"STEP 1: ANALYZING EXISTING IMAGES")
    print(f"{'='*80}\n")
    
    # Images are already in webshop folder
    image_folder = Path('../DemaWebshop/dema-webshop/public/product-images/verzinkte-buizen')
    
    if not image_folder.exists():
        print(f"❌ Image folder not found: {image_folder}")
        return
    
    all_images = list(image_folder.glob('*.webp')) + list(image_folder.glob('*.jpeg')) + list(image_folder.glob('*.png'))
    print(f"🖼️  Total images: {len(all_images)}")
    
    # Parse images by page
    images_by_page = defaultdict(list)
    for img in all_images:
        match = re.search(r'_p(\d+)', img.name)
        if match:
            page = int(match.group(1))
            
            images_by_page[page].append({
                'page': page,
                'filename': img.name,
                'path': f"/product-images/verzinkte-buizen/{img.name}"
            })
    
    print(f"📄 Pages with images: {len(images_by_page)} pages")
    print(f"   Pages: {sorted(images_by_page.keys())}\n")
    
    # ===================
    # STEP 2: LOAD DATA
    # ===================
    print(f"{'='*80}")
    print(f"STEP 2: LOADING DATA")
    print(f"{'='*80}\n")
    
    # Load grouped data
    grouped_file = Path('../DemaWebshop/dema-webshop/public/data/verzinkte_buizen_grouped.json')
    with open(grouped_file, 'r', encoding='utf-8') as f:
        grouped_data = json.load(f)
    
    print(f"📊 Loaded grouped data: {len(grouped_data)} groups")
    
    total_variants = sum(len(g.get('variants', [])) for g in grouped_data)
    print(f"📊 Total variants: {total_variants}")
    
    # Try to load from comprehensive data
    comprehensive_file = Path('output/products_ready_for_webshop_v2_comprehensive.json')
    sku_properties = {}
    
    if comprehensive_file.exists():
        with open(comprehensive_file, 'r', encoding='utf-8') as f:
            all_products = json.load(f)
        
        # Filter verzinkte-buizen products
        for product in all_products:
            if 'verzinkte' in product.get('catalog', '').lower():
                sku = product.get('sku')
                if sku:
                    sku_properties[sku] = product
        
        print(f"📊 Loaded comprehensive data: {len(sku_properties)} verzinkte-buizen SKUs\n")
    else:
        print(f"⚠️  No comprehensive data found\n")
    
    # ===================
    # STEP 3: MAP IMAGES
    # ===================
    print(f"{'='*80}")
    print(f"STEP 3: MAPPING IMAGES TO SKUs")
    print(f"{'='*80}\n")
    
    # Group SKUs by page
    skus_by_page = defaultdict(list)
    for group in grouped_data:
        for variant in group.get('variants', []):
            page = variant.get('page_in_pdf')
            sku = variant.get('sku')
            if page and sku:
                skus_by_page[page].append(sku)
    
    print(f"📄 Pages with products: {len(skus_by_page)}")
    print(f"   Pages: {sorted(skus_by_page.keys())}\n")
    
    # Create mapping
    sku_to_image = {}
    images_used = set()
    mapped_count = 0
    
    for page in sorted(skus_by_page.keys()):
        skus = skus_by_page[page]
        images = images_by_page.get(page, [])
        
        if not images:
            print(f"⚠️  Page {page}: {len(skus)} SKUs, NO images")
            continue
        
        print(f"📄 Page {page}: {len(skus)} SKUs, {len(images)} images")
        
        for i, sku in enumerate(skus):
            # Cycle through images if more SKUs than images
            img_index = i % len(images)
            image_info = images[img_index]
            
            sku_to_image[sku] = image_info['path']
            images_used.add(image_info['filename'])
            mapped_count += 1
    
    print(f"\n{'='*80}")
    print(f"MAPPING SUMMARY")
    print(f"{'='*80}\n")
    print(f"✅ SKUs mapped: {mapped_count}")
    print(f"✅ Images used: {len(images_used)}")
    print(f"📊 Images available: {len(all_images)}")
    print(f"📊 Coverage: {mapped_count/total_variants*100:.1f}%")
    
    # Save mapping
    mapping_file = Path('../DemaWebshop/dema-webshop/public/data/verzinkte_buizen_image_mapping.json')
    with open(mapping_file, 'w', encoding='utf-8') as f:
        json.dump(sku_to_image, f, indent=2, ensure_ascii=False)
    
    print(f"\n✅ Saved: {mapping_file.name}\n")
    
    # ===================
    # STEP 4: ENRICH WITH PROPERTIES
    # ===================
    print(f"{'='*80}")
    print(f"STEP 4: ENRICHING WITH PROPERTIES")
    print(f"{'='*80}\n")
    
    enriched_count = 0
    for group in grouped_data:
        for variant in group.get('variants', []):
            sku = variant.get('sku')
            if sku and sku in sku_properties:
                props = sku_properties[sku]
                
                # Copy attributes (comprehensive data uses 'attributes', not 'properties')
                attributes = props.get('attributes', {})
                properties = props.get('properties', attributes)  # Fallback to attributes
                
                variant['properties'] = properties
                variant['attributes'] = attributes
                
                # Copy other useful fields
                for field in ['brand', 'category', 'description']:
                    if field in props:
                        variant[field] = props[field]
                
                enriched_count += 1
    
    print(f"✅ Variants enriched: {enriched_count}")
    
    if enriched_count > 0:
        print(f"📊 Enrichment rate: {enriched_count/total_variants*100:.1f}%\n")
        
        # Save enriched data
        with open(grouped_file, 'w', encoding='utf-8') as f:
            json.dump(grouped_data, f, indent=2, ensure_ascii=False)
        
        print(f"✅ Saved enriched data: {grouped_file.name}\n")
    else:
        print(f"⚠️  No properties to enrich\n")
    
    # ===================
    # FINAL SUMMARY
    # ===================
    print(f"{'='*80}")
    print(f"DEPLOYMENT COMPLETE")
    print(f"{'='*80}\n")
    print(f"📊 Total Products: {total_variants}")
    print(f"📊 With Images: {mapped_count} ({mapped_count/total_variants*100:.1f}%)")
    print(f"📊 With Properties: {enriched_count} ({enriched_count/total_variants*100:.1f}%)")
    print(f"📊 Images Used: {len(images_used)}/{len(all_images)}")
    print(f"\n✅ Ready to deploy!\n")
    
    return {
        'total': total_variants,
        'mapped': mapped_count,
        'enriched': enriched_count,
        'images_used': len(images_used),
        'images_total': len(all_images)
    }

if __name__ == '__main__':
    result = deploy_verzinkte_buizen()
    print(f"✨ Success!")
    print(f"   • {result['mapped']} products with images ({result['mapped']/result['total']*100:.1f}%)")
    print(f"   • {result['enriched']} products with properties ({result['enriched']/result['total']*100:.1f}%)")
    print(f"   • {result['images_used']}/{result['images_total']} images used\n")
