#!/usr/bin/env python3
"""
Re-extract Catalogs with Smart Property Parsing

Re-processes all catalogs using the advanced smart property parser
to extract more comprehensive and accurate product properties.
"""

import fitz
import json
import re
from pathlib import Path
from typing import Dict, List, Any, Optional
from smart_property_extractor import (
    COMPREHENSIVE_PROPERTY_MAP,
    SmartPropertyParser,
    normalize_header,
    match_header_to_property,
    parse_property_value
)

PROJECT_ROOT = Path(__file__).parent
INPUT_PDFS = PROJECT_ROOT / "input_pdfs"
OUTPUT_DIR = PROJECT_ROOT / "output"

# Catalogs to re-extract - UPDATED to include catalogus-aandrijftechniek-150922
CATALOGS_TO_PROCESS = [
    "bronpompen",
    "catalogus-aandrijftechniek-150922",  # ✅ Now included!
    "centrifugaalpompen",
    "digitale-versie-pompentoebehoren-compressed",
    "dompelpompen",
    "drukbuizen",
    "kunststof-afvoerleidingen",
    "messing-draadfittingen"
]

# PDF filename mappings
PDF_FILE_MAP = {
    "bronpompen": "bronpompen.pdf",
    "catalogus-aandrijftechniek-150922": "catalogus aandrijftechniek.pdf",
    "centrifugaalpompen": "centrifugaalpompen.pdf",
    "digitale-versie-pompentoebehoren-compressed": "digitale-versie-pompentoebehoren-compressed.pdf",
    "dompelpompen": "dompelpompen.pdf",
    "drukbuizen": "drukbuizen.pdf",
    "kunststof-afvoerleidingen": "kunststof-afvoerleidingen.pdf",
    "messing-draadfittingen": "messing-draadfittingen.pdf"
}


def is_valid_sku(text: str) -> bool:
    """Check if text looks like a valid SKU"""
    if not text or not isinstance(text, str):
        return False
    
    text = str(text).strip()
    
    # Skip header keywords
    header_keywords = [
        'bestelnr', 'code', 'artikelnr', 'sku', 'maat', 'diameter',
        'werkdruk', 'lengte', 'gewicht', 'druk', 'omschrijving',
        'description', 'price', 'prijs', 'type', 'model'
    ]
    
    if text.lower() in header_keywords:
        return False
    
    # Length checks
    if len(text) < 2 or len(text) > 30:
        return False
    
    # Must have some alphanumeric content
    alphanumeric_ratio = len(re.findall(r'[A-Za-z0-9]', text)) / len(text)
    if alphanumeric_ratio < 0.5:
        return False
    
    # Good indicators
    has_digit = bool(re.search(r'\d', text))
    has_alpha = bool(re.search(r'[A-Za-z]', text))
    
    return has_digit or (has_alpha and len(text) >= 4)


def is_header_row(row: List[str]) -> bool:
    """Check if row appears to be a header row"""
    if not row or not any(row):
        return False
    
    # Check if row contains header keywords
    row_text = ' '.join(str(cell).lower() for cell in row if cell)
    
    header_indicators = [
        'bestelnr', 'code', 'artikel', 'maat', 'diameter',
        'werkdruk', 'lengte', 'gewicht', 'type', 'model',
        'description', 'omschrijving'
    ]
    
    return any(indicator in row_text for indicator in header_indicators)


def extract_tables_from_page(page) -> List[List[List[str]]]:
    """Extract all tables from a PDF page"""
    try:
        tables = page.find_tables()
        if not tables or not tables.tables:
            return []
        
        extracted_tables = []
        for table in tables.tables:
            try:
                table_data = table.extract()
                if table_data and len(table_data) > 1:
                    extracted_tables.append(table_data)
            except:
                continue
        
        return extracted_tables
    except:
        return []


def process_table_with_smart_parsing(table_data: List[List[str]], page_num: int, catalog_key: str) -> List[Dict[str, Any]]:
    """Process table using smart property parsing"""
    if not table_data or len(table_data) < 2:
        return []
    
    products = []
    headers = []
    header_indices = {}
    sku_column = None
    
    # Find header row and map columns
    for row_idx, row in enumerate(table_data[:3]):  # Check first 3 rows for headers
        if is_header_row(row):
            headers = row
            
            # Map headers to properties
            for col_idx, header in enumerate(headers):
                if not header:
                    continue
                
                prop_info = match_header_to_property(header)
                if prop_info:
                    header_indices[col_idx] = {
                        'header': header,
                        'property': prop_info['property'],
                        'info': prop_info
                    }
                    
                    # Identify SKU column
                    if prop_info['property'] == 'sku':
                        sku_column = col_idx
            
            # Process data rows
            for data_row_idx in range(row_idx + 1, len(table_data)):
                data_row = table_data[data_row_idx]
                
                # Skip empty rows
                if not any(data_row):
                    continue
                
                # Get SKU
                sku = None
                if sku_column is not None and sku_column < len(data_row):
                    potential_sku = data_row[sku_column]
                    if is_valid_sku(potential_sku):
                        sku = potential_sku
                
                # If no valid SKU, skip this row
                if not sku:
                    continue
                
                # Extract properties
                product = {
                    'sku': sku,
                    'catalog': catalog_key,
                    'page_in_pdf': page_num,
                    'source': 'pdf_table',
                    'properties': {},
                    'raw_data': {}
                }
                
                # Parse each column
                for col_idx, col_info in header_indices.items():
                    if col_idx >= len(data_row):
                        continue
                    
                    cell_value = data_row[col_idx]
                    if not cell_value or cell_value == '':
                        continue
                    
                    # Skip SKU column (already processed)
                    if col_info['property'] == 'sku':
                        continue
                    
                    # Parse the property value
                    parsed_value = parse_property_value(cell_value, col_info['info'])
                    
                    if parsed_value is not None:
                        product['properties'][col_info['property']] = parsed_value
                        product['raw_data'][col_info['header']] = cell_value
                
                # Only add product if it has at least one property
                if product['properties']:
                    products.append(product)
            
            break  # Found header row, stop looking
    
    return products


def extract_catalog_smart(catalog_key: str) -> Optional[Dict]:
    """Extract catalog with smart property parsing"""
    print(f"\n{'='*80}")
    print(f"📖 EXTRACTING: {catalog_key.upper()}")
    print(f"{'='*80}")
    
    # Find PDF file
    pdf_filename = PDF_FILE_MAP.get(catalog_key)
    if not pdf_filename:
        print(f"  ⚠️  No PDF filename mapping for {catalog_key}")
        return None
    
    pdf_path = INPUT_PDFS / pdf_filename
    if not pdf_path.exists():
        print(f"  ⚠️  PDF not found: {pdf_path}")
        return None
    
    print(f"  📄 File: {pdf_filename}")
    
    # Open PDF
    try:
        doc = fitz.open(pdf_path)
        print(f"  📑 Pages: {len(doc)}")
    except Exception as e:
        print(f"  ❌ Error opening PDF: {e}")
        return None
    
    all_products = []
    pages_with_tables = 0
    total_properties_extracted = 0
    
    # Process each page
    for page_num in range(len(doc)):
        page = doc[page_num]
        
        # Extract tables
        tables = extract_tables_from_page(page)
        
        if tables:
            pages_with_tables += 1
            print(f"  📊 Page {page_num + 1}: Found {len(tables)} table(s)", end='')
            
            page_products = []
            for table in tables:
                products = process_table_with_smart_parsing(table, page_num + 1, catalog_key)
                page_products.extend(products)
            
            print(f" → {len(page_products)} products")
            
            all_products.extend(page_products)
            
            # Count properties
            for product in page_products:
                total_properties_extracted += len(product.get('properties', {}))
    
    doc.close()
    
    print(f"\n  ✅ Extracted {len(all_products)} products from {pages_with_tables} pages")
    print(f"  📊 Total properties: {total_properties_extracted}")
    
    if total_properties_extracted > 0:
        avg_props = total_properties_extracted / len(all_products) if all_products else 0
        print(f"  📈 Average properties per product: {avg_props:.1f}")
    
    # Save extraction
    output_file = OUTPUT_DIR / f"{catalog_key.replace('-', '_')}_smart_extracted.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_products, f, indent=2, ensure_ascii=False)
    
    print(f"  💾 Saved: {output_file.name}")
    
    return {
        'catalog': catalog_key,
        'products': len(all_products),
        'properties': total_properties_extracted,
        'avg_properties': total_properties_extracted / len(all_products) if all_products else 0
    }


def main():
    print("="*80)
    print("SMART PROPERTY RE-EXTRACTION")
    print("="*80)
    print(f"\n📝 Using {len(COMPREHENSIVE_PROPERTY_MAP)} property mappings")
    print(f"🎯 Processing {len(CATALOGS_TO_PROCESS)} catalogs\n")
    
    results = []
    for catalog in CATALOGS_TO_PROCESS:
        result = extract_catalog_smart(catalog)
        if result:
            results.append(result)
    
    print(f"\n{'='*80}")
    print("SUMMARY")
    print(f"{'='*80}\n")
    
    if results:
        print(f"{'Catalog':<45s} {'Products':<10s} {'Props':<10s} {'Avg Props':<10s}")
        print("-" * 80)
        
        for r in results:
            print(f"{r['catalog']:<45s} {r['products']:<10d} {r['properties']:<10d} {r['avg_properties']:<10.1f}")
        
        total_products = sum(r['products'] for r in results)
        total_props = sum(r['properties'] for r in results)
        avg_overall = total_props / total_products if total_products > 0 else 0
        
        print("-" * 80)
        print(f"{'TOTAL':<45s} {total_products:<10d} {total_props:<10d} {avg_overall:<10.1f}")
    
    print(f"\n{'='*80}")
    print(f"✅ COMPLETE - Re-extracted {len(results)} catalogs with smart parsing")
    print(f"{'='*80}")
    
    print("\n📊 Property Types Supported:")
    prop_types = {}
    for prop_info in COMPREHENSIVE_PROPERTY_MAP.values():
        prop_type = prop_info.get('type', 'other')
        prop_types[prop_type] = prop_types.get(prop_type, 0) + 1
    
    for prop_type, count in sorted(prop_types.items()):
        print(f"  - {prop_type.capitalize()}: {count} properties")


if __name__ == "__main__":
    main()
