#!/usr/bin/env python3
"""
Rename aandrijftechniek images from generic names to semantic group-based names.

From: pageXXX_imgYY.jpeg
To:   catalogus-aandrijftechniek_pXXX_GroupName.jpeg
"""

import json
import re
from pathlib import Path
import shutil

def rename_images_to_group_names():
    """Rename image files to use semantic group-based names"""
    
    print(f"\n{'='*80}")
    print(f"RENAMING AANDRIJFTECHNIEK IMAGES TO SEMANTIC NAMES")
    print(f"{'='*80}\n")
    
    # Load group mapping
    group_mapping_file = Path('../DemaWebshop/dema-webshop/public/data/aandrijftechniek_group_mapping.json')
    if not group_mapping_file.exists():
        print(f"❌ Group mapping not found: {group_mapping_file}")
        print(f"   Run fix_aandrijftechniek_images_v2.py first!")
        return
    
    with open(group_mapping_file, 'r', encoding='utf-8') as f:
        group_to_image = json.load(f)
    
    print(f"📊 Loaded {len(group_to_image)} group mappings\n")
    
    # Image folder
    image_folder = Path('../DemaWebshop/dema-webshop/public/images/products/aandrijftechniek')
    if not image_folder.exists():
        print(f"❌ Image folder not found: {image_folder}")
        return
    
    # Create rename map: old_filename -> new_filename
    rename_map = {}
    
    for group_id, old_path in group_to_image.items():
        # Extract filename from path
        old_filename = old_path.split('/')[-1]
        
        # Parse group_id (e.g., "page20_RLNUC205")
        match = re.match(r'page(\d+)_(.+)', group_id)
        if match:
            page = int(match.group(1))
            group_name = match.group(2)
            
            # Create new semantic filename
            new_filename = f"catalogus-aandrijftechniek_p{page:03d}_{group_name}.jpeg"
            
            # Store mapping
            rename_map[old_filename] = new_filename
    
    print(f"📋 Prepared {len(rename_map)} files for renaming\n")
    print(f"{'='*80}")
    print(f"RENAME PLAN")
    print(f"{'='*80}\n")
    
    for old, new in sorted(rename_map.items()):
        print(f"  {old:<25} → {new}")
    
    print(f"\n{'='*80}")
    print(f"EXECUTING RENAMES")
    print(f"{'='*80}\n")
    
    renamed_count = 0
    skipped_count = 0
    
    for old_filename, new_filename in rename_map.items():
        old_file = image_folder / old_filename
        new_file = image_folder / new_filename
        
        if old_file.exists():
            if new_file.exists():
                print(f"  ⚠️  SKIP: {new_filename} already exists")
                skipped_count += 1
            else:
                # Rename the file
                old_file.rename(new_file)
                print(f"  ✅ {old_filename} → {new_filename}")
                renamed_count += 1
        else:
            print(f"  ⚠️  NOT FOUND: {old_filename}")
            skipped_count += 1
    
    print(f"\n{'='*80}")
    print(f"UPDATE MAPPING FILES")
    print(f"{'='*80}\n")
    
    # Update group mapping
    updated_group_mapping = {}
    for group_id, old_path in group_to_image.items():
        old_filename = old_path.split('/')[-1]
        if old_filename in rename_map:
            new_filename = rename_map[old_filename]
            new_path = f"/images/products/aandrijftechniek/{new_filename}"
            updated_group_mapping[group_id] = new_path
        else:
            updated_group_mapping[group_id] = old_path
    
    with open(group_mapping_file, 'w', encoding='utf-8') as f:
        json.dump(updated_group_mapping, f, indent=2, ensure_ascii=False)
    
    print(f"✅ Updated: {group_mapping_file.name}")
    
    # Update SKU mapping
    sku_mapping_file = Path('../DemaWebshop/dema-webshop/public/data/aandrijftechniek_image_mapping.json')
    if sku_mapping_file.exists():
        with open(sku_mapping_file, 'r', encoding='utf-8') as f:
            sku_to_image = json.load(f)
        
        updated_sku_mapping = {}
        for sku, old_path in sku_to_image.items():
            old_filename = old_path.split('/')[-1]
            if old_filename in rename_map:
                new_filename = rename_map[old_filename]
                new_path = f"/images/products/aandrijftechniek/{new_filename}"
                updated_sku_mapping[sku] = new_path
            else:
                updated_sku_mapping[sku] = old_path
        
        with open(sku_mapping_file, 'w', encoding='utf-8') as f:
            json.dump(updated_sku_mapping, f, indent=2, ensure_ascii=False)
        
        print(f"✅ Updated: {sku_mapping_file.name}")
    
    print(f"\n{'='*80}")
    print(f"SUMMARY")
    print(f"{'='*80}\n")
    print(f"✅ Renamed: {renamed_count} files")
    print(f"⚠️  Skipped: {skipped_count} files")
    print(f"✅ Updated mapping files")
    print(f"\n📁 Location: {image_folder}")
    print(f"\n{'='*80}\n")
    
    # Show sample new filenames
    print(f"Sample renamed files:")
    renamed_files = list(image_folder.glob('catalogus-aandrijftechniek_*.jpeg'))[:10]
    for f in renamed_files:
        size_kb = f.stat().st_size / 1024
        print(f"  ✓ {f.name} ({size_kb:.1f} KB)")
    
    if len(renamed_files) > 10:
        print(f"  ... and {len(renamed_files) - 10} more")
    
    print(f"\n✨ SUCCESS! Images renamed to semantic group-based names.\n")
    
    return {
        'renamed': renamed_count,
        'skipped': skipped_count,
        'total': len(rename_map)
    }

if __name__ == '__main__':
    result = rename_images_to_group_names()
    
    if result:
        print(f"🎯 All done! Your images now have meaningful, semantic names.")
        print(f"   Visit: http://localhost:3000/catalog/aandrijftechniek-grouped\n")
