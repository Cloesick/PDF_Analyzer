#!/usr/bin/env python3
"""
Create complete aandrijftechniek data with ALL products and image mappings.

This will use all 1,369 products from the comprehensive data
and map the 87 available images to them.
"""

import json
from pathlib import Path
from collections import defaultdict
import re

def create_complete_data():
    """Create complete product data with image mappings"""
    
    print(f"\n{'='*80}")
    print(f"CREATING COMPLETE AANDRIJFTECHNIEK DATA")
    print(f"{'='*80}\n")
    
    # Load comprehensive product data
    comprehensive_file = Path('output/products_ready_for_webshop_v2_comprehensive.json')
    with open(comprehensive_file, 'r', encoding='utf-8') as f:
        all_products = json.load(f)
    
    # Filter aandrijftechniek products
    aandrijf_products = [p for p in all_products if p.get('catalog') == 'catalogus-aandrijftechniek-150922']
    print(f"📊 Total aandrijftechniek products: {len(aandrijf_products)}")
    
    # Get all available images
    image_folder = Path('../DemaWebshop/dema-webshop/public/images/products/aandrijftechniek')
    all_images = list(image_folder.glob('catalogus-aandrijftechniek_*.jpeg'))
    all_images += list(image_folder.glob('catalogus-aandrijftechniek_*.png'))
    
    print(f"🖼️  Available images: {len(all_images)}")
    
    # Parse images by page
    images_by_page = defaultdict(list)
    for img in all_images:
        match = re.search(r'_p(\d+)_', img.name)
        if match:
            page = int(match.group(1))
            img_match = re.search(r'_img(\d+)', img.name)
            img_num = int(img_match.group(1)) if img_match else 0
            
            images_by_page[page].append({
                'page': page,
                'img_num': img_num,
                'filename': img.name,
                'path': f"/images/products/aandrijftechniek/{img.name}"
            })
    
    for page in images_by_page:
        images_by_page[page].sort(key=lambda x: x['img_num'])
    
    print(f"📄 Pages with images: {len(images_by_page)} pages\n")
    
    # Group products by page
    products_by_page = defaultdict(list)
    for product in aandrijf_products:
        page = product.get('page_in_pdf')
        if page:
            products_by_page[page].append(product)
    
    print(f"{'='*80}")
    print(f"MAPPING IMAGES TO ALL PRODUCTS")
    print(f"{'='*80}\n")
    
    # Create SKU → Image mapping
    sku_to_image = {}
    images_used = 0
    products_mapped = 0
    
    for page in sorted(products_by_page.keys()):
        products = products_by_page[page]
        images = images_by_page.get(page, [])
        
        if images:
            print(f"📄 Page {page}: {len(products)} products, {len(images)} images")
            
            # Map images to products on this page
            for i, product in enumerate(products):
                sku = product.get('sku')
                if sku:
                    # Cycle through available images
                    img_index = i % len(images)
                    sku_to_image[sku] = images[img_index]['path']
                    products_mapped += 1
            
            images_used += len(images)
    
    print(f"\n{'='*80}")
    print(f"MAPPING SUMMARY")
    print(f"{'='*80}\n")
    print(f"✅ Total products: {len(aandrijf_products)}")
    print(f"✅ Products with images: {products_mapped}")
    print(f"✅ Images used: {images_used}")
    print(f"✅ Coverage: {(products_mapped / len(aandrijf_products) * 100):.1f}%")
    
    # Save mapping
    mapping_file = Path('../DemaWebshop/dema-webshop/public/data/aandrijftechniek_image_mapping_FULL.json')
    with open(mapping_file, 'w', encoding='utf-8') as f:
        json.dump(sku_to_image, f, indent=2, ensure_ascii=False)
    
    print(f"\n✅ Saved FULL mapping: {mapping_file.name}")
    print(f"   {len(sku_to_image)} SKUs mapped\n")
    
    # Show stats by page
    print(f"{'='*80}")
    print(f"TOP PAGES WITH IMAGES")
    print(f"{'='*80}\n")
    
    page_stats = []
    for page in sorted(products_by_page.keys()):
        products = products_by_page[page]
        images = images_by_page.get(page, [])
        if images:
            page_stats.append({
                'page': page,
                'products': len(products),
                'images': len(images)
            })
    
    for stat in sorted(page_stats, key=lambda x: x['products'], reverse=True)[:15]:
        print(f"   Page {stat['page']:3d}: {stat['products']:3d} products, {stat['images']:2d} images")
    
    print(f"\n{'='*80}\n")
    
    return {
        'total_products': len(aandrijf_products),
        'mapped_products': products_mapped,
        'images_available': len(all_images),
        'images_used': images_used
    }

if __name__ == '__main__':
    result = create_complete_data()
    
    print(f"✨ Complete mapping created!")
    print(f"   • {result['total_products']} total products in catalog")
    print(f"   • {result['mapped_products']} products have images")
    print(f"   • {result['images_used']} images in use")
    print(f"   • {(result['mapped_products'] / result['total_products'] * 100):.1f}% coverage\n")
    print(f"💡 Next step: Replace aandrijftechniek_image_mapping.json with the FULL version")
    print(f"   Or create complete grouped data for all 1,369 products\n")
