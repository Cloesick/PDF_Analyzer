"""
Fix concatenated table extraction - parse tables where cells are merged together
"""
import re
import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"

def parse_concatenated_table(raw_text):
    """
    Parse table data where all cells are concatenated together
    Example: "HeaderValue 1Value 2Accuplatform64Vmax64Vmax..."
    """
    
    # Define known property patterns and their expected formats
    property_patterns = [
        (r'Accuplatform', r'[\d\w\s]+'),
        (r'Inbegrepen accu\'s', r'[A-Z0-9\s\(\),\.]+'),
        (r'Inbegrepen lader', r'[A-Z0-9]+'),
        (r'Max\. uitgangsvermogen', r'[\d\s]+W'),
        (r'Maaibreedte', r'[\d,]+\s*cm'),
        (r'Maaihoogte', r'[\d\s\-]+cm'),
        (r'Capaciteit opvangbak', r'[\d\s]+l'),
        (r'Toerental onbelast', r'[\d\s\.,\-⁻¹]+'),
        (r'Aanbevolen oppervlakte', r'[\d\s\.,]+m²'),
        (r'Zelftrekkend', r'[\-\w\s]*'),
        (r'Mulching', r'\([YesNo\s]+\)'),
        (r'Gewicht', r'[\d,\s\-]+kg'),
        (r'Prijs \(excl\. btw\)', r'€\s*[\d,\.]+'),
        (r'Prijs \(incl\. btw\)', r'€\s*[\d,\.]+'),
    ]
    
    # Extract header and values
    header_match = re.match(r'Header(Value \d+)(Value \d+)', raw_text)
    if not header_match:
        # Try alternative pattern
        header_match = re.match(r'(.*?)(Value \d+)(Value \d+)', raw_text)
    
    products = [{}, {}]  # Two product columns
    
    # Parse each property
    current_pos = 0
    text = raw_text
    
    # Remove "Header" prefix
    text = re.sub(r'^Header', '', text)
    text = re.sub(r'^Value \d+Value \d+', '', text)
    
    for prop_name, value_pattern in property_patterns:
        # Try to find this property in the text
        pattern = rf'{prop_name}({value_pattern})({value_pattern})'
        match = re.search(pattern, text, re.IGNORECASE)
        
        if match:
            value1 = match.group(1).strip()
            value2 = match.group(2).strip()
            
            # Translate property name
            prop_english = translate_property(prop_name)
            
            products[0][prop_english] = value1
            products[1][prop_english] = value2
            
            print(f"  ✓ {prop_english}: '{value1}' | '{value2}'")
    
    return products

def translate_property(dutch_name):
    """Translate Dutch property to English"""
    translations = {
        'Accuplatform': 'Battery platform',
        'Inbegrepen accu\'s': 'Included batteries',
        'Inbegrepen lader': 'Included charger',
        'Max. uitgangsvermogen': 'Max. output power',
        'Maaibreedte': 'Cutting width',
        'Maaihoogte': 'Cutting height',
        'Capaciteit opvangbak': 'Collection bag capacity',
        'Toerental onbelast': 'No-load speed',
        'Aanbevolen oppervlakte': 'Recommended surface',
        'Zelftrekkend': 'Self-propelling',
        'Mulching': 'Mulching',
        'Gewicht': 'Weight',
        'Prijs (excl. btw)': 'Price excl. VAT',
        'Prijs (incl. btw)': 'Price incl. VAT',
    }
    return translations.get(dutch_name, dutch_name)

def extract_from_sample():
    """Extract from the user's sample data"""
    
    sample_data = """HeaderValue 1Value 2Accuplatform64Vmax64VmaxInbegrepen accu'sBL6440 (4,0 Ah)BL6440 (4,0 Ah)Inbegrepen laderDC64WADC64WAMax. uitgangsvermogen2300 W2300 WMaaibreedte48 cm53,4 cmMaaihoogte2 - 10 cm2 - 10 cmCapaciteit opvangbak62 l70 lToerental onbelast2,500 - 3,200 min⁻¹2,300 - 2,800 min⁻¹Aanbevolen oppervlakte1,400 m²1,600 m²Zelftrekkend--Mulching (Yes) (Yes)Gewicht24,4 - 26,1 kg25,7 - 27,6 kgPrijs (excl. btw)€ 1098,35€ 1197,52Prijs (incl. btw)€ 1329,00€ 1449,00"""
    
    print("="*80)
    print("PARSING CONCATENATED TABLE DATA")
    print("="*80)
    
    # Method 1: Manual parsing with known structure
    print("\n[METHOD 1] Manual Pattern Matching")
    print("-" * 80)
    
    # Extract data using regex patterns
    data = {}
    
    # Extract each field with specific patterns
    patterns = {
        'Battery platform': r'Accuplatform(64Vmax)64Vmax',
        'Included batteries': r'Inbegrepen accu\'s(BL6440 \(4,0 Ah\))BL6440',
        'Included charger': r'Inbegrepen lader(DC64WA)DC64WA',
        'Max. output power': r'Max\. uitgangsvermogen(2300 W)2300 W',
        'Cutting width': r'Maaibreedte(48 cm)(53,4 cm)',
        'Cutting height': r'Maaihoogte(2 - 10 cm)2 - 10 cm',
        'Collection bag capacity': r'Capaciteit opvangbak(62 l)(70 l)',
        'No-load speed': r'Toerental onbelast(2,500 - 3,200 min⁻¹)(2,300 - 2,800 min⁻¹)',
        'Recommended surface': r'Aanbevolen oppervlakte(1,400 m²)(1,600 m²)',
        'Self-propelling': r'Zelftrekkend(--)(-)',
        'Mulching': r'Mulching\((Yes)\) \((Yes)\)',
        'Weight': r'Gewicht(24,4 - 26,1 kg)(25,7 - 27,6 kg)',
        'Price excl. VAT': r'Prijs \(excl\. btw\)(€ 1098,35)(€ 1197,52)',
        'Price incl. VAT': r'Prijs \(incl\. btw\)(€ 1329,00)(€ 1449,00)',
    }
    
    product1 = {}
    product2 = {}
    
    for prop_name, pattern in patterns.items():
        match = re.search(pattern, sample_data)
        if match:
            if len(match.groups()) == 2:
                val1 = match.group(1).strip()
                val2 = match.group(2).strip()
                product1[prop_name] = val1
                product2[prop_name] = val2
                print(f"  ✓ {prop_name}: '{val1}' | '{val2}'")
            elif len(match.groups()) == 1:
                val = match.group(1).strip()
                product1[prop_name] = val
                product2[prop_name] = val
                print(f"  ✓ {prop_name}: '{val}' (both)")
    
    # Create product objects with icons
    products_with_icons = []
    
    for idx, product in enumerate([product1, product2], 1):
        product_obj = {
            'sku': f'MAKITA_MOWER_{idx}',
            'name': f'Makita Lawn Mower {idx}',
            'brand': 'Makita',
            'category': 'Garden Tools',
            'specs': []
        }
        
        # Add specs with icons
        for prop_name, value in product.items():
            icon = get_icon_for_property(prop_name, value)
            spec = {
                'name': prop_name,
                'value': f'{icon} {value}',
                'value_plain': value,
                'icon_display': True
            }
            product_obj['specs'].append(spec)
        
        # Extract prices
        if 'Price excl. VAT' in product:
            price_str = product['Price excl. VAT'].replace('€', '').replace('.', '').replace(',', '.')
            try:
                product_obj['price'] = {
                    'amount': float(price_str),
                    'currency': 'EUR',
                    'excl_vat': float(price_str),
                    'display': product['Price excl. VAT']
                }
            except:
                pass
        
        products_with_icons.append(product_obj)
    
    return products_with_icons

def get_icon_for_property(prop_name, value):
    """Get appropriate icon for property"""
    icon_map = {
        'Battery platform': '⚡',
        'Included batteries': '🔋',
        'Included charger': '🔌',
        'Max. output power': '⚡',
        'Cutting width': '✂️',
        'Cutting height': '📐',
        'Collection bag capacity': '🗑️',
        'No-load speed': '🔄',
        'Recommended surface': '📏',
        'Self-propelling': '🚜',
        'Mulching': '🌿',
        'Weight': '⚖️',
        'Price excl. VAT': '💰',
        'Price incl. VAT': '💰',
    }
    return icon_map.get(prop_name, '📋')

def main():
    print("\n" + "="*80)
    print("EXTRACTING SAMPLE TABLE")
    print("="*80)
    
    products = extract_from_sample()
    
    # Save to JSON
    output_file = OUTPUT_DIR / "makita_mowers_extracted.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(products, f, indent=2, ensure_ascii=False)
    
    print(f"\n[SAVED] {output_file}")
    print(f"[EXTRACTED] {len(products)} products")
    
    # Display formatted
    print("\n" + "="*80)
    print("FORMATTED OUTPUT WITH ICONS")
    print("="*80)
    
    for product in products:
        print(f"\n{product['name']}")
        print("-" * 80)
        for spec in product['specs']:
            print(f"  {spec['value']}")
        if 'price' in product:
            print(f"\n  💰 Price: {product['price']['display']}")
    
    print("\n" + "="*80)
    print("SOLUTION FOR TABLE EXTRACTION")
    print("="*80)
    print("""
The issue is that pdfplumber is not properly detecting column boundaries.

Solutions:
1. Use explicit table settings in pdfplumber:
   tables = page.extract_tables({
       "vertical_strategy": "explicit",
       "horizontal_strategy": "explicit",
       "explicit_vertical_lines": [...],
       "explicit_horizontal_lines": [...]
   })

2. Use OCR-based table detection (Tesseract + image processing)

3. Parse concatenated text with regex patterns (as done above)

4. Use table_settings with specific column positions:
   table_settings = {
       "vertical_strategy": "lines_strict",
       "horizontal_strategy": "lines_strict",
       "snap_tolerance": 3,
   }

For your Makita PDFs, I recommend updating extract_makita_tables_smart.py
to use better table detection settings.
    """)

if __name__ == '__main__':
    main()
