"""
Identify PDFs that need comprehensive analysis
"""
from pathlib import Path
import json

print("="*80)
print("IDENTIFYING PDFs NEEDING COMPREHENSIVE ANALYSIS")
print("="*80)

input_dir = Path('input_pdfs')
output_dir = Path('output')

all_pdfs = sorted([f.stem for f in input_dir.glob('*.pdf')])

needs_analysis = []
has_comprehensive = []

for pdf_name in all_pdfs:
    # Check for comprehensive analysis (not enriched, just the main one)
    analysis_json = output_dir / f"{pdf_name.replace('-', '_')}_analysis.json"
    
    if analysis_json.exists():
        # Check if it's comprehensive (has 'pages' with 'products_found')
        try:
            with open(analysis_json, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if 'pages' in data and data.get('total_products', 0) > 0:
                has_comprehensive.append({
                    'name': pdf_name,
                    'products': data.get('total_products', 0),
                    'images': data.get('total_images', 0)
                })
            else:
                needs_analysis.append(pdf_name)
        except:
            needs_analysis.append(pdf_name)
    else:
        needs_analysis.append(pdf_name)

print(f"\n✅ PDFs WITH COMPREHENSIVE ANALYSIS ({len(has_comprehensive)}):")
for item in has_comprehensive:
    print(f"  • {item['name']:<50} ({item['products']} products, {item['images']} images)")

print(f"\n⚠️  PDFs NEEDING COMPREHENSIVE ANALYSIS ({len(needs_analysis)}):")
for pdf_name in needs_analysis:
    pdf_path = input_dir / f"{pdf_name}.pdf"
    size_mb = pdf_path.stat().st_size / (1024 * 1024)
    print(f"  • {pdf_name:<50} ({size_mb:.1f} MB)")

print(f"\n{'='*80}")
print(f"PRIORITY PDFs FOR ANALYSIS")
print(f"{'='*80}")

# Categorize by type
pipes_and_fittings = [p for p in needs_analysis if any(term in p.lower() for term in ['buizen', 'pipes', 'fittingen', 'fittings', 'draad', 'verzinkte', 'rvs'])]
hoses = [p for p in needs_analysis if any(term in p.lower() for term in ['slang', 'hose', 'afzuig'])]
pumps = [p for p in needs_analysis if any(term in p.lower() for term in ['pomp', 'pump', 'bron', 'dompel', 'zuiger', 'centrifugaal'])]
compressors = [p for p in needs_analysis if any(term in p.lower() for term in ['airpress', 'kranzle', 'compressor'])]
other = [p for p in needs_analysis if p not in pipes_and_fittings + hoses + pumps + compressors]

if pipes_and_fittings:
    print(f"\n🔧 PIPES & FITTINGS ({len(pipes_and_fittings)}):")
    for p in pipes_and_fittings:
        print(f"  • {p}")

if hoses:
    print(f"\n🔌 HOSES & COUPLINGS ({len(hoses)}):")
    for p in hoses:
        print(f"  • {p}")

if pumps:
    print(f"\n⚙️  PUMPS ({len(pumps)}):")
    for p in pumps:
        print(f"  • {p}")

if compressors:
    print(f"\n🔊 COMPRESSORS ({len(compressors)}):")
    for p in compressors:
        print(f"  • {p}")

if other:
    print(f"\n📦 OTHER ({len(other)}):")
    for p in other:
        print(f"  • {p}")

print(f"\n{'='*80}")
print(f"RECOMMENDATION")
print(f"{'='*80}")
print(f"\nStart with smaller, similar PDFs first:")
print(f"  1. Pipes & Fittings (similar structure to pe-buizen)")
print(f"  2. Hoses (similar structure to plat-oprolbare)")
print(f"  3. Pumps (table-heavy catalogs)")
print(f"  4. Compressors (technical specs)")
print(f"  5. Makita (large, complex - save for last)")

# Save list for batch processing
with open('pdfs_needing_analysis.txt', 'w') as f:
    for pdf in needs_analysis:
        f.write(f"{pdf}\n")

print(f"\n✓ Saved list to: pdfs_needing_analysis.txt")
print("="*80)
