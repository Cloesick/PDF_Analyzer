#!/usr/bin/env python3
"""
Create comprehensive SKU→Image mapping using ALL 87 images.

Strategy: Match images to SKUs by page number and sequential order.
- Products on same page get images from that page
- Images assigned sequentially to products on each page
"""

import json
from pathlib import Path
from collections import defaultdict
import re

def map_all_images():
    """Create comprehensive mapping using all available images"""
    
    print(f"\n{'='*80}")
    print(f"COMPREHENSIVE IMAGE MAPPING - ALL 87 IMAGES")
    print(f"{'='*80}\n")
    
    # Load grouped products
    grouped_file = Path('../DemaWebshop/dema-webshop/public/data/aandrijftechniek_grouped.json')
    with open(grouped_file, 'r', encoding='utf-8') as f:
        product_groups = json.load(f)
    
    # Collect all SKUs with their page numbers
    sku_pages = []
    for group in product_groups:
        page = group.get('page_in_pdf')
        for variant in group.get('variants', []):
            sku = variant.get('sku')
            if sku and page:
                sku_pages.append({'sku': sku, 'page': page})
    
    print(f"📊 Total SKUs from grouped data: {len(sku_pages)}")
    
    # Get all image files
    image_folder = Path('../DemaWebshop/dema-webshop/public/images/products/aandrijftechniek')
    all_images = list(image_folder.glob('catalogus-aandrijftechniek_*.jpeg'))
    all_images += list(image_folder.glob('catalogus-aandrijftechniek_*.png'))
    
    print(f"🖼️  Total image files: {len(all_images)}")
    
    # Parse images by page and image number
    images_by_page = defaultdict(list)
    for img in all_images:
        # Match: catalogus-aandrijftechniek_pXXX_...
        match = re.search(r'_p(\d+)_', img.name)
        if match:
            page = int(match.group(1))
            # Extract image number if present
            img_match = re.search(r'_img(\d+)', img.name)
            img_num = int(img_match.group(1)) if img_match else 0
            
            images_by_page[page].append({
                'page': page,
                'img_num': img_num,
                'filename': img.name,
                'path': f"/images/products/aandrijftechniek/{img.name}"
            })
    
    # Sort images by page and image number
    for page in images_by_page:
        images_by_page[page].sort(key=lambda x: x['img_num'])
    
    print(f"📄 Pages with images: {sorted(images_by_page.keys())}")
    print(f"📄 Page count: {len(images_by_page)}\n")
    
    # Group SKUs by page
    skus_by_page = defaultdict(list)
    for item in sku_pages:
        skus_by_page[item['page']].append(item['sku'])
    
    print(f"{'='*80}")
    print(f"MAPPING STRATEGY: PAGE-BASED SEQUENTIAL ASSIGNMENT")
    print(f"{'='*80}\n")
    
    # Create comprehensive mapping
    sku_to_image = {}
    images_used = set()
    mapped_count = 0
    
    for page in sorted(skus_by_page.keys()):
        skus = skus_by_page[page]
        images = images_by_page.get(page, [])
        
        if not images:
            print(f"⚠️  Page {page}: {len(skus)} SKUs, but NO images available")
            continue
        
        print(f"📄 Page {page}:")
        print(f"   SKUs: {len(skus)}")
        print(f"   Images: {len(images)}")
        
        # Assign images to SKUs sequentially
        for i, sku in enumerate(skus):
            # Use modulo to cycle through available images if more SKUs than images
            img_index = i % len(images)
            image_info = images[img_index]
            
            sku_to_image[sku] = image_info['path']
            images_used.add(image_info['filename'])
            mapped_count += 1
            
            if i < 3:  # Show first 3 mappings as examples
                print(f"   ✅ {sku} → {image_info['filename']}")
        
        if len(skus) > 3:
            print(f"   ... and {len(skus) - 3} more SKUs on this page")
        print()
    
    print(f"{'='*80}")
    print(f"MAPPING SUMMARY")
    print(f"{'='*80}\n")
    print(f"✅ Total SKUs mapped: {mapped_count}")
    print(f"✅ Unique images used: {len(images_used)}")
    print(f"📊 Total images available: {len(all_images)}")
    print(f"⚠️  Unused images: {len(all_images) - len(images_used)}")
    
    # Save comprehensive mapping
    output_file = Path('../DemaWebshop/dema-webshop/public/data/aandrijftechniek_image_mapping.json')
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(sku_to_image, f, indent=2, ensure_ascii=False)
    
    print(f"\n✅ Saved mapping: {output_file}")
    print(f"   {len(sku_to_image)} SKUs → {len(images_used)} images\n")
    
    # Show sample mappings
    print(f"{'='*80}")
    print(f"SAMPLE MAPPINGS")
    print(f"{'='*80}\n")
    
    for i, (sku, img_path) in enumerate(list(sku_to_image.items())[:15]):
        print(f"   {sku:<20} → {img_path.split('/')[-1]}")
    
    if len(sku_to_image) > 15:
        print(f"   ... and {len(sku_to_image) - 15} more")
    
    # Show which images are still unused
    all_image_names = {img.name for img in all_images}
    unused_images = all_image_names - images_used
    
    if unused_images:
        print(f"\n{'='*80}")
        print(f"UNUSED IMAGES ({len(unused_images)} files)")
        print(f"{'='*80}\n")
        print(f"These images exist but aren't on pages with products:")
        for img in sorted(list(unused_images)[:10]):
            # Extract page number
            match = re.search(r'_p(\d+)_', img)
            if match:
                page = int(match.group(1))
                print(f"   {img} (page {page})")
        
        if len(unused_images) > 10:
            print(f"   ... and {len(unused_images) - 10} more")
    
    print(f"\n{'='*80}\n")
    
    return {
        'total_skus': mapped_count,
        'images_used': len(images_used),
        'images_available': len(all_images),
        'images_unused': len(all_images) - len(images_used)
    }

if __name__ == '__main__':
    result = map_all_images()
    
    print(f"✨ Comprehensive mapping complete!")
    print(f"   • {result['total_skus']} SKUs mapped")
    print(f"   • {result['images_used']} images in use")
    print(f"   • {result['images_unused']} images unused (on pages without products)\n")
