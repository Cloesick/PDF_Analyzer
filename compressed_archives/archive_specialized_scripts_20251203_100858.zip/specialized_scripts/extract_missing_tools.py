"""
Extract images for the 27 tools that are missing proper product photos
"""
import pdfplumber
import json
from pathlib import Path
from PIL import Image
import io

PROJECT_ROOT = Path(__file__).parent
INPUT_PDF = PROJECT_ROOT / "input_pdfs" / "makita-catalogus-2022-nl.pdf"
OUTPUT_DIR = PROJECT_ROOT / "product-images-by-pdf" / "makita-catalogus-2022-nl"
RESULTS_FILE = PROJECT_ROOT / "output" / "sku_classification_results.json"

# Tools that need images (from analysis)
MISSING_TOOLS = [
    'TW04GD201', 'TW007GD201', 'TW007GM201', 'TW007GZ01',
    'GA037GM201', 'GA036GZ', 'GA037GZO1', 
    'PV001GZ', 'PV001GM1O1',
    'JR001GD', 'JR002GM201', 'JR001GZ', 'JR001GM201', 'JR001GD201',
    'PT001GD101', 'PT001GZO1',
    'FN00GA202', 'FN001GA202', 'FN001GZ02',
    'GA038GM201',
    'HS009G',
    'RT001GZ16',
    'KP001GZ01',
    'DK0126G401',
    'M3001GZ',
    'LS003GZO1', 'LS002GZO1'
]

def find_sku_in_text(text, sku):
    """Check if SKU appears in text"""
    text_clean = text.replace(' ', '').replace('-', '').upper()
    sku_clean = sku.replace(' ', '').replace('-', '').upper()
    return sku_clean in text_clean

def extract_images_for_skus():
    """Extract images for missing tool SKUs"""
    
    print("="*80)
    print("EXTRACTING IMAGES FOR MISSING TOOLS")
    print("="*80)
    print(f"\nSearching for {len(MISSING_TOOLS)} tools in PDF...")
    print(f"PDF: {INPUT_PDF.name}")
    
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    found_skus = {}
    extracted_count = 0
    
    with pdfplumber.open(INPUT_PDF) as pdf:
        total_pages = len(pdf.pages)
        print(f"Scanning {total_pages} pages...\n")
        
        for page_num in range(total_pages):
            page = pdf.pages[page_num]
            page_text = page.extract_text() or ""
            
            # Check which missing SKUs are on this page
            skus_on_page = []
            for sku in MISSING_TOOLS:
                if find_sku_in_text(page_text, sku):
                    skus_on_page.append(sku)
            
            if not skus_on_page:
                continue
            
            print(f"Page {page_num + 1}: Found {len(skus_on_page)} SKUs: {', '.join(skus_on_page)}")
            
            # Extract images from this page
            try:
                # Get page as image
                page_image = page.to_image(resolution=300)
                page_pil = page_image.original
                
                # Get all images on the page
                images = page.images
                
                if images:
                    print(f"  Found {len(images)} images on page")
                    
                    for img_index, img in enumerate(images):
                        # Try to extract image
                        try:
                            # Get image coordinates
                            x0 = img.get('x0', 0)
                            y0 = img.get('top', 0)
                            x1 = img.get('x1', page.width)
                            y1 = img.get('bottom', page.height)
                            
                            # Crop from page image
                            # Convert PDF coords to image coords (resolution=300, so 300/72 = 4.17 ratio)
                            ratio = 300 / 72
                            crop_box = (
                                int(x0 * ratio),
                                int(y0 * ratio),
                                int(x1 * ratio),
                                int(y1 * ratio)
                            )
                            
                            cropped = page_pil.crop(crop_box)
                            
                            # Check if image is large enough
                            if cropped.width < 50 or cropped.height < 50:
                                continue
                            
                            # Save for each SKU on this page
                            for sku in skus_on_page:
                                if sku not in found_skus:
                                    found_skus[sku] = []
                                
                                # Create filename
                                filename = f"{sku}_makita-catalogus-2022-nl_p{page_num+1:03d}_img{img_index}.webp"
                                output_path = OUTPUT_DIR / filename
                                
                                # Save as WebP
                                cropped.save(output_path, 'WEBP', quality=90)
                                
                                found_skus[sku].append(filename)
                                extracted_count += 1
                                
                                print(f"    ✅ Saved: {filename}")
                        
                        except Exception as e:
                            print(f"    ⚠️ Error extracting image {img_index}: {e}")
                            continue
                
                else:
                    # No discrete images, save whole page section
                    print(f"  No discrete images, saving page section")
                    
                    for sku in skus_on_page:
                        if sku not in found_skus:
                            found_skus[sku] = []
                        
                        filename = f"{sku}_makita-catalogus-2022-nl_p{page_num+1:03d}.webp"
                        output_path = OUTPUT_DIR / filename
                        
                        # Save page as image
                        page_pil.save(output_path, 'WEBP', quality=90)
                        
                        found_skus[sku].append(filename)
                        extracted_count += 1
                        
                        print(f"    ✅ Saved: {filename}")
            
            except Exception as e:
                print(f"  ⚠️ Error on page {page_num + 1}: {e}")
                continue
    
    # Summary
    print("\n" + "="*80)
    print("EXTRACTION COMPLETE")
    print("="*80)
    
    print(f"\nTotal images extracted: {extracted_count}")
    print(f"SKUs with images found: {len(found_skus)}/{len(MISSING_TOOLS)}")
    
    if found_skus:
        print(f"\n✅ SUCCESSFULLY EXTRACTED:")
        for sku, images in found_skus.items():
            print(f"  {sku}: {len(images)} image(s)")
    
    missing = [sku for sku in MISSING_TOOLS if sku not in found_skus]
    if missing:
        print(f"\n⚠️ STILL MISSING ({len(missing)}):")
        for sku in missing:
            print(f"  {sku}")
    
    print(f"\n📁 Images saved to: {OUTPUT_DIR}")
    
    return found_skus

if __name__ == '__main__':
    extract_images_for_skus()
