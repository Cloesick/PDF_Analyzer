"""
Extract actual product images from catalogus-aandrijftechniek PDF
- Skip brand logos (NTN, FK, SNR)
- Extract actual product images (bearings, etc.)
"""
import fitz
import json
from pathlib import Path
from collections import defaultdict
from PIL import Image
import io

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "catalogus-aandrijftechniek-150922.pdf"
OUTPUT_DIR = PROJECT_ROOT / "extracted_images" / "aandrijftechniek"
OUTPUT_JSON = PROJECT_ROOT / "output" / "aandrijftechniek_images.json"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Brand logo detection
BRAND_KEYWORDS = ['ntn', 'fk', 'snr', 'skf', 'fag', 'timken', 'koyo', 'nsk', 'logo']

def is_brand_logo(image_pil, image_index, page_num):
    """Detect if image is a brand logo vs product image"""
    width, height = image_pil.size
    aspect_ratio = width / height if height > 0 else 0
    
    # Brand logos are typically:
    # - Very wide (aspect > 3) or very tall (aspect < 0.3)
    # - Small (< 100x100)
    # - Or very large headers (> 1000 width)
    
    if width < 100 and height < 100:
        return True  # Too small, likely logo
    
    if width > 1000 and height < 200:
        return True  # Wide header, likely logo
    
    if aspect_ratio > 4 or aspect_ratio < 0.25:
        return True  # Extreme aspect ratio, likely logo
    
    # Logos are often in the top 20% of the page
    # This would require position data which we'll skip for now
    
    return False

def extract_images_from_pdf():
    """Extract product images from PDF"""
    print("=" * 80)
    print("EXTRACTING AANDRIJFTECHNIEK PRODUCT IMAGES")
    print("=" * 80)
    
    doc = fitz.open(PDF_PATH)
    
    results = {
        'pdf_name': PDF_PATH.name,
        'total_pages': len(doc),
        'images_by_page': {}
    }
    
    stats = {
        'total_images': 0,
        'brand_logos_skipped': 0,
        'product_images_saved': 0,
        'pages_processed': 0
    }
    
    print(f"\n📄 Processing PDF: {PDF_PATH.name}")
    print(f"   Total pages: {len(doc)}")
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        image_list = page.get_images()
        
        if not image_list:
            continue
        
        stats['pages_processed'] += 1
        page_images = []
        
        if (page_num + 1) % 20 == 0:
            print(f"   Processing page {page_num + 1}... ({stats['product_images_saved']} products found)")
        
        for img_index, img in enumerate(image_list):
            stats['total_images'] += 1
            
            try:
                xref = img[0]
                base_image = doc.extract_image(xref)
                image_bytes = base_image["image"]
                image_ext = base_image["ext"]
                
                # Open with PIL for analysis
                image_pil = Image.open(io.BytesIO(image_bytes))
                width, height = image_pil.size
                
                # Skip brand logos
                if is_brand_logo(image_pil, img_index, page_num):
                    stats['brand_logos_skipped'] += 1
                    continue
                
                # Skip very small images (icons, etc.)
                if width < 80 or height < 80:
                    continue
                
                # Save product image
                image_filename = f"page{page_num+1:03d}_img{img_index:02d}.{image_ext}"
                image_path = OUTPUT_DIR / image_filename
                
                with open(image_path, "wb") as img_file:
                    img_file.write(image_bytes)
                
                page_images.append({
                    'filename': image_filename,
                    'width': width,
                    'height': height,
                    'path': str(image_path.relative_to(PROJECT_ROOT))
                })
                
                stats['product_images_saved'] += 1
                
            except Exception as e:
                continue
        
        if page_images:
            results['images_by_page'][page_num + 1] = page_images
    
    doc.close()
    
    # Save JSON mapping
    OUTPUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    print(f"\n📊 EXTRACTION STATISTICS:")
    print(f"   Pages processed:         {stats['pages_processed']}")
    print(f"   Total images found:      {stats['total_images']}")
    print(f"   Brand logos skipped:     {stats['brand_logos_skipped']}")
    print(f"   Product images saved:    {stats['product_images_saved']}")
    print(f"\n💾 Images saved to: {OUTPUT_DIR}")
    print(f"   Mapping saved to: {OUTPUT_JSON}")
    
    print(f"\n{'='*80}")
    print("✅ EXTRACTION COMPLETE")
    print("="*80)
    
    return results

if __name__ == '__main__':
    extract_images_from_pdf()
