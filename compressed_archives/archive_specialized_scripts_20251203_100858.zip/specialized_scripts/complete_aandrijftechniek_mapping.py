#!/usr/bin/env python3
"""
Complete the aandrijftechniek mapping by including ALL 14 product groups.

Strategy: Keep clean filenames, but ensure ALL groups are mapped.
Multiple groups on the same page will share the same image.
"""

import json
from pathlib import Path
from collections import defaultdict

def complete_mapping():
    """Create comprehensive mapping for all 14 product groups"""
    
    print(f"\n{'='*80}")
    print(f"COMPLETING AANDRIJFTECHNIEK IMAGE MAPPING")
    print(f"{'='*80}\n")
    
    # Load grouped products data
    grouped_file = Path('../DemaWebshop/dema-webshop/public/data/aandrijftechniek_grouped.json')
    with open(grouped_file, 'r', encoding='utf-8') as f:
        product_groups = json.load(f)
    
    print(f"📊 Total Product Groups: {len(product_groups)}")
    
    # Load existing group mapping
    group_mapping_file = Path('../DemaWebshop/dema-webshop/public/data/aandrijftechniek_group_mapping.json')
    with open(group_mapping_file, 'r', encoding='utf-8') as f:
        existing_mapping = json.load(f)
    
    print(f"📋 Currently Mapped Groups: {len(existing_mapping)}")
    print(f"❌ Missing Groups: {len(product_groups) - len(existing_mapping)}\n")
    
    # Image folder
    image_folder = Path('../DemaWebshop/dema-webshop/public/images/products/aandrijftechniek')
    
    # Organize groups by page
    groups_by_page = defaultdict(list)
    for group in product_groups:
        page = group.get('page_in_pdf')
        if page:
            groups_by_page[page].append(group)
    
    # Map images to groups
    new_group_mapping = {}
    new_sku_mapping = {}
    image_usage = defaultdict(list)  # Track which groups use each image
    
    print(f"{'='*80}")
    print(f"MAPPING STRATEGY BY PAGE")
    print(f"{'='*80}\n")
    
    for page in sorted(groups_by_page.keys()):
        groups_on_page = groups_by_page[page]
        
        # Find available images on this page
        available_images = sorted(image_folder.glob(f'catalogus-aandrijftechniek_p{page:03d}_*.jpeg'))
        available_images += sorted(image_folder.glob(f'catalogus-aandrijftechniek_p{page:03d}_*.png'))
        
        print(f"📄 Page {page}:")
        print(f"   Groups: {len(groups_on_page)}")
        print(f"   Images: {len(available_images)}")
        
        if not available_images:
            print(f"   ⚠️  No images available for this page")
            continue
        
        # Assign images to groups
        for i, group in enumerate(groups_on_page):
            group_id = group.get('group_id')
            family = group.get('family', 'unknown')
            variants = group.get('variants', [])
            
            # Try to find image with group name first
            matched_image = None
            for img in available_images:
                if family.lower() in img.stem.lower():
                    matched_image = img
                    break
            
            # If no specific match, use first available image for this page
            if not matched_image and available_images:
                matched_image = available_images[0]
            
            if matched_image:
                image_path = f"/images/products/aandrijftechniek/{matched_image.name}"
                
                # Map group
                new_group_mapping[group_id] = image_path
                
                # Map all SKUs in this group
                for variant in variants:
                    sku = variant.get('sku')
                    if sku:
                        new_sku_mapping[sku] = image_path
                
                # Track usage
                image_usage[matched_image.name].append({
                    'group': family,
                    'skus': len(variants),
                    'group_id': group_id
                })
                
                print(f"   ✅ {family} ({len(variants)} SKUs) → {matched_image.name}")
        
        print()
    
    # Save updated mappings
    with open(group_mapping_file, 'w', encoding='utf-8') as f:
        json.dump(new_group_mapping, f, indent=2, ensure_ascii=False)
    
    sku_mapping_file = Path('../DemaWebshop/dema-webshop/public/data/aandrijftechniek_image_mapping.json')
    with open(sku_mapping_file, 'w', encoding='utf-8') as f:
        json.dump(new_sku_mapping, f, indent=2, ensure_ascii=False)
    
    print(f"{'='*80}")
    print(f"MAPPING SUMMARY")
    print(f"{'='*80}\n")
    print(f"✅ Total Groups Mapped: {len(new_group_mapping)}")
    print(f"✅ Total SKUs Mapped: {len(new_sku_mapping)}")
    print(f"📷 Unique Images Used: {len(image_usage)}")
    
    print(f"\n{'='*80}")
    print(f"IMAGE SHARING DETAILS")
    print(f"{'='*80}\n")
    
    # Show which images are shared by multiple groups
    for img_name in sorted(image_usage.keys()):
        groups = image_usage[img_name]
        if len(groups) > 1:
            total_skus = sum(g['skus'] for g in groups)
            print(f"📷 {img_name}")
            print(f"   Shared by {len(groups)} groups ({total_skus} total SKUs):")
            for g in groups:
                print(f"   • {g['group']} ({g['skus']} SKUs)")
            print()
    
    # Show single-use images
    single_use = [img for img, groups in image_usage.items() if len(groups) == 1]
    if single_use:
        print(f"Single-use images: {len(single_use)}")
        for img in single_use[:5]:
            g = image_usage[img][0]
            print(f"  • {img} → {g['group']} ({g['skus']} SKUs)")
        if len(single_use) > 5:
            print(f"  ... and {len(single_use) - 5} more")
    
    print(f"\n{'='*80}")
    print(f"FILES UPDATED")
    print(f"{'='*80}\n")
    print(f"✅ {group_mapping_file.name} - {len(new_group_mapping)} groups")
    print(f"✅ {sku_mapping_file.name} - {len(new_sku_mapping)} SKUs")
    
    print(f"\n✨ SUCCESS! All {len(product_groups)} product groups now mapped to images.\n")
    
    return {
        'groups_mapped': len(new_group_mapping),
        'skus_mapped': len(new_sku_mapping),
        'unique_images': len(image_usage),
        'shared_images': len([img for img, g in image_usage.items() if len(g) > 1])
    }

if __name__ == '__main__':
    result = complete_mapping()
    
    if result:
        print(f"🎯 Mapping Complete!")
        print(f"   • {result['groups_mapped']} groups → {result['unique_images']} images")
        print(f"   • {result['skus_mapped']} SKUs mapped")
        print(f"   • {result['shared_images']} images shared by multiple groups")
        print(f"\n   Visit: http://localhost:3000/catalog/aandrijftechniek-grouped\n")
