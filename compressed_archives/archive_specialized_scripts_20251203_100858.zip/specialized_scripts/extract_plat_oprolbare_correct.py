"""
Extract plat-oprolbare-slangen with correct column structure:
- Column 0: Bestelnr (SKU)
- Column 1: Binnen dia (mm) - Inner diameter
- Column 2: Werkdruk (bar) - Work pressure
- Column 3: Barstdruk (bar) - Rupture/burst pressure
- Column 4: Gewicht (g/m) - Weight in grams per meter
- Column 5: Rollengte (m) - Roll length in meters
"""
import fitz
import json
import re
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "plat-oprolbare-slangen.pdf"
OUTPUT_JSON = PROJECT_ROOT / "output" / "plat_oprolbare_specs.json"

def extract_number(value_str):
    """Extract numeric value from string"""
    if not value_str:
        return None
    
    # Remove whitespace and newlines
    value_str = str(value_str).strip().replace('\n', ' ')
    
    # Extract number
    match = re.search(r'(\d+(?:[.,]\d+)?)', value_str)
    if match:
        return float(match.group(1).replace(',', '.'))
    
    return None

def process_pdf():
    """Process plat-oprolbare-slangen PDF"""
    print("=" * 80)
    print("EXTRACTING PLAT-OPROLBARE-SLANGEN WITH CORRECT STRUCTURE")
    print("=" * 80)
    
    doc = fitz.open(PDF_PATH)
    
    all_products = []
    stats = {
        'pages_processed': 0,
        'tables_found': 0,
        'products_extracted': 0,
        'with_inner_diameter': 0,
        'with_work_pressure': 0,
        'with_rupture_pressure': 0,
        'with_weight': 0,
        'with_length': 0
    }
    
    print(f"\n📄 Processing: {PDF_PATH.name}")
    print(f"   Total pages: {len(doc)}")
    print(f"\n⚡ Extracting products...")
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        stats['pages_processed'] += 1
        
        if (page_num + 1) % 10 == 0:
            print(f"   Processing page {page_num + 1}... ({stats['products_extracted']} products found)")
        
        # Extract tables
        try:
            tables = page.find_tables()
            for table in tables:
                stats['tables_found'] += 1
                extracted = table.extract()
                
                if not extracted or len(extracted) < 2:
                    continue
                
                # Check if this is a plat-oprolbare table
                # Should have headers: Bestelnr | Binnen dia | Werkdruk | Barstdruk | Gewicht | Rollengte
                headers = extracted[0]
                if not any('bestelnr' in str(h).lower() for h in headers):
                    continue
                
                # Fixed column structure
                BESTELNR_COL = 0      # SKU
                BINNEN_DIA_COL = 1    # Inner diameter (mm)
                WERKDRUK_COL = 2      # Work pressure (bar)
                BARSTDRUK_COL = 3     # Rupture pressure (bar)
                GEWICHT_COL = 4       # Weight (g/m)
                ROLLENGTE_COL = 5     # Roll length (m)
                
                # Process rows
                for row in extracted[1:]:
                    if not row or len(row) < 2:
                        continue
                    
                    # Column 0: SKU (Bestelnr)
                    sku = str(row[BESTELNR_COL]).strip()
                    if not sku or len(sku) < 3:
                        continue
                    
                    # Build product
                    product = {
                        'sku': sku,
                        'page_in_pdf': page_num + 1
                    }
                    
                    # Column 1: Inner diameter (mm)
                    if len(row) > BINNEN_DIA_COL:
                        inner_dia = extract_number(row[BINNEN_DIA_COL])
                        if inner_dia:
                            product['inner_diameter_mm'] = inner_dia
                            product['diameter_mm'] = inner_dia  # Use inner as main diameter
                            stats['with_inner_diameter'] += 1
                    
                    # Column 2: Work pressure (bar)
                    if len(row) > WERKDRUK_COL:
                        work_pressure = extract_number(row[WERKDRUK_COL])
                        if work_pressure:
                            product['work_pressure_bar'] = work_pressure
                            product['pressure_max_bar'] = work_pressure  # Also set as max pressure
                            stats['with_work_pressure'] += 1
                    
                    # Column 3: Rupture/burst pressure (bar)
                    if len(row) > BARSTDRUK_COL:
                        rupture_pressure = extract_number(row[BARSTDRUK_COL])
                        if rupture_pressure:
                            product['rupture_pressure_bar'] = rupture_pressure
                            stats['with_rupture_pressure'] += 1
                    
                    # Column 4: Weight (g/m) - convert to kg/m
                    if len(row) > GEWICHT_COL:
                        weight_g_m = extract_number(row[GEWICHT_COL])
                        if weight_g_m:
                            product['weight_g_per_m'] = weight_g_m
                            product['weight_kg_per_m'] = weight_g_m / 1000  # Convert to kg/m
                            stats['with_weight'] += 1
                    
                    # Column 5: Roll length (m)
                    if len(row) > ROLLENGTE_COL:
                        length = extract_number(row[ROLLENGTE_COL])
                        if length:
                            product['length_m'] = length
                            stats['with_length'] += 1
                    
                    all_products.append(product)
                    stats['products_extracted'] += 1
                    
                    if stats['products_extracted'] <= 10:
                        print(f"      ✓ {sku:20} | ⊙ {product.get('inner_diameter_mm', 'N/A'):4} mm | 🔧 {product.get('work_pressure_bar', 'N/A'):4} bar | 📐 {product.get('length_m', 'N/A'):4} m")
                        
        except Exception as e:
            continue
    
    doc.close()
    
    # Save results
    OUTPUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(all_products, f, ensure_ascii=False, indent=2)
    
    # Statistics
    print(f"\n📊 EXTRACTION STATISTICS:")
    print(f"   Pages processed:           {stats['pages_processed']}")
    print(f"   Tables found:              {stats['tables_found']}")
    print(f"   Products extracted:        {stats['products_extracted']}")
    print(f"   With inner diameter:       {stats['with_inner_diameter']}")
    print(f"   With work pressure:        {stats['with_work_pressure']}")
    print(f"   With rupture pressure:     {stats['with_rupture_pressure']}")
    print(f"   With weight (g/m):         {stats['with_weight']}")
    print(f"   With roll length:          {stats['with_length']}")
    
    # Show samples
    print(f"\n📋 SAMPLE PRODUCTS:")
    for product in all_products[:5]:
        print(f"\n   SKU: {product['sku']}")
        if 'inner_diameter_mm' in product:
            print(f"      ⊙ Inner diameter: {product['inner_diameter_mm']} mm")
        if 'work_pressure_bar' in product:
            print(f"      🔧 Work pressure: {product['work_pressure_bar']} bar")
        if 'rupture_pressure_bar' in product:
            print(f"      💥 Rupture pressure: {product['rupture_pressure_bar']} bar")
        if 'weight_g_per_m' in product:
            print(f"      ⚖️ Weight: {product['weight_g_per_m']} g/m ({product['weight_kg_per_m']} kg/m)")
        if 'length_m' in product:
            print(f"      📐 Length: {product['length_m']} m")
    
    print(f"\n💾 Output saved to: {OUTPUT_JSON}")
    print(f"\n{'='*80}")
    print("✅ EXTRACTION COMPLETE")
    print("="*80)
    
    return all_products

if __name__ == '__main__':
    process_pdf()
