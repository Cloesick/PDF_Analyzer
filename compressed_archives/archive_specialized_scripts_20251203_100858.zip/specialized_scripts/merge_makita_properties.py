"""
Merge Extracted Properties into Makita Products
================================================
Combine extracted properties with product data
"""
import json
from pathlib import Path
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
PRODUCTS_JSON = PROJECT_ROOT / "output" / "products_with_makita_images.json"
PROPERTIES_JSON = PROJECT_ROOT / "output" / "makita_properties_extracted.json"
OUTPUT_JSON = PROJECT_ROOT / "output" / "makita_complete_products.json"

def merge_properties():
    print("=" * 80)
    print("MERGING MAKITA PROPERTIES")
    print("=" * 80)
    
    # Load data
    print("\n📦 Loading data...")
    with open(PRODUCTS_JSON, 'r', encoding='utf-8') as f:
        all_products = json.load(f)
    
    with open(PROPERTIES_JSON, 'r', encoding='utf-8') as f:
        extracted_properties = json.load(f)
    
    # Build SKU → properties mapping
    props_by_sku = {}
    for item in extracted_properties:
        sku = item['sku']
        props_by_sku[sku] = item
    
    makita_products = [p for p in all_products if 'makita-catalogus-2022-nl' in p.get('pdf_source', '')]
    print(f"   {len(makita_products)} Makita products")
    print(f"   {len(props_by_sku)} products with extracted properties")
    
    # Merge properties
    print("\n🔗 Merging properties...")
    stats = {
        'exact_matches': 0,
        'fuzzy_matches': 0,
        'no_match': 0,
        'properties_added': 0
    }
    
    updated_products = []
    for product in all_products:
        # Only process Makita products
        if 'makita-catalogus-2022-nl' not in product.get('pdf_source', ''):
            updated_products.append(product)
            continue
        
        sku = product.get('sku', '')
        
        # Try exact match first
        if sku in props_by_sku:
            props_data = props_by_sku[sku]
            
            # Add properties to product
            product['extracted_properties'] = props_data['properties']
            product['raw_specifications'] = props_data.get('raw_specifications', [])
            
            # Also add to attributes for webshop display
            if not product.get('attributes'):
                product['attributes'] = {}
            product['attributes'].update(props_data['properties'])
            
            # Add to specifications array
            if not product.get('specifications'):
                product['specifications'] = []
            for spec_str in props_data.get('raw_specifications', []):
                if ':' in spec_str:
                    key, val = spec_str.split(':', 1)
                    product['specifications'].append({
                        'key': key.strip(),
                        'value': val.strip()
                    })
            
            stats['exact_matches'] += 1
            stats['properties_added'] += len(props_data['properties'])
        else:
            # Try fuzzy matching (SKU might have suffix)
            matched = False
            for prop_sku, props_data in props_by_sku.items():
                if sku in prop_sku or prop_sku in sku:
                    product['extracted_properties'] = props_data['properties']
                    product['raw_specifications'] = props_data.get('raw_specifications', [])
                    
                    if not product.get('attributes'):
                        product['attributes'] = {}
                    product['attributes'].update(props_data['properties'])
                    
                    stats['fuzzy_matches'] += 1
                    stats['properties_added'] += len(props_data['properties'])
                    matched = True
                    break
            
            if not matched:
                stats['no_match'] += 1
        
        updated_products.append(product)
    
    # Save updated products
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(updated_products, f, indent=2, ensure_ascii=False)
    
    # Calculate coverage
    makita_with_props = len([p for p in updated_products 
                            if 'makita-catalogus-2022-nl' in p.get('pdf_source', '') 
                            and p.get('extracted_properties')])
    
    makita_with_images = len([p for p in updated_products 
                             if 'makita-catalogus-2022-nl' in p.get('pdf_source', '') 
                             and p.get('image_url')])
    
    makita_complete = len([p for p in updated_products 
                          if 'makita-catalogus-2022-nl' in p.get('pdf_source', '') 
                          and p.get('image_url') and p.get('extracted_properties')])
    
    # Print summary
    print("\n" + "=" * 80)
    print("MERGE COMPLETE")
    print("=" * 80)
    
    print(f"\n📊 Match Statistics:")
    print(f"   Exact SKU matches:    {stats['exact_matches']}")
    print(f"   Fuzzy matches:        {stats['fuzzy_matches']}")
    print(f"   No match found:       {stats['no_match']}")
    print(f"   Properties added:     {stats['properties_added']}")
    
    print(f"\n📈 Coverage:")
    print(f"   Total Makita products:         {len(makita_products)}")
    print(f"   ✅ With images:                {makita_with_images} ({makita_with_images/len(makita_products)*100:.1f}%)")
    print(f"   ✅ With properties:            {makita_with_props} ({makita_with_props/len(makita_products)*100:.1f}%)")
    print(f"   🎯 Complete (image + props):   {makita_complete} ({makita_complete/len(makita_products)*100:.1f}%)")
    
    # Show sample complete product
    complete_products = [p for p in updated_products 
                        if 'makita-catalogus-2022-nl' in p.get('pdf_source', '') 
                        and p.get('image_url') and p.get('extracted_properties')]
    
    if complete_products:
        print(f"\n🔍 Sample Complete Product:")
        sample = complete_products[0]
        print(f"   SKU: {sample.get('sku')}")
        print(f"   Name: {sample.get('name')}")
        print(f"   Category: {sample.get('product_category')}")
        print(f"   Image: ✅ {sample.get('image_url', '')[:50]}...")
        print(f"   Properties: {len(sample.get('extracted_properties', {}))} fields")
        print(f"   Sample props: {list(sample.get('extracted_properties', {}).keys())[:8]}")
    
    print(f"\n💾 Saved to: {OUTPUT_JSON}")
    
    # Show improvement
    print(f"\n✨ IMPROVEMENT:")
    print(f"   Before: 0% with properties")
    print(f"   After:  {makita_with_props/len(makita_products)*100:.1f}% with properties")
    print(f"   Complete products (both): {makita_complete/len(makita_products)*100:.1f}%")

if __name__ == '__main__':
    merge_properties()
