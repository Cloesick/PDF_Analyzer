"""
Convert all JPEG and PNG images to WebP format
"""

from pathlib import Path
from PIL import Image
import os

PROJECT_ROOT = Path(__file__).parent
IMAGES_DIR = PROJECT_ROOT / "product-images"

print("🔄 Converting all images to WebP format...\n")

converted = 0
skipped = 0
errors = 0

for catalog_dir in sorted(IMAGES_DIR.iterdir()):
    if not catalog_dir.is_dir():
        continue
    
    print(f"📁 {catalog_dir.name}")
    
    catalog_converted = 0
    
    # Find all non-WebP images
    for img_file in catalog_dir.glob("*"):
        if not img_file.is_file():
            continue
        
        ext = img_file.suffix.lower()
        
        # Skip if already WebP
        if ext == '.webp':
            skipped += 1
            continue
        
        # Skip if not an image format we handle
        if ext not in ['.jpg', '.jpeg', '.png', '.gif', '.bmp']:
            continue
        
        try:
            # Load image
            img = Image.open(img_file)
            
            # Convert RGBA/LA to RGB for WebP
            if img.mode in ('RGBA', 'LA', 'P'):
                # Create white background
                background = Image.new('RGB', img.size, (255, 255, 255))
                if img.mode == 'P':
                    img = img.convert('RGBA')
                background.paste(img, mask=img.split()[-1] if img.mode in ('RGBA', 'LA') else None)
                img = background
            elif img.mode != 'RGB':
                img = img.convert('RGB')
            
            # Create new filename with .webp extension
            new_filename = img_file.stem + '.webp'
            new_path = catalog_dir / new_filename
            
            # Save as WebP
            img.save(new_path, 'WEBP', quality=85, method=6)
            
            # Delete old file
            img_file.unlink()
            
            converted += 1
            catalog_converted += 1
            
        except Exception as e:
            print(f"   ❌ Error converting {img_file.name}: {e}")
            errors += 1
            continue
    
    if catalog_converted > 0:
        print(f"   ✅ Converted {catalog_converted} images")

print(f"\n{'='*60}")
print(f"✅ Conversion Complete!")
print(f"{'='*60}")
print(f"   Converted: {converted} images")
print(f"   Skipped (already WebP): {skipped} images")
if errors:
    print(f"   Errors: {errors}")

print(f"\n💾 Space Savings:")
print(f"   WebP format typically saves 25-35% compared to JPEG")
print(f"   With {converted} images converted, expect significant space savings")

# Verify
print(f"\n🔍 Verification:")
total_images = 0
webp_images = 0

for catalog_dir in IMAGES_DIR.iterdir():
    if catalog_dir.is_dir():
        for img_file in catalog_dir.glob("*"):
            if img_file.is_file():
                total_images += 1
                if img_file.suffix.lower() == '.webp':
                    webp_images += 1

print(f"   Total images: {total_images}")
print(f"   WebP images: {webp_images}")
print(f"   Coverage: {webp_images/total_images*100:.1f}%")

if webp_images == total_images:
    print(f"\n🎉 Perfect! All images are now in WebP format!")
