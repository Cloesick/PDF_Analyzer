"""
Data Enrichment Script for Product Groups
Ensures NO data loss from original products - only enrichment!
Combines data from multiple sources for maximum detail and quality.
"""

import json
from pathlib import Path
from typing import Dict, List, Any, Optional

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"
WEBSHOP_DATA = Path("C:/Users/prova/Documents/Projects/DemaWebshop/dema-webshop/public/data")


def load_json(file_path: Path) -> Any:
    """Load JSON file safely."""
    if not file_path.exists():
        print(f"⚠️  File not found: {file_path}")
        return None
    
    with file_path.open("r", encoding="utf-8") as f:
        return json.load(f)


def enrich_variant_with_catalog_data(variant: Dict, catalog_products: List[Dict], 
                                     extraction_products: List[Dict]) -> Dict:
    """
    Enrich a variant with all available data from catalog and extraction sources.
    Priority: extraction_data > catalog_data > current_data
    """
    sku = variant.get("sku")
    enriched = variant.copy()
    
    # Find matching catalog product (from webshop)
    catalog_match = next((p for p in catalog_products if p.get("sku") == sku), None)
    
    # Find matching extraction product (from PDF)
    extraction_match = next((p for p in extraction_products if p.get("sku") == sku), None)
    
    # Start with current properties
    properties = enriched.get("properties", {}).copy()
    
    # Add extraction data (highest priority - most detailed)
    if extraction_match:
        for key, value in extraction_match.items():
            if key not in ["sku", "catalog", "pdf_source", "source_pages"] and value is not None:
                properties[key] = value
    
    # Add catalog metadata
    if catalog_match:
        # Add category, brand, description if available
        if catalog_match.get("category"):
            properties["category"] = catalog_match["category"]
        if catalog_match.get("brand"):
            properties["brand"] = catalog_match["brand"]
        if catalog_match.get("description"):
            properties["description"] = catalog_match["description"]
        if catalog_match.get("product_category"):
            properties["product_category"] = catalog_match["product_category"]
        
        # Add SEO data
        if catalog_match.get("seo"):
            properties["seo"] = catalog_match["seo"]
        
        # Add price if available
        if catalog_match.get("price"):
            properties["price"] = catalog_match["price"]
        
        # Add stock info
        if catalog_match.get("stock"):
            properties["stock"] = catalog_match["stock"]
    
    # Update enriched variant
    enriched["properties"] = properties
    enriched["attributes"] = properties  # Keep both for compatibility
    
    # Add full name if not present
    if not enriched.get("name"):
        enriched["name"] = enriched.get("label", sku)
    
    return enriched


def enrich_product_group(group: Dict, catalog_name: str) -> Dict:
    """
    Enrich an entire product group with all available data sources.
    """
    enriched_group = group.copy()
    
    print(f"\n📦 Enriching: {group.get('name', group.get('group_id'))}")
    print(f"   Variants: {len(group.get('variants', []))}")
    
    # Load catalog data (from webshop)
    catalog_file = WEBSHOP_DATA / "catalogs" / f"{catalog_name}.json"
    catalog_products = load_json(catalog_file) or []
    print(f"   Found {len(catalog_products)} products in catalog JSON")
    
    # Load extraction data (from PDF analyzer)
    # Try to find the extraction file - check multiple locations
    extraction_files = [
        OUTPUT_DIR / f"{catalog_name}_smart_extracted.json",  # NEW: Check smart extracted first
        OUTPUT_DIR / f"{catalog_name.replace('-', '_')}_smart_extracted.json",  # Try with underscores
        OUTPUT_DIR / "archive" / "catalog_extractions" / f"{catalog_name}_dynamic.json",
        OUTPUT_DIR / "archive" / "catalog_extractions" / f"abs_persluchtbuizen_dynamic.json",
        OUTPUT_DIR / "archive" / "catalog_extractions" / f"slangkoppelingen_dynamic.json",
        OUTPUT_DIR / "archive" / "catalog_extractions" / f"pomp_specials_dynamic.json",
        OUTPUT_DIR / "archive" / "catalog_extractions" / f"aandrijftechniek_dynamic.json",
    ]
    
    extraction_products = []
    for ext_file in extraction_files:
        if ext_file.exists():
            extraction_products = load_json(ext_file) or []
            if extraction_products:
                print(f"   Found {len(extraction_products)} products in extraction JSON")
                break
    
    # Enrich each variant
    enriched_variants = []
    properties_added = 0
    
    for variant in enriched_group.get("variants", []):
        original_prop_count = len(variant.get("properties", {}))
        enriched_variant = enrich_variant_with_catalog_data(
            variant, catalog_products, extraction_products
        )
        new_prop_count = len(enriched_variant.get("properties", {}))
        
        if new_prop_count > original_prop_count:
            properties_added += (new_prop_count - original_prop_count)
        
        enriched_variants.append(enriched_variant)
    
    enriched_group["variants"] = enriched_variants
    
    # Add group-level metadata if available
    if catalog_products:
        first_catalog = catalog_products[0]
        if first_catalog.get("category") and not enriched_group.get("category"):
            enriched_group["category"] = first_catalog["category"]
        if first_catalog.get("brand") and not enriched_group.get("brand"):
            enriched_group["brand"] = first_catalog["brand"]
    
    print(f"   ✓ Enriched! Added {properties_added} additional properties")
    
    return enriched_group


def enrich_all_grouped_catalogs():
    """
    Enrich all grouped product catalogs with full data from original sources.
    """
    print("=" * 80)
    print("DATA ENRICHMENT FOR PRODUCT GROUPS")
    print("Ensuring no data loss - only enrichment!")
    print("=" * 80)
    
    # List of grouped catalogs to enrich
    grouped_catalogs = [
        {
            "name": "ABS Persluchtbuizen",
            "grouped_file": "abs_persluchtbuizen_grouped.json",
            "catalog_name": "abs-persluchtbuizen",
            "output_file": "abs_persluchtbuizen_grouped.json"
        },
        {
            "name": "Slangkoppelingen",
            "grouped_file": "slangkoppelingen_grouped.json",
            "catalog_name": "slangkoppelingen",
            "output_file": "slangkoppelingen_grouped.json"
        },
        {
            "name": "Pomp Specials",
            "grouped_file": "pomp_specials_grouped.json",
            "catalog_name": "pomp-specials",
            "output_file": "pomp_specials_grouped.json"
        },
        {
            "name": "Aandrijftechniek",
            "grouped_file": "aandrijftechniek_grouped.json",
            "catalog_name": "catalogus-aandrijftechniek-150922",
            "output_file": "aandrijftechniek_grouped.json"
        },
    ]
    
    total_enriched = 0
    
    for cat_config in grouped_catalogs:
        print(f"\n{'='*80}")
        print(f"ENRICHING: {cat_config['name'].upper()}")
        print(f"{'='*80}")
        
        # Load grouped data
        grouped_file = OUTPUT_DIR / cat_config["grouped_file"]
        if not grouped_file.exists():
            print(f"❌ Grouped file not found: {grouped_file}")
            continue
        
        product_groups = load_json(grouped_file)
        if not product_groups:
            print(f"❌ No data in grouped file")
            continue
        
        print(f"📂 Loaded {len(product_groups)} product groups")
        
        # Enrich each group
        enriched_groups = []
        for group in product_groups:
            enriched_group = enrich_product_group(group, cat_config["catalog_name"])
            enriched_groups.append(enriched_group)
            total_enriched += 1
        
        # Save enriched data
        output_file = OUTPUT_DIR / cat_config["output_file"]
        with output_file.open("w", encoding="utf-8") as f:
            json.dump(enriched_groups, f, indent=2, ensure_ascii=False)
        
        print(f"\n💾 Saved enriched data to: {output_file}")
        
        # Copy to webshop
        webshop_file = WEBSHOP_DATA / cat_config["output_file"]
        with webshop_file.open("w", encoding="utf-8") as f:
            json.dump(enriched_groups, f, indent=2, ensure_ascii=False)
        
        print(f"💾 Copied to webshop: {webshop_file}")
        
        # Statistics
        total_variants = sum(g.get("variant_count", 0) for g in enriched_groups)
        print(f"\n📊 Enrichment Complete:")
        print(f"   Groups enriched:  {len(enriched_groups)}")
        print(f"   Variants enriched: {total_variants}")
    
    print(f"\n{'='*80}")
    print(f"✅ ALL ENRICHMENT COMPLETE")
    print(f"Total groups enriched: {total_enriched}")
    print(f"{'='*80}\n")


if __name__ == "__main__":
    enrich_all_grouped_catalogs()
