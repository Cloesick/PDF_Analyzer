"""
Copy cleaned Makita images and data to the webshop
"""
import json
import shutil
from pathlib import Path

PDF_ANALYZER = Path(r"C:\Users\prova\Documents\Projects\PDF_Analyzer")
WEBSHOP = Path(r"C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop")

# Source paths
SOURCE_IMAGES = PDF_ANALYZER / "product-images-by-pdf"
SOURCE_DATA = PDF_ANALYZER / "output" / "products_ready_for_webshop.json"

# Destination paths
DEST_IMAGES = WEBSHOP / "public" / "product-images"
DEST_DATA = WEBSHOP / "public" / "data" / "products.json"

def copy_makita_images():
    """Copy cleaned Makita images to webshop"""
    
    print("="*80)
    print("COPYING MAKITA IMAGES TO WEBSHOP")
    print("="*80)
    
    catalogs = [
        'makita-catalogus-2022-nl',
        'makita-tuinfolder-2022-nl'
    ]
    
    total_copied = 0
    
    for catalog in catalogs:
        source_dir = SOURCE_IMAGES / catalog
        dest_dir = DEST_IMAGES / catalog
        
        if not source_dir.exists():
            print(f"\n[SKIP] {catalog} - source not found")
            continue
        
        # Create destination
        dest_dir.mkdir(parents=True, exist_ok=True)
        
        # Get all images
        images = list(source_dir.glob('*.webp')) + list(source_dir.glob('*.jpg')) + list(source_dir.glob('*.png'))
        
        print(f"\n{catalog}:")
        print(f"  Copying {len(images)} images...")
        
        for img_path in images:
            dest_path = dest_dir / img_path.name
            shutil.copy2(str(img_path), str(dest_path))
            total_copied += 1
        
        print(f"  ✅ Copied {len(images)} images")
    
    print(f"\n✅ Total images copied: {total_copied}")
    print(f"📁 Destination: {DEST_IMAGES}")

def copy_product_data():
    """Copy product data to webshop"""
    
    print("\n" + "="*80)
    print("COPYING PRODUCT DATA TO WEBSHOP")
    print("="*80)
    
    if not SOURCE_DATA.exists():
        print(f"\n❌ Source data not found: {SOURCE_DATA}")
        return
    
    # Load data
    with open(SOURCE_DATA, 'r', encoding='utf-8') as f:
        products = json.load(f)
    
    print(f"\nLoaded {len(products)} products")
    
    # Filter Makita products
    makita_products = [p for p in products if 'makita' in p.get('catalog', '').lower() or p.get('brand') == 'Makita']
    other_products = [p for p in products if p not in makita_products]
    
    print(f"  Makita products: {len(makita_products)}")
    print(f"  Other products: {len(other_products)}")
    
    # Create destination directory
    DEST_DATA.parent.mkdir(parents=True, exist_ok=True)
    
    # Save to webshop
    with open(DEST_DATA, 'w', encoding='utf-8') as f:
        json.dump(products, f, indent=2, ensure_ascii=False)
    
    print(f"\n✅ Saved {len(products)} products to webshop")
    print(f"📁 Destination: {DEST_DATA}")
    
    # Show sample Makita product
    if makita_products:
        sample = makita_products[0]
        print(f"\n" + "="*80)
        print("SAMPLE MAKITA PRODUCT")
        print("="*80)
        print(f"SKU: {sample.get('sku')}")
        print(f"Brand: {sample.get('brand')}")
        print(f"Specs: {len(sample.get('specs', []))}")
        print(f"Images: {len(sample.get('media', []))}")
        
        if sample.get('specs'):
            print(f"\nSample specs:")
            for spec in sample['specs'][:3]:
                print(f"  {spec.get('value')}")

def verify_webshop_structure():
    """Verify webshop has correct structure"""
    
    print("\n" + "="*80)
    print("VERIFYING WEBSHOP STRUCTURE")
    print("="*80)
    
    checks = [
        (WEBSHOP, "Webshop root"),
        (WEBSHOP / "public", "Public folder"),
        (DEST_IMAGES, "Product images"),
        (DEST_DATA.parent, "Data folder"),
        (DEST_DATA, "Products JSON"),
    ]
    
    all_good = True
    
    for path, name in checks:
        exists = path.exists()
        status = "✅" if exists else "❌"
        print(f"{status} {name}: {path}")
        if not exists:
            all_good = False
    
    if all_good:
        print(f"\n✅ Webshop structure is correct!")
    else:
        print(f"\n⚠️ Some paths are missing - creating them...")

def main():
    print("="*80)
    print("WEBSHOP INTEGRATION - COPY CLEANED DATA")
    print("="*80)
    print(f"\nSource: {PDF_ANALYZER}")
    print(f"Destination: {WEBSHOP}")
    
    # Verify webshop exists
    if not WEBSHOP.exists():
        print(f"\n❌ ERROR: Webshop not found at {WEBSHOP}")
        print(f"Please update the WEBSHOP path in this script.")
        return
    
    # Verify source data exists
    if not SOURCE_DATA.exists():
        print(f"\n❌ ERROR: Source data not found at {SOURCE_DATA}")
        print(f"Please run: python merge_makita_to_webshop.py")
        return
    
    # Verify structure
    verify_webshop_structure()
    
    # Copy images
    copy_makita_images()
    
    # Copy data
    copy_product_data()
    
    # Final message
    print("\n" + "="*80)
    print("✅ INTEGRATION COMPLETE")
    print("="*80)
    print(f"\nNext steps:")
    print(f"1. ✅ Images copied to: {DEST_IMAGES}")
    print(f"2. ✅ Data copied to: {DEST_DATA}")
    print(f"3. 🔄 Restart your dev server: npm run dev")
    print(f"4. 🌐 Check: http://localhost:3000/products")

if __name__ == '__main__':
    main()
