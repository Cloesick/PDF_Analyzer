#!/usr/bin/env python3
"""
Process All Catalogs - Automation Script

This script automates the complete workflow for processing PDF catalogs:
1. Extract product data from PDF
2. Extract images from PDF
3. Group products by table/family
4. Copy to webshop (optional)

Usage:
    python process_all_catalogs.py --catalog rubber-slangen
    python process_all_catalogs.py --phase 1
    python process_all_catalogs.py --list
"""

import sys
import subprocess
import json
from pathlib import Path
from typing import Dict, List, Optional

# Project paths
PROJECT_ROOT = Path(__file__).parent
INPUT_PDFS = PROJECT_ROOT / "input_pdfs"
OUTPUT_DIR = PROJECT_ROOT / "output"
WEBSHOP_ROOT = PROJECT_ROOT.parent / "DemaWebshop" / "dema-webshop"

# Custom extraction scripts mapping (high-quality catalog-specific scripts)
CUSTOM_EXTRACTION_SCRIPTS = {
    "abs-persluchtbuizen": "extract_abs_from_tables.py",
    "slangkoppelingen": "extract_slangkoppelingen_correct.py",
    "pomp-specials": "extract_pomp_specials_correct_v2.py",
    "aandrijftechniek": "extract_aandrijf_specs.py",
    "plat-oprolbare-slangen": "extract_plat_oprolbare_correct.py",
    "rvs-draadfittingen": "extract_rvs_improved.py",
    "makita-catalogus": "extract_makita_tools_only.py",
    "makita-tuinfolder": "extract_makita_tuinfolder.py",
}

# Catalog configurations
CATALOG_CONFIG = {
    # Phase 1: High-value hoses and tubes
    "rubber-slangen": {
        "pdf": "rubber-slangen.pdf",
        "phase": 1,
        "priority": "high",
        "expected_groups": "20-40"
    },
    "pu-afzuigslangen": {
        "pdf": "pu-afzuigslangen.pdf",
        "phase": 1,
        "priority": "high",
        "expected_groups": "10-20"
    },
    "slangklemmen": {
        "pdf": "slangklemmen.pdf",
        "phase": 1,
        "priority": "high",
        "expected_groups": "15-30"
    },
    "drukbuizen": {
        "pdf": "drukbuizen.pdf",
        "phase": 1,
        "priority": "high",
        "expected_groups": "10-25"
    },
    "pe-buizen": {
        "pdf": "pe-buizen.pdf",
        "phase": 1,
        "priority": "high",
        "expected_groups": "10-20"
    },
    "verzinkte-buizen": {
        "pdf": "verzinkte-buizen.pdf",
        "phase": 1,
        "priority": "high",
        "expected_groups": "10-20"
    },
    
    # Phase 2: Fittings
    "messing-draadfittingen": {
        "pdf": "messing-draadfittingen.pdf",
        "phase": 2,
        "priority": "medium",
        "expected_groups": "20-40"
    },
    "rvs-draadfittingen": {
        "pdf": "rvs-draadfittingen.pdf",
        "phase": 2,
        "priority": "medium",
        "expected_groups": "15-30"
    },
    "zwarte-draad-en-lasfittingen": {
        "pdf": "zwarte-draad-en-lasfittingen (1).pdf",
        "pdf_variations": ["zwarte-draad-en-lasfittingen.pdf", "zwarte-draad-en-lasfittingen (1).pdf"],
        "phase": 2,
        "priority": "medium",
        "expected_groups": "10-25"
    },
    "kunststof-afvoerleidingen": {
        "pdf": "kunststof-afvoerleidingen.pdf",
        "phase": 2,
        "priority": "medium",
        "expected_groups": "10-20"
    },
    
    # Phase 3: Pumps
    "centrifugaalpompen": {
        "pdf": "centrifugaalpompen.pdf",
        "phase": 3,
        "priority": "medium",
        "expected_groups": "5-15"
    },
    "dompelpompen": {
        "pdf": "dompelpompen.pdf",
        "phase": 3,
        "priority": "medium",
        "expected_groups": "5-15"
    },
    "bronpompen": {
        "pdf": "bronpompen.pdf",
        "phase": 3,
        "priority": "medium",
        "expected_groups": "5-10"
    },
    "zuigerpompen": {
        "pdf": "zuigerpompen (1).pdf",
        "pdf_variations": ["zuigerpompen.pdf", "zuigerpompen (1).pdf"],
        "phase": 3,
        "priority": "medium",
        "expected_groups": "5-10"
    },
    "pompentoebehoren": {
        "pdf": "digitale-versie-pompentoebehoren-compressed.pdf",
        "pdf_variations": ["pompentoebehoren.pdf", "digitale-versie-pompentoebehoren-compressed.pdf"],
        "phase": 3,
        "priority": "low",
        "expected_groups": "10-30"
    },
    
    # Phase 4: Brand catalogs
    "makita-catalogus": {
        "pdf": "makita-catalogus-2022-nl.pdf",
        "phase": 4,
        "priority": "high",
        "expected_groups": "30-60",
        "notes": "Large catalog, many power tools"
    },
    "makita-tuinfolder": {
        "pdf": "makita-tuinfolder-2022-nl.pdf",
        "phase": 4,
        "priority": "medium",
        "expected_groups": "10-20"
    },
    "kranzle-catalogus": {
        "pdf": "kranzle-catalogus-2021-nl-1.pdf",
        "phase": 4,
        "priority": "medium",
        "expected_groups": "15-30"
    },
    "airpress-catalogus-nl": {
        "pdf": "airpress-catalogus-nl-fr.pdf",
        "phase": 4,
        "priority": "medium",
        "expected_groups": "20-40",
        "notes": "Multi-language, may need filtering"
    },
    "airpress-catalogus-en": {
        "pdf": "airpress-catalogus-eng.pdf",
        "phase": 4,
        "priority": "low",
        "expected_groups": "20-40",
        "notes": "English version, possible duplicate"
    }
}

# Already processed catalogs
PROCESSED_CATALOGS = {
    "abs-persluchtbuizen": {"groups": 18, "variants": 240},
    "slangkoppelingen": {"groups": 34, "variants": 313},
    "pomp-specials": {"groups": 11, "variants": 107},
    "aandrijftechniek": {"groups": 14, "variants": 54},
    "plat-oprolbare-slangen": {"groups": 0, "variants": 67}
}


def print_banner(text: str):
    """Print a nice banner"""
    print(f"\n{'='*80}")
    print(f"{text}")
    print(f"{'='*80}\n")


def run_command(cmd: List[str], cwd: Optional[Path] = None) -> bool:
    """Run a command and return success status"""
    try:
        result = subprocess.run(
            cmd,
            cwd=cwd or PROJECT_ROOT,
            capture_output=False,
            check=True
        )
        return result.returncode == 0
    except subprocess.CalledProcessError as e:
        print(f"❌ Command failed with exit code {e.returncode}")
        return False
    except Exception as e:
        print(f"❌ Error running command: {e}")
        return False


def check_extraction_exists(catalog_name: str) -> bool:
    """Check if extraction data already exists"""
    dynamic_file = OUTPUT_DIR / "archive" / "catalog_extractions" / f"{catalog_name.replace('-', '_')}_dynamic.json"
    return dynamic_file.exists()


def check_images_exist(catalog_name: str) -> bool:
    """Check if images have been extracted"""
    images_dir = PROJECT_ROOT / "product-images-by-pdf" / catalog_name
    if not images_dir.exists():
        return False
    return len(list(images_dir.glob("*.webp"))) > 0


def extract_catalog_data(catalog_name: str) -> bool:
    """Step 1: Extract product data from PDF (uses custom script if available)"""
    print(f"📦 Step 1: Extracting product data from {catalog_name}...")
    
    if check_extraction_exists(catalog_name):
        print(f"   ✅ Extraction data already exists, skipping...")
        return True
    
    # HYBRID APPROACH: Check for custom script first
    if catalog_name in CUSTOM_EXTRACTION_SCRIPTS:
        custom_script = CUSTOM_EXTRACTION_SCRIPTS[catalog_name]
        script_path = PROJECT_ROOT / custom_script
        
        if script_path.exists():
            print(f"   🎯 Using custom high-quality script: {custom_script}")
            cmd = [sys.executable, custom_script]
            return run_command(cmd)
        else:
            print(f"   ⚠️  Custom script not found: {custom_script}, falling back to universal")
    
    # Fallback to universal extraction script
    print(f"   🔧 Using universal extraction script")
    cmd = [sys.executable, "extract_single_catalog.py", catalog_name]
    return run_command(cmd)


def extract_images(catalog_name: str, pdf_filename: str) -> bool:
    """Step 2: Extract images from PDF"""
    print(f"🖼️  Step 2: Extracting images from {pdf_filename}...")
    
    if check_images_exist(catalog_name):
        print(f"   ✅ Images already extracted, skipping...")
        return True
    
    pdf_path = INPUT_PDFS / pdf_filename
    if not pdf_path.exists():
        print(f"   ❌ PDF not found: {pdf_path}")
        return False
    
    # Use the universal image extraction script
    # Note: extract_all_images_universal.py processes ALL PDFs, not individual ones
    # For now, we'll skip if images don't exist and let user run manually
    print(f"   ⚠️  Run manually: python extract_all_images_universal.py")
    print(f"   ⚠️  Or extract images for {catalog_name} separately")
    return True  # Don't fail, just warn


def group_products(catalog_name: str) -> bool:
    """Step 3: Group products by table/family"""
    print(f"🔗 Step 3: Grouping products for {catalog_name}...")
    
    # First, check if catalog is in group_catalog_products.py config
    # If not, we need to add it (manual step for now)
    
    cmd = [sys.executable, "group_catalog_products.py", catalog_name]
    return run_command(cmd)


def copy_to_webshop(catalog_name: str) -> bool:
    """Step 4: Copy grouped data to webshop"""
    print(f"📋 Step 4: Copying to webshop...")
    
    grouped_file = OUTPUT_DIR / f"{catalog_name.replace('-', '_')}_grouped.json"
    if not grouped_file.exists():
        print(f"   ❌ Grouped file not found: {grouped_file}")
        return False
    
    webshop_data_dir = WEBSHOP_ROOT / "public" / "data"
    if not webshop_data_dir.exists():
        print(f"   ⚠️  Webshop directory not found: {webshop_data_dir}")
        return False
    
    dest = webshop_data_dir / f"{catalog_name.replace('-', '_')}_grouped.json"
    try:
        import shutil
        shutil.copy2(grouped_file, dest)
        print(f"   ✅ Copied to {dest}")
        return True
    except Exception as e:
        print(f"   ❌ Failed to copy: {e}")
        return False


def process_catalog(catalog_name: str, config: Dict, skip_if_exists: bool = True) -> Dict:
    """Process a complete catalog through all steps"""
    print_banner(f"PROCESSING: {catalog_name.upper()}")
    
    pdf_filename = config["pdf"]
    results = {
        "catalog": catalog_name,
        "success": False,
        "steps_completed": [],
        "steps_failed": []
    }
    
    # Step 1: Extract data
    if extract_catalog_data(catalog_name):
        results["steps_completed"].append("extraction")
    else:
        results["steps_failed"].append("extraction")
        print(f"\n❌ Extraction failed for {catalog_name}")
        return results
    
    # Step 2: Extract images
    if extract_images(catalog_name, pdf_filename):
        results["steps_completed"].append("images")
    else:
        results["steps_failed"].append("images")
        print(f"\n⚠️  Image extraction failed, continuing anyway...")
    
    # Step 3: Group products
    if group_products(catalog_name):
        results["steps_completed"].append("grouping")
    else:
        results["steps_failed"].append("grouping")
        print(f"\n❌ Grouping failed for {catalog_name}")
        return results
    
    # Step 4: Copy to webshop
    if copy_to_webshop(catalog_name):
        results["steps_completed"].append("webshop_copy")
    else:
        results["steps_failed"].append("webshop_copy")
        print(f"\n⚠️  Webshop copy failed, but catalog is processed")
    
    results["success"] = len(results["steps_failed"]) == 0
    print(f"\n{'✅' if results['success'] else '⚠️'} {catalog_name} processing complete!")
    
    return results


def list_catalogs():
    """List all available catalogs"""
    print_banner("AVAILABLE CATALOGS")
    
    print("📊 Already Processed:")
    for name, stats in PROCESSED_CATALOGS.items():
        print(f"   ✅ {name:30s} - {stats['groups']:3d} groups, {stats['variants']:4d} variants")
    
    print(f"\n📋 Ready to Process ({len(CATALOG_CONFIG)} catalogs):\n")
    
    for phase in [1, 2, 3, 4]:
        phase_catalogs = {k: v for k, v in CATALOG_CONFIG.items() if v.get("phase") == phase}
        if phase_catalogs:
            print(f"\n   Phase {phase}:")
            for name, config in phase_catalogs.items():
                priority = config.get("priority", "medium")
                expected = config.get("expected_groups", "unknown")
                priority_icon = {"high": "⭐", "medium": "▶️", "low": "⏸️"}.get(priority, "•")
                print(f"      {priority_icon} {name:30s} - Expected: {expected:8s} groups")
    
    total_processed = sum(s["groups"] for s in PROCESSED_CATALOGS.values())
    print(f"\n📊 Summary:")
    print(f"   Processed: {len(PROCESSED_CATALOGS)} catalogs, {total_processed} groups")
    print(f"   Remaining: {len(CATALOG_CONFIG)} catalogs")
    print(f"   Total: {len(PROCESSED_CATALOGS) + len(CATALOG_CONFIG)} catalogs")


def process_phase(phase_num: int):
    """Process all catalogs in a specific phase"""
    phase_catalogs = {k: v for k, v in CATALOG_CONFIG.items() if v.get("phase") == phase_num}
    
    if not phase_catalogs:
        print(f"❌ No catalogs found for phase {phase_num}")
        return
    
    print_banner(f"PROCESSING PHASE {phase_num} - {len(phase_catalogs)} Catalogs")
    
    results = []
    for name, config in phase_catalogs.items():
        result = process_catalog(name, config)
        results.append(result)
    
    # Summary
    print_banner("PHASE SUMMARY")
    successful = [r for r in results if r["success"]]
    failed = [r for r in results if not r["success"]]
    
    print(f"✅ Successful: {len(successful)}/{len(results)}")
    print(f"❌ Failed: {len(failed)}/{len(results)}")
    
    if failed:
        print(f"\nFailed catalogs:")
        for r in failed:
            print(f"   • {r['catalog']}")


def main():
    """Main entry point"""
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python process_all_catalogs.py --list")
        print("  python process_all_catalogs.py --catalog <name>")
        print("  python process_all_catalogs.py --phase <1-4>")
        print("  python process_all_catalogs.py --all")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "--list":
        list_catalogs()
    
    elif command == "--catalog":
        if len(sys.argv) < 3:
            print("❌ Please specify catalog name")
            sys.exit(1)
        
        catalog_name = sys.argv[2]
        if catalog_name not in CATALOG_CONFIG:
            print(f"❌ Unknown catalog: {catalog_name}")
            print(f"Available: {', '.join(CATALOG_CONFIG.keys())}")
            sys.exit(1)
        
        config = CATALOG_CONFIG[catalog_name]
        result = process_catalog(catalog_name, config)
        
        if result["success"]:
            print("\n🎉 Processing complete!")
        else:
            print("\n⚠️  Processing completed with errors")
    
    elif command == "--phase":
        if len(sys.argv) < 3:
            print("❌ Please specify phase number (1-4)")
            sys.exit(1)
        
        try:
            phase_num = int(sys.argv[2])
            if phase_num not in [1, 2, 3, 4]:
                raise ValueError()
        except ValueError:
            print("❌ Phase must be 1, 2, 3, or 4")
            sys.exit(1)
        
        process_phase(phase_num)
    
    elif command == "--all":
        print("⚠️  Processing ALL catalogs - this will take a while!")
        for phase in [1, 2, 3, 4]:
            process_phase(phase)
    
    else:
        print(f"❌ Unknown command: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
