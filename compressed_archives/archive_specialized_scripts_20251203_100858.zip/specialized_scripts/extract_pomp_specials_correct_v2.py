"""
CORRECT extraction of pomp-specials - READ TABLE HORIZONTALLY PER SKU ROW!
First column = SKU (Bestelnr)
Other columns = Properties based on headers
"""
import fitz
import json
import re
from pathlib import Path

def extract_number(text):
    """Extract first number from text"""
    if not text:
        return None
    match = re.search(r'(\d+(?:[.,]\d+)?)', str(text).replace(',', '.'))
    return float(match.group(1)) if match else None

def extract_rpm(text):
    """Extract RPM from text like '510 X 7,58' or '540 rpm'"""
    if not text:
        return None
    # Look for first number
    match = re.search(r'(\d+)', str(text))
    return int(match.group(1)) if match else None

pdf_path = Path(__file__).parent / 'input_pdfs' / 'pomp-specials.pdf'
output_path = Path(__file__).parent / 'output' / 'pomp_specials_correct_v2.json'
output_path.parent.mkdir(exist_ok=True)

print("=" * 100)
print("EXTRACTING POMP-SPECIALS - READING HORIZONTALLY PER SKU")
print("=" * 100)

doc = fitz.open(pdf_path)
products = []

for page_num in range(len(doc)):
    page = doc[page_num]
    tables = list(page.find_tables())
    
    if not tables:
        continue
    
    print(f"\n{'='*100}")
    print(f"PAGE {page_num + 1}")
    print(f"{'='*100}")
    
    for table_num, table in enumerate(tables):
        rows = []
        for row in table.extract():
            rows.append(row)
        
        if not rows or len(rows) < 2:
            continue
        
        # Get header row
        header = rows[0]
        print(f"\nTable {table_num + 1} - Headers: {header}")
        print(f"  Columns: {len(header)}")
        
        # Check if first column is Bestelnr (SKU)
        if 'Bestelnr' not in str(header[0]):
            print(f"  ⚠️  No Bestelnr column, skipping table")
            continue
        
        # Find column indices
        col_indices = {}
        for idx, h in enumerate(header):
            h_clean = str(h).lower().strip()
            if 'bestelnr' in h_clean:
                col_indices['sku'] = idx
            elif 'type' in h_clean and 'type' not in col_indices:
                col_indices['type'] = idx
            elif 'vermogen' in h_clean:
                col_indices['power'] = idx
                # Check if it's kW or pK
                if 'kw' in h_clean:
                    col_indices['power_unit'] = 'kW'
                elif 'pk' in h_clean:
                    col_indices['power_unit'] = 'pK'
            elif 'toeren' in h_clean:
                col_indices['rpm'] = idx
            elif 'debiet' in h_clean:
                col_indices['flow'] = idx
            elif 'opv' in h_clean or 'hoogte' in h_clean:
                col_indices['height'] = idx
            elif 'gewicht' in h_clean:
                col_indices['weight'] = idx
            elif 'aanzuig' in h_clean:
                col_indices['suction'] = idx
            elif 'steek' in h_clean and 'steekleiding' not in h_clean:
                col_indices['discharge'] = idx
        
        print(f"  Column mapping: {col_indices}")
        
        # Process each data row
        for row_num, row in enumerate(rows[1:], 1):
            if not row or len(row) < 2:
                continue
            
            # Get SKU from first column
            sku = str(row[col_indices.get('sku', 0)]).strip()
            if not sku or not re.match(r'\d+', sku):
                continue
            
            product = {
                'sku': sku,
                'catalog': 'pomp-specials',
                'page': page_num + 1
            }
            
            # READ HORIZONTALLY - get values from THIS row based on column indices
            
            # Type
            if 'type' in col_indices and col_indices['type'] < len(row):
                type_val = str(row[col_indices['type']]).strip()
                if type_val and type_val not in ['', 'nan', 'None']:
                    product['pump_type'] = type_val
            
            # Power
            if 'power' in col_indices and col_indices['power'] < len(row):
                power_val = extract_number(row[col_indices['power']])
                if power_val:
                    power_unit = col_indices.get('power_unit', 'kW')
                    if power_unit == 'pK':
                        product['power_hp'] = power_val
                        product['power_kw'] = round(power_val * 0.746, 2)
                    else:  # kW
                        product['power_kw'] = power_val
                        product['power_hp'] = round(power_val / 0.746, 2)
            
            # RPM
            if 'rpm' in col_indices and col_indices['rpm'] < len(row):
                rpm_val = extract_rpm(row[col_indices['rpm']])
                if rpm_val:
                    product['rpm'] = rpm_val
            
            # Flow
            if 'flow' in col_indices and col_indices['flow'] < len(row):
                flow_val = extract_number(row[col_indices['flow']])
                if flow_val:
                    product['flow_m3_per_h'] = flow_val
                    product['flow_l_min'] = round(flow_val * 16.667, 1)
            
            # Height
            if 'height' in col_indices and col_indices['height'] < len(row):
                height_val = extract_number(row[col_indices['height']])
                if height_val:
                    product['pressure_height_m'] = height_val
                    product['pressure_max_bar'] = round(height_val / 10, 1)
            
            # Weight
            if 'weight' in col_indices and col_indices['weight'] < len(row):
                weight_val = extract_number(row[col_indices['weight']])
                if weight_val:
                    product['weight_kg'] = weight_val
            
            # Suction DN
            if 'suction' in col_indices and col_indices['suction'] < len(row):
                suction_val = extract_number(row[col_indices['suction']])
                if suction_val:
                    product['suction_dn'] = int(suction_val)
            
            # Discharge DN
            if 'discharge' in col_indices and col_indices['discharge'] < len(row):
                discharge_val = extract_number(row[col_indices['discharge']])
                if discharge_val:
                    product['discharge_dn'] = int(discharge_val)
            
            products.append(product)
            
            # Show first 3 products per table
            if row_num <= 3:
                print(f"\n  Row {row_num}: SKU {sku}")
                for key, val in product.items():
                    if key not in ['sku', 'catalog', 'page']:
                        print(f"    {key}: {val}")

doc.close()

# Save
with open(output_path, 'w', encoding='utf-8') as f:
    json.dump(products, f, ensure_ascii=False, indent=2)

print(f"\n{'='*100}")
print(f"✅ EXTRACTED {len(products)} PRODUCTS")
print(f"💾 Saved to: {output_path}")
print(f"{'='*100}")
