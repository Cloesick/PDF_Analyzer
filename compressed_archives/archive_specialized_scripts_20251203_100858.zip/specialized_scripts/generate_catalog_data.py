#!/usr/bin/env python3
"""Generate per-catalog statistics and metadata for the webshop"""

import json
from pathlib import Path
from collections import defaultdict
import re

def slugify(text):
    """Convert catalog name to URL-friendly slug matching existing folder structure"""
    text = text.lower()
    # Remove common prefixes
    text = re.sub(r'^catalogus-', '', text)
    text = re.sub(r'^digitale-versie-', '', text)
    # Remove long numbers (like 150922, date codes, etc.)
    text = re.sub(r'-?\d{6,}', '', text)
    # Remove compressed suffix
    text = re.sub(r'-compressed$', '', text)
    # Remove version numbers at end (like -1, -2, etc.)
    text = re.sub(r'-\d+$', '', text)
    # Clean up special characters
    text = re.sub(r'[^\w\s-]', '', text)
    # Consolidate hyphens and spaces
    text = re.sub(r'[-\s]+', '-', text)
    return text.strip('-')

def get_catalog_icon(catalog_name):
    """Assign icons based on catalog name/category"""
    name_lower = catalog_name.lower()
    
    # Pumps
    if 'pomp' in name_lower or 'pump' in name_lower:
        if 'bron' in name_lower:
            return '🚰'
        elif 'centrifugaal' in name_lower:
            return '💧'
        elif 'dompel' in name_lower:
            return '🌊'
        elif 'zuiger' in name_lower:
            return '⚙️'
        else:
            return '🔧'
    
    # Pipes and tubes
    if 'buis' in name_lower or 'pipe' in name_lower or 'tube' in name_lower:
        return '🔩'
    
    # Hoses and fittings
    if 'slang' in name_lower or 'hose' in name_lower:
        return '〰️'
    if 'koppeling' in name_lower or 'fitting' in name_lower:
        return '🔗'
    
    # Tools and machinery
    if 'makita' in name_lower:
        return '🔨'
    if 'kranzle' in name_lower:
        return '🚿'
    if 'airpress' in name_lower:
        return '💨'
    
    # Drive technology
    if 'aandrijf' in name_lower or 'drive' in name_lower:
        return '⚙️'
    
    # Drainage
    if 'afvoer' in name_lower or 'drain' in name_lower:
        return '🚽'
    
    # Default
    return '📦'

def get_catalog_category(catalog_name):
    """Categorize catalogs"""
    name_lower = catalog_name.lower()
    
    if any(word in name_lower for word in ['pomp', 'pump']):
        return 'pumps'
    if any(word in name_lower for word in ['buis', 'pipe', 'tube']):
        return 'pipes'
    if any(word in name_lower for word in ['slang', 'hose', 'koppeling', 'fitting']):
        return 'hoses'
    if any(word in name_lower for word in ['makita', 'kranzle', 'airpress']):
        return 'tools'
    if any(word in name_lower for word in ['aandrijf', 'drive']):
        return 'technical'
    
    return 'other'

def calculate_catalog_stats():
    """Calculate comprehensive per-catalog statistics"""
    
    data_file = Path('output/products_ready_for_webshop_v2_comprehensive.json')
    
    if not data_file.exists():
        print("❌ Error: Data file not found!")
        return
    
    print("\n" + "="*70)
    print("GENERATING PER-CATALOG STATISTICS")
    print("="*70)
    
    with open(data_file, 'r', encoding='utf-8') as f:
        products = json.load(f)
    
    # Group products by catalog
    catalogs_data = defaultdict(lambda: {
        'products': [],
        'total_images': 0,
        'products_with_images': 0
    })
    
    for product in products:
        # Get catalog name
        catalog = product.get('catalog') or product.get('pdf_source', '').replace('.pdf', '')
        if not catalog:
            continue
        
        catalogs_data[catalog]['products'].append(product)
        
        # Count images
        media = product.get('media', [])
        if media and len(media) > 0:
            catalogs_data[catalog]['products_with_images'] += 1
            catalogs_data[catalog]['total_images'] += len(media)
    
    # Build catalog list with metadata
    catalog_list = []
    
    for catalog_name, data in sorted(catalogs_data.items()):
        total_products = len(data['products'])
        if total_products == 0:
            continue
        
        products_with_images = data['products_with_images']
        total_images = data['total_images']
        coverage = (products_with_images / total_products * 100) if total_products > 0 else 0
        
        # Count unique categories in this catalog
        categories = set()
        for p in data['products']:
            cat = p.get('category') or p.get('product_category')
            if cat:
                categories.add(cat)
        
        # Create clean catalog name
        clean_name = catalog_name.replace('_', ' ').replace('-', ' ').title()
        clean_name = re.sub(r'\d{6,}', '', clean_name)  # Remove long numbers
        clean_name = re.sub(r'\s+', ' ', clean_name).strip()
        
        # Get slug for URL
        slug = slugify(catalog_name)
        
        catalog_info = {
            'id': catalog_name,
            'name': clean_name,
            'slug': slug,
            'url': f'/catalog/{slug}-grouped',
            'icon': get_catalog_icon(catalog_name),
            'category': get_catalog_category(catalog_name),
            'totalProducts': total_products,
            'productsWithImages': products_with_images,
            'totalImages': total_images,
            'imageCoverage': round(coverage, 1),
            'categories': len(categories),
            'avgImagesPerProduct': round(total_images / total_products, 1) if total_products > 0 else 0,
            'description': f'{total_products:,} products with {coverage:.1f}% image coverage'
        }
        
        catalog_list.append(catalog_info)
        
        print(f"\n📚 {clean_name}")
        print(f"   ID: {catalog_name}")
        print(f"   Products: {total_products:,}")
        print(f"   With Images: {products_with_images:,} ({coverage:.1f}%)")
        print(f"   Total Images: {total_images:,}")
        print(f"   Categories: {len(categories)}")
        print(f"   Icon: {catalog_info['icon']}")
        print(f"   Category: {catalog_info['category']}")
    
    # Sort by number of products (descending)
    catalog_list.sort(key=lambda x: x['totalProducts'], reverse=True)
    
    # Save to JSON
    output_file = Path('output/catalogs_metadata.json')
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(catalog_list, f, indent=2, ensure_ascii=False)
    
    print("\n" + "="*70)
    print(f"✅ Generated metadata for {len(catalog_list)} catalogs")
    print(f"📁 Saved to: {output_file}")
    print("="*70)
    
    # Generate summary by category
    print("\n📊 CATALOGS BY CATEGORY:")
    categories = defaultdict(list)
    for cat in catalog_list:
        categories[cat['category']].append(cat)
    
    for category, cats in sorted(categories.items()):
        total_prods = sum(c['totalProducts'] for c in cats)
        print(f"\n   {category.upper()}: {len(cats)} catalogs, {total_prods:,} products")
        for cat in cats[:3]:  # Show top 3
            print(f"      • {cat['name']}: {cat['totalProducts']:,} products")
    
    # Generate TypeScript interface
    print("\n" + "="*70)
    print("TYPESCRIPT INTERFACE:")
    print("="*70)
    print("""
interface Catalog {
  id: string;
  name: string;
  slug: string;
  url: string;
  icon: string;
  category: 'pumps' | 'pipes' | 'hoses' | 'tools' | 'technical' | 'other';
  totalProducts: number;
  productsWithImages: number;
  totalImages: number;
  imageCoverage: number;
  categories: number;
  avgImagesPerProduct: number;
  description: string;
}
""")
    
    return catalog_list

if __name__ == '__main__':
    calculate_catalog_stats()
