"""
Extract pomp-specials with correct column structure:
- Column 0: Bestelnr (SKU)
- Column 1: Type
- Column 2: Vermogen pK (Power in horsepower)
- Column 3: Toeren x Overbrenging rpm (RPM - extract first number)
- Column 4: Debiet m³/h (Flow rate in cubic meters per hour)
- Column 5: Opv.hoogte m (Pressure height in meters)
"""
import fitz
import json
import re
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "pomp-specials.pdf"
OUTPUT_JSON = PROJECT_ROOT / "output" / "pomp_specials_specs.json"

def extract_number(value_str):
    """Extract first numeric value from string"""
    if not value_str:
        return None
    
    # Remove whitespace and newlines
    value_str = str(value_str).strip().replace('\n', ' ')
    
    # Extract number (including decimals with comma or dot)
    match = re.search(r'(\d+(?:[.,]\d+)?)', value_str)
    if match:
        return float(match.group(1).replace(',', '.'))
    
    return None

def extract_rpm(rpm_str):
    """Extract RPM from string like '510 X 7,58' - returns 510"""
    if not rpm_str:
        return None
    
    # Clean string
    rpm_str = str(rpm_str).strip().replace('\n', ' ')
    
    # Pattern: get first number before 'X' or 'x'
    match = re.search(r'(\d+)\s*[Xx]', rpm_str)
    if match:
        return int(match.group(1))
    
    # If no 'X', try to get first number
    match = re.search(r'(\d+)', rpm_str)
    if match:
        return int(match.group(1))
    
    return None

def process_pdf():
    """Process pomp-specials PDF"""
    print("=" * 80)
    print("EXTRACTING POMP-SPECIALS WITH CORRECT STRUCTURE")
    print("=" * 80)
    
    doc = fitz.open(PDF_PATH)
    
    all_products = []
    stats = {
        'pages_processed': 0,
        'tables_found': 0,
        'products_extracted': 0,
        'with_type': 0,
        'with_power': 0,
        'with_rpm': 0,
        'with_flow': 0,
        'with_pressure_height': 0
    }
    
    print(f"\n📄 Processing: {PDF_PATH.name}")
    print(f"   Total pages: {len(doc)}")
    print(f"\n⚡ Extracting products...")
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        stats['pages_processed'] += 1
        
        if (page_num + 1) % 10 == 0:
            print(f"   Processing page {page_num + 1}... ({stats['products_extracted']} products found)")
        
        # Extract tables
        try:
            tables = page.find_tables()
            for table in tables:
                stats['tables_found'] += 1
                extracted = table.extract()
                
                if not extracted or len(extracted) < 2:
                    continue
                
                # Check if this is a pomp-specials table
                # Should have headers: Bestelnr | Type | Vermogen | Toeren | Debiet | Opv.hoogte
                headers = extracted[0]
                if not any('bestelnr' in str(h).lower() for h in headers):
                    continue
                
                # Fixed column structure
                BESTELNR_COL = 0      # SKU
                TYPE_COL = 1          # Pump type
                VERMOGEN_COL = 2      # Power (HP/pK or kW)
                TOEREN_COL = 3        # RPM (with gear ratio)
                DEBIET_COL = 4        # Flow (m³/h)
                OPVHOOGTE_COL = 5     # Pressure height (m)
                
                # Check if power column is in pK (horsepower) or kW
                power_unit = 'pK'  # default
                if len(headers) > VERMOGEN_COL:
                    header_text = str(headers[VERMOGEN_COL]).lower()
                    if 'kw' in header_text:
                        power_unit = 'kW'
                    elif 'pk' in header_text:
                        power_unit = 'pK'
                
                if stats['tables_found'] <= 3:
                    print(f"      Table {stats['tables_found']}: Power unit detected = {power_unit}")
                
                # Process rows
                for row in extracted[1:]:
                    if not row or len(row) < 2:
                        continue
                    
                    # Column 0: SKU (Bestelnr)
                    sku = str(row[BESTELNR_COL]).strip()
                    if not sku or len(sku) < 3:
                        continue
                    
                    # Build product
                    product = {
                        'sku': sku,
                        'page_in_pdf': page_num + 1
                    }
                    
                    # Column 1: Type
                    if len(row) > TYPE_COL:
                        pump_type = str(row[TYPE_COL]).strip()
                        if pump_type and pump_type != '-':
                            product['pump_type'] = pump_type
                            stats['with_type'] += 1
                    
                    # Column 2: Power (HP/pK or kW - depends on header)
                    if len(row) > VERMOGEN_COL:
                        power_value = extract_number(row[VERMOGEN_COL])
                        if power_value:
                            if power_unit == 'pK':
                                # Value is in horsepower, convert to kW
                                product['power_hp'] = power_value
                                product['power_kw'] = round(power_value * 0.746, 2)
                            else:  # power_unit == 'kW'
                                # Value is in kilowatts, convert to HP
                                product['power_kw'] = power_value
                                product['power_hp'] = round(power_value / 0.746, 2)
                            stats['with_power'] += 1
                    
                    # Column 3: RPM (extract from "510 X 7,58" format)
                    if len(row) > TOEREN_COL:
                        rpm = extract_rpm(row[TOEREN_COL])
                        if rpm:
                            product['rpm'] = rpm
                            stats['with_rpm'] += 1
                    
                    # Column 4: Flow rate (m³/h)
                    if len(row) > DEBIET_COL:
                        flow_m3_h = extract_number(row[DEBIET_COL])
                        if flow_m3_h:
                            product['flow_m3_per_h'] = flow_m3_h
                            # Convert to L/min (1 m³/h = 16.667 L/min)
                            product['flow_l_min'] = round(flow_m3_h * 16.667, 1)
                            stats['with_flow'] += 1
                    
                    # Column 5: Pressure height (m)
                    if len(row) > OPVHOOGTE_COL:
                        pressure_height_m = extract_number(row[OPVHOOGTE_COL])
                        if pressure_height_m:
                            product['pressure_height_m'] = pressure_height_m
                            # Convert to bar (10 m ≈ 1 bar)
                            product['pressure_max_bar'] = round(pressure_height_m / 10, 2)
                            stats['with_pressure_height'] += 1
                    
                    all_products.append(product)
                    stats['products_extracted'] += 1
                    
                    if stats['products_extracted'] <= 10:
                        print(f"      ✓ {sku:20} | {product.get('pump_type', 'N/A'):10} | ⚡ {product.get('power_hp', 'N/A'):4} HP | 🔄 {product.get('rpm', 'N/A'):4} RPM")
                        
        except Exception as e:
            continue
    
    doc.close()
    
    # Save results
    OUTPUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(all_products, f, ensure_ascii=False, indent=2)
    
    # Statistics
    print(f"\n📊 EXTRACTION STATISTICS:")
    print(f"   Pages processed:           {stats['pages_processed']}")
    print(f"   Tables found:              {stats['tables_found']}")
    print(f"   Products extracted:        {stats['products_extracted']}")
    print(f"   With pump type:            {stats['with_type']}")
    print(f"   With power (HP):           {stats['with_power']}")
    print(f"   With RPM:                  {stats['with_rpm']}")
    print(f"   With flow (m³/h):          {stats['with_flow']}")
    print(f"   With pressure height (m):  {stats['with_pressure_height']}")
    
    # Show samples
    print(f"\n📋 SAMPLE PRODUCTS:")
    for product in all_products[:5]:
        print(f"\n   SKU: {product['sku']}")
        if 'pump_type' in product:
            print(f"      Type: {product['pump_type']}")
        if 'power_hp' in product:
            print(f"      ⚡ Power: {product['power_hp']} HP ({product['power_kw']} kW)")
        if 'rpm' in product:
            print(f"      🔄 RPM: {product['rpm']}")
        if 'flow_m3_per_h' in product:
            print(f"      💨 Flow: {product['flow_m3_per_h']} m³/h ({product['flow_l_min']} L/min)")
        if 'pressure_height_m' in product:
            print(f"      🔧 Pressure height: {product['pressure_height_m']} m ({product['pressure_max_bar']} bar)")
    
    print(f"\n💾 Output saved to: {OUTPUT_JSON}")
    print(f"\n{'='*80}")
    print("✅ EXTRACTION COMPLETE")
    print("="*80)
    
    return all_products

if __name__ == '__main__':
    process_pdf()
