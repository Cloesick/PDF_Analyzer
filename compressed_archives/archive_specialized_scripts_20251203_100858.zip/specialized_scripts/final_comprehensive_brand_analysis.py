"""
FINAL COMPREHENSIVE AANDRIJFTECHNIEK BRAND & SERIES ANALYSIS
Target: 95%+ categorization with ALL product series from user's text data
"""

import json
import re
from pathlib import Path
from collections import defaultdict

# Paths
INPUT_JSON = Path(r"C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop\public\data\catalogs\catalogus-aandrijftechniek-150922.json")
OUTPUT_DIR = Path(r"C:\Users\prova\Documents\Projects\PDF_Analyzer\output")
OUTPUT_JSON = OUTPUT_DIR / "catalogus_aandrijftechniek_FINAL_enriched.json"
OUTPUT_GROUPED = OUTPUT_DIR / "catalogus_aandrijftechniek_FINAL_grouped.json"
WEBSHOP_DATA = Path(r"C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop\public\data\aandrijftechniek-grouped.json")

# === COMPLETE PRODUCT SERIES MAPPING ===
# Extracted systematically from ALL sections of user's text data

SERIES_DB = [
    # ========================================================================
    # LAGERS EN LAGERHUIZEN - ZELFINSTELLENDE LAGERBLOKKEN
    # ========================================================================
    
    {"name": "NTN STAAND GIETIJZEREN LAGERBLOK P200-P300", "brand": "NTN", "series": "P200-P300", "type": "Staand Lagerblok", "material": "gietijzer", "category": "Zelfinstellende Lagerblokken", "pattern": r"^RLNUCP\d+$"},
    {"name": "FK STAAND GIETIJZEREN LAGERBLOK P200-P300", "brand": "FK", "series": "P200-P300", "type": "Staand Lagerblok", "material": "gietijzer", "category": "Zelfinstellende Lagerblokken", "pattern": r"^RLFUCP\d+$"},
    
    {"name": "NTN-SNR STAAND GIETIJZEREN LAGERBLOK PW200 (PAE200)", "brand": "NTN-SNR", "series": "PW200 (PAE200)", "type": "Staand Lagerblok", "material": "gietijzer", "category": "Zelfinstellende Lagerblokken", "pattern": r"^RL[NS]UC(PW|PAE)\d+$"},
    {"name": "FK STAAND GIETIJZEREN LAGERBLOK PW200 (PAE200)", "brand": "FK", "series": "PW200 (PAE200)", "type": "Staand Lagerblok", "material": "gietijzer", "category": "Zelfinstellende Lagerblokken", "pattern": r"^RLFUCPW\d+$"},
    
    {"name": "NTN-SNR VIERKANT GIETIJZEREN FLENSLAGERBLOK F200-F300", "brand": "NTN-SNR", "series": "F200-F300", "type": "Flenslagerblok Vierkant", "material": "gietijzer", "category": "Zelfinstellende Lagerblokken", "pattern": r"^RL[NS]UC(F|KF)\d+$"},
    {"name": "FK VIERKANT GIETIJZEREN FLENSLAGERBLOK F200", "brand": "FK", "series": "F200", "type": "Flenslagerblok Vierkant", "material": "gietijzer", "category": "Zelfinstellende Lagerblokken", "pattern": r"^RLFUCF\d+$"},
    
    {"name": "NTN ROND GIETIJZEREN FLENSLAGERBLOK FC200", "brand": "NTN", "series": "FC200", "type": "Flenslagerblok Rond", "material": "gietijzer", "category": "Zelfinstellende Lagerblokken", "pattern": r"^RLNUCFC\d+$"},
    
    {"name": "NTN OVAAL GIETIJZEREN FLENSLAGERBLOK FL200-FL300", "brand": "NTN", "series": "FL200-FL300", "type": "Flenslagerblok Ovaal", "material": "gietijzer", "category": "Zelfinstellende Lagerblokken", "pattern": r"^RLNUCFL\d+$"},
    {"name": "FK OVAAL GIETIJZEREN FLENSLAGERBLOK FL200-FL300", "brand": "FK", "series": "FL200-FL300", "type": "Flenslagerblok Ovaal", "material": "gietijzer", "category": "Zelfinstellende Lagerblokken", "pattern": r"^RLFUCFL\d+$"},
    
    {"name": "NTN-SNR VIERKANT GIETIJZEREN FLENSLAGERBLOK FS300", "brand": "NTN-SNR", "series": "FS300", "type": "Flenslagerblok Vierkant", "material": "gietijzer", "category": "Zelfinstellende Lagerblokken", "pattern": r"^RLSUCFS\d+$"},
    
    {"name": "NTN GIETIJZEREN LAGERBLOK FA200", "brand": "NTN", "series": "FA200", "type": "Flenslagerblok", "material": "gietijzer", "category": "Zelfinstellende Lagerblokken", "pattern": r"^RLNUCFA\d+$"},
    
    {"name": "NTN TAKE-UP GIETIJZEREN LAGERBLOK T200", "brand": "NTN", "series": "T200", "type": "Take-up Lagerblok", "material": "gietijzer", "category": "Zelfinstellende Lagerblokken", "pattern": r"^RLNUCT\d+$"},
    
    {"name": "NTN STAAND PLAATSTALEN LAGERBLOK PP200", "brand": "NTN", "series": "PP200", "type": "Staand Lagerblok", "material": "plaatstaal", "category": "Zelfinstellende Lagerblokken", "pattern": r"^RLASPP\d+$"},
    
    {"name": "NTN ROND PLAATSTALEN FLENSLAGERBLOK PF200", "brand": "NTN", "series": "PF200", "type": "Flenslagerblok Rond", "material": "plaatstaal", "category": "Zelfinstellende Lagerblokken", "pattern": r"^RLASPF\d+$"},
    
    {"name": "NTN OVAAL PLAATSTALEN FLENSLAGERBLOK PFL200", "brand": "NTN", "series": "PFL200", "type": "Flenslagerblok Ovaal", "material": "plaatstaal", "category": "Zelfinstellende Lagerblokken", "pattern": r"^RLASPFL\d+$"},
    
    # ========================================================================
    # SPANLAGERS
    # ========================================================================
    
    {"name": "NTN-SNR SPANLAGER UC200 TWEEZIJDIG MET STELSCHROEVEN", "brand": "NTN-SNR", "series": "UC200", "type": "Spanlager", "category": "Spanlagers", "pattern": r"^RLNUC\d{3}(?!F|FL|FC|PW|T|FA)$"},
    {"name": "NTN-SNR SPANLAGER UC200 3-VOUDIGE LIPPENDAFDICHTING", "brand": "NTN-SNR", "series": "UC200 3L", "type": "Spanlager", "category": "Spanlagers", "pattern": r"^RLNUC\d{3}G2L3$"},
    {"name": "NTN-SNR SPANLAGER UC300 TWEEZIJDIG MET STELSCHROEVEN", "brand": "NTN-SNR", "series": "UC300", "type": "Spanlager", "category": "Spanlagers", "pattern": r"^RLNUC3\d{2}$"},
    
    {"name": "SKF SPANLAGER YAR TWEEZIJDIG MET STELSCHROEVEN", "brand": "SKF", "series": "YAR", "type": "Spanlager", "category": "Spanlagers", "pattern": r"^SKFYAR\d+$"},
    {"name": "SKF SPANLAGER YAT EENZIJDIG MET STELSCHROEVEN", "brand": "SKF", "series": "YAT", "type": "Spanlager", "category": "Spanlagers", "pattern": r"^SKFYAT\d+$"},
    {"name": "SKF SPANLAGER YET EXCENTRISCHE SPANRING", "brand": "SKF", "series": "YET", "type": "Spanlager", "category": "Spanlagers", "pattern": r"^SKFYET\d+$"},
    {"name": "SKF SPANLAGER YEL EXCENTRISCHE SPANRING", "brand": "SKF", "series": "YEL", "type": "Spanlager", "category": "Spanlagers", "pattern": r"^SKFYEL\d+$"},
    
    {"name": "NTN-SNR SPANLAGER AS200/US200 EENZIJDIG MET STELSCHROEVEN", "brand": "NTN-SNR", "series": "AS200/US200", "type": "Spanlager", "category": "Spanlagers", "pattern": r"^RL(N)?AS\d+$"},
    
    {"name": "NTN-SNR SPANLAGER CS200 BOLVORMIG ZONDER ASBEVESTIGING", "brand": "NTN-SNR", "series": "CS200", "type": "Spanlager", "category": "Spanlagers", "pattern": r"^RLNCS\d+$"},
    
    {"name": "NTN-SNR SPANLAGER AEL200/ES200 EXCENTRISCHE SPANRING", "brand": "NTN-SNR", "series": "AEL200/ES200", "type": "Spanlager", "category": "Spanlagers", "pattern": r"^RLNAEL\d+$"},
    
    {"name": "NTN-SNR SPANLAGER UEL200/EX200 TWEEZIJDIG EXCENTRISCHE SPANRING", "brand": "NTN-SNR", "series": "UEL200/EX200", "type": "Spanlager", "category": "Spanlagers", "pattern": r"^RLNUEL\d+$"},
    
    {"name": "NTN-SNR SPANLAGER UK200 TWEEZIJDIG MET TREKBUS", "brand": "NTN-SNR", "series": "UK200", "type": "Spanlager", "category": "Spanlagers", "pattern": r"^RLNUK2\d{2}$"},
    {"name": "NTN-SNR SPANLAGER UK300 TWEEZIJDIG MET TREKBUS", "brand": "NTN-SNR", "series": "UK300", "type": "Spanlager", "category": "Spanlagers", "pattern": r"^RLNUK3\d{2}$"},
    
    # ========================================================================
    # KOGELLAGERS
    # ========================================================================
    
    {"name": "NTN-SNR GROEFKOGELLAGER 6000 SERIE MET RUBBER AFDICHTING", "brand": "NTN-SNR", "series": "6000 serie", "type": "Groefkogellager", "category": "Kogellagers", "pattern": r"^RL[NS]6\d+$"},
    {"name": "SKF GROEFKOGELLAGER 6000 SERIE MET RUBBER AFDICHTING", "brand": "SKF", "series": "6000 serie", "type": "Groefkogellager", "category": "Kogellagers", "pattern": r"^SKF6\d+2RS$"},
    
    {"name": "NTN-SNR GROEFKOGELLAGER 16000 SERIE ZONDER DICHTING", "brand": "NTN-SNR", "series": "16000 serie", "type": "Groefkogellager Smal", "category": "Kogellagers", "pattern": r"^RLS16\d+$"},
    
    {"name": "NTN-SNR TWEERIJDIG GROEFKOGELLAGER 4200 SERIE", "brand": "NTN-SNR", "series": "4200 serie", "type": "Tweerijdig Groefkogellager", "category": "Kogellagers", "pattern": r"^RLS42\d{2}$"},
    
    {"name": "NTN-SNR TWEERIJDIG HOEKCONTACTLAGER 3200 SERIE ZONDER DICHTING", "brand": "NTN-SNR", "series": "3200 serie", "type": "Hoekcontactlager", "category": "Kogellagers", "pattern": r"^RLN32\d{2}$"},
    
    {"name": "NTN-SNR TWEERIJDIG HOEKCONTACTLAGER 5200 SERIE MET AFDICHTING", "brand": "NTN-SNR", "series": "5200 serie", "type": "Hoekcontactlager", "category": "Kogellagers", "pattern": r"^RLS5\d{3}$"},
    
    {"name": "NTN-SNR ZELFINSTELLEND KOGELLAGER 1200/1300 SERIE", "brand": "NTN-SNR", "series": "1200/1300 serie", "type": "Zelfinstellend Kogellager", "category": "Kogellagers", "pattern": r"^RL[NS](1|2)\d{3}S?$"},
    
    {"name": "NTN-SNR ZELFINSTELLEND KOGELLAGER CONISCH 1200/1300 SK", "brand": "NTN-SNR", "series": "1200/1300 SK", "type": "Zelfinstellend Kogellager Conisch", "category": "Kogellagers", "pattern": r"^RLN\d{4}SK$"},
    
    {"name": "NTN-SNR ZELFINSTELLEND KOGELLAGER 2200/2300 SERIE MET DICHTING", "brand": "NTN-SNR", "series": "2200/2300 serie 2RS", "type": "Zelfinstellend Kogellager", "category": "Kogellagers", "pattern": r"^RLS2\d{3}$"},
    
    # ========================================================================
    # KEGELLAGERS
    # ========================================================================
    
    {"name": "NTN-SNR KEGELLAGER 30000 SERIE", "brand": "NTN-SNR", "series": "30000 serie", "type": "Kegellager", "category": "Kegellagers", "pattern": r"^RL[NS]3\d{4}$"},
    
    # ========================================================================
    # TONLAGERS
    # ========================================================================
    
    {"name": "NTN-SNR TWEERIJDIG TONLAGER 22000 SERIE", "brand": "NTN-SNR", "series": "22000 serie", "type": "Tonlager", "category": "Tonlagers", "pattern": r"^RLS22\d{3}$"},
    
    # ========================================================================
    # LAGERBUSSEN
    # ========================================================================
    
    {"name": "GLIJLAGER STAAL-POM", "brand": "Diverse", "series": "Glijlager", "type": "Glijlager", "category": "Lagerbussen", "pattern": r"^110505(82|83)$"},
    {"name": "GLIJLAGER BRONS", "brand": "Diverse", "series": "Glijlager Brons", "type": "Glijlager", "category": "Lagerbussen", "pattern": r"^(11050550|17900007)$"},
    
    # ========================================================================
    # TREKBUSSEN
    # ========================================================================
    
    {"name": "NTN-SNR TREKBUS H-SERIE", "brand": "NTN-SNR", "series": "H-serie", "type": "Trekbus", "category": "Trekbussen", "pattern": r"^RLH\d+$"},
    
    # ========================================================================
    # KETTINGAANDRIJVINGEN - ROLLENKETTINGEN
    # ========================================================================
    
    {"name": "BTC BS SIMPLEX ROLLENKETTING", "brand": "BTC", "series": "BS Simplex", "type": "Rollenketting", "category": "Kettingaandrijvingen", "pattern": r"^RKKBS\d+(?!2|3)$"},
    {"name": "BTC BS DUPLEX ROLLENKETTING", "brand": "BTC", "series": "BS Duplex", "type": "Rollenketting", "category": "Kettingaandrijvingen", "pattern": r"^RKKBS\d+2$"},
    {"name": "BTC BS TRIPLEX ROLLENKETTING", "brand": "BTC", "series": "BS Triplex", "type": "Rollenketting", "category": "Kettingaandrijvingen", "pattern": r"^RKKBS\d+3$"},
    
    {"name": "BTC ASA SIMPLEX ROLLENKETTING", "brand": "BTC", "series": "ASA Simplex", "type": "Rollenketting", "category": "Kettingaandrijvingen", "pattern": r"^RKKASA\d+(?!2|3)$"},
    {"name": "BTC ASA DUPLEX ROLLENKETTING", "brand": "BTC", "series": "ASA Duplex", "type": "Rollenketting", "category": "Kettingaandrijvingen", "pattern": r"^RKKASA\d+2$"},
    {"name": "BTC ASA TRIPLEX ROLLENKETTING", "brand": "BTC", "series": "ASA Triplex", "type": "Rollenketting", "category": "Kettingaandrijvingen", "pattern": r"^RKKASA\d+3$"},
    
    {"name": "BTC VERZWAARDE KETTING EUROPEES", "brand": "BTC", "series": "Verzwaard EU", "type": "Rollenketting Verzwaard", "category": "Kettingaandrijvingen", "pattern": r"^RKKBS(081|083|084|332|428|12R|16R|24R)"},
    {"name": "BTC VERZWAARDE KETTING ASA", "brand": "BTC", "series": "Verzwaard ASA", "type": "Rollenketting Verzwaard", "category": "Kettingaandrijvingen", "pattern": r"^RKKASA\d+H"},
    
    {"name": "BTC SLUITSCHAKELS BS", "brand": "BTC", "series": "Sluitschakels BS", "type": "Sluitschakel", "category": "Kettingaandrijvingen", "pattern": r"^RKSBS\d+"},
    {"name": "BTC SLUITSCHAKELS ASA", "brand": "BTC", "series": "Sluitschakels ASA", "type": "Sluitschakel", "category": "Kettingaandrijvingen", "pattern": r"^RKSASA\d+"},
    
    {"name": "BTC VERLOOPSCHAKELS BS", "brand": "BTC", "series": "Verloopschakels BS", "type": "Verloopschakel", "category": "Kettingaandrijvingen", "pattern": r"^RKVBS\d+"},
    {"name": "BTC VERLOOPSCHAKELS ASA", "brand": "BTC", "series": "Verloopschakels ASA", "type": "Verloopschakel", "category": "Kettingaandrijvingen", "pattern": r"^RKVASA\d+"},
    
    {"name": "BTC LANDBOUWKETTING", "brand": "BTC", "series": "Landbouwketting", "type": "Landbouwketting", "category": "Kettingaandrijvingen", "pattern": r"^RKKS55RH\d+"},
    {"name": "BTC LANDBOUWKETTING SLUITSCHAKEL", "brand": "BTC", "series": "Landbouwketting Sluiting", "type": "Sluitschakel", "category": "Kettingaandrijvingen", "pattern": r"^RKSS55RH$"},
    
    {"name": "BTC HOLLEBOUTKETTING C2062", "brand": "BTC", "series": "Holleboutketting", "type": "Holleboutketting", "category": "Kettingaandrijvingen", "pattern": r"^RK(K|S)HBC\d+"},
    
    # ========================================================================
    # AANDRIJFASSEN - COMPLEET
    # ========================================================================
    
    {"name": "WALTERSCHEID W-SERIE STANDAARD", "brand": "Walterscheid", "series": "W-serie Standaard", "type": "Aandrijfas", "category": "Aandrijfassen", "pattern": r"^CARDW\d{4}(?!V)"},
    {"name": "WALTERSCHEID W-SERIE MET VRIJLOOP", "brand": "Walterscheid", "series": "W-serie Vrijloop", "type": "Aandrijfas", "category": "Aandrijfassen", "pattern": r"^CARDW\d{4}V$"},
    {"name": "WALTERSCHEID W-SERIE MET BREEKBOUT", "brand": "Walterscheid", "series": "W-serie Breekbout", "type": "Aandrijfas", "category": "Aandrijfassen", "pattern": r"^CARDW\d{4}B"},
    
    {"name": "WALTERSCHEID WWE-SERIE GROOTHOEK STANDAARD", "brand": "Walterscheid", "series": "WWE-serie Groothoek", "type": "Aandrijfas Groothoek", "category": "Aandrijfassen", "pattern": r"^CARDWWE\d{4}(?!V)"},
    {"name": "WALTERSCHEID WWE-SERIE MET VRIJLOOP", "brand": "Walterscheid", "series": "WWE-serie Vrijloop", "type": "Aandrijfas Groothoek", "category": "Aandrijfassen", "pattern": r"^CARDWWE\d{4}V"},
    
    {"name": "WALTERSCHEID PWE-SERIE", "brand": "Walterscheid", "series": "PWE-serie", "type": "Aandrijfas", "category": "Aandrijfassen", "pattern": r"^CARDPWE\d+"},
    
    {"name": "WALTERSCHEID WWZ-SERIE DUBBELE GROOTHOEK", "brand": "Walterscheid", "series": "WWZ-serie", "type": "Aandrijfas Dubbele Groothoek", "category": "Aandrijfassen", "pattern": r"^CARDWWZ\d+"},
    
    # ========================================================================
    # AANDRIJFASSEN - GAFFELS
    # ========================================================================
    
    {"name": "WALTERSCHEID AANSLUITGAFFEL", "brand": "Walterscheid", "series": "Gaffels", "type": "Aansluitgaffel", "category": "Aandrijfassen", "pattern": r"^CARG\d+(?!D)"},
    {"name": "WALTERSCHEID DUBBELGAFFEL", "brand": "Walterscheid", "series": "Dubbelgaffels", "type": "Dubbelgaffel", "category": "Aandrijfassen", "pattern": r"^CARGD\d+"},
    
    # ========================================================================
    # AANDRIJFASSEN - KRUISKOPPELINGEN & KRUISSTUKKEN
    # ========================================================================
    
    {"name": "WALTERSCHEID KRUISKOPPELING", "brand": "Walterscheid", "series": "Kruiskoppelingen", "type": "Kruiskoppeling", "category": "Aandrijfassen", "pattern": r"^CARK\d+"},
    
    {"name": "WALTERSCHEID KRUISSTUK STANDAARD C-AFDICHTING", "brand": "Walterscheid", "series": "Kruisstukken", "type": "Kruisstuk", "category": "Aandrijfassen", "pattern": r"^CARS\d+"},
    
    # ========================================================================
    # AANDRIJFASSEN - PROFIELBUIZEN
    # ========================================================================
    
    {"name": "WALTERSCHEID PROFIELBUIS BUITENBUIS", "brand": "Walterscheid", "series": "Profielbuizen", "type": "Profielbuis Buiten", "category": "Aandrijfassen", "pattern": r"^CARBU12\d+"},
    {"name": "WALTERSCHEID PROFIELBUIS BINNENBUIS", "brand": "Walterscheid", "series": "Profielbuizen", "type": "Profielbuis Binnen", "category": "Aandrijfassen", "pattern": r"^CARBU11\d+"},
    
    {"name": "BONDIOLI & PAVESI PROFIELBUIS BUITENBUIS", "brand": "Bondioli & Pavesi", "series": "Profielbuizen", "type": "Profielbuis Buiten", "category": "Aandrijfassen", "pattern": r"^CARBU32\d+"},
    {"name": "BONDIOLI & PAVESI PROFIELBUIS BINNENBUIS", "brand": "Bondioli & Pavesi", "series": "Profielbuizen", "type": "Profielbuis Binnen", "category": "Aandrijfassen", "pattern": r"^CARBU31\d+"},
    
    # ========================================================================
    # AANDRIJFRIEMEN
    # ========================================================================
    
    {"name": "OPTIBELT KLASSIEKE V-RIEM PROFIEL A/13", "brand": "Optibelt", "series": "Klassiek A/13", "type": "V-Riem", "category": "Aandrijfriemen", "pattern": r"^VRA\d+"},
    {"name": "OPTIBELT KLASSIEKE V-RIEM PROFIEL B/17", "brand": "Optibelt", "series": "Klassiek B/17", "type": "V-Riem", "category": "Aandrijfriemen", "pattern": r"^VRB\d+"},
    {"name": "OPTIBELT KLASSIEKE V-RIEM PROFIEL C/22", "brand": "Optibelt", "series": "Klassiek C/22", "type": "V-Riem", "category": "Aandrijfriemen", "pattern": r"^VRC\d+"},
    
    {"name": "OPTIBELT HOOGVERMOGEN V-RIEM PROFIEL SPB", "brand": "Optibelt", "series": "SPB", "type": "V-Riem Hoogvermogen", "category": "Aandrijfriemen", "pattern": r"^VRSPB\d+"},
    {"name": "OPTIBELT HOOGVERMOGEN V-RIEM PROFIEL SPZ", "brand": "Optibelt", "series": "SPZ", "type": "V-Riem Hoogvermogen", "category": "Aandrijfriemen", "pattern": r"^VRSPZ\d+"},
    
    {"name": "OPTIBELT VENTILATORRIEM VERTAND PROFIEL AVX10", "brand": "Optibelt", "series": "AVX10", "type": "Ventilatorriem", "category": "Aandrijfriemen", "pattern": r"^VRAVX10\d+"},
    {"name": "OPTIBELT VENTILATORRIEM VERTAND PROFIEL AVX13", "brand": "Optibelt", "series": "AVX13", "type": "Ventilatorriem", "category": "Aandrijfriemen", "pattern": r"^VRAVX13\d+"},
    
    # ========================================================================
    # OLIEKEERRINGEN
    # ========================================================================
    
    {"name": "OLIEKEERRING MET RUBBER MANTEL EN STOFLIP", "brand": "Diverse", "series": "Oliekeerringen", "type": "Oliekeerring", "category": "Oliekeerringen", "pattern": r"^OK\d+"},
    
    # ========================================================================
    # NYLON STAFMATERIAAL
    # ========================================================================
    
    {"name": "PA6 XT GIETNYLON STAAF", "brand": "Diverse", "series": "PA6 XT", "type": "Gietnylon Staaf", "category": "Nylon Stafmateriaal", "pattern": r"^14210\d{3}$"},
    
    # ========================================================================
    # COMPONENT CODES (Lagerhuis, Spanlager codes used in tables)
    # ========================================================================
    
    {"name": "LAGERHUIS P-SERIE", "brand": "Component", "series": "P-serie", "type": "Lagerhuis", "category": "Components", "pattern": r"^P\d{3}$"},
    {"name": "LAGERHUIS PW-SERIE/PAE-SERIE", "brand": "Component", "series": "PW/PAE-serie", "type": "Lagerhuis", "category": "Components", "pattern": r"^P(W|AE)\d{3}$"},
    {"name": "LAGERHUIS F-SERIE", "brand": "Component", "series": "F-serie", "type": "Lagerhuis", "category": "Components", "pattern": r"^F[A-Z]?\d{3}$"},
    {"name": "LAGERHUIS T-SERIE", "brand": "Component", "series": "T-serie", "type": "Lagerhuis Take-up", "category": "Components", "pattern": r"^T\d{3}$"},
    {"name": "LAGERHUIS PP-SERIE", "brand": "Component", "series": "PP-serie", "type": "Lagerhuis Plaatstaal", "category": "Components", "pattern": r"^PP\d{3}$"},
    {"name": "LAGERHUIS PF-SERIE", "brand": "Component", "series": "PF-serie", "type": "Lagerhuis Plaatstaal Rond", "category": "Components", "pattern": r"^PF\d{3}$"},
    
    {"name": "SPANLAGER UC-SERIE", "brand": "Component", "series": "UC-serie", "type": "Spanlager", "category": "Components", "pattern": r"^UC\d{3}G?\d?L?\d?$"},
    {"name": "SPANLAGER UK-SERIE", "brand": "Component", "series": "UK-serie", "type": "Spanlager", "category": "Components", "pattern": r"^UK\d{3}G?\d?H?$"},
    {"name": "SPANLAGER US/AS-SERIE", "brand": "Component", "series": "US/AS-serie", "type": "Spanlager", "category": "Components", "pattern": r"^(US|AS)\d{3}G?\d?$"},
    
    {"name": "BORGMOER/BORGRING", "brand": "Component", "series": "Borgingen", "type": "Borgmoer/Borgring", "category": "Components", "pattern": r"^(KM|MB)\d+$"},
    {"name": "SPANBUS H-SERIE", "brand": "Component", "series": "H-serie Spanbus", "type": "Spanbus", "category": "Components", "pattern": r"^H\d{4}$"},
]

def find_best_match(sku):
    """Find the best matching series for a SKU"""
    for series in SERIES_DB:
        if re.match(series["pattern"], sku):
            return series
    return None

def enrich_product(product):
    """Enrich a product with complete brand and series information"""
    sku = product.get("sku", "")
    
    # Find best match
    match = find_best_match(sku)
    
    if match:
        product["brand"] = match["brand"]
        product["series"] = match["series"]
        product["product_type"] = match["type"]
        product["subcategory"] = match["category"]
        product["material"] = match.get("material")
        
        # Generate name and description
        brand = product["brand"]
        ptype = product["product_type"]
        series = product.get("series", "")
        
        product["name"] = f"{brand} {ptype} {sku}"
        if series:
            product["description"] = f"{brand} {ptype} uit de {series} serie"
        else:
            product["description"] = f"{brand} {ptype}"
        
        # Initialize attributes
        if not product.get("attributes"):
            product["attributes"] = {}
        
        if match.get("material"):
            product["attributes"]["material"] = match["material"]
    
    return product

def main():
    print("=" * 90)
    print("🎯 FINAL COMPREHENSIVE AANDRIJFTECHNIEK BRAND & SERIES ANALYSIS")
    print("=" * 90)
    print(f"\n📚 Loaded {len(SERIES_DB)} product series definitions")
    
    # Load existing data
    print("\n📖 Loading catalog data...")
    with open(INPUT_JSON, 'r', encoding='utf-8') as f:
        products = json.load(f)
    print(f"   ✓ Loaded {len(products)} products")
    
    # Enrich all products
    print("\n🔍 Enriching products...")
    enriched_products = []
    brand_stats = defaultdict(int)
    category_stats = defaultdict(int)
    series_stats = defaultdict(int)
    unmatched = []
    
    for i, product in enumerate(products):
        if (i + 1) % 200 == 0:
            print(f"   📊 Processed {i + 1}/{len(products)} products...")
        
        enriched = enrich_product(product)
        enriched_products.append(enriched)
        
        brand = enriched.get("brand")
        if not brand:
            unmatched.append(enriched.get("sku"))
            brand = "Uncategorized"
        
        category = enriched.get("subcategory", "Diverse")
        series = enriched.get("series", "")
        
        brand_stats[brand] += 1
        category_stats[category] += 1
        if series:
            series_stats[f"{brand} - {series}"] += 1
    
    print(f"   ✓ Enriched {len(enriched_products)} products")
    
    # Save enriched products
    print("\n💾 Saving enriched catalog...")
    OUTPUT_DIR.mkdir(exist_ok=True)
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(enriched_products, f, indent=2, ensure_ascii=False)
    print(f"   ✓ Saved to: {OUTPUT_JSON}")
    
    # Create grouped structure
    print("\n📊 Creating grouped structure...")
    grouped = defaultdict(lambda: defaultdict(list))
    
    for product in enriched_products:
        brand = product.get("brand", "Uncategorized")
        series = product.get("series", "Overig")
        category = product.get("subcategory", "Diverse")
        
        if series and series != "Overig":
            group_key = f"{brand} - {series}"
        else:
            group_key = f"{brand} - {category}"
        
        grouped[brand][group_key].append(product)
    
    # Format grouped output
    output_groups = []
    for brand, series_dict in sorted(grouped.items(), key=lambda x: str(x[0])):
        for series_name, products_list in sorted(series_dict.items(), key=lambda x: str(x[0])):
            rep_product = products_list[0]
            
            group = {
                "group_id": series_name.lower().replace(" ", "-").replace("--", "-").replace("(", "").replace(")", "").replace("/", "-"),
                "group_name": series_name,
                "brand": brand,
                "category": rep_product.get("subcategory", "Diverse"),
                "series": rep_product.get("series", ""),
                "product_type": rep_product.get("product_type", "Product"),
                "material": rep_product.get("material"),
                "product_count": len(products_list),
                "media": [],
                "variants": []
            }
            
            # Collect images
            all_images = []
            for prod in products_list:
                if prod.get("image_paths"):
                    all_images.extend(prod["image_paths"])
                elif prod.get("imageUrl"):
                    all_images.append(prod["imageUrl"])
            
            unique_images = list(dict.fromkeys(all_images))
            if unique_images:
                group["media"] = [
                    {"url": img, "role": "main" if i == 0 else "gallery", "type": "image"} 
                    for i, img in enumerate(unique_images[:15])
                ]
            
            # Add variants
            for prod in products_list:
                variant = {
                    "sku": prod["sku"],
                    "name": prod["name"],
                    "attributes": prod.get("attributes", {}),
                    "specs": prod.get("specs", []),
                    "image_url": prod.get("imageUrl"),
                    "pages": prod.get("source_pages", [])
                }
                group["variants"].append(variant)
            
            output_groups.append(group)
    
    # Save grouped output
    with open(OUTPUT_GROUPED, 'w', encoding='utf-8') as f:
        json.dump(output_groups, f, indent=2, ensure_ascii=False)
    print(f"   ✓ Created {len(output_groups)} product groups")
    print(f"   ✓ Saved to: {OUTPUT_GROUPED}")
    
    # Copy to webshop
    print("\n🌐 Copying to webshop...")
    with open(WEBSHOP_DATA, 'w', encoding='utf-8') as f:
        json.dump(output_groups, f, indent=2, ensure_ascii=False)
    print(f"   ✓ Saved to: {WEBSHOP_DATA}")
    
    # Statistics
    match_rate = ((len(products) - len(unmatched)) / len(products) * 100)
    
    print("\n" + "=" * 90)
    print("📈 FINAL RESULTS")
    print("=" * 90)
    
    print(f"\n✅ CATEGORIZATION SUCCESS:")
    print(f"   • Total Products         : {len(products)}")
    print(f"   • Successfully Categorized: {len(products) - len(unmatched)} ({match_rate:.1f}%)")
    print(f"   • Uncategorized          : {len(unmatched)} ({100 - match_rate:.1f}%)")
    print(f"   • Total Groups Created   : {len(output_groups)}")
    print(f"   • Series Definitions Used: {len(SERIES_DB)}")
    
    print(f"\n🏭 TOP 10 BRANDS:")
    for brand, count in sorted(brand_stats.items(), key=lambda x: -x[1])[:10]:
        pct = (count / len(products)) * 100
        brand_str = str(brand) if brand else "None"
        print(f"   • {brand_str:25s} : {count:4d} products ({pct:5.1f}%)")
    
    print(f"\n📦 TOP 10 CATEGORIES:")
    for cat, count in sorted(category_stats.items(), key=lambda x: -x[1])[:10]:
        pct = (count / len(products)) * 100
        cat_str = str(cat) if cat else "None"
        print(f"   • {cat_str:35s} : {count:4d} products ({pct:5.1f}%)")
    
    if unmatched:
        print(f"\n⚠️  REMAINING UNCATEGORIZED ({len(unmatched)} SKUs):")
        print(f"   Sample: {', '.join(unmatched[:15])}")
    
    print("\n" + "=" * 90)
    if match_rate >= 95:
        print("🎉 SUCCESS! Achieved 95%+ categorization target!")
    elif match_rate >= 90:
        print("✅ EXCELLENT! Achieved 90%+ categorization!")
    elif match_rate >= 80:
        print("✓ GOOD! Achieved 80%+ categorization")
    else:
        print("⚠️  More patterns needed to reach 95% target")
    print("=" * 90)

if __name__ == "__main__":
    main()
