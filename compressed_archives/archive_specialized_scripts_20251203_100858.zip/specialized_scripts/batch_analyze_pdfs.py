"""
Batch analyzer for remaining PDFs using the comprehensive extraction approach
"""
import shutil
from pathlib import Path

# Copy the best analyzer as a template
print("="*80)
print("CREATING BATCH ANALYZERS")
print("="*80)

# Priority PDFs to analyze (excluding Makita - too large, will do separately)
priority_pdfs = [
    # Pipes & Fittings (similar to pe-buizen)
    ('drukbuizen', 'drukbuizen.pdf'),
    ('kunststof-afvoerleidingen', 'kunststof-afvoerleidingen.pdf'),
    ('verzinkte-buizen', 'verzinkte-buizen.pdf'),
    ('abs-persluchtbuizen', 'abs-persluchtbuizen.pdf'),
    ('messing-draadfittingen', 'messing-draadfittingen.pdf'),
    ('rvs-draadfittingen', 'rvs-draadfittingen.pdf'),
    ('zwarte-draad-en-lasfittingen (1)', 'zwarte-draad-en-lasfittingen (1).pdf'),
    
    # Hoses (similar to plat-oprolbare)
    ('rubber-slangen', 'rubber-slangen.pdf'),
    ('pu-afzuigslangen', 'pu-afzuigslangen.pdf'),
    ('slangklemmen', 'slangklemmen.pdf'),
    ('slangkoppelingen', 'slangkoppelingen.pdf'),
    
    # Pumps
    ('bronpompen', 'bronpompen.pdf'),
    ('centrifugaalpompen', 'centrifugaalpompen.pdf'),
    ('dompelpompen', 'dompelpompen.pdf'),
    ('zuigerpompen (1)', 'zuigerpompen (1).pdf'),
    ('pomp-specials', 'pomp-specials.pdf'),
]

print(f"\nWill create analyzers for {len(priority_pdfs)} PDFs\n")

# Use pe-buizen analyzer as template (it's the most robust)
template_file = 'analyze_pe_buizen.py'

for script_name, pdf_filename in priority_pdfs:
    output_script = f'analyze_{script_name.replace("-", "_").replace(" ", "_").replace("(", "").replace(")", "")}.py'
    
    print(f"Creating: {output_script}")
    
    # Read template
    with open(template_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Replace PDF filename and output paths
    content = content.replace('pe-buizen.pdf', pdf_filename)
    content = content.replace('pe_buizen_analysis.json', f'{script_name.replace("-", "_")}_analysis.json')
    content = content.replace('PE-BUIZEN', script_name.upper().replace('-', ' '))
    content = content.replace('pe-buizen', script_name)
    
    # Write new analyzer
    with open(output_script, 'w', encoding='utf-8') as f:
        f.write(content)

print(f"\n✓ Created {len(priority_pdfs)} analyzer scripts!")
print(f"\n{'='*80}")
print(f"NEXT STEPS")
print(f"{'='*80}")
print(f"\nRun analyzers in batches:")
print(f"  Batch 1 (Pipes): drukbuizen, kunststof-afvoerleidingen, verzinkte-buizen")
print(f"  Batch 2 (Fittings): messing, rvs, zwarte-draad") 
print(f"  Batch 3 (Hoses): rubber, pu-afzuig, slangklemmen, slangkoppelingen")
print(f"  Batch 4 (Pumps): bronpompen, centrifugaal, dompel, zuiger")
print("="*80)
