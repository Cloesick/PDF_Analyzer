"""
Group products from the same table into product families with variants.
Products on the same page with similar SKU prefixes share the same image,
and users can select variants through a picklist.
"""
import json
import re
from pathlib import Path
from typing import Dict, List, Any, Optional
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"
INPUT_JSON = OUTPUT_DIR / "archive" / "catalog_extractions" / "abs_persluchtbuizen_dynamic.json"
OUTPUT_JSON = OUTPUT_DIR / "abs_persluchtbuizen_grouped.json"

# Public URL prefix for images
BASE_MEDIA_URL = "https://example.com/media/"


def extract_product_family(sku: str) -> str:
    """
    Extract the product family from SKU.
    Examples:
    - ABSBU016 -> ABSBU
    - ABSBU020 -> ABSBU
    - ABST02045 -> ABST
    - ABSVM04032 -> ABSVM
    """
    # Match letters at the start
    match = re.match(r'^([A-Z]+)', sku)
    if match:
        return match.group(1)
    return sku[:4]  # Fallback


def find_image_for_group(page_num: int, family: str, group_skus: List[str]) -> Optional[str]:
    """
    Find the best image for a product group by looking for actual image files.
    Searches for images that match any SKU in the group.
    """
    images_dir = PROJECT_ROOT / "product-images-by-pdf" / "abs-persluchtbuizen"
    
    if not images_dir.exists():
        return None
    
    # Look for images that match any SKU in the group
    for sku in group_skus:
        # Try exact match first
        pattern = f"{sku}_*.webp"
        matching_images = list(images_dir.glob(pattern))
        
        if matching_images:
            # Return relative path from project root
            rel_path = matching_images[0].relative_to(PROJECT_ROOT)
            return str(rel_path).replace('\\', '/')
    
    # Fallback: look for images with the family prefix on this page
    pattern = f"{family}*_p{page_num:03d}_*.webp"
    matching_images = list(images_dir.glob(pattern))
    
    if matching_images:
        rel_path = matching_images[0].relative_to(PROJECT_ROOT)
        return str(rel_path).replace('\\', '/')
    
    return None


def build_variant_properties(product: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract variant-specific properties from a product.
    Creates both raw values and formatted display strings for consistency.
    """
    props = {}
    
    # Comprehensive property mappings with display formatting
    property_mappings = {
        # Dimensions
        'diameter_mm': ('diameter_mm', 'diameter_display', 'mm'),
        'inner_diameter_mm': ('inner_diameter_mm', 'inner_diameter_display', 'mm'),
        'outer_diameter_mm': ('outer_diameter_mm', 'outer_diameter_display', 'mm'),
        'wall_thickness_mm': ('wall_thickness_mm', 'wall_thickness_display', 'mm'),
        'width_mm': ('width_mm', 'width_display', 'mm'),
        'height_mm': ('height_mm', 'height_display', 'mm'),
        'length_mm': ('length_mm', 'length_mm_display', 'mm'),
        
        # Length in meters
        'length_m': ('length_m', 'length_display', 'm'),
        
        # Pressure variations (normalize to pressure_bar for consistency)
        'pressure_bar': ('pressure_bar', 'pressure_display', 'bar'),
        'pressure_work_bar': ('pressure_bar', 'pressure_display', 'bar'),  # Normalize work pressure
        'pressure_burst_bar': ('pressure_burst_bar', 'pressure_burst_display', 'bar'),
        'pressure_max_bar': ('pressure_max_bar', 'pressure_max_display', 'bar'),
        'pressure_min_bar': ('pressure_min_bar', 'pressure_min_display', 'bar'),
        
        # Weight
        'weight_kg': ('weight_kg', 'weight_display', 'kg'),
        
        # Volume
        'volume_l': ('volume_l', 'volume_display', 'L'),
        'tank_volume_l': ('tank_volume_l', 'tank_volume_display', 'L'),
        
        # Flow
        'flow_l_min': ('flow_l_min', 'flow_display', 'L/min'),
        'intake_l_min': ('intake_l_min', 'intake_display', 'L/min'),
        'outtake_l_min': ('outtake_l_min', 'outtake_display', 'L/min'),
        
        # Material & Text properties
        'material': ('material', None, None),
        'connection_type': ('connection_type', None, None),
        'thread_size': ('thread_size', None, None),
    }
    
    for source_key, (target_key, display_key, unit) in property_mappings.items():
        if source_key in product and product[source_key] is not None:
            value = product[source_key]
            
            # Store the value
            props[target_key] = value
            
            # Create display format if needed
            if display_key and unit:
                # Format the display string with proper decimals
                if isinstance(value, float):
                    # Show 1 decimal for bar/kg, 0 for mm/m
                    if 'bar' in unit or 'kg' in unit or 'L' in unit:
                        formatted_value = f"{value:.1f}"
                    else:
                        formatted_value = f"{int(value)}" if value.is_integer() else f"{value:.1f}"
                else:
                    formatted_value = str(value)
                
                props[display_key] = f"{formatted_value} {unit}"
            elif display_key is None and isinstance(value, str):
                # For text properties, just store as is
                pass
    
    return props


def create_variant_label(sku: str, props: Dict[str, Any]) -> str:
    """
    Create a human-readable label for the variant.
    Example: "ABSBU016 - ø 16mm, 10 bar, 5m"
    """
    parts = [sku]
    
    if "diameter_display" in props:
        parts.append(f"ø {props['diameter_display']}")
    
    if "pressure_display" in props:
        parts.append(props["pressure_display"])
    
    if "length_display" in props:
        parts.append(props["length_display"])
    
    return " - ".join(parts)


def group_products_by_table(products: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    """
    Group products that belong to the same table.
    Products are grouped by page + product family.
    """
    groups = defaultdict(list)
    
    for product in products:
        page = product.get("page_in_pdf")
        sku = product.get("sku")
        
        if not page or not sku:
            continue
        
        family = extract_product_family(sku)
        group_key = f"page{page}_{family}"
        groups[group_key].append(product)
    
    return groups


def create_product_group(group_id: str, products: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Create a product group with variants from a list of products.
    """
    if not products:
        return None
    
    # Use first product as template for shared data
    template = products[0]
    page = template.get("page_in_pdf")
    catalog = template.get("catalog", "abs-persluchtbuizen")
    family = extract_product_family(template.get("sku", ""))
    
    # Get all SKUs for image matching
    group_skus = [p.get("sku") for p in products if p.get("sku")]
    
    # Find shared image for this group
    image_path = find_image_for_group(page, family, group_skus)
    media = []
    if image_path:
        media.append({
            "url": image_path,
            "role": "main"
        })
    
    # Create variants
    variants = []
    for product in products:
        sku = product.get("sku")
        props = build_variant_properties(product)
        variant_label = create_variant_label(sku, props)
        
        variants.append({
            "sku": sku,
            "label": variant_label,
            "properties": props,
            "page_in_pdf": product.get("page_in_pdf"),
        })
    
    # Sort variants by diameter if available, otherwise by SKU
    def sort_key(v):
        if "diameter_mm" in v["properties"]:
            return v["properties"]["diameter_mm"]
        return v["sku"]
    
    variants.sort(key=sort_key)
    
    # Create group name
    group_name = f"{family} Series"
    if variants:
        first_props = variants[0]["properties"]
        if "pressure_bar" in first_props:
            group_name += f" - {first_props['pressure_bar']} bar"
    
    # Extract common properties (properties that are the same across all variants)
    common_props = {}
    if variants:
        first_props = variants[0]["properties"]
        for key, value in first_props.items():
            if all(v["properties"].get(key) == value for v in variants):
                if key not in ["diameter_mm", "diameter_display"]:  # Don't include diameter as common
                    common_props[key] = value
    
    return {
        "group_id": group_id,
        "type": "product_group",
        "catalog": catalog,
        "family": family,
        "name": group_name,
        "page_in_pdf": page,
        "media": media,
        "common_properties": common_props,
        "variants": variants,
        "variant_count": len(variants),
        "default_variant_sku": variants[0]["sku"] if variants else None,
    }


def process_catalog():
    """
    Process the ABS catalog and create grouped products.
    """
    print("=" * 80)
    print("GROUPING TABLE PRODUCTS INTO VARIANTS")
    print("=" * 80)
    
    # Load products
    if not INPUT_JSON.exists():
        print(f"❌ Input JSON not found: {INPUT_JSON}")
        return
    
    with INPUT_JSON.open("r", encoding="utf-8") as f:
        products = json.load(f)
    
    print(f"\n📦 Loaded {len(products)} products from {INPUT_JSON.name}")
    
    # Check for images directory
    images_dir = PROJECT_ROOT / "product-images-by-pdf" / "abs-persluchtbuizen"
    if images_dir.exists():
        image_count = len(list(images_dir.glob("*.webp")))
        print(f"🖼️  Found {image_count} images in {images_dir.name}")
    else:
        print(f"⚠️  No images directory found at {images_dir}")
    
    # Group products by table
    print("\n🔍 Grouping products by table...")
    groups_dict = group_products_by_table(products)
    print(f"   Found {len(groups_dict)} product groups")
    
    # Create product groups
    print("\n🏗️  Building product groups...")
    product_groups = []
    stats = {
        "total_groups": 0,
        "total_variants": 0,
        "groups_with_images": 0,
    }
    
    for group_id, group_products in sorted(groups_dict.items()):
        if len(group_products) < 2:
            # Skip single products (not part of a table)
            continue
        
        group = create_product_group(group_id, group_products)
        if group:
            product_groups.append(group)
            stats["total_groups"] += 1
            stats["total_variants"] += len(group["variants"])
            if group["media"]:
                stats["groups_with_images"] += 1
            
            # Show first few groups
            if stats["total_groups"] <= 5:
                print(f"\n   ✓ {group['name']}")
                print(f"      Family: {group['family']}, Page: {group['page_in_pdf']}")
                print(f"      Variants: {len(group['variants'])}")
                print(f"      SKUs: {', '.join([v['sku'] for v in group['variants'][:3]])}")
                if len(group['variants']) > 3:
                    print(f"            ... and {len(group['variants']) - 3} more")
    
    # Save results
    OUTPUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT_JSON.open("w", encoding="utf-8") as f:
        json.dump(product_groups, f, ensure_ascii=False, indent=2)
    
    # Statistics
    print(f"\n📊 GROUPING STATISTICS:")
    print(f"   Product groups created:     {stats['total_groups']}")
    print(f"   Total variants:             {stats['total_variants']}")
    print(f"   Groups with images:         {stats['groups_with_images']}")
    print(f"   Avg variants per group:     {stats['total_variants'] / stats['total_groups']:.1f}")
    
    # Show sample groups
    print(f"\n📋 SAMPLE PRODUCT GROUPS:")
    for group in product_groups[:3]:
        print(f"\n   {group['name']}")
        print(f"   └─ {group['variant_count']} variants:")
        for variant in group['variants'][:3]:
            print(f"      • {variant['label']}")
        if group['variant_count'] > 3:
            print(f"      ... and {group['variant_count'] - 3} more")
    
    print(f"\n💾 Output saved to: {OUTPUT_JSON}")
    print(f"\n{'='*80}")
    print("✅ GROUPING COMPLETE")
    print("="*80)
    
    return product_groups


if __name__ == '__main__':
    process_catalog()
