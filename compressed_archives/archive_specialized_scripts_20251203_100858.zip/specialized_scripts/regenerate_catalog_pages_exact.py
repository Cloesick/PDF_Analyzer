#!/usr/bin/env python3
"""
Regenerate ALL catalog pages to match abs-grouped EXACTLY
"""

import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
WEBSHOP_ROOT = PROJECT_ROOT.parent / "DemaWebshop" / "dema-webshop"
TEMPLATE_FILE = WEBSHOP_ROOT / "src" / "app" / "catalog" / "abs-grouped" / "page.tsx"
OUTPUT_DIR = WEBSHOP_ROOT / "src" / "app" / "catalog"
DATA_DIR = WEBSHOP_ROOT / "public" / "data"

# Catalog configurations
CATALOGS = {
    "slangkoppelingen": {
        "title": "Slangkoppelingen",
        "description": "Professional hose couplings for all applications",
        "emoji": "🔗",
        "data_file": "slangkoppelingen_grouped.json",
        "pdf_source": "slangkoppelingen.pdf"
    },
    "slangklemmen": {
        "title": "Slangklemmen",
        "description": "High-quality hose clamps for secure connections",
        "emoji": "🔩",
        "data_file": "slangklemmen_grouped.json",
        "pdf_source": "slangklemmen.pdf"
    },
    "pu-afzuigslangen": {
        "title": "PU Afzuigslangen",
        "description": "Professional PU extraction hoses for industrial applications",
        "emoji": "💨",
        "data_file": "pu_afzuigslangen_grouped.json",
        "pdf_source": "pu-afzuigslangen.pdf"
    },
    "rubber-slangen": {
        "title": "Rubber Slangen",
        "description": "Durable rubber hoses for various applications",
        "emoji": "⚫",
        "data_file": "rubber_slangen_grouped.json",
        "pdf_source": "rubber-slangen.pdf"
    },
    "drukbuizen": {
        "title": "Drukbuizen",
        "description": "Pressure pipes for high-performance systems",
        "emoji": "💪",
        "data_file": "drukbuizen_grouped.json",
        "pdf_source": "drukbuizen.pdf"
    },
    "pe-buizen": {
        "title": "PE Buizen",
        "description": "Polyethylene pipes for water and gas applications",
        "emoji": "🔵",
        "data_file": "pe_buizen_grouped.json",
        "pdf_source": "pe-buizen.pdf"
    },
    "verzinkte-buizen": {
        "title": "Verzinkte Buizen",
        "description": "Galvanized pipes for long-lasting installations",
        "emoji": "⚙️",
        "data_file": "verzinkte_buizen_grouped.json",
        "pdf_source": "verzinkte-buizen.pdf"
    },
    "kunststof-afvoerleidingen": {
        "title": "Kunststof Afvoerleidingen",
        "description": "Plastic drainage pipes for sewage systems",
        "emoji": "🚰",
        "data_file": "kunststof_afvoerleidingen_grouped.json",
        "pdf_source": "kunststof-afvoerleidingen.pdf"
    },
    "messing-draadfittingen": {
        "title": "Messing Draadfittingen",
        "description": "Brass threaded fittings for reliable connections",
        "emoji": "🟡",
        "data_file": "messing_draadfittingen_grouped.json",
        "pdf_source": "messing-draadfittingen.pdf"
    },
    "rvs-draadfittingen": {
        "title": "RVS Draadfittingen",
        "description": "Stainless steel threaded fittings for corrosion resistance",
        "emoji": "✨",
        "data_file": "rvs_draadfittingen_grouped.json",
        "pdf_source": "rvs-draadfittingen.pdf"
    },
    "zwarte-draad-en-lasfittingen": {
        "title": "Zwarte Draad en Lasfittingen",
        "description": "Black threaded and welding fittings",
        "emoji": "⚫",
        "data_file": "zwarte_draad_en_lasfittingen_grouped.json",
        "pdf_source": "zwarte-draad-en-lasfittingen.pdf"
    },
    "pomp-specials": {
        "title": "Pomp Specials",
        "description": "Special pump components and accessories",
        "emoji": "🔧",
        "data_file": "pomp_specials_grouped.json",
        "pdf_source": "pomp-specials.pdf"
    },
    "centrifugaalpompen": {
        "title": "Centrifugaalpompen",
        "description": "Centrifugal pumps for efficient fluid transfer",
        "emoji": "🌀",
        "data_file": "centrifugaalpompen_grouped.json",
        "pdf_source": "centrifugaalpompen.pdf"
    },
    "dompelpompen": {
        "title": "Dompelpompen",
        "description": "Submersible pumps for water management",
        "emoji": "💧",
        "data_file": "dompelpompen_grouped.json",
        "pdf_source": "dompelpompen.pdf"
    },
    "bronpompen": {
        "title": "Bronpompen",
        "description": "Well pumps for water extraction",
        "emoji": "🏞️",
        "data_file": "bronpompen_grouped.json",
        "pdf_source": "bronpompen.pdf"
    },
    "pompentoebehoren": {
        "title": "Pompentoebehoren",
        "description": "Pump accessories and spare parts",
        "emoji": "🔩",
        "data_file": "pompentoebehoren_grouped.json",
        "pdf_source": "pompentoebehoren.pdf"
    },
    "aandrijftechniek": {
        "title": "Aandrijftechniek",
        "description": "Drive technology and transmission components",
        "emoji": "⚙️",
        "data_file": "aandrijftechniek_grouped.json",
        "pdf_source": "aandrijftechniek.pdf"
    }
}

def create_catalog_page(catalog_key, config):
    """Create a catalog page from template"""
    
    # Read template
    with open(TEMPLATE_FILE, 'r', encoding='utf-8') as f:
        template = f.read()
    
    # Function name (PascalCase)
    func_name = ''.join(word.capitalize() for word in catalog_key.replace('-', '_').split('_')) + 'CatalogPage'
    
    # Replace template values
    page_content = template
    
    # Replace function name
    page_content = page_content.replace('export default function ABSGroupedCatalogPage()', 
                                       f'export default function {func_name}()')
    
    # Replace data file
    page_content = page_content.replace("fetch('/data/abs_persluchtbuizen_grouped.json')",
                                       f"fetch('/data/{config['data_file']}')")
    
    # Replace pdf_source
    page_content = page_content.replace("pdf_source: 'abs-persluchtbuizen.pdf'",
                                       f"pdf_source: '{config['pdf_source']}'")
    
    # Replace header title and description
    page_content = page_content.replace('📦 ABS Persluchtbuizen - Product Groups',
                                       f"{config['emoji']} {config['title']} - Product Groups")
    
    # Save to file
    output_path = OUTPUT_DIR / f"{catalog_key}-grouped" / "page.tsx"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(page_content)
    
    return output_path

def main():
    print("="*80)
    print("REGENERATING ALL CATALOG PAGES (EXACT MATCH TO ABS-GROUPED)")
    print("="*80)
    
    if not TEMPLATE_FILE.exists():
        print(f"\n❌ Template not found: {TEMPLATE_FILE}")
        return
    
    print(f"\n✅ Using template: {TEMPLATE_FILE.name}")
    print(f"\n📝 Regenerating {len(CATALOGS)} catalog pages...\n")
    
    created = 0
    for catalog_key, config in CATALOGS.items():
        try:
            output_path = create_catalog_page(catalog_key, config)
            print(f"  ✅ {catalog_key:35s} → {output_path.relative_to(WEBSHOP_ROOT)}")
            created += 1
        except Exception as e:
            print(f"  ❌ {catalog_key:35s} → Error: {e}")
    
    print(f"\n{'='*80}")
    print(f"✅ SUCCESS: Regenerated {created}/{len(CATALOGS)} catalog pages")
    print(f"{'='*80}")
    print("\n⚠️  IMPORTANT: Restart the dev server:")
    print("   npm run start")

if __name__ == "__main__":
    main()
