#!/usr/bin/env python3
"""
Validation script to ensure the aandrijftechniek SKU → Image mapping system is secure and complete.

This verifies:
1. All mapping files exist and are valid JSON
2. All referenced images actually exist on disk
3. All SKUs in grouped data have image mappings
4. No broken links or missing files
5. Frontend integration is correct
"""

import json
from pathlib import Path
from collections import defaultdict

def validate_system():
    """Comprehensive validation of the mapping system"""
    
    print(f"\n{'='*80}")
    print(f"AANDRIJFTECHNIEK MAPPING SYSTEM VALIDATION")
    print(f"{'='*80}\n")
    
    errors = []
    warnings = []
    
    # File paths
    webshop_root = Path('../DemaWebshop/dema-webshop')
    sku_mapping_file = webshop_root / 'public/data/aandrijftechniek_image_mapping.json'
    group_mapping_file = webshop_root / 'public/data/aandrijftechniek_group_mapping.json'
    grouped_data_file = webshop_root / 'public/data/aandrijftechniek_grouped.json'
    image_folder = webshop_root / 'public/images/products/aandrijftechniek'
    frontend_file = webshop_root / 'src/app/catalog/aandrijftechniek-grouped/page.tsx'
    
    # 1. Verify all required files exist
    print(f"{'='*80}")
    print(f"1. CHECKING FILE EXISTENCE")
    print(f"{'='*80}\n")
    
    required_files = {
        'SKU Mapping': sku_mapping_file,
        'Group Mapping': group_mapping_file,
        'Grouped Data': grouped_data_file,
        'Image Folder': image_folder,
        'Frontend Code': frontend_file
    }
    
    for name, path in required_files.items():
        if path.exists():
            print(f"  ✅ {name}: {path.name}")
        else:
            error = f"❌ {name} NOT FOUND: {path}"
            print(f"  {error}")
            errors.append(error)
    
    if errors:
        print(f"\n❌ Critical errors found. System not secure.\n")
        return False
    
    # 2. Validate JSON files
    print(f"\n{'='*80}")
    print(f"2. VALIDATING JSON FILES")
    print(f"{'='*80}\n")
    
    try:
        with open(sku_mapping_file, 'r', encoding='utf-8') as f:
            sku_mapping = json.load(f)
        print(f"  ✅ SKU Mapping: Valid JSON ({len(sku_mapping)} SKUs)")
    except Exception as e:
        error = f"❌ SKU Mapping JSON invalid: {e}"
        print(f"  {error}")
        errors.append(error)
        return False
    
    try:
        with open(group_mapping_file, 'r', encoding='utf-8') as f:
            group_mapping = json.load(f)
        print(f"  ✅ Group Mapping: Valid JSON ({len(group_mapping)} groups)")
    except Exception as e:
        error = f"❌ Group Mapping JSON invalid: {e}"
        print(f"  {error}")
        errors.append(error)
        return False
    
    try:
        with open(grouped_data_file, 'r', encoding='utf-8') as f:
            grouped_data = json.load(f)
        print(f"  ✅ Grouped Data: Valid JSON ({len(grouped_data)} groups)")
    except Exception as e:
        error = f"❌ Grouped Data JSON invalid: {e}"
        print(f"  {error}")
        errors.append(error)
        return False
    
    # 3. Verify all images exist
    print(f"\n{'='*80}")
    print(f"3. VERIFYING IMAGE FILES")
    print(f"{'='*80}\n")
    
    unique_images = set(sku_mapping.values())
    print(f"  Unique images referenced: {len(unique_images)}")
    
    missing_images = []
    for image_path in unique_images:
        # Convert web path to file path
        filename = image_path.split('/')[-1]
        file_path = image_folder / filename
        
        if not file_path.exists():
            missing_images.append(filename)
    
    if missing_images:
        print(f"  ❌ Missing {len(missing_images)} images:")
        for img in missing_images[:5]:
            print(f"     - {img}")
        if len(missing_images) > 5:
            print(f"     ... and {len(missing_images) - 5} more")
        errors.extend([f"Missing image: {img}" for img in missing_images])
    else:
        print(f"  ✅ All {len(unique_images)} images exist on disk")
    
    # 4. Verify all SKUs have mappings
    print(f"\n{'='*80}")
    print(f"4. CHECKING SKU COVERAGE")
    print(f"{'='*80}\n")
    
    # Collect all SKUs from grouped data
    all_skus = []
    for group in grouped_data:
        for variant in group.get('variants', []):
            sku = variant.get('sku')
            if sku:
                all_skus.append(sku)
    
    print(f"  Total SKUs in data: {len(all_skus)}")
    print(f"  SKUs in mapping: {len(sku_mapping)}")
    
    # Find unmapped SKUs
    unmapped_skus = [sku for sku in all_skus if sku not in sku_mapping]
    
    if unmapped_skus:
        print(f"  ⚠️  {len(unmapped_skus)} SKUs without image mappings:")
        for sku in unmapped_skus[:10]:
            print(f"     - {sku}")
        if len(unmapped_skus) > 10:
            print(f"     ... and {len(unmapped_skus) - 10} more")
        warnings.extend([f"Unmapped SKU: {sku}" for sku in unmapped_skus])
    else:
        print(f"  ✅ All {len(all_skus)} SKUs have image mappings")
    
    # 5. Verify mapping consistency
    print(f"\n{'='*80}")
    print(f"5. CHECKING MAPPING CONSISTENCY")
    print(f"{'='*80}\n")
    
    # Verify SKU mapping matches group mapping
    sku_to_group = {}
    for group in grouped_data:
        group_id = group.get('group_id')
        for variant in group.get('variants', []):
            sku = variant.get('sku')
            if sku:
                sku_to_group[sku] = group_id
    
    inconsistencies = []
    for sku, image_path in sku_mapping.items():
        group_id = sku_to_group.get(sku)
        if group_id and group_id in group_mapping:
            group_image = group_mapping[group_id]
            if image_path != group_image:
                inconsistencies.append(f"SKU {sku}: mapped to {image_path} but group {group_id} uses {group_image}")
    
    if inconsistencies:
        print(f"  ⚠️  {len(inconsistencies)} mapping inconsistencies found")
        for inc in inconsistencies[:5]:
            print(f"     - {inc}")
        warnings.extend(inconsistencies)
    else:
        print(f"  ✅ SKU and group mappings are consistent")
    
    # 6. Verify frontend integration
    print(f"\n{'='*80}")
    print(f"6. VERIFYING FRONTEND INTEGRATION")
    print(f"{'='*80}\n")
    
    with open(frontend_file, 'r', encoding='utf-8') as f:
        frontend_code = f.read()
    
    required_patterns = [
        "aandrijftechniek_image_mapping.json",
        "imageMapping[variant.sku]",
        "setImageMapping",
        "mappedImage"
    ]
    
    missing_patterns = []
    for pattern in required_patterns:
        if pattern in frontend_code:
            print(f"  ✅ Found: {pattern}")
        else:
            missing_patterns.append(pattern)
            print(f"  ❌ Missing: {pattern}")
    
    if missing_patterns:
        errors.extend([f"Frontend missing: {p}" for p in missing_patterns])
    
    # 7. Image usage statistics
    print(f"\n{'='*80}")
    print(f"7. IMAGE USAGE STATISTICS")
    print(f"{'='*80}\n")
    
    image_usage = defaultdict(int)
    for sku, image_path in sku_mapping.items():
        image_usage[image_path] += 1
    
    most_shared = sorted(image_usage.items(), key=lambda x: x[1], reverse=True)[0]
    print(f"  Total images: {len(image_usage)}")
    print(f"  Total SKUs: {len(sku_mapping)}")
    print(f"  Avg SKUs per image: {len(sku_mapping) / len(image_usage):.1f}")
    print(f"  Most shared image: {most_shared[1]} SKUs use {most_shared[0].split('/')[-1]}")
    
    shared_images = [(img, count) for img, count in image_usage.items() if count > 1]
    print(f"  Images shared by multiple SKUs: {len(shared_images)}")
    
    # Final Report
    print(f"\n{'='*80}")
    print(f"VALIDATION SUMMARY")
    print(f"{'='*80}\n")
    
    if errors:
        print(f"❌ FAILED: {len(errors)} critical errors found\n")
        for error in errors:
            print(f"  - {error}")
        print(f"\n⚠️  System is NOT secure. Fix errors before deploying.\n")
        return False
    elif warnings:
        print(f"⚠️  WARNINGS: {len(warnings)} warnings found\n")
        for warning in warnings[:10]:
            print(f"  - {warning}")
        if len(warnings) > 10:
            print(f"  ... and {len(warnings) - 10} more")
        print(f"\n✅ System is functional but has minor issues.\n")
        return True
    else:
        print(f"✅ PASSED: All validations successful!\n")
        print(f"System Components:")
        print(f"  • {len(sku_mapping)} SKUs mapped")
        print(f"  • {len(group_mapping)} groups mapped")
        print(f"  • {len(unique_images)} unique images")
        print(f"  • {len(grouped_data)} product groups")
        print(f"  • Frontend integration verified")
        print(f"\n🔒 System is SECURE and ready for production!\n")
        return True

if __name__ == '__main__':
    success = validate_system()
    exit(0 if success else 1)
