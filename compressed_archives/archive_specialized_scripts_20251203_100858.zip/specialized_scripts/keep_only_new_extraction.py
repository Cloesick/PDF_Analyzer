"""
Keep only the NEW tool-only extraction, remove old mixed extraction
"""
from pathlib import Path
import shutil

PROJECT_ROOT = Path(__file__).parent
IMAGE_DIR = PROJECT_ROOT / "product-images-by-pdf"
BACKUP_DIR = PROJECT_ROOT / "backup-old-extraction"

CATALOGS = {
    "makita-catalogus-2022-nl": "makita-catalogus-202_",  # Old prefix
    "makita-tuinfolder-2022-nl": "makita-tuinfolder-20_",  # Old prefix
}

def main():
    print("="*80)
    print("KEEPING ONLY NEW TOOL-ONLY EXTRACTION")
    print("="*80)
    
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    
    total_stats = {'old_removed': 0, 'new_kept': 0}
    
    for catalog, old_prefix in CATALOGS.items():
        catalog_dir = IMAGE_DIR / catalog
        
        if not catalog_dir.exists():
            print(f"\n[SKIP] {catalog} - not found")
            continue
        
        print(f"\n{catalog}:")
        
        images = list(catalog_dir.glob("*.webp"))
        print(f"  Total images: {len(images)}")
        
        old_images = []
        new_images = []
        
        for img in images:
            # Check if it's the old extraction (truncated catalog name)
            if old_prefix in img.name:
                old_images.append(img)
            # Or if it's a numeric-only SKU (from old cleanup runs)
            elif img.name.split('_')[0].isdigit():
                old_images.append(img)
            else:
                new_images.append(img)
        
        print(f"  Old extraction: {len(old_images)}")
        print(f"  New extraction: {len(new_images)}")
        
        # Move old to backup
        if old_images:
            backup_catalog = BACKUP_DIR / catalog
            backup_catalog.mkdir(parents=True, exist_ok=True)
            
            for img in old_images:
                dest = backup_catalog / img.name
                shutil.move(str(img), str(dest))
            
            total_stats['old_removed'] += len(old_images)
            total_stats['new_kept'] += len(new_images)
            
            print(f"  [MOVED] {len(old_images)} old images to backup")
            print(f"  [KEPT] {len(new_images)} new tool-only images")
        
        # Show samples
        if new_images:
            print(f"\n  Sample remaining (first 5):")
            for img in new_images[:5]:
                print(f"    - {img.name}")
    
    print("\n" + "="*80)
    print("CLEANUP COMPLETE")
    print("="*80)
    print(f"\nSummary:")
    print(f"  Old images moved to backup: {total_stats['old_removed']}")
    print(f"  New tool-only images kept: {total_stats['new_kept']}")
    print(f"\nBackup: {BACKUP_DIR}")
    print(f"\nFinal folders contain ONLY tool-only extraction!")

if __name__ == '__main__':
    main()
