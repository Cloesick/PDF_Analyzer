"""
Merge comprehensive analysis data into webshop-ready format
Enrich existing products with new specifications, images, and table data
"""
import json
from pathlib import Path
from collections import defaultdict

print("="*80)
print("MERGING COMPREHENSIVE DATA TO WEBSHOP FORMAT")
print("="*80)

# Load existing webshop products
webshop_file = 'output/products_ready_for_webshop.json'
print(f"\n📦 Loading existing webshop data: {webshop_file}")

with open(webshop_file, 'r', encoding='utf-8') as f:
    webshop_products = json.load(f)

print(f"  • Loaded {len(webshop_products)} existing products")

# Load all comprehensive analysis files
output_dir = Path('output')
enriched_files = sorted(output_dir.glob('*_analysis_enriched.json'))

print(f"\n📊 Loading comprehensive analysis data:")
print(f"  • Found {len(enriched_files)} enriched analysis files")

# Build mapping of catalog -> products
comprehensive_data = {}

for json_file in enriched_files:
    catalog_name = json_file.stem.replace('_analysis_enriched', '')
    
    with open(json_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    comprehensive_data[catalog_name] = data
    print(f"  ✓ {catalog_name}: {data.get('total_products', 0)} products")

# Statistics
updated_count = 0
new_specs_count = 0
new_images_count = 0
skipped_count = 0

print(f"\n{'='*80}")
print(f"MERGING DATA")
print(f"{'='*80}\n")

# Map to quickly find products by catalog and page
catalog_products_map = defaultdict(list)

for catalog_name, data in comprehensive_data.items():
    for page in data.get('pages', []):
        for product in page.get('products_found', []):
            catalog_products_map[catalog_name].append({
                'page': page['page_number'],
                'product_id': product['product_id'],
                'specs': product.get('specifications', {}),
                'image_url': product.get('image_url'),
                'image_formats': product.get('image_formats', {}),
                'description': product.get('description', ''),
                'category': product.get('category', '')
            })

# Update webshop products
for idx, product in enumerate(webshop_products):
    catalog = product.get('catalog', '').replace('-', '_')
    
    # Check if we have comprehensive data for this catalog
    if catalog not in comprehensive_data:
        skipped_count += 1
        continue
    
    # Find matching product from comprehensive data
    # Match by page number
    source_pages = product.get('source', {}).get('pages', [])
    if not source_pages:
        skipped_count += 1
        continue
    
    page_num = source_pages[0]
    
    # Find comprehensive product from same page
    matching_products = [
        p for p in catalog_products_map[catalog]
        if p['page'] == page_num
    ]
    
    if not matching_products:
        skipped_count += 1
        continue
    
    # Use first matching product (or try to match by description)
    comp_product = matching_products[0]
    
    # Check if product already has good specs
    had_specs = len(product.get('specs', [])) > 0
    had_good_image = product.get('imageUrl') and 'img' in str(product.get('imageUrl'))
    
    # Update specifications
    if comp_product['specs']:
        # Convert specs dict to array format
        new_specs = []
        for key, value in comp_product['specs'].items():
            # Skip table_ raw columns for webshop (keep only parsed)
            if key.startswith('table_'):
                continue
            
            # Create readable label
            label = key.replace('_', ' ').title()
            new_specs.append({
                'label': label,
                'value': str(value),
                'key': key
            })
        
        if new_specs:
            product['specs'] = new_specs
            if not had_specs:
                new_specs_count += 1
    
    # Update image URL with new comprehensive image path
    if comp_product['image_url'] and not had_good_image:
        product['imageUrl'] = comp_product['image_url']
        product['media'] = [{
            'url': comp_product['image_url'],
            'role': 'main',
            'type': 'image',
            'format': 'webp'
        }]
        
        # Add alternative formats
        if comp_product['image_formats']:
            for fmt, url in comp_product['image_formats'].items():
                if fmt != 'webp':
                    product['media'].append({
                        'url': url,
                        'role': 'alternative',
                        'type': 'image',
                        'format': fmt
                    })
        
        new_images_count += 1
    
    # Update description if empty
    if not product.get('description') and comp_product['description']:
        product['description'] = comp_product['description']
    
    # Update category if more specific
    if comp_product['category']:
        product['category'] = comp_product['category'].replace('_', ' ').title()
        product['product_category'] = product['category']
    
    updated_count += 1
    
    if (idx + 1) % 1000 == 0:
        print(f"  Processed {idx + 1}/{len(webshop_products)} products...")

# Save updated webshop data
output_file = 'output/products_ready_for_webshop_v2_comprehensive.json'
with open(output_file, 'w', encoding='utf-8') as f:
    json.dump(webshop_products, f, indent=2, ensure_ascii=False)

print(f"\n{'='*80}")
print(f"MERGE COMPLETE")
print(f"{'='*80}")

print(f"\n📊 STATISTICS:")
print(f"  • Total webshop products: {len(webshop_products)}")
print(f"  • Products updated: {updated_count}")
print(f"  • Products with new specs: {new_specs_count}")
print(f"  • Products with new images: {new_images_count}")
print(f"  • Products skipped (no match): {skipped_count}")

print(f"\n✅ Saved to: {output_file}")

print(f"\n💡 NEXT STEPS:")
print(f"  1. Review the updated file")
print(f"  2. Deploy to your frontend")
print(f"  3. Update image paths to match your CDN/storage")

# Create a sample of updated products
sample_file = 'output/webshop_sample_with_comprehensive_data.json'
sample_products = [p for p in webshop_products if len(p.get('specs', [])) > 5][:10]

with open(sample_file, 'w', encoding='utf-8') as f:
    json.dump(sample_products, f, indent=2, ensure_ascii=False)

print(f"\n📄 Sample file created: {sample_file}")
print(f"   (10 products with comprehensive specs)")

print("="*80)
