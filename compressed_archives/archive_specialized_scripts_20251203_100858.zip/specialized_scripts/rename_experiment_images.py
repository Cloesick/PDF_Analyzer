"""
Rename images in images_experiment folder with better names that include:
- Primary SKU
- Product name/description
- Category information

This makes it easier to identify images and relate them to products.
"""

import json
import re
import shutil
from pathlib import Path
from typing import Dict, List, Set
from collections import defaultdict


PROJECT_ROOT = Path(__file__).parent
IMAGES_EXPERIMENT = PROJECT_ROOT / "images_experiment"
OUTPUT_DIR = PROJECT_ROOT / "output"
JSON_FILE = OUTPUT_DIR / "products_for_shop.json"


def sanitize_filename(text: str, max_length: int = 50) -> str:
    """Sanitize text for use in a filename."""
    # Remove or replace invalid filename characters
    text = re.sub(r'[<>:"/\\|?*]', '_', text)
    # Replace multiple spaces/underscores with single underscore
    text = re.sub(r'[\s_]+', '_', text)
    # Remove leading/trailing underscores and spaces
    text = text.strip('_ ')
    # Limit length
    if len(text) > max_length:
        text = text[:max_length].rstrip('_ ')
    return text


def extract_page_from_path(filepath: Path) -> str:
    """Extract page number from filepath if it contains _p### pattern."""
    # Look for pattern like _p005_ or _p12_ in the path
    match = re.search(r'_p(\d{1,4})_', str(filepath))
    if match:
        return f"p{match.group(1)}"
    return None


def extract_skus_from_filename(filename: str) -> List[str]:
    """Extract SKU numbers from the current filename format.
    
    Examples:
    - PISTO_PISTON_COMPRESSORS_Blue_Series_Pro_36826+36827+36828_IMG.png
      -> ['36826', '36827', '36828']
    - HAND_TOOLS_TOOLSETS_Sockets_wrench_sets__45349+45580+45780_IMG.png
      -> ['45349', '45580', '45780']
    """
    # Look for pattern like: numbers with + separators before _IMG
    match = re.search(r'_([\d\-N+]+)_IMG', filename)
    if match:
        sku_string = match.group(1)
        # Split on + to get individual SKUs
        skus = [s.strip() for s in sku_string.split('+') if s.strip()]
        return skus
    
    # Check for "Unknown" pattern
    if '_Unknown_IMG' in filename:
        return []
    
    return []


def normalize_sku_for_lookup(sku: str) -> str:
    """Normalize SKU for lookup - remove spaces and convert to uppercase."""
    return sku.replace(' ', '').replace('-', '').upper()


def load_products_json() -> Dict[str, Dict]:
    """Load products JSON and create SKU to product mapping."""
    print(f"Loading products from {JSON_FILE}...")
    
    with open(JSON_FILE, 'r', encoding='utf-8') as f:
        products = json.load(f)
    
    # Create SKU mapping with multiple variations for better matching
    sku_map = {}
    for product in products:
        sku = product.get('sku', '').strip()
        if sku:
            # Store with original SKU
            sku_map[sku.upper()] = product
            # Store with normalized SKU (no spaces/dashes)
            normalized = normalize_sku_for_lookup(sku)
            sku_map[normalized] = product
            # Store without any prefix (e.g., "N 36510-N" -> "36510N")
            sku_only = ''.join(c for c in sku if c.isdigit() or c == 'N').upper()
            if sku_only:
                sku_map[sku_only] = product
    
    print(f"Loaded {len(products)} products with {len(sku_map)} SKU variations")
    return sku_map


def extract_category_from_filename(filename: str) -> str:
    """Extract category from the current filename format."""
    # Pattern is typically: CATEGORY_SUBCATEGORY_...
    # Take first 2 or 3 parts before the SKU numbers
    parts = filename.split('_')
    
    # Find where SKU numbers start (look for part with digits and +)
    category_parts = []
    for part in parts:
        # Stop when we hit a part that looks like SKUs or "IMG"
        if re.match(r'^[\d\-N+]+$', part) or part == 'IMG':
            break
        category_parts.append(part)
    
    # Take first 2-3 parts for category
    if len(category_parts) > 3:
        category_parts = category_parts[:3]
    
    return '_'.join(category_parts) if category_parts else 'UNKNOWN'


def find_product_by_sku(sku: str, sku_map: Dict[str, Dict]) -> Dict | None:
    """Try to find a product using various SKU matching strategies."""
    # Try exact match first
    if sku.upper() in sku_map:
        return sku_map[sku.upper()]
    
    # Try normalized version
    normalized = normalize_sku_for_lookup(sku)
    if normalized in sku_map:
        return sku_map[normalized]
    
    # Try just the numbers and N
    sku_only = ''.join(c for c in sku if c.isdigit() or c == 'N').upper()
    if sku_only in sku_map:
        return sku_map[sku_only]
    
    return None


def extract_product_details(product: Dict) -> Dict[str, str]:
    """Extract relevant details from product JSON for filename."""
    details = {}
    
    # Get attributes if available
    attrs = product.get('attributes', {})
    specs = product.get('specs', [])
    
    # Look for key technical specs
    if attrs:
        # Power info
        if 'power_kw' in attrs:
            details['power'] = f"{attrs['power_kw']}kW"
        elif 'power_hp' in attrs:
            details['power'] = f"{attrs['power_hp']}HP"
        
        # Pressure info
        if 'pressure_max_bar' in attrs:
            details['pressure'] = f"{attrs['pressure_max_bar']}bar"
        
        # Volume info
        if 'volume_l' in attrs:
            details['volume'] = f"{attrs['volume_l']}L"
        
        # Dimensions
        if 'dimensions_mm_list' in attrs:
            dims = attrs['dimensions_mm_list']
            if isinstance(dims, list) and len(dims) >= 2:
                details['size'] = f"{dims[0]}x{dims[1]}mm"
    
    return details


def build_new_filename(
    original_filename: str,
    original_path: Path,
    skus: List[str],
    sku_map: Dict[str, Dict],
    category: str,
    extension: str
) -> str:
    """Build a new, more descriptive filename with page number and product details."""
    
    # Extract page number from original path
    page_info = extract_page_from_path(original_path)
    page_str = f"__{page_info}" if page_info else ""
    
    if not skus:
        # Unknown SKU case
        return f"{category}{page_str}__UNKNOWN_SKU{extension}"
    
    # Get primary SKU (first one)
    primary_sku = skus[0]
    
    # Try to find product info
    product = find_product_by_sku(primary_sku, sku_map)
    
    if product:
        # Use the extracted category from filename (more descriptive than JSON category)
        # and add the catalog info from JSON for context
        catalog = product.get('catalog', 'unknown')
        catalog_short = sanitize_filename(catalog.replace('-', ' '), max_length=15)
        safe_category = sanitize_filename(category, max_length=35)
        
        # Extract technical details
        details = extract_product_details(product)
        details_str = ""
        if details:
            # Add key specs to filename (max 2-3 details)
            detail_parts = []
            for key in ['power', 'pressure', 'volume', 'size']:
                if key in details:
                    detail_parts.append(details[key])
                    if len(detail_parts) >= 2:  # Limit to 2 specs to keep filename reasonable
                        break
            if detail_parts:
                details_str = "__" + "_".join(detail_parts)
        
        # Build filename: PRIMARY_SKU__CATEGORY__PAGE__CATALOG__DETAILS__[ALL_SKUS]
        if len(skus) == 1:
            new_name = f"{primary_sku}__{safe_category}{page_str}__{catalog_short}{details_str}{extension}"
        else:
            # Multiple SKUs - include all of them
            all_skus_str = '+'.join(skus[:5])  # Limit to 5 SKUs to avoid too long filenames
            if len(skus) > 5:
                all_skus_str += f"+{len(skus)-5}more"
            new_name = f"{primary_sku}__{safe_category}{page_str}__{catalog_short}{details_str}__[{all_skus_str}]{extension}"
    else:
        # SKU not found in JSON
        if len(skus) == 1:
            new_name = f"{primary_sku}__{category}{page_str}__NOT_IN_DB{extension}"
        else:
            all_skus_str = '+'.join(skus[:5])
            if len(skus) > 5:
                all_skus_str += f"+{len(skus)-5}more"
            new_name = f"{primary_sku}__{category}{page_str}__NOT_IN_DB__[{all_skus_str}]{extension}"
    
    return new_name


def process_images(dry_run: bool = True):
    """Process all images in the experiment folder."""
    
    # Load product data
    sku_map = load_products_json()
    
    # Statistics
    stats = {
        'total_images': 0,
        'renamed': 0,
        'skipped': 0,
        'not_in_db': 0,
        'unknown_sku': 0,
        'errors': 0
    }
    
    # Track which SKUs were found/not found
    found_skus = set()
    missing_skus = set()
    
    print(f"\n{'DRY RUN: ' if dry_run else ''}Processing images in {IMAGES_EXPERIMENT}...")
    print("=" * 80)
    
    # Create output directory for renamed images
    output_dir = IMAGES_EXPERIMENT / "renamed"
    if not dry_run:
        output_dir.mkdir(exist_ok=True)
    
    # Walk through all images
    image_extensions = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp'}
    
    for root, dirs, files in IMAGES_EXPERIMENT.walk():
        for filename in files:
            filepath = root / filename
            
            # Skip if not an image
            if filepath.suffix.lower() not in image_extensions:
                continue
            
            stats['total_images'] += 1
            
            # Extract SKUs from filename
            skus = extract_skus_from_filename(filename)
            
            # Extract category
            category = extract_category_from_filename(filename)
            
            # Build new filename
            extension = filepath.suffix
            new_filename = build_new_filename(filename, filepath, skus, sku_map, category, extension)
            
            # Determine relative path structure
            rel_path = filepath.relative_to(IMAGES_EXPERIMENT)
            rel_dir = rel_path.parent
            
            # New path in the renamed directory
            new_filepath = output_dir / rel_dir / new_filename
            
            # Track statistics
            if not skus:
                stats['unknown_sku'] += 1
            else:
                product = find_product_by_sku(skus[0], sku_map)
                if not product:
                    stats['not_in_db'] += 1
                    missing_skus.update(skus)
                else:
                    found_skus.add(skus[0].upper())
            
            # Show progress every 50 images
            if stats['total_images'] % 50 == 0:
                print(f"Processed {stats['total_images']} images...", end='\r')
            
            # Perform the rename/copy
            if not dry_run:
                try:
                    new_filepath.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(filepath, new_filepath)
                    stats['renamed'] += 1
                except Exception as e:
                    print(f"\nError processing {filepath}: {e}")
                    stats['errors'] += 1
            else:
                # In dry run, just count
                stats['renamed'] += 1
                
                # Print some examples (first 10)
                if stats['total_images'] <= 10:
                    print(f"\nWould rename:")
                    print(f"  FROM: {rel_path}")
                    print(f"  TO:   {rel_dir / new_filename}")
    
    # Clear progress line
    print(" " * 80 + "\r", end='')
    
    # Print final statistics
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print(f"Total images found:          {stats['total_images']}")
    print(f"Images {'that would be ' if dry_run else ''}renamed:       {stats['renamed']}")
    print(f"Images with unknown SKUs:    {stats['unknown_sku']}")
    print(f"Images with SKUs not in DB:  {stats['not_in_db']}")
    print(f"Errors:                      {stats['errors']}")
    print(f"\nSKUs found in JSON:          {len(found_skus)}")
    print(f"SKUs NOT found in JSON:      {len(missing_skus)}")
    
    if missing_skus and len(missing_skus) <= 20:
        print(f"\nMissing SKUs: {', '.join(sorted(missing_skus))}")
    
    if dry_run:
        print("\n" + "=" * 80)
        print("This was a DRY RUN. No files were modified.")
        print("Run with --execute to actually rename the files.")
        print("=" * 80)
    else:
        print(f"\nRenamed images saved to: {output_dir}")
    
    return stats


def main():
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Rename images in images_experiment with better, more descriptive names"
    )
    parser.add_argument(
        '--execute',
        action='store_true',
        help='Actually perform the renaming (default is dry-run)'
    )
    
    args = parser.parse_args()
    
    # Check if paths exist
    if not JSON_FILE.exists():
        print(f"Error: JSON file not found at {JSON_FILE}")
        return 1
    
    if not IMAGES_EXPERIMENT.exists():
        print(f"Error: Images folder not found at {IMAGES_EXPERIMENT}")
        return 1
    
    # Process images
    process_images(dry_run=not args.execute)
    
    return 0


if __name__ == '__main__':
    exit(main())
