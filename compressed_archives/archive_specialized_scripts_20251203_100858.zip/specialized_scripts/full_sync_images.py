"""
Full sync of all properly-named WebP images to webshop
This will replace old-style filenames with new proper filenames
"""

import shutil
from pathlib import Path

SOURCE = Path(r"C:\Users\prova\Documents\Projects\PDF_Analyzer\product-images")
DEST = Path(r"C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop\public\product-images")

print("🔄 Full sync of images to webshop...\n")
print("This will replace old-style filenames with new proper filenames\n")

synced_catalogs = 0
synced_images = 0

for catalog_dir in sorted(SOURCE.iterdir()):
    if not catalog_dir.is_dir():
        continue
    
    print(f"📁 {catalog_dir.name}")
    
    dest_catalog = DEST / catalog_dir.name
    
    # Remove old files in destination
    if dest_catalog.exists():
        old_files = list(dest_catalog.glob('*'))
        if old_files:
            print(f"   🗑️  Removing {len(old_files)} old files...")
            for f in old_files:
                f.unlink()
    else:
        dest_catalog.mkdir(parents=True)
    
    # Copy all .webp files
    webp_files = list(catalog_dir.glob('*.webp'))
    for img_file in webp_files:
        dest_file = dest_catalog / img_file.name
        shutil.copy2(img_file, dest_file)
    
    synced_images += len(webp_files)
    synced_catalogs += 1
    print(f"   ✅ Synced {len(webp_files)} images")

print(f"\n{'='*60}")
print(f"✅ Sync Complete!")
print(f"{'='*60}")
print(f"   Catalogs synced: {synced_catalogs}")
print(f"   Total images: {synced_images}")
print(f"\n🔄 Next: Dev server will auto-reload the images")
