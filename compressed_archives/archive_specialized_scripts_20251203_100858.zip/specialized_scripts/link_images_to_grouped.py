#!/usr/bin/env python3
"""
Link images to grouped product data
Matches images to product groups based on SKU and page
"""

import json
import re
from pathlib import Path
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"
WEBSHOP_DATA = PROJECT_ROOT.parent / "DemaWebshop" / "dema-webshop" / "public" / "data"
IMAGE_DIR = PROJECT_ROOT / "product-images-by-pdf"

# Catalogs to process
CATALOGS_TO_PROCESS = [
    "bronpompen",
    "catalogus-aandrijftechniek-150922",
    "centrifugaalpompen",
    "digitale-versie-pompentoebehoren-compressed",
    "dompelpompen",
    "drukbuizen",
    "kunststof-afvoerleidingen",
    "messing-draadfittingen",
    # NEW: Kränzle and Airpress catalogs
    "kranzle-catalogus-2021-nl-1",
    "airpress-catalogus-eng",
    "airpress-catalogus-nl-fr"
]

# Catalog to image directory mapping
CATALOG_IMAGE_MAP = {
    "bronpompen": "bronpompen",
    "catalogus-aandrijftechniek-150922": "catalogus-aandrijftechniek-150922",
    "centrifugaalpompen": "centrifugaalpompen",
    "digitale-versie-pompentoebehoren-compressed": "digitale-versie-pompentoebehoren-compressed",
    "dompelpompen": "dompelpompen",
    "drukbuizen": "drukbuizen",
    "kunststof-afvoerleidingen": "kunststof-afvoerleidingen",
    "messing-draadfittingen": "messing-draadfittingen",
    # NEW: Kränzle and Airpress catalogs
    "kranzle-catalogus-2021-nl-1": "kranzle-catalogus-2021-nl-1",
    "airpress-catalogus-eng": "airpress-catalogus-eng",
    "airpress-catalogus-nl-fr": "airpress-catalogus-nl-fr"
}

def load_grouped_data(catalog_key):
    """Load grouped JSON data"""
    filename = f"{catalog_key.replace('-', '_')}_grouped.json"
    file_path = OUTPUT_DIR / filename
    
    if not file_path.exists():
        return None
    
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def find_images_for_catalog(catalog_key):
    """Find all images for a catalog"""
    image_folder = CATALOG_IMAGE_MAP.get(catalog_key, catalog_key)
    image_path = IMAGE_DIR / image_folder
    
    if not image_path.exists():
        return []
    
    # Find all image files
    images = []
    for ext in ['*.webp', '*.png', '*.jpg', '*.jpeg']:
        images.extend(image_path.glob(ext))
    
    return images

def extract_page_from_filename(filename):
    """Extract page number from image filename"""
    # Look for patterns like _p010, _page10, p10, etc.
    patterns = [
        r'_p(\d+)',
        r'_page(\d+)',
        r'p(\d+)',
        r'page(\d+)'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, filename.lower())
        if match:
            return int(match.group(1))
    
    return None

def extract_sku_from_filename(filename):
    """Extract SKU from image filename"""
    # Remove extension
    name = Path(filename).stem
    
    # Split by common separators
    parts = re.split(r'[_\-\.]', name)
    
    # First part is usually the SKU
    if parts:
        return parts[0].strip()
    
    return None

def match_image_to_group(group, images):
    """Match images to a product group"""
    page = group.get('page_in_pdf')
    variant_skus = [v['sku'] for v in group.get('variants', [])]
    
    matched_images = []
    
    for image_path in images:
        filename = image_path.name
        
        # Check if page matches
        image_page = extract_page_from_filename(filename)
        if image_page and image_page == page:
            matched_images.append(image_path)
            continue
        
        # Check if any variant SKU is in the filename
        for sku in variant_skus:
            if sku.lower() in filename.lower():
                matched_images.append(image_path)
                break
    
    return matched_images

def link_images(catalog_key):
    """Link images to product groups"""
    print(f"\n{'='*80}")
    print(f"LINKING IMAGES: {catalog_key.upper()}")
    print(f"{'='*80}")
    
    # Load grouped data
    groups = load_grouped_data(catalog_key)
    if not groups:
        print(f"  ⚠️  No grouped data found")
        return
    
    print(f"  📦 Loaded {len(groups)} groups")
    
    # Find images
    images = find_images_for_catalog(catalog_key)
    print(f"  🖼️  Found {len(images)} images")
    
    if not images:
        print(f"  ⚠️  No images found")
        return
    
    # Build image index by page
    images_by_page = defaultdict(list)
    for img in images:
        page = extract_page_from_filename(img.name)
        if page:
            images_by_page[page].append(img)
    
    # Link images to groups
    linked_count = 0
    for group in groups:
        page = group.get('page_in_pdf')
        
        # Try to find image for this page
        if page in images_by_page:
            page_images = images_by_page[page]
            
            # If only one image for this page, use it
            if len(page_images) == 1:
                img = page_images[0]
                image_folder = CATALOG_IMAGE_MAP.get(catalog_key, catalog_key)
                relative_path = f"product-images-by-pdf/{image_folder}/{img.name}"
                
                group['media'] = [{
                    "url": relative_path,
                    "role": "main"
                }]
                linked_count += 1
            else:
                # Multiple images on this page, try to match by SKU
                matched = match_image_to_group(group, page_images)
                if matched:
                    img = matched[0]
                    image_folder = CATALOG_IMAGE_MAP.get(catalog_key, catalog_key)
                    relative_path = f"product-images-by-pdf/{image_folder}/{img.name}"
                    
                    group['media'] = [{
                        "url": relative_path,
                        "role": "main"
                    }]
                    linked_count += 1
    
    print(f"  ✅ Linked {linked_count}/{len(groups)} groups to images")
    
    # Save updated data
    filename = f"{catalog_key.replace('-', '_')}_grouped.json"
    
    # Save to output
    output_file = OUTPUT_DIR / filename
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(groups, f, indent=2, ensure_ascii=False)
    
    print(f"  💾 Saved: {output_file.name}")
    
    # Save to webshop
    webshop_file = WEBSHOP_DATA / filename
    with open(webshop_file, 'w', encoding='utf-8') as f:
        json.dump(groups, f, indent=2, ensure_ascii=False)
    
    print(f"  📤 Copied to webshop: {webshop_file.name}")
    
    return {
        'catalog': catalog_key,
        'groups': len(groups),
        'images_linked': linked_count,
        'coverage': round(linked_count / len(groups) * 100, 1) if groups else 0
    }

def main():
    print("="*80)
    print("LINKING IMAGES TO GROUPED DATA")
    print("="*80)
    
    results = []
    for catalog in CATALOGS_TO_PROCESS:
        result = link_images(catalog)
        if result:
            results.append(result)
    
    print(f"\n{'='*80}")
    print("SUMMARY")
    print(f"{'='*80}\n")
    
    if results:
        print(f"{'Catalog':<45s} {'Groups':<8s} {'Linked':<8s} {'Coverage':<10s}")
        print("-" * 80)
        for r in results:
            print(f"{r['catalog']:<45s} {r['groups']:<8d} {r['images_linked']:<8d} {r['coverage']:<10.1f}%")
        
        total_groups = sum(r['groups'] for r in results)
        total_linked = sum(r['images_linked'] for r in results)
        avg_coverage = total_linked / total_groups * 100 if total_groups else 0
        
        print("-" * 80)
        print(f"{'TOTAL':<45s} {total_groups:<8d} {total_linked:<8d} {avg_coverage:<10.1f}%")
    
    print(f"\n{'='*80}")
    print(f"✅ COMPLETE - Linked images for {len(results)} catalogs")
    print(f"{'='*80}")

if __name__ == "__main__":
    main()
