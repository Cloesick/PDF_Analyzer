"""
Format Makita Battery Products into Table
==========================================
Creates structured table with exact format requested:
- SKU
- Product Name
- Specifications/Content
- Price (Excl. VAT)
- Price (Incl. VAT)

Note: "Li" always stands for Lithium
"""

import json
import re
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
OUTPUT_JSON = PROJECT_ROOT / "output" / "makita_batteries_formatted.json"
OUTPUT_TABLE = PROJECT_ROOT / "output" / "makita_batteries_table.md"

VAT_RATE = 1.21

# Manual data based on user's provided table (ground truth)
BATTERY_DATA = {
    'batteries': [
        {
            'sku': '191L29-0',
            'product_name': 'Li-ion battery BL4020',
            'specifications': '40Vmax • 2.0 Ah • 0.69 kg • 22 min charge',
            'price_excl': 125.00,
            'price_incl': 151.25
        },
        {
            'sku': '191B36-3',
            'product_name': 'Li-ion battery BL4025',
            'specifications': '40Vmax • 2.5 Ah • 0.71 kg • 28 min charge',
            'price_excl': 135.00,
            'price_incl': 163.35
        },
        {
            'sku': '191B26-6',
            'product_name': 'Li-ion battery BL4040',
            'specifications': '40Vmax • 4.0 Ah • 1 kg • 45 min charge',
            'price_excl': 195.00,
            'price_incl': 235.95
        },
        {
            'sku': '191L47-8',
            'product_name': 'Li-ion battery BL4050F',
            'specifications': '40Vmax • 5.0 Ah • 1.3 kg • 50 min charge',
            'price_excl': 219.00,
            'price_incl': 264.99
        },
        {
            'sku': '191X65-8',
            'product_name': 'Li-ion battery BL4080F',
            'specifications': '40Vmax • 8.0 Ah • 2.0 kg • 80 min charge',
            'price_excl': 315.00,
            'price_incl': 381.15
        },
    ],
    'powerpacks': [
        {
            'sku': '191V07-0',
            'product_name': 'XGT Powerpack 2.0 Ah',
            'specifications': 'Includes MAKPAC case',
            'price_excl': 355.00,
            'price_incl': 429.55
        },
        {
            'sku': '191J81-6',
            'product_name': 'XGT Powerpack 2.5 Ah',
            'specifications': 'Includes MAKPAC case',
            'price_excl': 399.00,
            'price_incl': 482.79
        },
        {
            'sku': '191J65-4',
            'product_name': 'XGT Powerpack 4.0 Ah',
            'specifications': 'Single battery + charger (No MAKPAC shown)',
            'price_excl': 299.00,
            'price_incl': 361.79
        },
        {
            'sku': '191J97-1',
            'product_name': 'XGT Powerpack 4.0 Ah',
            'specifications': 'Includes MAKPAC case',
            'price_excl': 499.00,
            'price_incl': 603.79
        },
        {
            'sku': '191V35-5',
            'product_name': 'XGT Powerpack 5.0 Ah',
            'specifications': 'Includes MAKPAC case',
            'price_excl': 565.00,
            'price_incl': 683.65
        },
        {
            'sku': '191U00-8',
            'product_name': 'XGT Powerpack 4.0 Ah',
            'specifications': 'Duo charger + MAKPAC',
            'price_excl': 569.00,
            'price_incl': 688.49
        },
        {
            'sku': '191U28-6',
            'product_name': 'XGT Powerpack 4.0 Ah',
            'specifications': '4 Batteries + Duo charger + MAKPAC',
            'price_excl': 929.00,
            'price_incl': 1124.09
        },
        {
            'sku': '191U13-9',
            'product_name': 'XGT Powerpack 5.0 Ah',
            'specifications': 'Duo charger + MAKPAC',
            'price_excl': 639.00,
            'price_incl': 773.19
        },
        {
            'sku': '191U42-2',
            'product_name': 'XGT Powerpack 5.0 Ah',
            'specifications': '4 Batteries + Duo charger + MAKPAC',
            'price_excl': 1069.00,
            'price_incl': 1293.49
        },
        {
            'sku': '191Y97-1',
            'product_name': 'XGT Powerpack 8.0 Ah',
            'specifications': '2x BL4080F + DC40RB in MAKPAC',
            'price_excl': 799.00,
            'price_incl': 966.79
        },
    ],
    'chargers': [
        {
            'sku': '191E07-8',
            'product_name': 'Charger DC40RA',
            'specifications': 'Fast charger for XGT 40Vmax batteries',
            'price_excl': 125.00,
            'price_incl': 151.25
        },
        {
            'sku': '191N09-8',
            'product_name': 'Duo fast charger DC40RB',
            'specifications': 'Simultaneous charging of two XGT 40Vmax batteries',
            'price_excl': 205.00,
            'price_incl': 248.05
        },
    ],
    'adapters': [
        {
            'sku': '191C10-7',
            'product_name': 'ADP10 Charging Adapter',
            'specifications': 'Adapter to charge LXT 14.4V/18V batteries on XGT charger',
            'price_excl': 59.50,
            'price_incl': 72.00
        },
        {
            'sku': 'DEAADP001G',
            'product_name': 'ADP001 Charging Adapter',
            'specifications': 'USB-adapter for XGT 40Vmax batteries',
            'price_excl': 50.80,
            'price_incl': 61.50
        },
    ]
}

def create_markdown_table():
    """Create markdown table"""
    
    lines = []
    lines.append("# Makita Battery Products\n")
    lines.append("**Note:** Li = Lithium\n")
    
    for category, title in [
        ('batteries', '## Batteries'),
        ('powerpacks', '## Powerpacks (Kits)'),
        ('chargers', '## Chargers & Adapters')
    ]:
        items = BATTERY_DATA.get(category, [])
        if category == 'chargers':
            items = BATTERY_DATA['chargers'] + BATTERY_DATA['adapters']
        
        if not items:
            continue
        
        lines.append(f"\n{title}\n")
        lines.append("| SKU | Product Name | Specifications / Content | Price (Excl. VAT) | Price (Incl. VAT) |")
        lines.append("|-----|--------------|--------------------------|-------------------|-------------------|")
        
        for item in items:
            sku = item['sku']
            name = item['product_name']
            specs = item['specifications']
            price_ex = f"€ {item['price_excl']:.2f}"
            price_in = f"€ {item['price_incl']:.2f}"
            
            lines.append(f"| {sku} | {name} | {specs} | {price_ex} | {price_in} |")
    
    return '\n'.join(lines)

def parse_specifications(specs, category):
    """Parse specifications into structured properties with icons"""
    props = {}
    
    # Voltage
    voltage_match = re.search(r'(\d+\.?\d*)\s*V\s*(?:max)?', specs, re.IGNORECASE)
    if voltage_match:
        props['voltage'] = {
            'value': voltage_match.group(0),
            'icon': '⚡',
            'label': 'Voltage'
        }
    
    # Capacity (Ah)
    capacity_match = re.search(r'(\d+\.?\d*)\s*Ah', specs, re.IGNORECASE)
    if capacity_match:
        props['capacity'] = {
            'value': capacity_match.group(0),
            'icon': '🔋',
            'label': 'Capacity'
        }
    
    # Weight
    weight_match = re.search(r'(\d+\.?\d*)\s*kg', specs, re.IGNORECASE)
    if weight_match:
        props['weight'] = {
            'value': weight_match.group(0),
            'icon': '⚖️',
            'label': 'Weight'
        }
    
    # Charge time
    charge_match = re.search(r'(\d+)\s*min(?:uten)?\s*charge', specs, re.IGNORECASE)
    if charge_match:
        props['charge_time'] = {
            'value': f"{charge_match.group(1)} min",
            'icon': '⏱️',
            'label': 'Charge Time'
        }
    
    # Kit contents
    if 'MAKPAC' in specs or 'makpac' in specs.lower():
        props['case'] = {
            'value': 'MAKPAC case included',
            'icon': '💼',
            'label': 'Case'
        }
    
    if 'Duo charger' in specs or 'duo' in specs.lower():
        props['charger_type'] = {
            'value': 'Duo charger',
            'icon': '🔌',
            'label': 'Charger'
        }
    elif 'charger' in specs.lower() and category == 'powerpacks':
        props['charger_type'] = {
            'value': 'Single charger',
            'icon': '🔌',
            'label': 'Charger'
        }
    
    # Battery count in kits
    if '4 Batteries' in specs or '4 batteries' in specs.lower():
        props['battery_count'] = {
            'value': '4 batteries',
            'icon': '🔋',
            'label': 'Batteries'
        }
    elif '2x' in specs or '2 batteries' in specs.lower():
        props['battery_count'] = {
            'value': '2 batteries',
            'icon': '🔋',
            'label': 'Batteries'
        }
    
    # Charger specific
    if 'Fast charger' in specs:
        props['charger_type'] = {
            'value': 'Fast charger',
            'icon': '⚡',
            'label': 'Type'
        }
    
    if 'Simultaneous' in specs:
        props['feature'] = {
            'value': 'Simultaneous charging',
            'icon': '🔄',
            'label': 'Feature'
        }
    
    # Adapter specific
    if 'USB' in specs or 'usb' in specs.lower():
        props['adapter_type'] = {
            'value': 'USB adapter',
            'icon': '🔌',
            'label': 'Type'
        }
    
    if '14.4V' in specs or '18V' in specs:
        props['compatibility'] = {
            'value': 'LXT 14.4V/18V compatible',
            'icon': '🔄',
            'label': 'Compatibility'
        }
    
    return props

def create_json_output():
    """Create JSON output with display format"""
    
    import re
    
    output = {
        'metadata': {
            'source': 'makita-catalogus-2022-nl',
            'note': 'Li = Lithium',
            'total_products': sum(len(BATTERY_DATA[cat]) for cat in ['batteries', 'powerpacks', 'chargers', 'adapters'])
        },
        'products': []
    }
    
    for category in ['batteries', 'powerpacks', 'chargers', 'adapters']:
        for item in BATTERY_DATA[category]:
            # Parse specifications into structured properties
            properties = parse_specifications(item['specifications'], category)
            
            # Create display object with icons
            display_props = {}
            for key, prop in properties.items():
                display_props[key] = f"{prop['icon']} {prop['value']}"
            
            product = {
                'sku': item['sku'],
                'category': category,
                'product_name': item['product_name'],
                'specifications': item['specifications'],
                'properties': properties,  # Structured properties with icons
                'prices': {
                    'excl_vat': item['price_excl'],
                    'incl_vat': item['price_incl'],
                    'vat_rate': 0.21
                },
                'display': {
                    'price_excl': f"💶 € {item['price_excl']:.2f} (ex BTW)",
                    'price_incl': f"💶 € {item['price_incl']:.2f} (incl BTW)",
                    'full_spec': f"{item['product_name']} - {item['specifications']}",
                    'properties': display_props  # Properties with icons for frontend
                }
            }
            output['products'].append(product)
    
    return output

def format_batteries():
    """Format battery products"""
    
    print("="*80)
    print("MAKITA BATTERY PRODUCTS FORMATTER")
    print("="*80)
    
    # Create markdown table
    markdown = create_markdown_table()
    with open(OUTPUT_TABLE, 'w', encoding='utf-8') as f:
        f.write(markdown)
    
    print(f"\n✅ Markdown table created: {OUTPUT_TABLE}")
    
    # Create JSON
    json_data = create_json_output()
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(json_data, f, indent=2, ensure_ascii=False)
    
    print(f"✅ JSON data created: {OUTPUT_JSON}")
    
    # Display tables
    print(f"\n{'='*80}")
    print("FORMATTED TABLES")
    print(f"{'='*80}\n")
    print(markdown)
    print(f"\n{'='*80}")
    
    # Summary
    print(f"\n📊 Summary:")
    print(f"   Batteries:        {len(BATTERY_DATA['batteries'])}")
    print(f"   Powerpacks:       {len(BATTERY_DATA['powerpacks'])}")
    print(f"   Chargers:         {len(BATTERY_DATA['chargers'])}")
    print(f"   Adapters:         {len(BATTERY_DATA['adapters'])}")
    print(f"   Total:            {json_data['metadata']['total_products']}")
    
    print(f"\n💡 Note: Li = Lithium in all product names")
    print(f"{'='*80}\n")
    
    return json_data

if __name__ == "__main__":
    format_batteries()
