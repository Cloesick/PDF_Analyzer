#!/usr/bin/env python3
"""
Create frontend catalog pages for all processed catalogs
Uses abs-grouped as template
"""

from pathlib import Path
import re

# Paths
WEBSHOP_ROOT = Path(__file__).parent.parent / "DemaWebshop" / "dema-webshop"
TEMPLATE_PATH = WEBSHOP_ROOT / "src" / "app" / "catalog" / "abs-grouped" / "page.tsx"
CATALOG_DIR = WEBSHOP_ROOT / "src" / "app" / "catalog"

# Catalogs to create pages for
CATALOGS = [
    {
        "key": "rubber-slangen",
        "title": "Rubber Slangen",
        "json": "rubber_slangen_grouped.json",
        "pdf": "rubber-slangen.pdf",
        "description": "High-quality rubber hoses for various applications"
    },
    {
        "key": "slangklemmen",
        "title": "Slangklemmen",
        "json": "slangklemmen_grouped.json",
        "pdf": "slangklemmen.pdf",
        "description": "Hose clamps in various sizes"
    },
    {
        "key": "drukbuizen",
        "title": "Drukbuizen",
        "json": "drukbuizen_grouped.json",
        "pdf": "drukbuizen.pdf",
        "description": "Pressure pipes for industrial applications"
    },
    {
        "key": "pe-buizen",
        "title": "PE Buizen",
        "json": "pe_buizen_grouped.json",
        "pdf": "pe-buizen.pdf",
        "description": "Polyethylene pipes"
    },
    {
        "key": "verzinkte-buizen",
        "title": "Verzinkte Buizen",
        "json": "verzinkte_buizen_grouped.json",
        "pdf": "verzinkte-buizen.pdf",
        "description": "Galvanized pipes"
    },
    {
        "key": "messing-draadfittingen",
        "title": "Messing Draadfittingen",
        "json": "messing_draadfittingen_grouped.json",
        "pdf": "messing-draadfittingen.pdf",
        "description": "Brass threaded fittings"
    },
    {
        "key": "rvs-draadfittingen",
        "title": "RVS Draadfittingen",
        "json": "rvs_draadfittingen_grouped.json",
        "pdf": "rvs-draadfittingen.pdf",
        "description": "Stainless steel threaded fittings"
    },
    {
        "key": "zwarte-draad-en-lasfittingen",
        "title": "Zwarte Draad en Lasfittingen",
        "json": "zwarte_draad_en_lasfittingen_grouped.json",
        "pdf": "zwarte-draad-en-lasfittingen.pdf",
        "description": "Black threaded and welding fittings"
    },
    {
        "key": "kunststof-afvoerleidingen",
        "title": "Kunststof Afvoerleidingen",
        "json": "kunststof_afvoerleidingen_grouped.json",
        "pdf": "kunststof-afvoerleidingen.pdf",
        "description": "Plastic drainage pipes"
    },
    {
        "key": "centrifugaalpompen",
        "title": "Centrifugaalpompen",
        "json": "centrifugaalpompen_grouped.json",
        "pdf": "centrifugaalpompen.pdf",
        "description": "Centrifugal pumps"
    },
    {
        "key": "dompelpompen",
        "title": "Dompelpompen",
        "json": "dompelpompen_grouped.json",
        "pdf": "dompelpompen.pdf",
        "description": "Submersible pumps"
    },
    {
        "key": "bronpompen",
        "title": "Bronpompen",
        "json": "bronpompen_grouped.json",
        "pdf": "bronpompen.pdf",
        "description": "Well pumps"
    },
    {
        "key": "pompentoebehoren",
        "title": "Pompentoebehoren",
        "json": "pompentoebehoren_grouped.json",
        "pdf": "pompentoebehoren.pdf",
        "description": "Pump accessories"
    },
]


def create_catalog_page(catalog):
    """Create a catalog page from template"""
    print(f"Creating page for: {catalog['title']}")
    
    # Read template
    with open(TEMPLATE_PATH, 'r', encoding='utf-8') as f:
        template = f.read()
    
    # Replace placeholders
    content = template
    
    # Function name
    function_name = ''.join(word.capitalize() for word in catalog['key'].replace('-', '_').split('_')) + 'CatalogPage'
    content = re.sub(r'export default function \w+\(\)', f'export default function {function_name}()', content)
    
    # JSON file path
    content = content.replace('abs_persluchtbuizen_grouped.json', catalog['json'])
    
    # PDF source
    content = content.replace('abs-persluchtbuizen.pdf', catalog['pdf'])
    
    # Page title and metadata
    content = content.replace('ABS Persluchtbuizen Catalog', f'{catalog["title"]} Catalog')
    content = content.replace('ABS Persluchtbuizen', catalog['title'])
    
    # Create directory
    page_dir = CATALOG_DIR / f"{catalog['key']}-grouped"
    page_dir.mkdir(parents=True, exist_ok=True)
    
    # Write file
    page_file = page_dir / "page.tsx"
    with open(page_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"   ✅ Created: {page_file}")


def main():
    print("="*80)
    print("CREATING CATALOG PAGES")
    print("="*80)
    print(f"\nTemplate: {TEMPLATE_PATH}")
    print(f"Catalogs to create: {len(CATALOGS)}\n")
    
    for catalog in CATALOGS:
        create_catalog_page(catalog)
    
    print(f"\n{'='*80}")
    print(f"✅ SUCCESS: Created {len(CATALOGS)} catalog pages!")
    print(f"{'='*80}")
    
    print("\n📋 Catalog Pages Created:")
    for catalog in CATALOGS:
        url = f"http://localhost:3000/catalog/{catalog['key']}-grouped"
        print(f"   • {catalog['title']:30s} → {url}")


if __name__ == "__main__":
    main()
