"""
PE-BUIZEN ENHANCED REPORT GENERATOR
====================================

Creates an enhanced HTML report showing:
- Product data structure
- Products organized by category
- Visual representation of which products share images
- Summary statistics

Author: PDF Analyzer System
"""

import json
from pathlib import Path
from collections import defaultdict

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"
INPUT_JSON = OUTPUT_DIR / "pe_buizen_analysis.json"
OUTPUT_HTML = OUTPUT_DIR / "pe_buizen_report.html"

# ============================================================================
# LOAD DATA
# ============================================================================

def load_analysis_data():
    """Load the analysis JSON data"""
    with open(INPUT_JSON, 'r', encoding='utf-8') as f:
        return json.load(f)

# ============================================================================
# ANALYSIS FUNCTIONS
# ============================================================================

def group_products_by_category(data):
    """Group products by their category"""
    categories = defaultdict(list)
    
    for page in data['pages']:
        for product in page['products_found']:
            categories[product['category']].append(product)
    
    return dict(categories)

def find_products_with_same_page_images(data):
    """Find products that appear on the same page (likely sharing images)"""
    page_products = defaultdict(list)
    
    for page in data['pages']:
        if len(page['products_found']) > 0:
            page_num = page['page_number']
            for product in page['products_found']:
                page_products[page_num].append({
                    'product_id': product['product_id'],
                    'description': product['description'],
                    'category': product['category'],
                    'specs': product['specifications'],
                })
    
    # Find pages with multiple products
    shared_image_groups = []
    for page_num, products in page_products.items():
        if len(products) > 1:
            shared_image_groups.append({
                'page': page_num,
                'product_count': len(products),
                'products': products
            })
    
    return shared_image_groups

def analyze_image_distribution(data):
    """Analyze how images are distributed across pages"""
    image_stats = {
        'pages_with_images': 0,
        'pages_without_images': 0,
        'pages_with_multiple_images': 0,
        'average_images_per_page': 0,
        'image_distribution': defaultdict(int)
    }
    
    total_images = 0
    pages_with_images = 0
    
    for page in data['pages']:
        img_count = len(page['images_found'])
        total_images += img_count
        
        if img_count > 0:
            pages_with_images += 1
            image_stats['pages_with_images'] += 1
            
            if img_count > 2:
                image_stats['pages_with_multiple_images'] += 1
        else:
            image_stats['pages_without_images'] += 1
        
        image_stats['image_distribution'][img_count] += 1
    
    if pages_with_images > 0:
        image_stats['average_images_per_page'] = round(total_images / pages_with_images, 2)
    
    return image_stats

# ============================================================================
# HTML GENERATION
# ============================================================================

def generate_html_report(data):
    """Generate a comprehensive HTML report"""
    
    categories = group_products_by_category(data)
    shared_groups = find_products_with_same_page_images(data)
    image_stats = analyze_image_distribution(data)
    
    html = f"""
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PE-Buizen Analysis Report</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
        }}
        
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            overflow: hidden;
        }}
        
        header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }}
        
        header h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
        }}
        
        header p {{
            font-size: 1.2em;
            opacity: 0.9;
        }}
        
        .content {{
            padding: 40px;
        }}
        
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }}
        
        .stat-card {{
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }}
        
        .stat-card h3 {{
            font-size: 2.5em;
            margin-bottom: 10px;
        }}
        
        .stat-card p {{
            font-size: 1.1em;
            opacity: 0.9;
        }}
        
        .section {{
            margin-bottom: 40px;
        }}
        
        .section h2 {{
            font-size: 2em;
            margin-bottom: 20px;
            color: #667eea;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
        }}
        
        .category-section {{
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }}
        
        .category-section h3 {{
            font-size: 1.5em;
            color: #764ba2;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        
        .category-badge {{
            background: #764ba2;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9em;
        }}
        
        .product-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 15px;
        }}
        
        .product-card {{
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 20px;
            transition: all 0.3s ease;
        }}
        
        .product-card:hover {{
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
            transform: translateY(-2px);
        }}
        
        .product-id {{
            font-weight: bold;
            color: #667eea;
            font-size: 0.9em;
            margin-bottom: 10px;
        }}
        
        .product-desc {{
            color: #555;
            margin-bottom: 10px;
            font-size: 0.95em;
        }}
        
        .product-specs {{
            background: #f0f4ff;
            padding: 10px;
            border-radius: 5px;
            font-size: 0.85em;
        }}
        
        .product-specs dt {{
            font-weight: bold;
            color: #764ba2;
            display: inline;
        }}
        
        .product-specs dd {{
            display: inline;
            margin-left: 10px;
            color: #555;
        }}
        
        .product-specs dd:after {{
            content: "";
            display: block;
            margin-bottom: 5px;
        }}
        
        .shared-group {{
            background: #fff9e6;
            border-left: 4px solid #ffc107;
            padding: 20px;
            margin-bottom: 15px;
            border-radius: 5px;
        }}
        
        .shared-group h4 {{
            color: #f57c00;
            margin-bottom: 15px;
        }}
        
        .mini-product {{
            background: white;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
            border-left: 3px solid #ffc107;
        }}
        
        .page-info {{
            font-weight: bold;
            color: #667eea;
            margin-bottom: 10px;
        }}
        
        .distribution-chart {{
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 20px;
        }}
        
        .chart-bar {{
            background: #667eea;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            flex: 1;
            min-width: 150px;
            text-align: center;
        }}
        
        .chart-bar strong {{
            display: block;
            font-size: 1.5em;
        }}
        
        .no-data {{
            text-align: center;
            color: #999;
            padding: 40px;
            font-style: italic;
        }}
        
        .highlight {{
            background: #fffacd;
            padding: 2px 5px;
            border-radius: 3px;
        }}
        
        footer {{
            background: #f8f9fa;
            padding: 20px;
            text-align: center;
            color: #666;
            border-top: 1px solid #e0e0e0;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>📊 PE-Buizen PDF Analysis Report</h1>
            <p>Comprehensive data structure and product categorization</p>
        </header>
        
        <div class="content">
            <!-- Summary Statistics -->
            <div class="section">
                <h2>📈 Summary Statistics</h2>
                <div class="stats-grid">
                    <div class="stat-card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                        <h3>{data['total_pages']}</h3>
                        <p>Total Pages</p>
                    </div>
                    <div class="stat-card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                        <h3>{data['total_products']}</h3>
                        <p>Products Found</p>
                    </div>
                    <div class="stat-card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                        <h3>{data['total_images']}</h3>
                        <p>Images Extracted</p>
                    </div>
                    <div class="stat-card" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
                        <h3>{len(categories)}</h3>
                        <p>Categories</p>
                    </div>
                </div>
            </div>
            
            <!-- Category Distribution -->
            <div class="section">
                <h2>🏷️ Category Distribution</h2>
                <div class="distribution-chart">
"""
    
    # Add category distribution
    for category, count in sorted(data['categories'].items(), key=lambda x: x[1], reverse=True):
        html += f"""
                    <div class="chart-bar">
                        <strong>{count}</strong>
                        <span>{category.upper()}</span>
                    </div>
"""
    
    html += """
                </div>
            </div>
            
            <!-- Products by Category -->
            <div class="section">
                <h2>📦 Products by Category</h2>
"""
    
    # Add products organized by category
    for category, products in sorted(categories.items()):
        html += f"""
                <div class="category-section">
                    <h3>
                        {category.upper()}
                        <span class="category-badge">{len(products)} products</span>
                    </h3>
                    <div class="product-grid">
"""
        
        for product in products[:20]:  # Limit to first 20 per category for readability
            specs_html = ""
            if product.get('specifications'):
                specs_html = "<dl class='product-specs'>"
                for key, value in product['specifications'].items():
                    specs_html += f"<dt>{key}:</dt><dd>{value}</dd>"
                specs_html += "</dl>"
            
            html += f"""
                        <div class="product-card">
                            <div class="product-id">{product['product_id']}</div>
                            <div class="product-desc">{product['description'][:150]}...</div>
                            {specs_html}
                            <small style="color: #999;">Page {product['page_number']}</small>
                        </div>
"""
        
        if len(products) > 20:
            html += f"""
                        <div class="product-card" style="text-align: center; color: #999;">
                            <em>... and {len(products) - 20} more products</em>
                        </div>
"""
        
        html += """
                    </div>
                </div>
"""
    
    html += """
            </div>
            
            <!-- Products Sharing Images (Same Page) -->
            <div class="section">
                <h2>🖼️ Products Potentially Sharing Images</h2>
                <p style="margin-bottom: 20px; color: #666;">
                    Products appearing on the same page are likely sharing product images. 
                    Below are pages with multiple products:
                </p>
"""
    
    if shared_groups:
        for group in shared_groups[:15]:  # Show first 15 groups
            html += f"""
                <div class="shared-group">
                    <h4>📄 Page {group['page']} - {group['product_count']} Products Sharing Space</h4>
"""
            for product in group['products']:
                specs_str = ", ".join([f"{k}: {v}" for k, v in product['specs'].items()]) if product['specs'] else "No specs"
                html += f"""
                    <div class="mini-product">
                        <strong>{product['product_id']}</strong><br>
                        <small>{product['description'][:120]}...</small><br>
                        <small style="color: #999;">{specs_str}</small>
                    </div>
"""
            html += """
                </div>
"""
    else:
        html += """
                <div class="no-data">
                    No pages with multiple products detected. Each page appears to have a single product.
                </div>
"""
    
    html += """
            </div>
            
            <!-- Image Distribution Analysis -->
            <div class="section">
                <h2>📊 Image Distribution Analysis</h2>
                <div class="stats-grid">
                    <div class="stat-card" style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);">
                        <h3>{}</h3>
                        <p>Pages with Images</p>
                    </div>
                    <div class="stat-card" style="background: linear-gradient(135deg, #30cfd0 0%, #330867 100%);">
                        <h3>{}</h3>
                        <p>Pages without Images</p>
                    </div>
                    <div class="stat-card" style="background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);">
                        <h3>{}</h3>
                        <p>Avg Images/Page</p>
                    </div>
                </div>
            </div>
        </div>
        
        <footer>
            <p>Generated by PE-Buizen PDF Analyzer | {}</p>
            <p style="margin-top: 10px;">Data extracted from: <strong>{}</strong></p>
        </footer>
    </div>
</body>
</html>
""".format(
        image_stats['pages_with_images'],
        image_stats['pages_without_images'],
        image_stats['average_images_per_page'],
        "PDF Analysis System",
        data['pdf_name']
    )
    
    return html

# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    print("\n" + "="*70)
    print("GENERATING PE-BUIZEN HTML REPORT")
    print("="*70 + "\n")
    
    # Load data
    print(f"Loading analysis data from: {INPUT_JSON}")
    data = load_analysis_data()
    
    # Generate HTML
    print("Generating HTML report...")
    html = generate_html_report(data)
    
    # Save HTML
    with open(OUTPUT_HTML, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"\n✓ Report saved to: {OUTPUT_HTML}")
    print(f"\n{'='*70}")
    print("REPORT SUMMARY")
    print("="*70)
    print(f"Total Products: {data['total_products']}")
    print(f"Total Images: {data['total_images']}")
    print(f"Categories: {len(data['categories'])}")
    print("\nOpen the HTML file in your browser to view the full interactive report!")
    print("="*70 + "\n")
