"""
Sync all WebP images to webshop
"""

import shutil
from pathlib import Path

SOURCE = Path(r"C:\Users\prova\Documents\Projects\PDF_Analyzer\product-images")
DEST = Path(r"C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop\public\product-images")

print("🔄 Syncing WebP images to webshop...\n")

copied = 0
skipped = 0

for catalog_dir in sorted(SOURCE.iterdir()):
    if not catalog_dir.is_dir():
        continue
    
    dest_catalog = DEST / catalog_dir.name
    dest_catalog.mkdir(parents=True, exist_ok=True)
    
    catalog_copied = 0
    
    for img_file in catalog_dir.glob("*.webp"):
        dest_file = dest_catalog / img_file.name
        
        # Copy if doesn't exist or is different size
        if not dest_file.exists() or dest_file.stat().st_size != img_file.stat().st_size:
            shutil.copy2(img_file, dest_file)
            copied += 1
            catalog_copied += 1
        else:
            skipped += 1
    
    if catalog_copied > 0:
        print(f"   ✅ {catalog_dir.name}: {catalog_copied} images copied")

print(f"\n{'='*60}")
print(f"✅ Sync Complete!")
print(f"{'='*60}")
print(f"   Copied: {copied} images")
print(f"   Skipped: {skipped} (already up-to-date)")

# Verify
print(f"\n🔍 Verification:")
dest_count = sum(1 for catalog in DEST.iterdir() if catalog.is_dir() for _ in catalog.glob("*.webp"))
print(f"   WebP images in webshop: {dest_count}")
