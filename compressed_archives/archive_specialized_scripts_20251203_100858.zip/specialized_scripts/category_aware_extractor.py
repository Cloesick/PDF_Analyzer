"""
Category-aware PDF extractor with proper property detection
"""
import os
import json
import re
from pathlib import Path
from datetime import datetime
import fitz  # PyMuPDF

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ROOT = Path(__file__).parent
INPUT_PDFS = PROJECT_ROOT / "input_pdfs"
OUTPUT_DIR = PROJECT_ROOT / "output"

VERBOSE = True

# ============================================================================
# CATEGORY-SPECIFIC PROPERTY RULES
# ============================================================================

CATEGORY_RULES = {
    # Hose fittings - NO kW/V, YES diameter/pressure/material
    'slangkoppelingen': {
        'allowed': ['diameter_mm', 'inner_diameter_mm', 'outer_diameter_mm', 'pressure_max_bar', 
                   'material', 'materials', 'connection_type', 'size_inch', 'thread_size'],
        'blocked': ['power_kw', 'power_hp', 'voltage_v', 'flow_l_min', 'rpm'],
        'icon': '🔗'
    },
    # Threaded fittings - NO kW/V, YES diameter/thread/pressure/material  
    'draadfittingen': {
        'allowed': ['diameter_mm', 'thread_size', 'pressure_max_bar', 'material', 'materials',
                   'connection_type', 'size_inch', 'length_m'],
        'blocked': ['power_kw', 'power_hp', 'voltage_v', 'flow_l_min', 'rpm'],
        'icon': '🔩'
    },
    # Hose clamps - NO kW/V, YES diameter range
    'slangklemmen': {
        'allowed': ['diameter_mm', 'diameter_min_mm', 'diameter_max_mm', 'width_mm',
                   'material', 'materials', 'band_width'],
        'blocked': ['power_kw', 'power_hp', 'voltage_v', 'flow_l_min', 'rpm', 'pressure_max_bar'],
        'icon': '🗜️'
    },
    # Flat hoses - NO kW/V, YES length/diameter/pressure/material
    'plat-oprolbare-slangen': {
        'allowed': ['length_m', 'diameter_mm', 'inner_diameter_mm', 'pressure_max_bar',
                   'material', 'materials', 'weight_kg'],
        'blocked': ['power_kw', 'power_hp', 'voltage_v', 'rpm'],
        'icon': '💧'
    },
    # Extraction hoses - NO kW/V, YES diameter/length/material
    'afzuigslangen': {
        'allowed': ['diameter_mm', 'inner_diameter_mm', 'outer_diameter_mm', 'length_m',
                   'material', 'materials', 'temperature_max', 'weight_kg'],
        'blocked': ['power_kw', 'power_hp', 'voltage_v', 'flow_l_min', 'rpm'],
        'icon': '🌪️'
    },
    # Pump specials - YES kW/V/flow, and other pump properties
    'pomp-specials': {
        'allowed': ['power_kw', 'power_hp', 'voltage_v', 'flow_l_min', 'flow_max_l_min',
                   'pressure_max_bar', 'head_max_m', 'rpm', 'weight_kg', 'diameter_mm',
                   'connection_size', 'material', 'phase'],
        'blocked': [],
        'icon': '⚙️'
    },
}

# Enhanced header mappings with more variations
HEADER_MAPPINGS = {
    # Diameter variations
    'diameter': 'diameter_mm',
    'dia': 'diameter_mm', 
    'ø': 'diameter_mm',
    'binnen ø': 'inner_diameter_mm',
    'binnen dia': 'inner_diameter_mm',
    'binnendiameter': 'inner_diameter_mm',
    'buiten ø': 'outer_diameter_mm',
    'buiten dia': 'outer_diameter_mm',
    'buitendiameter': 'outer_diameter_mm',
    'inner diameter': 'inner_diameter_mm',
    'outer diameter': 'outer_diameter_mm',
    
    # Length variations
    'lengte': 'length_m',
    'length': 'length_m',
    'lng': 'length_m',
    'l': 'length_m',
    
    # Material
    'materiaal': 'material',
    'material': 'material',
    'mat': 'material',
    'stof': 'material',
    
    # Thread/Connection
    'draad': 'thread_size',
    'thread': 'thread_size',
    'schroefdraad': 'thread_size',
    'aansluiting': 'connection_type',
    'connection': 'connection_type',
    
    # Pressure
    'druk': 'pressure_max_bar',
    'max druk': 'pressure_max_bar',
    'werkdruk': 'pressure_max_bar',
    'pressure': 'pressure_max_bar',
    'bar': 'pressure_max_bar',
    
    # Flow
    'debiet': 'flow_l_min',
    'flow': 'flow_l_min',
    'capaciteit': 'flow_l_min',
    'l/min': 'flow_l_min',
    
    # Power
    'vermogen': 'power_kw',
    'power': 'power_kw',
    'kw': 'power_kw',
    'pk': 'power_hp',
    'hp': 'power_hp',
    
    # Voltage
    'spanning': 'voltage_v',
    'voltage': 'voltage_v',
    'volt': 'voltage_v',
    'v': 'voltage_v',
    
    # Weight
    'gewicht': 'weight_kg',
    'weight': 'weight_kg',
    'kg': 'weight_kg',
    
    # Clamp specific
    'bandbreedte': 'band_width',
    'band width': 'band_width',
    'breedte': 'width_mm',
    'width': 'width_mm',
    'bereik': 'diameter_range',
    'range': 'diameter_range',
}

SKU_PATTERNS = [
    re.compile(r'\b([A-Z]{2,}[\d]{2,}[-\w]*)\b'),
    re.compile(r'\b([\d]{4,}[-\w]*)\b'),
    re.compile(r'\b([A-Z][\d]{2,}[-\w]*)\b'),
]

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def detect_catalog_category(pdf_filename: str) -> str:
    """Detect category from PDF filename"""
    filename_lower = pdf_filename.lower()
    
    for category in CATEGORY_RULES.keys():
        if category in filename_lower:
            return category
    
    # Default category rules (general products)
    return 'general'

def is_property_allowed(category: str, property_name: str) -> bool:
    """Check if property is allowed for this category"""
    if category not in CATEGORY_RULES:
        return True  # Allow all for unknown categories
    
    rules = CATEGORY_RULES[category]
    
    # Check if explicitly blocked
    if property_name in rules['blocked']:
        return False
    
    # Check if in allowed list (if list exists)
    if rules['allowed'] and property_name not in rules['allowed']:
        return False
    
    return True

def extract_numeric_value(text: str) -> float:
    """Extract numeric value from text"""
    if not text:
        return None
    cleaned = re.sub(r'[^\d.,\-+]', ' ', str(text))
    numbers = re.findall(r'\d+[.,]?\d*', cleaned)
    if not numbers:
        return None
    try:
        return float(numbers[0].replace(',', '.'))
    except:
        return None

def extract_diameter_range(text: str) -> dict:
    """Extract diameter range (e.g., '13-16 mm')"""
    match = re.search(r'(\d+(?:[.,]\d+)?)\s*[-–]\s*(\d+(?:[.,]\d+)?)', str(text))
    if match:
        return {
            'diameter_min_mm': float(match.group(1).replace(',', '.')),
            'diameter_max_mm': float(match.group(2).replace(',', '.'))
        }
    return {}

def extract_material_from_text(text: str) -> str:
    """Extract material from text"""
    materials = {
        'RVS': 'Stainless Steel',
        'INOX': 'Stainless Steel', 
        'SS': 'Stainless Steel',
        'BRASS': 'Brass',
        'MESSING': 'Brass',
        'PVC': 'PVC',
        'PP': 'Polypropylene',
        'PE': 'Polyethylene',
        'RUBBER': 'Rubber',
        'NBR': 'Nitrile Rubber',
        'EPDM': 'EPDM',
        'STEEL': 'Steel',
        'STAAL': 'Steel',
        'ALUMINUM': 'Aluminum',
        'ALUMINIUM': 'Aluminum',
    }
    
    text_upper = str(text).upper()
    for key, value in materials.items():
        if key in text_upper:
            return value
    return None

def map_header_to_property(header: str) -> str:
    """Map table header to property name"""
    if not header:
        return None
    header_clean = str(header).lower().strip()
    return HEADER_MAPPINGS.get(header_clean)

# ============================================================================
# TABLE PARSING
# ============================================================================

def parse_table_with_category_rules(table: list, page_num: int, category: str) -> list:
    """Parse table with category-specific rules"""
    if not table or len(table) < 2:
        return []
    
    headers = table[0]
    data_rows = table[1:]
    
    # Map headers to properties
    header_map = {}
    for idx, header in enumerate(headers):
        if not header:
            continue
        prop_name = map_header_to_property(header)
        if prop_name and is_property_allowed(category, prop_name):
            header_map[idx] = prop_name
            if VERBOSE:
                print(f"        Column {idx} '{header}' -> {prop_name}")
    
    products = []
    sku_column_idx = None
    
    # Find SKU column
    for idx, prop in header_map.items():
        if prop == 'sku':
            sku_column_idx = idx
            break
    
    for row_idx, row in enumerate(data_rows):
        if not row or all(not cell for cell in row):
            continue
        
        # Find SKU
        sku = None
        if sku_column_idx is not None and sku_column_idx < len(row):
            sku = row[sku_column_idx]
        
        if not sku:
            for cell in row:
                for pattern in SKU_PATTERNS:
                    matches = pattern.findall(str(cell))
                    if matches:
                        sku = matches[0]
                        break
                if sku:
                    break
        
        if not sku:
            continue
        
        product = {
            'sku': sku.strip(),
            'page_in_pdf': page_num,
            'table_row': row_idx + 2,
            'category': category
        }
        
        # Extract properties
        for col_idx, cell_value in enumerate(row):
            if col_idx not in header_map or not cell_value:
                continue
            
            prop_name = header_map[col_idx]
            cell_str = str(cell_value).strip()
            
            # Extract material
            if 'material' in prop_name:
                material = extract_material_from_text(cell_str)
                if material:
                    product[prop_name] = material
            # Extract diameter range
            elif 'diameter_range' in prop_name or 'bereik' in prop_name.lower():
                diameter_range = extract_diameter_range(cell_str)
                product.update(diameter_range)
            # Extract numeric values
            elif any(x in prop_name for x in ['mm', 'bar', 'kw', 'hp', 'voltage', 'weight', 'flow', 'rpm', 'length']):
                numeric_value = extract_numeric_value(cell_str)
                if numeric_value is not None:
                    product[prop_name] = numeric_value
            else:
                product[prop_name] = cell_str
        
        products.append(product)
    
    return products

# ============================================================================
# PDF PROCESSING
# ============================================================================

def process_pdf_category_aware(pdf_path: Path) -> list:
    """Process PDF with category awareness"""
    category = detect_catalog_category(pdf_path.name)
    
    print(f"\n📄 Processing: {pdf_path.name}")
    print(f"   Category: {category} {CATEGORY_RULES.get(category, {}).get('icon', '')}")
    
    try:
        doc = fitz.open(pdf_path)
        all_products = []
        
        for page_num in range(len(doc)):
            page = doc[page_num]
            
            if VERBOSE and (page_num + 1) % 10 == 0:
                print(f"   Processing page {page_num + 1}...")
            
            # Extract tables
            try:
                tables = page.find_tables()
                for table_idx, table in enumerate(tables):
                    extracted = table.extract()
                    products = parse_table_with_category_rules(extracted, page_num + 1, category)
                    all_products.extend(products)
                    if VERBOSE and products:
                        print(f"      ✓ Table {table_idx + 1}: Found {len(products)} products")
            except:
                pass
        
        doc.close()
        return all_products
        
    except Exception as e:
        print(f"   ⚠️ Error processing {pdf_path.name}: {e}")
        return []

# ============================================================================
# MAIN
# ============================================================================

def main():
    print("=" * 80)
    print("CATEGORY-AWARE PDF EXTRACTION")
    print("=" * 80)
    
    # Target PDFs for re-extraction
    target_pdfs = [
        'slangkoppelingen.pdf',
        'messing-draadfittingen.pdf',
        'rvs-draadfittingen.pdf',
        'zwarte-draad-en-lasfittingen (1).pdf',
        'slangklemmen.pdf',
        'plat-oprolbare-slangen.pdf',
        'pu-afzuigslangen.pdf',
        'pomp-specials.pdf',
    ]
    
    all_products = []
    
    for pdf_name in target_pdfs:
        pdf_path = INPUT_PDFS / pdf_name
        if not pdf_path.exists():
            print(f"\n❌ {pdf_name} not found")
            continue
        
        products = process_pdf_category_aware(pdf_path)
        all_products.extend(products)
        print(f"   ✓ Extracted {len(products)} products")
    
    # Save output
    OUTPUT_DIR.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_file = OUTPUT_DIR / f'products_category_aware_{timestamp}.json'
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_products, f, ensure_ascii=False, indent=2)
    
    print(f"\n{'='*80}")
    print(f"✅ EXTRACTION COMPLETE")
    print(f"{'='*80}")
    print(f"Total products extracted: {len(all_products)}")
    print(f"Output saved to: {output_file}")
    
    # Statistics
    by_category = {}
    for p in all_products:
        cat = p.get('category', 'unknown')
        if cat not in by_category:
            by_category[cat] = []
        by_category[cat].append(p)
    
    print(f"\n📊 BY CATEGORY:")
    for cat, prods in sorted(by_category.items(), key=lambda x: len(x[1]), reverse=True):
        icon = CATEGORY_RULES.get(cat, {}).get('icon', '📦')
        print(f"   {icon} {cat:30} {len(prods):5} products")

if __name__ == '__main__':
    main()
