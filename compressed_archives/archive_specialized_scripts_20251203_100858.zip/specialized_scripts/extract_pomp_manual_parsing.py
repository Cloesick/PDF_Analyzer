"""
Manual parsing of pomp-specials using text blocks instead of table detection
"""
import fitz
import json
import re
from pathlib import Path

def extract_number(text):
    """Extract first number from text"""
    if not text:
        return None
    match = re.search(r'(\d+(?:[.,]\d+)?)', str(text).replace(',', '.'))
    return float(match.group(1)) if match else None

def extract_rpm(text):
    """Extract RPM from text"""
    if not text:
        return None
    match = re.search(r'(\d+)', str(text))
    return int(match.group(1)) if match else None

pdf_path = Path(__file__).parent / 'input_pdfs' / 'pomp-specials.pdf'
output_path = Path(__file__).parent / 'output' / 'pomp_specials_manual.json'

doc = fitz.open(pdf_path)
products = []

# Manually define the correct table structure for pages 4-5
# Based on visual inspection of the PDF

# Page 4: Table starts at row with specific SKUs, we know the layout
page_4_data = [
    # SKU, Type, Power_pK, RPM, Flow_m3h, Height_m
    ('17130231', 'T1-40', 25, 510, 30, 105),
    ('17130290', 'T1-40', 25, 550, 35, 87),
    ('17130230', 'T2-40', 40, 460, 66, 59),
    ('17130292', 'T2-40', 40, 500, 72, 54),
    ('17130293', 'T2-40', 40, 545, 78, 50),
    ('17130231', 'T2-40', 40, 739, 106, 36),
    ('17130295', 'T2-40', 40, 900, 130, 30),
]

print("=" * 100)
print("MANUAL EXTRACTION - USING VERIFIED VALUES FROM PDF")
print("=" * 100)

print("\nPage 4 - Creating products from verified data:")
for sku, pump_type, power_pk, rpm, flow, height in page_4_data:
    product = {
        'sku': sku,
        'catalog': 'pomp-specials',
        'page': 4,
        'pump_type': pump_type,
        'power_hp': float(power_pk),
        'power_kw': round(power_pk * 0.746, 2),
        'rpm': rpm,
        'flow_m3_per_h': float(flow),
        'flow_l_min': round(flow * 16.667, 1),
        'pressure_height_m': float(height),
        'pressure_max_bar': round(height / 10, 1)
    }
    products.append(product)
    print(f"  {sku}: Flow={flow}, Height={height}")

# For the rest, use automated extraction
print("\nPages 5+: Using automated extraction...")

for page_num in range(4, len(doc)):  # Start from page 5
    page = doc[page_num]
    tables = list(page.find_tables())
    
    if not tables:
        continue
    
    for table in tables:
        rows = [list(row) for row in table.extract()]
        
        if not rows or len(rows) < 2:
            continue
        
        header = rows[0]
        
        # Check if it's a product table
        if 'Bestelnr' not in str(header[0]):
            continue
        
        # Find column indices
        col_idx = {}
        for idx, h in enumerate(header):
            h_clean = str(h).lower()
            if 'bestelnr' in h_clean:
                col_idx['sku'] = idx
            elif 'type' in h_clean and 'type' not in col_idx:
                col_idx['type'] = idx
            elif 'vermogen' in h_clean:
                col_idx['power'] = idx
                col_idx['power_unit'] = 'kW' if 'kw' in h_clean else 'pK'
            elif 'toeren' in h_clean:
                col_idx['rpm'] = idx
            elif 'debiet' in h_clean:
                col_idx['flow'] = idx
            elif 'opv' in h_clean or 'hoogte' in h_clean:
                if 'sproeihoogte' not in h_clean:  # Not spray height
                    col_idx['height'] = idx
            elif 'gewicht' in h_clean:
                col_idx['weight'] = idx
        
        # Extract products
        for row in rows[1:]:
            if not row or len(row) < 2:
                continue
            
            sku = str(row[col_idx.get('sku', 0)]).strip()
            if not sku or not re.match(r'\d+', sku):
                continue
            
            # Skip if we already have this SKU from manual data
            if any(p['sku'] == sku for p in products):
                continue
            
            product = {
                'sku': sku,
                'catalog': 'pomp-specials',
                'page': page_num + 1
            }
            
            if 'type' in col_idx and col_idx['type'] < len(row):
                type_val = str(row[col_idx['type']]).strip()
                if type_val and type_val not in ['', 'nan', 'None']:
                    product['pump_type'] = type_val
            
            if 'power' in col_idx and col_idx['power'] < len(row):
                power_val = extract_number(row[col_idx['power']])
                if power_val:
                    if col_idx.get('power_unit') == 'pK':
                        product['power_hp'] = power_val
                        product['power_kw'] = round(power_val * 0.746, 2)
                    else:
                        product['power_kw'] = power_val
                        product['power_hp'] = round(power_val / 0.746, 2)
            
            if 'rpm' in col_idx and col_idx['rpm'] < len(row):
                rpm_val = extract_rpm(row[col_idx['rpm']])
                if rpm_val:
                    product['rpm'] = rpm_val
            
            if 'flow' in col_idx and col_idx['flow'] < len(row):
                flow_val = extract_number(row[col_idx['flow']])
                if flow_val:
                    product['flow_m3_per_h'] = flow_val
                    product['flow_l_min'] = round(flow_val * 16.667, 1)
            
            if 'height' in col_idx and col_idx['height'] < len(row):
                height_val = extract_number(row[col_idx['height']])
                if height_val:
                    product['pressure_height_m'] = height_val
                    product['pressure_max_bar'] = round(height_val / 10, 1)
            
            if 'weight' in col_idx and col_idx['weight'] < len(row):
                weight_val = extract_number(row[col_idx['weight']])
                if weight_val:
                    product['weight_kg'] = weight_val
            
            products.append(product)

doc.close()

# Save
with open(output_path, 'w', encoding='utf-8') as f:
    json.dump(products, f, ensure_ascii=False, indent=2)

print(f"\n{'='*100}")
print(f"✅ EXTRACTED {len(products)} PRODUCTS")
print(f"💾 Saved to: {output_path}")
print(f"{'='*100}")
