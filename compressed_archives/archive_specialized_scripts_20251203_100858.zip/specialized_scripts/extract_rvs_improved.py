"""
RVS DRAADFITTINGEN IMPROVED EXTRACTOR
======================================
Extract images and properties from rvs-draadfittingen.pdf

Based on successful Makita extraction strategy
"""

import pdfplumber
import fitz  # PyMuPDF
import re
import json
from pathlib import Path
from PIL import Image
from collections import defaultdict
import cv2
import numpy as np
from io import BytesIO

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "rvs-draadfittingen.pdf"
OUTPUT_IMAGES = PROJECT_ROOT / "product-images-rvs-improved"
OUTPUT_JSON = PROJECT_ROOT / "output" / "rvs_extracted_products.json"

IMAGE_DPI = 300
MIN_IMAGE_AREA = 10000  # Smaller for fittings
WEBP_QUALITY = 90

# RVS fitting SKU patterns (typically codes like NR 312, X 21, DN15, etc.)
RVS_SKU_PATTERNS = [
    r'\bNR\s*\d+[A-Z]*\b',           # NR 312, NR 312A
    r'\bX\s*\d+[A-Z]*\b',             # X 21, X 114
    r'\bDN\s*\d+\b',                  # DN15, DN20
    r'\b\d{2,3}[A-Z]{1,2}\b',         # 312A, 21X
    r'\bG\s*\d+/\d+\b',               # G 1/2, G 3/4 (thread sizes)
    r'\b\d+/\d+"\b',                  # 1/2", 3/4" (inch sizes)
    r'\bM\d+x\d+\.?\d*\b',            # M10x1.5 (metric threads)
]

# ============================================================================
# SKU DETECTION
# ============================================================================

def extract_skus_from_text(text):
    """Extract all potential RVS fitting SKUs from text"""
    skus = set()
    for pattern in RVS_SKU_PATTERNS:
        matches = re.findall(pattern, text, re.IGNORECASE)
        skus.update(matches)
    return skus

def find_nearby_text(page, bbox, radius=50):
    """Find text near an image bbox"""
    x0, y0, x1, y1 = bbox
    
    search_bbox = (
        max(0, x0 - radius),
        max(0, y0 - radius),
        x1 + radius,
        y1 + radius
    )
    
    nearby_words = []
    for word in page.extract_words():
        wx0, wy0, wx1, wy1 = word['x0'], word['top'], word['x1'], word['bottom']
        
        if (wx0 >= search_bbox[0] and wx1 <= search_bbox[2] and
            wy0 >= search_bbox[1] and wy1 <= search_bbox[3]):
            nearby_words.append(word['text'])
    
    return ' '.join(nearby_words)

# ============================================================================
# IMAGE PROCESSING
# ============================================================================

def is_product_image(pil_image):
    """Determine if image is likely a product photo"""
    img_array = np.array(pil_image.convert('RGB'))
    
    # Check color variance
    r, g, b = img_array[:,:,0], img_array[:,:,1], img_array[:,:,2]
    rg_diff = np.abs(r.astype(int) - g.astype(int))
    rb_diff = np.abs(r.astype(int) - b.astype(int))
    gb_diff = np.abs(g.astype(int) - b.astype(int))
    color_variance = (rg_diff.mean() + rb_diff.mean() + gb_diff.mean()) / 3
    
    width, height = pil_image.size
    aspect_ratio = max(width, height) / min(width, height)
    
    # Fittings images: accept B&W technical drawings (lower threshold)
    # Also check if image has reasonable size and not too extreme aspect ratio
    if color_variance > 0.5 and aspect_ratio < 5 and width * height > MIN_IMAGE_AREA:
        return True, color_variance
    
    return False, color_variance

def clean_and_crop_image(pil_image):
    """Remove white background and crop to product"""
    try:
        img_array = np.array(pil_image.convert('RGB'))
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
        
        # Threshold to find object
        _, mask = cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY_INV)
        
        # Find contours
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return pil_image
        
        largest_contour = max(contours, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(largest_contour)
        
        # Add padding
        padding = 15
        x = max(0, x - padding)
        y = max(0, y - padding)
        w = min(img_array.shape[1] - x, w + 2 * padding)
        h = min(img_array.shape[0] - y, h + 2 * padding)
        
        cropped = pil_image.crop((x, y, x + w, y + h))
        return cropped
    except:
        return pil_image

# ============================================================================
# MAIN EXTRACTION
# ============================================================================

def extract_rvs_catalog():
    """Extract products and images from RVS draadfittingen catalog"""
    
    print("=" * 80)
    print("RVS DRAADFITTINGEN EXTRACTOR - IMPROVED")
    print("=" * 80)
    
    if not PDF_PATH.exists():
        print(f"❌ PDF not found: {PDF_PATH}")
        return
    
    print(f"\n📄 Processing: {PDF_PATH.name}")
    
    OUTPUT_IMAGES.mkdir(parents=True, exist_ok=True)
    
    pdf_plumber = pdfplumber.open(PDF_PATH)
    pdf_pymupdf = fitz.open(PDF_PATH)
    
    extracted_products = []
    stats = {
        'pages_processed': 0,
        'images_found': 0,
        'images_extracted': 0,
        'skus_found': set(),
        'products_created': 0
    }
    
    print(f"\n📊 Total pages: {len(pdf_plumber.pages)}")
    
    # Process each page
    for page_num in range(1, len(pdf_plumber.pages) + 1):
        print(f"\n📄 Page {page_num}...")
        stats['pages_processed'] += 1
        
        page_plumber = pdf_plumber.pages[page_num - 1]
        page_pymupdf = pdf_pymupdf[page_num - 1]
        
        # Extract page text
        page_text = page_plumber.extract_text() or ""
        page_skus = extract_skus_from_text(page_text)
        print(f"   Found {len(page_skus)} potential SKUs on page")
        
        # Get images
        image_list = page_pymupdf.get_images(full=True)
        print(f"   Found {len(image_list)} images")
        stats['images_found'] += len(image_list)
        
        # Process each image
        for img_idx, img_info in enumerate(image_list):
            try:
                xref = img_info[0]
                
                base_image = pdf_pymupdf.extract_image(xref)
                image_bytes = base_image["image"]
                
                pil_image = Image.open(BytesIO(image_bytes))
                if pil_image.mode != 'RGB':
                    pil_image = pil_image.convert('RGB')
                
                # Check if product image
                is_product, color_var = is_product_image(pil_image)
                if not is_product:
                    print(f"   ⊘ Image {img_idx}: Skipped (color_var={color_var:.1f})")
                    continue
                
                # Get nearby text
                img_rects = page_pymupdf.get_image_rects(xref)
                if img_rects:
                    rect = img_rects[0]
                    bbox = (rect.x0, rect.y0, rect.x1, rect.y1)
                    nearby_text = find_nearby_text(page_plumber, bbox, radius=100)
                    nearby_skus = extract_skus_from_text(nearby_text)
                else:
                    nearby_skus = set()
                
                # Combine SKUs
                all_skus = nearby_skus | page_skus
                
                if not all_skus:
                    print(f"   ⊘ Image {img_idx}: No SKUs found")
                    continue
                
                # Clean image
                cleaned_image = clean_and_crop_image(pil_image)
                
                # Generate filename
                primary_sku = sorted(all_skus)[0]
                safe_sku = primary_sku.replace(' ', '_').replace('/', '-')
                filename = f"{safe_sku}_p{page_num:03d}_img{img_idx:02d}.webp"
                filepath = OUTPUT_IMAGES / filename
                
                # Save
                cleaned_image.save(filepath, format='WEBP', quality=WEBP_QUALITY)
                stats['images_extracted'] += 1
                
                print(f"   ✓ Image {img_idx}: {primary_sku} ({len(all_skus)} SKUs) -> {filename}")
                
                # Create product entries
                for sku in all_skus:
                    extracted_products.append({
                        'sku': sku,
                        'pdf_source': PDF_PATH.name,
                        'page_num': page_num,
                        'image_index': img_idx,
                        'image_filename': filename,
                        'image_path': str(filepath),
                        'skus_in_image': sorted(all_skus),
                        'color_variance': float(color_var),
                        'from_nearby': sku in nearby_skus,
                        'from_page': sku in page_skus
                    })
                    stats['skus_found'].add(sku)
                    stats['products_created'] += 1
                
            except Exception as e:
                print(f"   ⚠️ Error processing image {img_idx}: {e}")
                continue
        
        # Progress
        if page_num % 5 == 0:
            print(f"\n   📊 Progress: {page_num} pages, {stats['images_extracted']} images extracted")
    
    pdf_plumber.close()
    pdf_pymupdf.close()
    
    # Save results
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(extracted_products, f, indent=2, ensure_ascii=False)
    
    # Print summary
    print("\n" + "=" * 80)
    print("EXTRACTION COMPLETE")
    print("=" * 80)
    
    print(f"\n📊 Statistics:")
    print(f"   Pages processed:      {stats['pages_processed']}")
    print(f"   Images found:         {stats['images_found']}")
    print(f"   Images extracted:     {stats['images_extracted']}")
    print(f"   Unique SKUs found:    {len(stats['skus_found'])}")
    print(f"   Product entries:      {stats['products_created']}")
    
    print(f"\n💾 Output:")
    print(f"   Images: {OUTPUT_IMAGES}")
    print(f"   JSON:   {OUTPUT_JSON}")
    
    return extracted_products

if __name__ == '__main__':
    extract_rvs_catalog()
