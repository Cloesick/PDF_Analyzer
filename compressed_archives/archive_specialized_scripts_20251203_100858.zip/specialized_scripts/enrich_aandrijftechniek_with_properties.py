#!/usr/bin/env python3
"""
Enrich aandrijftechniek grouped data with properties from comprehensive data.

The grouped data has SKUs and page numbers but empty properties/attributes.
The comprehensive data has rich properties. We need to merge them.
"""

import json
from pathlib import Path

def enrich_grouped_data():
    """Merge properties from comprehensive data into grouped data"""
    
    print(f"\n{'='*80}")
    print(f"ENRICHING GROUPED DATA WITH PROPERTIES")
    print(f"{'='*80}\n")
    
    # Load grouped data (has structure but no properties)
    grouped_file = Path('../DemaWebshop/dema-webshop/public/data/aandrijftechniek_grouped.json')
    with open(grouped_file, 'r', encoding='utf-8') as f:
        grouped_data = json.load(f)
    
    print(f"📊 Loaded grouped data: {len(grouped_data)} groups")
    
    # Load raw products data (has rich properties!)
    raw_file = Path('output/aandrijftechniek_products_raw.json')
    with open(raw_file, 'r', encoding='utf-8') as f:
        raw_products = json.load(f)
    
    # Create SKU lookup
    sku_data = {}
    for product in raw_products:
        sku = product.get('sku')
        if sku:
            sku_data[sku] = product
    
    print(f"📊 Loaded raw product data: {len(sku_data)} SKUs with properties")
    
    # Enrich grouped data with properties
    enriched_count = 0
    missing_count = 0
    
    for group in grouped_data:
        for variant in group.get('variants', []):
            sku = variant.get('sku')
            if sku and sku in sku_data:
                raw_product = sku_data[sku]
                
                # Copy properties
                properties = raw_product.get('properties', {})
                raw_data = raw_product.get('raw_data', {})
                
                # Merge both properties and raw_data
                all_properties = {**properties, **raw_data}
                
                variant['properties'] = all_properties
                variant['attributes'] = all_properties  # PropertyBadges uses attributes
                
                # Also copy useful fields
                if 'brand' in raw_product:
                    variant['brand'] = raw_product['brand']
                if 'category' in raw_product:
                    variant['category'] = raw_product['category']
                
                enriched_count += 1
            else:
                missing_count += 1
    
    print(f"\n{'='*80}")
    print(f"ENRICHMENT SUMMARY")
    print(f"{'='*80}\n")
    print(f"✅ Variants enriched: {enriched_count}")
    print(f"⚠️  Variants missing data: {missing_count}")
    
    # Save enriched data
    output_file = Path('../DemaWebshop/dema-webshop/public/data/aandrijftechniek_grouped.json')
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(grouped_data, f, indent=2, ensure_ascii=False)
    
    print(f"\n✅ Saved enriched data: {output_file.name}")
    
    # Show sample enriched variant
    print(f"\n{'='*80}")
    print(f"SAMPLE ENRICHED VARIANT")
    print(f"{'='*80}\n")
    
    sample_variant = grouped_data[0]['variants'][0]
    print(f"SKU: {sample_variant['sku']}")
    print(f"Properties: {list(sample_variant.get('properties', {}).keys())[:10]}")
    print(f"Attributes: {list(sample_variant.get('attributes', {}).keys())[:10]}")
    
    if sample_variant.get('properties'):
        print(f"\nSample property values:")
        for key, value in list(sample_variant['properties'].items())[:5]:
            print(f"  {key}: {value}")
    
    print(f"\n{'='*80}\n")
    
    return {
        'enriched': enriched_count,
        'missing': missing_count,
        'total': enriched_count + missing_count
    }

if __name__ == '__main__':
    result = enrich_grouped_data()
    
    print(f"✨ Enrichment complete!")
    print(f"   • {result['enriched']} variants enriched with properties")
    print(f"   • {result['missing']} variants missing in comprehensive data")
    print(f"   • {result['total']} total variants processed\n")
