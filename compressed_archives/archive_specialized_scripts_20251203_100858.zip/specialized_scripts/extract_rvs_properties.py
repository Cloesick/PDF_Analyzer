"""
Extract RVS Properties from Tables
===================================
Focus on table extraction since images are B&W technical drawings
"""

import pdfplumber
import re
import json
from pathlib import Path
from collections import defaultdict

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "rvs-draadfittingen.pdf"
OUTPUT_JSON = PROJECT_ROOT / "output" / "rvs_properties_extracted.json"

# Property mappings (Dutch → English)
PROPERTY_MAP = {
    'maat': 'size',
    'buismaat': 'pipe_size',
    'wanddikte': 'wall_thickness',
    'flens pn': 'flange_rating',
    'steekcircel': 'bolt_circle',
    'gatmaat': 'hole_size',
    'maat dn': 'dn_size',
    'maat inch': 'inch_size',
}

# RVS SKU patterns (alphanumeric codes)
RVS_SKU_PATTERNS = [
    r'\b9[A-Z]{3}\d{6}\b',      # 9LAR048021, 9ZFGF12
    r'\bFLALU\d{3}\b',           # FLALU010
    r'\b[A-Z]{2}\s*\d+\b',       # NR 312
    r'\b\d{2,3}[A-Z]+\b',        # 312A
]

# ============================================================================
# SKU DETECTION
# ============================================================================

def extract_skus_from_text(text):
    """Extract RVS fitting SKUs"""
    skus = set()
    for pattern in RVS_SKU_PATTERNS:
        matches = re.findall(pattern, text, re.IGNORECASE)
        skus.update(matches)
    return skus

def normalize_property_name(name):
    """Convert Dutch property name to English key"""
    if not name:
        return None
    
    name_lower = str(name).lower().strip()
    
    # Direct mapping
    if name_lower in PROPERTY_MAP:
        return PROPERTY_MAP[name_lower]
    
    # Partial matching
    for dutch, english in PROPERTY_MAP.items():
        if dutch in name_lower:
            return english
    
    # Fallback
    return name_lower.replace(' ', '_').replace('.', '')

def clean_value(value):
    """Clean extracted value"""
    if value is None or value == '':
        return None
    
    value = str(value).strip()
    
    if value.lower() == 'none' or value == '':
        return None
    
    return value

# ============================================================================
# TABLE PARSING
# ============================================================================

def parse_rvs_table(table, page_text=''):
    """Parse RVS table and extract products"""
    if not table or len(table) < 2:
        return []
    
    products = []
    
    # Find SKUs in table
    table_skus = []
    for row in table:
        row_text = ' '.join([str(cell) for cell in row if cell])
        skus_found = extract_skus_from_text(row_text)
        table_skus.extend(skus_found)
    
    # If no SKUs in table, try page text
    if not table_skus:
        table_skus = list(extract_skus_from_text(page_text))[:20]
    
    # Get header row (first non-empty row)
    header_row = None
    header_idx = 0
    for i, row in enumerate(table):
        if row and any(cell for cell in row):
            header_row = row
            header_idx = i
            break
    
    if not header_row:
        return []
    
    # Identify columns
    prop_col = 0  # First column usually has property names or SKU
    value_cols = list(range(1, len(header_row)))  # Rest are values
    
    # Process each row after header
    current_sku_idx = 0
    for row in table[header_idx + 1:]:
        if not row or not any(cell for cell in row):
            continue
        
        # Check if first cell is a SKU
        first_cell = clean_value(row[0])
        if first_cell:
            found_skus = extract_skus_from_text(first_cell)
            if found_skus:
                # This row has a SKU in first column
                sku = list(found_skus)[0]
                
                # Extract properties from this row
                properties = {}
                raw_specs = []
                
                for i, cell in enumerate(row[1:], 1):
                    value = clean_value(cell)
                    if value and i < len(header_row):
                        header_cell = clean_value(header_row[i])
                        if header_cell:
                            prop_name = normalize_property_name(header_cell)
                            if prop_name:
                                properties[prop_name] = value
                                raw_specs.append(f"{header_cell}: {value}")
                
                if properties:
                    products.append({
                        'sku': sku,
                        'properties': properties,
                        'raw_specs': raw_specs
                    })
    
    return products

# ============================================================================
# MAIN EXTRACTION
# ============================================================================

def extract_rvs_properties():
    """Extract all properties from RVS catalog"""
    
    print("=" * 80)
    print("RVS PROPERTY EXTRACTION")
    print("=" * 80)
    
    pdf = pdfplumber.open(PDF_PATH)
    print(f"\n📄 Processing: {PDF_PATH.name}")
    print(f"   Total pages: {len(pdf.pages)}")
    
    all_products = defaultdict(lambda: {'properties': {}, 'raw_specs': [], 'pages': []})
    stats = {
        'pages_processed': 0,
        'tables_found': 0,
        'tables_parsed': 0,
        'products_found': set(),
        'properties_extracted': 0
    }
    
    # Process each page
    for page_num in range(1, len(pdf.pages) + 1):
        page = pdf.pages[page_num - 1]
        
        page_text = page.extract_text() or ''
        tables = page.extract_tables()
        
        if not tables:
            stats['pages_processed'] += 1
            continue
        
        stats['tables_found'] += len(tables)
        
        # Parse each table
        for table_idx, table in enumerate(tables):
            products_in_table = parse_rvs_table(table, page_text)
            
            if not products_in_table:
                continue
            
            stats['tables_parsed'] += 1
            
            # Merge properties
            for product in products_in_table:
                sku = product['sku']
                stats['products_found'].add(sku)
                
                all_products[sku]['properties'].update(product['properties'])
                all_products[sku]['raw_specs'].extend(product['raw_specs'])
                all_products[sku]['pages'].append(page_num)
                
                stats['properties_extracted'] += len(product['properties'])
        
        stats['pages_processed'] += 1
        
        if page_num % 5 == 0:
            print(f"   Processed {page_num}/{len(pdf.pages)} pages | {len(stats['products_found'])} products | {stats['tables_parsed']} tables")
    
    pdf.close()
    
    # Convert to list
    products_list = []
    for sku, data in all_products.items():
        products_list.append({
            'sku': sku,
            'properties': data['properties'],
            'raw_specifications': list(set(data['raw_specs'])),
            'found_on_pages': sorted(set(data['pages']))
        })
    
    # Save
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(products_list, f, indent=2, ensure_ascii=False)
    
    # Summary
    print("\n" + "=" * 80)
    print("EXTRACTION COMPLETE")
    print("=" * 80)
    
    print(f"\n📊 Statistics:")
    print(f"   Pages processed:      {stats['pages_processed']}")
    print(f"   Tables found:         {stats['tables_found']}")
    print(f"   Tables parsed:        {stats['tables_parsed']}")
    print(f"   Products with props:  {len(stats['products_found'])}")
    print(f"   Total properties:     {stats['properties_extracted']}")
    
    # Sample
    print(f"\n🔍 Sample Products:")
    for product in products_list[:5]:
        print(f"\n   SKU: {product['sku']}")
        print(f"   Properties: {len(product['properties'])}")
        print(f"   Sample: {list(product['properties'].keys())[:5]}")
    
    print(f"\n💾 Saved to: {OUTPUT_JSON}")
    
    return products_list

if __name__ == '__main__':
    extract_rvs_properties()
