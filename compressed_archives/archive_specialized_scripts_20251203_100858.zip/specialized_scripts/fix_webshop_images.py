"""
Fix webshop images - ensure all product-images are synced and URLs are correct
"""

import json
from pathlib import Path

PDF_ANALYZER = Path(__file__).parent
WEBSHOP = Path(r"C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop")

SOURCE_IMAGES = PDF_ANALYZER / "product-images"
DEST_IMAGES = WEBSHOP / "public" / "product-images"  
PRODUCTS_JSON = WEBSHOP / "public" / "data" / "products_for_shop.json"

print("🔍 Checking image availability...")
print(f"Source: {SOURCE_IMAGES}")
print(f"Dest: {DEST_IMAGES}")

# Check if images are already synced
if not DEST_IMAGES.exists():
    print("❌ Destination images folder doesn't exist!")
elif not SOURCE_IMAGES.exists():
    print("❌ Source images folder doesn't exist!")
else:
    # Count images in both locations
    source_count = len(list(SOURCE_IMAGES.rglob("*.webp")))
    dest_count = len(list(DEST_IMAGES.rglob("*.webp")))
    
    print(f"✅ Source images: {source_count}")
    print(f"✅ Dest images: {dest_count}")
    
    if dest_count > 0:
        print("\n✅ Images are already synced to webshop!")
    
    # List some sample files
    print("\n📁 Sample files in destination:")
    samples = list(DEST_IMAGES.rglob("*.webp"))[:5]
    for img in samples:
        rel_path = img.relative_to(DEST_IMAGES)
        print(f"   /product-images/{rel_path.as_posix()}")

# Now check products JSON
print("\n📊 Checking products JSON...")
if PRODUCTS_JSON.exists():
    with PRODUCTS_JSON.open("r", encoding="utf-8") as f:
        products = json.load(f)
    
    with_media = [p for p in products if p.get("media")]
    print(f"   Total products: {len(products)}")
    print(f"   With media: {len(with_media)}")
    
    if with_media:
        sample = with_media[0]
        print(f"\n📋 Sample product with image:")
        print(f"   SKU: {sample['sku']}")
        print(f"   Image URL: {sample['media'][0]['url']}")
        
        # Check if image file exists
        img_url = sample['media'][0]['url']
        if img_url.startswith("/product-images/"):
            img_path = DEST_IMAGES.parent / img_url.lstrip("/")
            exists = img_path.exists()
            print(f"   File exists: {exists}")
            if not exists:
                print(f"   Expected at: {img_path}")
                
                # Try to find similar files
                filename = img_path.name
                similar = list(DEST_IMAGES.rglob(f"*{filename[-30:]}"))[:3]
                if similar:
                    print(f"   Similar files found:")
                    for s in similar:
                        print(f"      {s.relative_to(DEST_IMAGES.parent)}")

print("\n" + "="*60)
print("🎯 DIAGNOSIS:")
print("="*60)

# The real issue: check what format the image URLs are in
if PRODUCTS_JSON.exists():
    with PRODUCTS_JSON.open("r", encoding="utf-8") as f:
        products = json.load(f)
    
    # Check various URL formats
    formats = {}
    for p in products[:500]:
        if p.get("media"):
            url = p["media"][0]["url"]
            prefix = url.split("/")[1] if "/" in url else "unknown"
            formats[prefix] = formats.get(prefix, 0) + 1
    
    print(f"\nImage URL formats found:")
    for fmt, count in sorted(formats.items(), key=lambda x: -x[1]):
        print(f"   /{fmt}/... : {count} products")
    
    # Check if the issue is the folder structure
    print(f"\nActual folder structure in {DEST_IMAGES.name}:")
    if DEST_IMAGES.exists():
        subdirs = [d.name for d in DEST_IMAGES.iterdir() if d.is_dir()][:10]
        for d in subdirs:
            file_count = len(list((DEST_IMAGES / d).glob("*.webp")))
            print(f"   {d}/ ({file_count} files)")
    
    print(f"\n💡 SOLUTION:")
    print(f"   Images URLs in JSON: /product-images/{subdirs[0] if subdirs else 'CATALOG'}/*.webp")
    print(f"   Actual files location: public/product-images/{subdirs[0] if subdirs else 'CATALOG'}/*.webp")
    print(f"   Status: {'✅ MATCH!' if subdirs else '❌ MISMATCH'}")

