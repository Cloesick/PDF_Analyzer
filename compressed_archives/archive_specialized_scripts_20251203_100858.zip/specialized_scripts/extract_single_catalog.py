"""
Extract Single Catalog - Individual PDF Extraction

Usage:
    python extract_single_catalog.py rubber-slangen
    python extract_single_catalog.py pu-afzuigslangen
"""

import sys
import json
from pathlib import Path

# Import the extraction function from the universal script
# We'll use the same logic but for individual catalogs
import fitz
import re

PROJECT_ROOT = Path(__file__).parent
INPUT_PDFS = PROJECT_ROOT / "input_pdfs"
OUTPUT_DIR = PROJECT_ROOT / "output" / "archive" / "catalog_extractions"

# Universal header mapping (same as extract_all_catalogs_dynamic.py)
HEADER_MAPPING = {
    # SKU / Order number
    'bestelnr': {'property': 'sku', 'icon': None, 'unit': None},
    'code': {'property': 'sku', 'icon': None, 'unit': None},
    'artikelnr': {'property': 'sku', 'icon': None, 'unit': None},
    
    # Dimensions
    'maat': {'property': 'diameter_mm', 'icon': '📏', 'unit': 'mm', 'parser': 'diameter'},
    'maten': {'property': 'dimensions', 'icon': '◯⊙', 'unit': 'mm', 'parser': 'dimensions'},
    'diameter': {'property': 'diameter_mm', 'icon': '📏', 'unit': 'mm', 'parser': 'number'},
    'binnen dia': {'property': 'inner_diameter_mm', 'icon': '⊙', 'unit': 'mm', 'parser': 'number'},
    'buiten dia': {'property': 'outer_diameter_mm', 'icon': '◯', 'unit': 'mm', 'parser': 'number'},
    'lengte': {'property': 'length_m', 'icon': '📐', 'unit': 'm', 'parser': 'number'},
    'rollengte': {'property': 'length_m', 'icon': '📐', 'unit': 'm', 'parser': 'number'},
    
    # Pressure
    'werkdruk': {'property': 'pressure_work_bar', 'icon': '🔧', 'unit': 'bar', 'parser': 'number'},
    'barstdruk': {'property': 'pressure_burst_bar', 'icon': '💥', 'unit': 'bar', 'parser': 'number'},
    'max druk': {'property': 'pressure_max_bar', 'icon': '🔧', 'unit': 'bar', 'parser': 'number'},
    
    # Weight
    'gewicht': {'property': 'weight_kg', 'icon': '⚖️', 'unit': 'kg', 'parser': 'number'},
}


def normalize_header(text: str) -> str:
    """Normalize header text for matching"""
    if not text:
        return ''
    return text.lower().strip().replace('.', '').replace(':', '')


def parse_number(text: str) -> float:
    """Extract first number from text"""
    if not text:
        return None
    match = re.search(r'\d+\.?\d*', str(text))
    return float(match.group()) if match else None


def is_valid_sku(text: str) -> bool:
    """Check if text looks like a valid SKU (not a header)"""
    if not text or not isinstance(text, str):
        return False
    
    text = str(text).strip()
    
    # Skip obvious header keywords
    header_keywords = [
        'bestelnr', 'code', 'artikelnr', 'sku', 'maat', 'maten', 
        'diameter', 'werkdruk', 'lengte', 'gewicht', 'druk',
        'omschrijving', 'description', 'price', 'prijs'
    ]
    
    if text.lower() in header_keywords:
        return False
    
    # SKUs typically have numbers and/or uppercase letters
    # Must contain at least one digit or be mostly alphanumeric
    has_digit = bool(re.search(r'\d', text))
    has_alpha = bool(re.search(r'[A-Za-z]', text))
    
    # Length checks - SKUs are usually 4-20 characters
    if len(text) < 3 or len(text) > 30:
        return False
    
    # Must have at least some alphanumeric content
    alphanumeric_ratio = len(re.findall(r'[A-Za-z0-9]', text)) / len(text)
    if alphanumeric_ratio < 0.5:
        return False
    
    # Good indicators: has digits, reasonable length, mostly alphanumeric
    return has_digit or (has_alpha and len(text) >= 4)


def is_header_row(row: list) -> bool:
    """Check if row appears to be a header row"""
    if not row or not any(row):
        return True
    
    # Check if first cell looks like a header
    first_cell = str(row[0]).strip() if row[0] else ''
    
    header_indicators = [
        'bestelnr', 'code', 'artikelnr', 'sku', 'order',
        'maat', 'diameter', 'werkdruk', 'lengte'
    ]
    
    return first_cell.lower() in header_indicators


def extract_table_data(pdf_path: Path, catalog_name: str):
    """Extract product data from PDF tables with improved header detection"""
    print(f"\n📦 Extracting: {catalog_name}")
    print(f"   PDF: {pdf_path}")
    
    doc = fitz.open(pdf_path)
    products = []
    skipped_headers = 0
    valid_products = 0
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        tables = page.find_tables()
        
        if not tables:
            continue
        
        for table_idx, table in enumerate(tables):
            try:
                # Get all rows including header
                all_rows = list(table.extract())
                if not all_rows or len(all_rows) < 2:
                    continue
                
                # First row is typically header
                header_row = all_rows[0]
                headers = [normalize_header(str(cell)) if cell else '' for cell in header_row]
                
                # Must have 'bestelnr' or 'code' column
                if not any(h in headers for h in ['bestelnr', 'code', 'artikelnr']):
                    continue
                
                # Map headers to properties
                header_map = {}
                sku_column_idx = None
                
                for i, header in enumerate(headers):
                    # Find SKU column
                    if header in ['bestelnr', 'code', 'artikelnr']:
                        sku_column_idx = i
                        header_map[i] = {'property': 'sku', 'parser': 'text'}
                    else:
                        # Map other headers
                        for key, config in HEADER_MAPPING.items():
                            if key in header:
                                header_map[i] = config
                                break
                
                if sku_column_idx is None:
                    continue
                
                # Process data rows (skip first row as it's header)
                for row_idx, row in enumerate(all_rows[1:], start=1):
                    if not row or not any(row):
                        continue
                    
                    # Check if this is a header row (sometimes tables repeat headers)
                    if is_header_row(row):
                        skipped_headers += 1
                        continue
                    
                    # Get SKU from designated column
                    sku_value = str(row[sku_column_idx]).strip() if sku_column_idx < len(row) and row[sku_column_idx] else None
                    
                    # Validate SKU
                    if not sku_value or not is_valid_sku(sku_value):
                        continue
                    
                    product = {
                        'sku': sku_value,
                        'catalog': catalog_name,
                        'pdf_source': pdf_path.name,
                        'page_in_pdf': page_num + 1,
                        'source_pages': [page_num + 1]
                    }
                    
                    # Map other cells to properties
                    for cell_idx, cell_value in enumerate(row):
                        if cell_idx not in header_map or cell_idx == sku_column_idx:
                            continue
                        
                        if not cell_value:
                            continue
                        
                        config = header_map[cell_idx]
                        prop_name = config['property']
                        
                        # Parse value based on type
                        if config.get('parser') == 'number' or 'bar' in prop_name or 'kg' in prop_name or 'mm' in prop_name:
                            value = parse_number(cell_value)
                        else:
                            value = str(cell_value).strip()
                        
                        if value:
                            product[prop_name] = value
                    
                    products.append(product)
                    valid_products += 1
            
            except Exception as e:
                print(f"      ⚠️  Error in table on page {page_num + 1}: {e}")
                continue
    
    print(f"   ✅ Extracted {valid_products} valid products")
    if skipped_headers > 0:
        print(f"   ℹ️  Skipped {skipped_headers} header rows")
    
    return products


def main():
    if len(sys.argv) < 2:
        print("Usage: python extract_single_catalog.py <catalog-name>")
        print("Example: python extract_single_catalog.py rubber-slangen")
        sys.exit(1)
    
    catalog_key = sys.argv[1]
    
    # Find PDF file - try multiple naming variations
    pdf_name_variations = [
        f"{catalog_key}.pdf",
        f"{catalog_key.replace('-', ' ')}.pdf",
        f"{catalog_key.replace('-', '_')}.pdf",
        f"{catalog_key} (1).pdf",  # Handle "(1)" suffix
        f"{catalog_key.replace('-', ' ')} (1).pdf",
    ]
    
    # Special cases for known problematic filenames
    if catalog_key == "pompentoebehoren":
        pdf_name_variations.insert(0, "digitale-versie-pompentoebehoren-compressed.pdf")
    elif catalog_key == "makita-catalogus":
        pdf_name_variations.insert(0, "makita-catalogus-2022-nl.pdf")
    elif catalog_key == "makita-tuinfolder":
        pdf_name_variations.insert(0, "makita-tuinfolder-2022-nl.pdf")
    elif catalog_key == "kranzle-catalogus":
        pdf_name_variations.insert(0, "kranzle-catalogus-2021-nl-1.pdf")
    elif catalog_key == "airpress-catalogus-nl":
        pdf_name_variations.insert(0, "airpress-catalogus-nl-fr.pdf")
    elif catalog_key == "airpress-catalogus-en":
        pdf_name_variations.insert(0, "airpress-catalogus-eng.pdf")
    
    pdf_files = []
    for variation in pdf_name_variations:
        pdf_files = list(INPUT_PDFS.glob(variation))
        if pdf_files:
            break
    
    if not pdf_files:
        print(f"❌ PDF not found for '{catalog_key}' in {INPUT_PDFS}")
        print(f"   Available PDFs:")
        for pdf in sorted(INPUT_PDFS.glob("*.pdf")):
            print(f"      • {pdf.name}")
        sys.exit(1)
    
    pdf_path = pdf_files[0]
    
    # Extract data
    products = extract_table_data(pdf_path, catalog_key)
    
    if not products:
        print(f"\n⚠️  No products extracted! The PDF may not have structured tables.")
        sys.exit(1)
    
    # Save results
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    output_file = OUTPUT_DIR / f"{catalog_key.replace('-', '_')}_dynamic.json"
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(products, f, ensure_ascii=False, indent=2)
    
    print(f"\n💾 Saved to: {output_file}")
    print(f"\n✅ Extraction complete!")


if __name__ == '__main__':
    main()
