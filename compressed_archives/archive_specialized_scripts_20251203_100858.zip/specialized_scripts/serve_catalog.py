"""
Simple HTTP server to view the product catalog
"""
import http.server
import socketserver
import os
from pathlib import Path

PORT = 8080
DIRECTORY = Path(__file__).parent

class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(DIRECTORY), **kwargs)
    
    def end_headers(self):
        # Allow CORS
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

if __name__ == '__main__':
    os.chdir(DIRECTORY)
    
    with socketserver.TCPServer(("", PORT), MyHTTPRequestHandler) as httpd:
        print(f"\n{'='*80}")
        print(f"🌐 Product Catalog Server Started!")
        print(f"{'='*80}")
        print(f"\n📱 Open in your browser:")
        print(f"   http://localhost:{PORT}/product_catalog.html")
        print(f"\n✨ Features:")
        print(f"   • 9757 products with images")
        print(f"   • Search by SKU or catalog name")
        print(f"   • Filter by catalog")
        print(f"   • Click product cards for details")
        print(f"   • Direct links to PDF pages")
        print(f"   • Image galleries")
        print(f"\n💡 Press Ctrl+C to stop the server")
        print(f"{'='*80}\n")
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n\n🛑 Server stopped")
