#!/usr/bin/env python3
"""
Regroup products by TABLE and SHARED IMAGE
Creates proper grouped structure where SKUs from the same table share one image
and SKU selection loads properties accordingly.

Uses abs-persluchtbuizen as the reference structure.
"""

import json
import re
from pathlib import Path
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
# UPDATED: Look in output/ first for smart-extracted files, then fallback to archive
INPUT_DIR = PROJECT_ROOT / "output"
INPUT_DIR_ARCHIVE = PROJECT_ROOT / "output" / "archive" / "catalog_extractions"
OUTPUT_DIR = PROJECT_ROOT / "output"
WEBSHOP_DATA = PROJECT_ROOT.parent / "DemaWebshop" / "dema-webshop" / "public" / "data"
IMAGE_DIR = PROJECT_ROOT / "product-images-by-pdf"

# Catalogs to reprocess with table-based grouping
CATALOGS_TO_PROCESS = [
    "bronpompen",
    "catalogus-aandrijftechniek-150922",
    "centrifugaalpompen",
    "digitale-versie-pompentoebehoren-compressed",
    "dompelpompen",
    "drukbuizen",
    "kunststof-afvoerleidingen",
    "messing-draadfittingen",
    # NEW: Kränzle and Airpress catalogs
    "kranzle-catalogus-2021-nl-1",
    "airpress-catalogus-eng",
    "airpress-catalogus-nl-fr"
]

# Map catalog keys to their actual extraction file names
CATALOG_FILE_MAP = {
    "catalogus-aandrijftechniek-150922": "catalogus_aandrijftechniek_150922_dynamic.json",
    "digitale-versie-pompentoebehoren-compressed": "digitale_versie_pompentoebehoren_compressed_dynamic.json",
    "kunststof-afvoerleidingen": "kunststof_afvoerleidingen_dynamic.json",
    "messing-draadfittingen": "messing_draadfittingen_dynamic.json"
}

def load_extraction_data(catalog_key):
    """Load raw extraction data - PRIORITIZE SMART EXTRACTION"""
    # First, try to load smart-extracted data (has 3x more properties!)
    smart_patterns = [
        f"{catalog_key}_smart_extracted.json",
        f"{catalog_key.replace('-', '_')}_smart_extracted.json",
    ]
    
    for pattern in smart_patterns:
        file_path = INPUT_DIR / pattern
        if file_path.exists():
            print(f"  📖 Loading SMART EXTRACTION: {file_path.name} 🧠")
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    
    # Fallback to old dynamic files in archive if smart extraction not available
    print(f"  ⚠️  Smart extraction not found, trying archive folder...")
    
    # Check if we have a specific mapping in archive
    if catalog_key in CATALOG_FILE_MAP:
        file_path = INPUT_DIR_ARCHIVE / CATALOG_FILE_MAP[catalog_key]
        if file_path.exists():
            print(f"  📖 Loading from archive: {file_path.name}")
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    
    # Try different file patterns in archive
    patterns = [
        f"{catalog_key}_dynamic.json",
        f"{catalog_key.replace('-', '_')}_dynamic.json",
        f"{catalog_key}_tables.json",
        # Also try aandrijftechniek without catalogus prefix
        "aandrijftechniek_dynamic.json" if "aandrijftechniek" in catalog_key else None,
        "pompentoebehoren_dynamic.json" if "pompentoebehoren" in catalog_key else None
    ]
    
    for pattern in patterns:
        if pattern is None:
            continue
        file_path = INPUT_DIR_ARCHIVE / pattern
        if file_path.exists():
            print(f"  📖 Loading from archive: {file_path.name}")
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    
    print(f"  ⚠️  No extraction file found for {catalog_key}")
    return None

def is_valid_sku(sku):
    """Check if SKU is valid (not a header or invalid value)"""
    if not sku or not isinstance(sku, str):
        return False
    
    sku_lower = sku.lower().strip()
    
    # Invalid SKU patterns
    invalid_patterns = [
        'bestelnr', 'code', 'artikel', 'item', 'product',
        'description', 'omschrijving', 'type', 'model',
        'sku', 'art', 'nr', 'no', 'nummer'
    ]
    
    if sku_lower in invalid_patterns:
        return False
    
    # Too short
    if len(sku) < 2:
        return False
    
    # Just a dash or special chars
    if sku in ['-', '--', '---', '_', '__', 'n/a', 'na', 'tbd']:
        return False
    
    return True

def extract_properties(product):
    """Extract all properties from a product"""
    props = {}
    
    # Direct properties
    property_keys = [
        'diameter', 'diameter_mm', 'diameter_inch', 
        'length', 'length_m', 'length_mm',
        'width', 'width_mm', 'height', 'height_mm', 
        'weight', 'weight_kg', 'weight_g',
        'pressure', 'pressure_bar', 'pressure_max_bar', 'pressure_work_bar',
        'temperature', 'temperature_max', 'temperature_min',
        'material', 'connection', 'connection_type', 'thread', 'thread_size',
        'size', 'size_inch', 'size_mm',
        'power', 'power_kw', 'power_hp', 'voltage', 'voltage_v',
        'flow_rate', 'flow_rate_lpm', 'flow_rate_m3h',
        'head', 'head_m', 'head_max_m',
        'rpm', 'rpm_max', 'torque', 'capacity', 'capacity_l',
        'color', 'colour', 'finish', 'coating',
        'temperature_range', 'ph_range'
    ]
    
    for key in property_keys:
        if key in product and product[key] is not None:
            # Skip if empty string or "n/a"
            value = product[key]
            if isinstance(value, str) and value.lower() in ['', 'n/a', 'na', '-', 'tbd']:
                continue
            props[key] = value
    
    # From attributes
    if 'attributes' in product and isinstance(product['attributes'], dict):
        for key, value in product['attributes'].items():
            if value is not None and value != '':
                props[key] = value
    
    # From specs
    if 'specs' in product and isinstance(product['specs'], list):
        for spec in product['specs']:
            if isinstance(spec, dict) and 'label' in spec and 'value' in spec:
                if spec['value'] is not None and spec['value'] != '':
                    props[spec['label']] = spec['value']
    
    return props

def find_common_properties(products_props):
    """Find properties common to all products (same value)"""
    if not products_props:
        return {}
    
    common = {}
    first_props = products_props[0]
    
    for key, value in first_props.items():
        if all(props.get(key) == value for props in products_props):
            common[key] = value
    
    return common

def group_by_table_and_image(products, catalog_key):
    """Group products by page and table (products on same page sharing image)"""
    print(f"\n  🔗 Grouping by table and image...")
    
    # Group by page first
    by_page = defaultdict(list)
    for product in products:
        page = product.get('page_in_pdf') or (product.get('source_pages', [1])[0] if product.get('source_pages') else 1)
        by_page[page].append(product)
    
    groups = []
    group_id = 1
    
    for page, page_products in sorted(by_page.items()):
        # Further group by image on same page
        by_image = defaultdict(list)
        
        for product in page_products:
            # Try to find image
            image_key = "no_image"
            
            if 'imageUrl' in product and product['imageUrl']:
                image_key = product['imageUrl']
            elif 'media' in product and isinstance(product['media'], list):
                for media in product['media']:
                    if isinstance(media, dict) and media.get('role') == 'main':
                        image_key = media.get('url', 'no_image')
                        break
            elif 'image_paths' in product and product['image_paths']:
                image_key = product['image_paths'][0]
            
            by_image[image_key].append(product)
        
        # Create groups for each image on this page
        for image_key, image_products in by_image.items():
            if len(image_products) == 0:
                continue
            
            # Extract properties for all products
            all_props = [extract_properties(p) for p in image_products]
            
            # Find common properties
            common_props = find_common_properties(all_props)
            
            # Determine variant-specific properties
            variant_prop_keys = set()
            if all_props:
                all_keys = set()
                for props in all_props:
                    all_keys.update(props.keys())
                
                for key in all_keys:
                    values = [props.get(key) for props in all_props if key in props]
                    if len(set(str(v) for v in values)) > 1:
                        variant_prop_keys.add(key)
            
            # Create variants (filter out invalid SKUs)
            variants = []
            for product in image_products:
                sku = product.get('sku') or product.get('id') or product.get('name', 'UNKNOWN')
                
                # Skip invalid SKUs
                if not is_valid_sku(sku):
                    continue
                
                props = extract_properties(product)
                var_props = {k: v for k, v in props.items() if k in variant_prop_keys}
                
                label = product.get('name') or sku
                
                variant = {
                    "sku": sku,
                    "label": label,
                    "properties": var_props,
                    "attributes": var_props,
                    "page_in_pdf": page
                }
                variants.append(variant)
            
            # Skip if no valid variants
            if len(variants) == 0:
                continue
            
            # Determine group name
            first_product = image_products[0]
            group_name = first_product.get('name', '')
            
            # If multiple variants, try to find common prefix
            if len(variants) > 1:
                skus = [v['sku'] for v in variants]
                # Find common prefix
                prefix = ""
                if skus and all(skus):
                    min_len = min(len(str(s)) for s in skus)
                    for i in range(min_len):
                        chars = [str(s)[i] for s in skus]
                        if len(set(chars)) == 1:
                            prefix += chars[0]
                        else:
                            break
                
                if prefix and len(prefix) >= 3:
                    group_name = f"{prefix}... Series ({len(variants)} variants)"
                else:
                    group_name = f"Page {page} Products ({len(variants)} variants)"
            
            # Create group
            group = {
                "group_id": f"{catalog_key}_page{page}_group{group_id}",
                "type": "product_group",
                "catalog": catalog_key,
                "name": group_name,
                "page_in_pdf": page,
                "media": [],
                "common_properties": common_props,
                "variants": variants,
                "variant_count": len(variants),
                "default_variant_sku": variants[0]['sku'] if variants else None,
                "brand": first_product.get('brand', 'Dema'),
                "category": first_product.get('category', catalog_key),
                "description": f"{group_name} - {len(variants)} variant{'s' if len(variants) != 1 else ''}"
            }
            
            # Add image
            if image_key != "no_image":
                group["media"] = [{
                    "url": image_key.lstrip('/'),
                    "role": "main"
                }]
            
            groups.append(group)
            group_id += 1
    
    return groups

def process_catalog(catalog_key):
    """Process a single catalog"""
    print(f"\n{'='*80}")
    print(f"PROCESSING: {catalog_key.upper()}")
    print(f"{'='*80}")
    
    # Load extraction data
    products = load_extraction_data(catalog_key)
    if not products:
        return None
    
    print(f"  📦 Loaded {len(products)} products")
    
    # Group by table and image
    groups = group_by_table_and_image(products, catalog_key)
    
    if not groups:
        print(f"  ⚠️  No groups created")
        return None
    
    print(f"  ✅ Created {len(groups)} groups")
    
    # Calculate stats
    total_variants = sum(g['variant_count'] for g in groups)
    avg_variants = total_variants / len(groups) if groups else 0
    
    print(f"     Total variants: {total_variants}")
    print(f"     Avg variants per group: {avg_variants:.1f}")
    
    # Save grouped data
    output_file = OUTPUT_DIR / f"{catalog_key.replace('-', '_')}_grouped.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(groups, f, indent=2, ensure_ascii=False)
    
    print(f"  💾 Saved: {output_file.name}")
    
    # Copy to webshop
    webshop_file = WEBSHOP_DATA / f"{catalog_key.replace('-', '_')}_grouped.json"
    with open(webshop_file, 'w', encoding='utf-8') as f:
        json.dump(groups, f, indent=2, ensure_ascii=False)
    
    print(f"  📤 Copied to webshop: {webshop_file.name}")
    
    return {
        'catalog': catalog_key,
        'groups': len(groups),
        'variants': total_variants,
        'avg_variants': avg_variants
    }

def main():
    print("="*80)
    print("TABLE-BASED REGROUPING - FOLLOWING ABS-PERSLUCHTBUIZEN STRUCTURE")
    print("="*80)
    print(f"\n📋 Processing {len(CATALOGS_TO_PROCESS)} catalogs...")
    
    results = []
    for catalog_key in CATALOGS_TO_PROCESS:
        result = process_catalog(catalog_key)
        if result:
            results.append(result)
    
    print(f"\n{'='*80}")
    print("SUMMARY")
    print(f"{'='*80}\n")
    
    if results:
        print(f"{'Catalog':<45s} {'Groups':<8s} {'Variants':<10s} {'Avg/Group':<10s}")
        print("-" * 80)
        for r in results:
            print(f"{r['catalog']:<45s} {r['groups']:<8d} {r['variants']:<10d} {r['avg_variants']:<10.1f}")
        
        total_groups = sum(r['groups'] for r in results)
        total_variants = sum(r['variants'] for r in results)
        
        print("-" * 80)
        print(f"{'TOTAL':<45s} {total_groups:<8d} {total_variants:<10d} {total_variants/total_groups if total_groups else 0:<10.1f}")
    
    print(f"\n{'='*80}")
    print(f"✅ COMPLETE - Processed {len(results)}/{len(CATALOGS_TO_PROCESS)} catalogs")
    print(f"{'='*80}")
    
    print("\n📝 Next steps:")
    print("   1. Verify the grouped JSON files in output/")
    print("   2. Check webshop data files in DemaWebshop/public/data/")
    print("   3. Test on frontend pages")

if __name__ == "__main__":
    main()
