"""
Identify table columns that are captured but not being parsed into structured specs
"""
import json
from collections import defaultdict

print("="*80)
print("UNPARSED COLUMN HEADERS ANALYSIS")
print("="*80)

pdfs = [
    ('PE-Buizen', 'output/pe_buizen_analysis.json'),
    ('Plat-Oprolbare', 'output/plat_oprolbare_analysis.json'),
    ('Aandrijftechniek', 'output/aandrijftechniek_analysis.json')
]

for pdf_name, json_path in pdfs:
    print(f"\n{'='*80}")
    print(f"PDF: {pdf_name}")
    print(f"{'='*80}")
    
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # Track which raw columns are parsed vs unparsed
    raw_columns = defaultdict(int)  # table_* fields
    parsed_fields = defaultdict(int)  # non-table_* fields
    
    for page in data['pages']:
        for prod in page['products_found']:
            if '_TBL' in prod['product_id']:  # Only check table products
                specs = prod['specifications']
                
                for key, value in specs.items():
                    if key.startswith('table_'):
                        raw_columns[key] += 1
                    else:
                        parsed_fields[key] += 1
    
    print(f"\n📊 STATISTICS:")
    print(f"  Raw table columns: {len(raw_columns)}")
    print(f"  Parsed fields: {len(parsed_fields)}")
    
    # Identify columns that are ONLY raw (not parsed)
    unparsed_columns = []
    parsed_columns = []
    
    for raw_col, count in raw_columns.items():
        clean_col = raw_col.replace('table_', '')
        
        # Check if this column has corresponding parsed fields
        has_parsed = False
        
        # Common parsing patterns
        if any(field in parsed_fields for field in [
            'diameter', 'diameter_mm', 'inner_diameter', 'outer_diameter',
            'dimension', 'wall_thickness', 'pressure', 'working_pressure',
            'burst_pressure', 'water_pressure', 'gas_pressure',
            'length', 'roll_length', 'weight', 'weight_per_meter',
            'sdr', 'sdr_value', 'material', 'power', 'voltage', 'speed',
            'torque', 'frequency', 'frame_size', 'efficiency_class',
            'welding_time', 'cooling_time', 'resistance', 'model',
            'order_number', 'pe_size', 'connection_size', 'gps_traceability'
        ]):
            # Check if this raw column likely maps to one of the parsed fields
            # by looking at common terms
            if any(term in clean_col for term in [
                'maat', 'diameter', 'binnen', 'buiten', 'diam',
                'druk', 'pressure', 'bar', 'werk', 'barst', 'max',
                'water', 'gas', 'lengte', 'length', 'rol',
                'gewicht', 'weight', 'sdr', 'material', 'type',
                'power', 'vermogen', 'kw', 'voltage', 'spanning',
                'rpm', 'toeren', 'speed', 'torque', 'koppel',
                'frequency', 'hz', 'frame', 'bouw', 'efficiency',
                'lastijd', 'welding', 'koeltijd', 'cooling',
                'weerstand', 'resistance', 'order', 'bestelnr'
            ]):
                parsed_columns.append((raw_col, count))
                has_parsed = True
        
        if not has_parsed:
            unparsed_columns.append((raw_col, count))
    
    # Sort by frequency
    unparsed_columns.sort(key=lambda x: x[1], reverse=True)
    
    if unparsed_columns:
        print(f"\n⚠️  UNPARSED COLUMNS ({len(unparsed_columns)}):")
        print(f"    These columns are captured as raw data but NOT parsed into structured fields:\n")
        
        for col, count in unparsed_columns[:20]:
            clean_name = col.replace('table_', '')
            print(f"    • {clean_name:<50} ({count} occurrences)")
        
        if len(unparsed_columns) > 20:
            print(f"\n    ...and {len(unparsed_columns) - 20} more unparsed columns")
        
        print(f"\n    ❓ THESE MAY NEED ATTENTION:")
        print(f"       - Do these columns contain important data?")
        print(f"       - Should they be parsed into structured specifications?")
        print(f"       - Are the column names unclear or need translation?")
    else:
        print(f"\n✅ ALL COLUMNS ARE BEING PARSED!")
        print(f"   Every table column is mapped to a structured specification field.")
    
    print(f"\n✓ COLUMNS BEING PARSED ({len(parsed_columns)}):")
    print(f"  These raw columns ARE being converted to structured specs:")
    for col, count in sorted(parsed_columns, key=lambda x: x[1], reverse=True)[:10]:
        clean_name = col.replace('table_', '')
        print(f"    • {clean_name:<50} ({count} occurrences)")
    if len(parsed_columns) > 10:
        print(f"  ...and {len(parsed_columns) - 10} more parsed columns")

print("\n" + "="*80)
print("ANALYSIS COMPLETE")
print("="*80)
print("\nSUMMARY:")
print("  - Raw columns are ALWAYS preserved (no data loss)")
print("  - Unparsed columns still exist in JSON as 'table_*' fields")
print("  - They can be parsed later if needed")
print("="*80)
