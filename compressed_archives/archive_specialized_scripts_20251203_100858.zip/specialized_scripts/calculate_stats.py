#!/usr/bin/env python3
"""Calculate real statistics from products data for banner display"""

import json
from pathlib import Path
from collections import defaultdict

def calculate_stats():
    """Calculate comprehensive statistics from products data"""
    
    data_file = Path('output/products_ready_for_webshop_v2_comprehensive.json')
    
    if not data_file.exists():
        print("Error: Data file not found!")
        return
    
    with open(data_file, 'r', encoding='utf-8') as f:
        products = json.load(f)
    
    # Initialize counters
    catalogs = set()
    categories = set()
    total_products = len(products)
    products_with_images = 0
    total_images = 0
    products_by_catalog = defaultdict(int)
    
    # Process each product
    for product in products:
        # Get catalog
        catalog = product.get('catalog') or product.get('pdf_source', '').replace('.pdf', '')
        if catalog:
            catalogs.add(catalog)
            products_by_catalog[catalog] += 1
        
        # Get category
        category = product.get('category') or product.get('product_category')
        if category:
            categories.add(category)
        
        # Count images
        media = product.get('media', [])
        if media and len(media) > 0:
            products_with_images += 1
            total_images += len(media)
    
    # Calculate statistics
    image_coverage = (products_with_images / total_products * 100) if total_products > 0 else 0
    avg_images_per_product = total_images / total_products if total_products > 0 else 0
    
    # Print statistics
    print("\n" + "="*60)
    print("PRODUCT CATALOG STATISTICS")
    print("="*60)
    print(f"\n📦 Total Products: {total_products:,}")
    print(f"📚 Unique Catalogs: {len(catalogs)}")
    print(f"🏷️  Unique Categories: {len(categories)}")
    print(f"🖼️  Products with Images: {products_with_images:,}")
    print(f"📸 Total Images: {total_images:,}")
    print(f"📊 Image Coverage: {image_coverage:.1f}%")
    print(f"🎯 Avg Images per Product: {avg_images_per_product:.1f}")
    
    print(f"\n📁 Products by Catalog:")
    for catalog, count in sorted(products_by_catalog.items(), key=lambda x: x[1], reverse=True):
        print(f"   • {catalog}: {count:,} products")
    
    print("\n" + "="*60)
    
    # Generate JavaScript object for use in HTML
    stats_js = {
        'totalProducts': total_products,
        'catalogs': len(catalogs),
        'categories': len(categories),
        'productsWithImages': products_with_images,
        'totalImages': total_images,
        'imageCoverage': round(image_coverage, 1),
        'avgImagesPerProduct': round(avg_images_per_product, 1),
        'catalogList': sorted(list(catalogs))
    }
    
    # Save to JSON for easy import
    output_file = Path('output/catalog_statistics.json')
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(stats_js, f, indent=2)
    
    print(f"\n✅ Statistics saved to: {output_file}")
    print("\nJavaScript code for banner:")
    print("-" * 60)
    print(f"""
const stats = {{
    totalProducts: {stats_js['totalProducts']},
    catalogs: {stats_js['catalogs']},
    categories: {stats_js['categories']},
    productsWithImages: {stats_js['productsWithImages']},
    totalImages: {stats_js['totalImages']},
    imageCoverage: {stats_js['imageCoverage']},
    avgImagesPerProduct: {stats_js['avgImagesPerProduct']}
}};
""")
    
    return stats_js

if __name__ == '__main__':
    calculate_stats()
