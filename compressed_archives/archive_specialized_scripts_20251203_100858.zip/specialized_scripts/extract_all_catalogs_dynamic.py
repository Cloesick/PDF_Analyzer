"""
Master Dynamic Extraction Script
Applies dynamic header-driven extraction to ALL catalogs
"""
import fitz
import json
import re
from pathlib import Path

# Universal header mapping dictionary
HEADER_MAPPING = {
    # SKU / Order number
    'bestelnr': {'property': 'sku', 'icon': None, 'unit': None},
    'code': {'property': 'sku', 'icon': None, 'unit': None},
    'artikelnr': {'property': 'sku', 'icon': None, 'unit': None},
    
    # Dimensions
    'maat': {'property': 'diameter_mm', 'icon': '📏', 'unit': 'mm', 'parser': 'diameter'},
    'maten': {'property': 'dimensions', 'icon': '◯⊙', 'unit': 'mm', 'parser': 'dimensions'},
    'diameter': {'property': 'diameter_mm', 'icon': '📏', 'unit': 'mm', 'parser': 'number'},
    'binnen dia': {'property': 'inner_diameter_mm', 'icon': '⊙', 'unit': 'mm', 'parser': 'number'},
    'buiten dia': {'property': 'outer_diameter_mm', 'icon': '◯', 'unit': 'mm', 'parser': 'number'},
    'breedte': {'property': 'width_mm', 'icon': '↔️', 'unit': 'mm', 'parser': 'number'},
    'lengte': {'property': 'length_m', 'icon': '📐', 'unit': 'm', 'parser': 'number'},
    'rollengte': {'property': 'length_m', 'icon': '📐', 'unit': 'm', 'parser': 'number'},
    'hoek': {'property': 'angle_degrees', 'icon': '📐', 'unit': '°', 'parser': 'number'},
    
    # Pressure
    'werkdruk': {'property': 'pressure_work_bar', 'icon': '🔧', 'unit': 'bar', 'parser': 'number'},
    'barstdruk': {'property': 'pressure_burst_bar', 'icon': '💥', 'unit': 'bar', 'parser': 'number'},
    'max druk': {'property': 'pressure_max_bar', 'icon': '🔧', 'unit': 'bar', 'parser': 'number'},
    'opv.hoogte': {'property': 'pressure_height_m', 'icon': '🔧', 'unit': 'm', 'parser': 'number'},
    'opvoerhoogte': {'property': 'pressure_height_m', 'icon': '🔧', 'unit': 'm', 'parser': 'number'},
    
    # Power
    'vermogen pk': {'property': 'power_hp', 'icon': '⚡', 'unit': 'HP', 'parser': 'number'},
    'vermogen kw': {'property': 'power_kw', 'icon': '⚡', 'unit': 'kW', 'parser': 'number'},
    'pk': {'property': 'power_hp', 'icon': '⚡', 'unit': 'HP', 'parser': 'number'},
    'kw': {'property': 'power_kw', 'icon': '⚡', 'unit': 'kW', 'parser': 'number'},
    
    # Flow & Speed
    'toeren': {'property': 'rpm', 'icon': '🔄', 'unit': 'RPM', 'parser': 'rpm'},
    'rpm': {'property': 'rpm', 'icon': '🔄', 'unit': 'RPM', 'parser': 'number'},
    'debiet': {'property': 'flow_m3_per_h', 'icon': '💨', 'unit': 'm³/h', 'parser': 'number'},
    'capaciteit': {'property': 'flow_m3_per_h', 'icon': '💨', 'unit': 'm³/h', 'parser': 'number'},
    
    # Weight & Volume
    'gewicht': {'property': 'weight_kg', 'icon': '⚖️', 'unit': 'kg', 'parser': 'number'},
    'volume': {'property': 'volume_l', 'icon': '🗜️', 'unit': 'L', 'parser': 'number'},
    'inhoud': {'property': 'volume_l', 'icon': '🗜️', 'unit': 'L', 'parser': 'number'},
    
    # Material & Type
    'materiaal': {'property': 'material', 'icon': '🔬', 'unit': None, 'parser': 'text'},
    'type': {'property': 'type', 'icon': '🏭', 'unit': None, 'parser': 'text'},
    'model': {'property': 'model', 'icon': '🏭', 'unit': None, 'parser': 'text'},
    
    # Temperature
    'temperatuur': {'property': 'temperature', 'icon': '🌡️', 'unit': '°C', 'parser': 'number'},
    'min temp': {'property': 'min_temp_c', 'icon': '🌡️', 'unit': '°C', 'parser': 'number'},
    'max temp': {'property': 'max_temp_c', 'icon': '🌡️', 'unit': '°C', 'parser': 'number'},
    
    # Bearings
    'lagerhuis': {'property': 'bearing_housing', 'icon': '🏠', 'unit': None, 'parser': 'text'},
    'spanlager': {'property': 'pillow_block_bearing', 'icon': '🔩', 'unit': None, 'parser': 'text'},
    'lager': {'property': 'bearing_type', 'icon': '🏷️', 'unit': None, 'parser': 'text'},
    
    # Other
    'toepassing': {'property': 'application', 'icon': '🔧', 'unit': None, 'parser': 'text'},
    'spanning': {'property': 'voltage_v', 'icon': '🔌', 'unit': 'V', 'parser': 'number'},
    'voltage': {'property': 'voltage_v', 'icon': '🔌', 'unit': 'V', 'parser': 'number'},
    'sn': {'property': 'standard_number', 'icon': None, 'unit': None, 'parser': 'text'},
    'keurmerk': {'property': 'quality_mark', 'icon': None, 'unit': None, 'parser': 'text'},
}

def extract_number(value_str):
    """Extract first numeric value from string"""
    if not value_str:
        return None
    value_str = str(value_str).strip().replace('\n', ' ')
    match = re.search(r'(\d+(?:[.,]\d+)?)', value_str)
    if match:
        return float(match.group(1).replace(',', '.'))
    return None

def extract_diameter(value_str):
    """Extract diameter from strings like '110 mm' or '16 mm x 3/8"'"""
    if not value_str:
        return None
    num = extract_number(value_str)
    if num:
        return int(num) if num == int(num) else num
    return None

def extract_dimensions(value_str):
    """Extract outer and inner diameter from 'Maten' like '50 x 40'"""
    if not value_str:
        return {}
    value_str = str(value_str).strip()
    # Pattern: "outer x inner"
    match = re.search(r'(\d+(?:[.,]\d+)?)\s*x\s*(\d+(?:[.,]\d+)?)', value_str, re.IGNORECASE)
    if match:
        outer = float(match.group(1).replace(',', '.'))
        inner = float(match.group(2).replace(',', '.'))
        return {
            'outer_diameter_mm': int(outer) if outer == int(outer) else outer,
            'inner_diameter_mm': int(inner) if inner == int(inner) else inner
        }
    # If just one number, treat as diameter
    num = extract_diameter(value_str)
    if num:
        return {'diameter_mm': num}
    return {}

def extract_rpm(rpm_str):
    """Extract RPM from string like '510 X 7,58' - returns 510"""
    if not rpm_str:
        return None
    rpm_str = str(rpm_str).strip().replace('\n', ' ')
    match = re.search(r'(\d+)\s*[Xx]', rpm_str)
    if match:
        return int(match.group(1))
    match = re.search(r'(\d+)', rpm_str)
    if match:
        return int(match.group(1))
    return None

def parse_value(value, parser_type):
    """Parse value based on parser type"""
    if not value or str(value).strip() in ['-', '', 'N/A']:
        return None
    
    if parser_type == 'number':
        return extract_number(value)
    elif parser_type == 'diameter':
        return extract_diameter(value)
    elif parser_type == 'dimensions':
        return extract_dimensions(value)
    elif parser_type == 'rpm':
        return extract_rpm(value)
    elif parser_type == 'text':
        return str(value).strip()
    else:
        return str(value).strip()

def normalize_header(header_text):
    """Normalize header text for matching"""
    if not header_text:
        return ''
    text = str(header_text).lower()
    text = text.replace('\n', ' ')
    text = re.sub(r'\s+', ' ', text)
    text = text.strip()
    return text

def detect_header_mapping(headers):
    """Automatically detect what each column represents"""
    mappings = []
    
    for i, header in enumerate(headers):
        normalized = normalize_header(header)
        
        mapping = None
        for key, config in HEADER_MAPPING.items():
            if key in normalized:
                mapping = {
                    'index': i,
                    'header': header,
                    'property': config['property'],
                    'icon': config['icon'],
                    'unit': config['unit'],
                    'parser': config.get('parser', 'text')
                }
                break
        
        mappings.append(mapping)
    
    return mappings

def extract_table_dynamically(table, pdf_name, page_num, catalog_name):
    """Extract products from a table using dynamic header detection"""
    extracted = table.extract()
    if not extracted or len(extracted) < 2:
        return []
    
    headers = extracted[0]
    column_mappings = detect_header_mapping(headers)
    
    # Find SKU column
    sku_mapping = next((m for m in column_mappings if m and m['property'] == 'sku'), None)
    if not sku_mapping:
        return []
    
    # Extract products
    products = []
    for row in extracted[1:]:
        if not row or len(row) < 2:
            continue
        
        # Get SKU
        sku = str(row[sku_mapping['index']]).strip()
        if not sku or len(sku) < 2:
            continue
        
        # Build product
        product = {
            'sku': sku,
            'catalog': catalog_name,
            'pdf_source': pdf_name,
            'page_in_pdf': page_num + 1,
            'source_pages': [page_num + 1]
        }
        
        # Extract all other properties
        for mapping in column_mappings:
            if not mapping or mapping['property'] == 'sku':
                continue
            
            col_index = mapping['index']
            if col_index >= len(row):
                continue
            
            value = parse_value(row[col_index], mapping['parser'])
            
            # Handle dimensions specially (returns dict)
            if isinstance(value, dict):
                product.update(value)
            elif value is not None:
                product[mapping['property']] = value
        
        products.append(product)
    
    return products

def process_pdf(pdf_path, catalog_name):
    """Process a PDF with dynamic extraction"""
    print(f"\n{'='*80}")
    print(f"PROCESSING: {catalog_name}")
    print(f"{'='*80}")
    
    doc = fitz.open(pdf_path)
    pdf_name = Path(pdf_path).name
    
    all_products = []
    tables_found = 0
    
    print(f"   PDF: {pdf_name}")
    print(f"   Pages: {len(doc)}")
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        try:
            tables = list(page.find_tables())
            
            for table in tables:
                tables_found += 1
                products = extract_table_dynamically(table, pdf_name, page_num, catalog_name)
                
                if products and tables_found <= 3:
                    headers = table.extract()[0]
                    print(f"\n   📋 Table {tables_found} on page {page_num + 1}:")
                    print(f"      Headers: {[h for h in headers]}")
                    mappings = detect_header_mapping(headers)
                    detected = [f"{m['icon']} {m['property']}" for m in mappings if m and m['icon']]
                    print(f"      Detected: {', '.join(detected)}")
                    print(f"      ✓ Extracted {len(products)} products")
                
                all_products.extend(products)
        
        except Exception as e:
            continue
    
    doc.close()
    
    print(f"\n   📊 TOTAL: {len(all_products)} products from {tables_found} tables")
    
    return all_products

# Catalog configurations
CATALOGS = [
    {
        'name': 'catalogus-aandrijftechniek',
        'pdf': 'input_pdfs/catalogus-aandrijftechniek-150922.pdf',
        'output': 'output/aandrijftechniek_dynamic.json'
    },
    {
        'name': 'catalogus-slangkoppelingen',
        'pdf': 'input_pdfs/slangkoppelingen.pdf',
        'output': 'output/slangkoppelingen_dynamic.json'
    },
    {
        'name': 'catalogus-plat-oprolbare-slangen',
        'pdf': 'input_pdfs/plat-oprolbare-slangen.pdf',
        'output': 'output/plat_oprolbare_slangen_dynamic.json'
    },
    {
        'name': 'catalogus-pomp-specials',
        'pdf': 'input_pdfs/pomp-specials.pdf',
        'output': 'output/pomp_specials_dynamic.json'
    },
    {
        'name': 'catalogus-abs-persluchtbuizen',
        'pdf': 'input_pdfs/abs-persluchtbuizen.pdf',
        'output': 'output/abs_persluchtbuizen_dynamic.json'
    }
]

if __name__ == '__main__':
    print("=" * 80)
    print("DYNAMIC EXTRACTION - ALL CATALOGS")
    print("=" * 80)
    
    all_results = {}
    
    for catalog in CATALOGS:
        products = process_pdf(catalog['pdf'], catalog['name'])
        all_results[catalog['name']] = products
        
        # Save individual catalog results
        output_path = Path(catalog['output'])
        output_path.parent.mkdir(exist_ok=True, parents=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(products, f, ensure_ascii=False, indent=2)
        
        print(f"   💾 Saved to: {output_path}")
    
    # Summary
    print(f"\n{'='*80}")
    print("EXTRACTION SUMMARY")
    print(f"{'='*80}")
    for catalog_name, products in all_results.items():
        print(f"   {catalog_name}: {len(products)} products")
    
    total = sum(len(p) for p in all_results.values())
    print(f"\n   ✅ TOTAL: {total} products extracted")
    print("=" * 80)
