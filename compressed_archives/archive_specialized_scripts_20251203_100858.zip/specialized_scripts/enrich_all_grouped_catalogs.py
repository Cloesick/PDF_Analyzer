"""
Enrich ALL grouped catalogs with properties from smart_extracted files
"""

import json
from pathlib import Path
from typing import Dict, List, Any

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"
WEBSHOP_DATA = Path("C:/Users/prova/Documents/Projects/DemaWebshop/dema-webshop/public/data")

def load_json(file_path: Path) -> Any:
    """Load JSON file safely."""
    if not file_path.exists():
        return None
    with file_path.open("r", encoding="utf-8") as f:
        return json.load(f)

def enrich_variant(variant: Dict, extraction_products: List[Dict]) -> Dict:
    """Enrich a variant with properties from extraction data."""
    sku = variant.get("sku")
    enriched = variant.copy()
    
    # Find matching product in extraction data
    match = next((p for p in extraction_products if p.get("sku") == sku), None)
    
    if match and match.get("properties"):
        # Copy all properties from extraction
        enriched["properties"] = match["properties"].copy()
        enriched["attributes"] = match["properties"].copy()  # Keep both for compatibility
        print(f"      ✓ {sku}: Added {len(match['properties'])} properties")
    else:
        # Keep empty dicts if no match
        if not enriched.get("properties"):
            enriched["properties"] = {}
        if not enriched.get("attributes"):
            enriched["attributes"] = {}
    
    return enriched

def enrich_grouped_catalog(catalog_name: str):
    """Enrich a single grouped catalog."""
    print(f"\n{'='*80}")
    print(f"ENRICHING: {catalog_name}")
    print(f"{'='*80}")
    
    # Load grouped data from webshop
    grouped_file = WEBSHOP_DATA / f"{catalog_name}_grouped.json"
    if not grouped_file.exists():
        print(f"❌ Grouped file not found: {grouped_file}")
        return False
    
    product_groups = load_json(grouped_file)
    if not product_groups:
        print(f"❌ No data in grouped file")
        return False
    
    print(f"📂 Loaded {len(product_groups)} product groups")
    
    # Load extraction data
    extraction_file = OUTPUT_DIR / f"{catalog_name}_smart_extracted.json"
    if not extraction_file.exists():
        print(f"⚠️  No extraction file: {extraction_file}")
        return False
    
    extraction_products = load_json(extraction_file)
    if not extraction_products:
        print(f"❌ No extraction data")
        return False
    
    print(f"📂 Loaded {len(extraction_products)} extracted products")
    
    # Enrich each group's variants
    enriched_count = 0
    for group in product_groups:
        group_name = group.get('name', group.get('group_id'))
        print(f"\n   📦 {group_name} ({len(group.get('variants', []))} variants)")
        
        enriched_variants = []
        for variant in group.get("variants", []):
            enriched_variant = enrich_variant(variant, extraction_products)
            enriched_variants.append(enriched_variant)
            if enriched_variant.get("properties"):
                enriched_count += 1
        
        group["variants"] = enriched_variants
    
    # Save enriched data back to webshop
    with grouped_file.open("w", encoding="utf-8") as f:
        json.dump(product_groups, f, indent=2, ensure_ascii=False)
    
    print(f"\n💾 Saved enriched data to: {grouped_file}")
    print(f"✓ Enriched {enriched_count} variants")
    
    return True

def main():
    """Enrich all grouped catalogs."""
    print("=" * 80)
    print("ENRICHING ALL GROUPED CATALOGS WITH PROPERTIES")
    print("=" * 80)
    
    # Find all grouped files in webshop
    grouped_files = list(WEBSHOP_DATA.glob("*_grouped.json"))
    print(f"\nFound {len(grouped_files)} grouped catalog files")
    
    success_count = 0
    for grouped_file in sorted(grouped_files):
        catalog_name = grouped_file.stem.replace("_grouped", "")
        if enrich_grouped_catalog(catalog_name):
            success_count += 1
    
    print(f"\n{'='*80}")
    print(f"✅ ENRICHMENT COMPLETE")
    print(f"Successfully enriched: {success_count}/{len(grouped_files)} catalogs")
    print(f"{'='*80}\n")

if __name__ == "__main__":
    main()
