#!/usr/bin/env python3
"""
Extract the missing catalogs that weren't found in the regrouping
"""

import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent

MISSING_CATALOGS = [
    "catalogus-aandrijftechniek-150922",
    "digitale-versie-pompentoebehoren-compressed",
    "kranzle-catalogus-2021-nl-1",
    "messing-draadfittingen"
]

def main():
    print("="*80)
    print("EXTRACTING MISSING CATALOGS")
    print("="*80)
    
    for catalog in MISSING_CATALOGS:
        print(f"\n{'='*80}")
        print(f"EXTRACTING: {catalog}")
        print(f"{'='*80}")
        
        cmd = [sys.executable, "extract_single_catalog.py", catalog]
        
        try:
            subprocess.run(cmd, cwd=PROJECT_ROOT, check=True)
            print(f"  ✅ Extracted {catalog}")
        except subprocess.CalledProcessError as e:
            print(f"  ❌ Failed to extract {catalog}: {e}")
    
    print(f"\n{'='*80}")
    print("EXTRACTION COMPLETE")
    print(f"{'='*80}")
    print("\nNow run: python regroup_by_table_and_image.py")

if __name__ == "__main__":
    main()
