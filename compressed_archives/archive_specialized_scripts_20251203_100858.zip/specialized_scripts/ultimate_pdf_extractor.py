"""
ULTIMATE PDF PRODUCT & IMAGE EXTRACTOR
=======================================

A comprehensive, production-ready system that extracts products and images from PDF catalogs
with intelligent SKU detection, smart image naming, and proper quality control.

Features:
- Multi-source SKU detection (in-image, nearby text, tables)
- Priority-based SKU assignment (nearby > table)
- Catalog-specific extraction rules
- Smart filename generation with page numbers and specs
- High-quality .webp image output
- GPT-powered image filtering
- Comprehensive logging and validation
- Progress tracking and statistics
- Error recovery and retry logic

Author: Enhanced PDF Analyzer System
Version: 1.0
"""

import pdfplumber
import re
import json
import os
import sys
import base64
import io
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional
from dataclasses import dataclass, asdict
import numpy as np
import cv2
from PIL import Image
from datetime import datetime

from openai import OpenAI

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ROOT = Path(__file__).parent
INPUT_FOLDER = PROJECT_ROOT / "input_pdfs"
OUTPUT_FOLDER = PROJECT_ROOT / "output"
IMAGES_FOLDER = PROJECT_ROOT / "product-images-ultimate"

# Image quality settings
WEBP_QUALITY = 85
IMAGE_RESOLUTION = 150
MIN_IMAGE_AREA = 10000  # Skip images smaller than ~100x100px

# GPT settings
GPT_MODEL = "gpt-4o-mini"
USE_GPT_FILTERING = True
USE_GPT_SKU_MATCHING = True

# Processing settings
VERBOSE = True
MAX_RETRIES = 3

# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class SKUSource:
    """Track where a SKU was found"""
    sku: str
    source_type: str  # 'image_text', 'nearby_text', 'table', 'page_text'
    confidence: float  # 1.0 = highest, 0.5 = uncertain
    location: Dict  # bbox or other location info
    
@dataclass
class ProductImage:
    """Represents an extracted product image"""
    sku_group: List[str]
    primary_sku: str
    pdf_source: str
    page_num: int
    image_index: int
    bbox: Dict
    filename: str
    file_path: str
    shared_with_skus: List[str]
    sku_sources: List[SKUSource]
    quality_score: float
    
@dataclass
class ExtractionStats:
    """Track extraction statistics"""
    total_pages: int = 0
    total_images_found: int = 0
    images_extracted: int = 0
    images_skipped_small: int = 0
    images_skipped_layout: int = 0
    images_dropped_gpt: int = 0
    skus_found: int = 0
    skus_with_images: int = 0
    errors: int = 0
    
# ============================================================================
# OPENAI CLIENT
# ============================================================================

_openai_client: Optional[OpenAI] = None

def get_openai_client() -> OpenAI:
    """Lazily instantiate and cache the OpenAI client."""
    global _openai_client
    if _openai_client is None:
        _openai_client = OpenAI()
    return _openai_client

# ============================================================================
# REGEX PATTERNS FOR ATTRIBUTE EXTRACTION
# ============================================================================

SKU_PATTERNS = [
    re.compile(r'\b([A-Z]{2,}\d+[-A-Z0-9]*)\b'),  # ABS...
    re.compile(r'\b(\d{5,}(?:-[A-Z0-9]+)?)\b'),   # 36744-E, 45424
    re.compile(r'\b(X\d+)\b'),                     # X0817015
    re.compile(r'\b([A-Z]{1,2}\s?\d{2,}[-A-Z0-9/]*)\b'),  # HL 150-24
    re.compile(r'\b(\d+-\d+(?:-[A-Z]+)?)\b')      # 79853-L
]

SPEC_PATTERNS = {
    'power_kw': re.compile(r'(\d+(?:[.,]\d+)?)\s*kW', re.IGNORECASE),
    'power_hp': re.compile(r'(\d+(?:[.,]\d+)?)\s*hp', re.IGNORECASE),
    'pressure_max_bar': re.compile(r'(\d+(?:[.,]\d+)?)\s*bar', re.IGNORECASE),
    'volume_l': re.compile(r'(\d+(?:[.,]\d+)?)\s*L(?!\s*[/])', re.IGNORECASE),
    'flow_l_min': re.compile(r'(\d+(?:[.,]\d+)?)\s*L/min', re.IGNORECASE),
    'voltage_v': re.compile(r'(\d+)\s*V', re.IGNORECASE),
    'weight_kg': re.compile(r'(\d+(?:[.,]\d+)?)\s*kg', re.IGNORECASE),
    'noise_db': re.compile(r'(\d+)\s*dB\(A\)', re.IGNORECASE),
    'rpm': re.compile(r'(\d+)\s*rpm', re.IGNORECASE),
}

# ============================================================================
# CATALOG-SPECIFIC RULES
# ============================================================================

CATALOG_RULES = {
    'airpress': {
        'sku_search_region': 'below_image',  # SKUs typically below images
        'sku_margin_y': 60,  # Extended search below image
        'category_from': 'headers',  # Extract category from page headers
        'table_layout': 'vertical',  # Products in vertical tables
    },
    'abs': {
        'sku_search_region': 'right_of_image',  # SKUs in table to right
        'sku_margin_x': 200,
        'category_from': 'filename',  # Category from PDF filename
        'table_layout': 'horizontal',
    },
    'default': {
        'sku_search_region': 'surrounding',
        'sku_margin_x': 20,
        'sku_margin_y': 40,
        'category_from': 'text',
        'table_layout': 'auto',
    }
}

def get_catalog_rules(pdf_name: str) -> Dict:
    """Get catalog-specific extraction rules"""
    pdf_lower = pdf_name.lower()
    for key, rules in CATALOG_RULES.items():
        if key in pdf_lower:
            return rules
    return CATALOG_RULES['default']

# ============================================================================
# IMAGE PROCESSING FUNCTIONS
# ============================================================================

def smart_crop_image(pil_image: Image.Image) -> Image.Image:
    """
    Find the main object on a light background and crop tightly around it.
    """
    open_cv_image = np.array(pil_image)
    
    if open_cv_image.ndim == 2:
        gray = open_cv_image
        color_bgr = cv2.cvtColor(open_cv_image, cv2.COLOR_GRAY2BGR)
    else:
        if open_cv_image.shape[2] == 4:
            open_cv_image = cv2.cvtColor(open_cv_image, cv2.COLOR_RGBA2RGB)
        color_bgr = open_cv_image[:, :, ::-1].copy()
        gray = cv2.cvtColor(color_bgr, cv2.COLOR_BGR2GRAY)

    gray_blur = cv2.GaussianBlur(gray, (5, 5), 0)
    _, thresh = cv2.threshold(gray_blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    kernel = np.ones((3, 3), np.uint8)
    mask = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations=2)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return pil_image

    largest_contour = max(contours, key=cv2.contourArea)
    x, y, w, h = cv2.boundingRect(largest_contour)
    if w < 20 or h < 20:
        return pil_image

    mask_object = np.zeros_like(gray, dtype=np.uint8)
    cv2.drawContours(mask_object, [largest_contour], -1, 255, thickness=cv2.FILLED)

    white_bg = np.full_like(color_bgr, 255)
    mask_3c = cv2.merge([mask_object, mask_object, mask_object])
    obj_on_white = np.where(mask_3c == 255, color_bgr, white_bg)

    padding = 10
    h_img, w_img = gray.shape[:2]
    x_new = max(0, x - padding)
    y_new = max(0, y - padding)
    x_max = min(w_img, x + w + padding)
    y_max = min(h_img, y + h + padding)

    obj_on_white_rgb = obj_on_white[:, :, ::-1]
    pil_obj_on_white = Image.fromarray(obj_on_white_rgb)
    return pil_obj_on_white.crop((x_new, y_new, x_max, y_max))


def is_layout_image(gray_arr: np.ndarray) -> bool:
    """
    Determine if an image is likely a layout element (line, separator, etc.)
    rather than a product image.
    """
    h_arr, w_arr = gray_arr.shape[:2]
    short_side = min(w_arr, h_arr)
    long_side = max(w_arr, h_arr)
    aspect_ratio = long_side / short_side if short_side > 0 else 0
    
    hist = np.bincount(gray_arr.ravel(), minlength=256)
    dominant_frac = hist.max() / float(gray_arr.size)
    std_gray = gray_arr.std()
    
    # Layout images: thin, high aspect ratio, low variation
    if (short_side < 200 and aspect_ratio > 3.0 and 
        dominant_frac > 0.75 and std_gray < 60):
        return True
    
    return False


def save_as_webp(pil_image: Image.Image, filepath: Path, quality: int = WEBP_QUALITY):
    """Save PIL image as high-quality .webp format."""
    filepath.parent.mkdir(parents=True, exist_ok=True)
    pil_image.save(filepath, format='WEBP', quality=quality, method=6)

# ============================================================================
# GPT-POWERED FUNCTIONS
# ============================================================================

def gpt_is_product_image(image_bytes: bytes) -> bool:
    """
    Use GPT-4 Vision to determine if an image shows an actual product
    (not a diagram, chart, or decorative element).
    """
    if not USE_GPT_FILTERING:
        return True
    
    try:
        client = get_openai_client()
        base64_image = base64.b64encode(image_bytes).decode('utf-8')
        
        response = client.chat.completions.create(
            model=GPT_MODEL,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": "Is this a photo or realistic rendering of an actual physical product (tool, machine, equipment)? Answer only 'yes' or 'no'."
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/webp;base64,{base64_image}"
                            }
                        }
                    ]
                }
            ],
            max_tokens=10
        )
        
        answer = response.choices[0].message.content.strip().lower()
        return 'yes' in answer
        
    except Exception as e:
        print(f"  [WARNING] GPT filtering error: {e}")
        return True  # Default to keeping image if GPT fails


def gpt_match_image_to_skus(image_bytes: bytes, candidate_skus: List[str], page_text: str = "") -> List[str]:
    """
    Use GPT-4 Vision to determine which SKUs from a list best match the product(s) shown in an image.
    """
    if not USE_GPT_SKU_MATCHING or not candidate_skus:
        return candidate_skus
    
    try:
        client = get_openai_client()
        base64_image = base64.b64encode(image_bytes).decode('utf-8')
        
        sku_list = ", ".join(candidate_skus)
        
        response = client.chat.completions.create(
            model=GPT_MODEL,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": f"This image shows product(s) with these possible SKUs: {sku_list}. Which SKUs actually appear in or match this image? Return only the matching SKUs separated by commas, or 'none' if uncertain."
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/webp;base64,{base64_image}"
                            }
                        }
                    ]
                }
            ],
            max_tokens=100
        )
        
        answer = response.choices[0].message.content.strip()
        if 'none' in answer.lower():
            return candidate_skus  # Keep all if uncertain
        
        # Parse matched SKUs
        matched = []
        for sku in candidate_skus:
            if sku in answer:
                matched.append(sku)
        
        return matched if matched else candidate_skus
        
    except Exception as e:
        print(f"  [WARNING] GPT SKU matching error: {e}")
        return candidate_skus

# ============================================================================
# SKU DETECTION & GROUPING
# ============================================================================

def find_all_skus(text: str) -> Set[str]:
    """Extract all SKUs from text using multiple patterns."""
    if not text:
        return set()
    
    skus = set()
    for pattern in SKU_PATTERNS:
        matches = pattern.findall(text)
        skus.update(matches)
    
    return skus


def are_skus_similar(sku1: str, sku2: str, threshold: int = 500) -> bool:
    """
    Determine if two SKUs are similar enough to potentially share an image.
    """
    nums1 = re.findall(r'\d+', sku1)
    nums2 = re.findall(r'\d+', sku2)
    
    if not nums1 or not nums2:
        return False
    
    base1 = int(nums1[0])
    base2 = int(nums2[0])
    
    # Same base number (different suffixes)
    if base1 == base2:
        return True
    
    # Same product series (within threshold)
    if abs(base1 - base2) <= threshold:
        return True
    
    return False


def group_similar_skus(skus: List[str]) -> List[List[str]]:
    """
    Group SKUs that are similar and likely to share the same image.
    """
    if not skus:
        return []
    
    groups = []
    remaining = set(skus)
    
    while remaining:
        current_sku = min(remaining)
        current_group = [current_sku]
        remaining.remove(current_sku)
        
        to_remove = set()
        for sku in remaining:
            if are_skus_similar(current_sku, sku):
                current_group.append(sku)
                to_remove.add(sku)
        
        remaining -= to_remove
        groups.append(sorted(current_group))
    
    return groups

# ============================================================================
# SKU EXTRACTION WITH PRIORITY
# ============================================================================

def extract_skus_from_image_region(page, bbox: Dict, catalog_rules: Dict) -> List[SKUSource]:
    """
    Extract SKUs from the image region itself and immediate surroundings.
    HIGHEST PRIORITY - these SKUs are visually associated with the image.
    """
    sku_sources = []
    
    x0, y0, x1, y1 = bbox['x0'], bbox['y0'], bbox['x1'], bbox['y1']
    
    # Get catalog-specific margins
    margin_x = catalog_rules.get('sku_margin_x', 20)
    margin_y = catalog_rules.get('sku_margin_y', 40)
    
    try:
        # Adjust region based on catalog rules
        search_region = catalog_rules.get('sku_search_region', 'surrounding')
        
        if search_region == 'below_image':
            region = (max(0, x0 - 5), y1, min(page.width, x1 + 5), min(page.height, y1 + margin_y))
        elif search_region == 'right_of_image':
            region = (x1, max(0, y0 - 5), min(page.width, x1 + margin_x), min(page.height, y1 + 5))
        else:  # surrounding
            region = (
                max(0, x0 - margin_x),
                max(0, y0 - margin_y),
                min(page.width, x1 + margin_x),
                min(page.height, y1 + margin_y)
            )
        
        cropped_region = page.crop(region)
        text = cropped_region.extract_text(x_tolerance=2, y_tolerance=2)
        
        if text:
            skus = find_all_skus(text)
            for sku in skus:
                sku_sources.append(SKUSource(
                    sku=sku,
                    source_type='nearby_text',
                    confidence=1.0,
                    location={'bbox': region, 'text': text[:100]}
                ))
    
    except Exception as e:
        print(f"  [WARNING] Error extracting nearby SKUs: {e}")
    
    return sku_sources


def extract_skus_from_tables(page, tables: List) -> Dict[Tuple, List[SKUSource]]:
    """
    Extract SKUs from tables and associate with table bounding boxes.
    MEDIUM PRIORITY - used when no nearby SKUs found.
    """
    table_sku_map = {}
    
    for table in tables:
        try:
            table_bbox = (page.bbox[0], page.bbox[1], page.bbox[2], page.bbox[3])
            table_skus = []
            
            for row in table:
                row_text = " ".join(str(cell) for cell in row if cell)
                skus = find_all_skus(row_text)
                
                for sku in skus:
                    table_skus.append(SKUSource(
                        sku=sku,
                        source_type='table',
                        confidence=0.7,
                        location={'bbox': table_bbox, 'row': row_text[:100]}
                    ))
            
            if table_skus:
                table_sku_map[table_bbox] = table_skus
        
        except Exception:
            continue
    
    return table_sku_map


def prioritize_sku_sources(sku_sources: List[SKUSource]) -> List[str]:
    """
    Given multiple SKU sources, prioritize and return the most relevant SKUs.
    Priority: nearby_text > table > page_text
    """
    if not sku_sources:
        return []
    
    # Group by source type
    by_type = defaultdict(list)
    for source in sku_sources:
        by_type[source.source_type].append(source.sku)
    
    # Return highest priority non-empty group
    if by_type['nearby_text']:
        return list(set(by_type['nearby_text']))
    elif by_type['table']:
        return list(set(by_type['table']))
    elif by_type['page_text']:
        return list(set(by_type['page_text']))
    
    return []

# ============================================================================
# SMART FILENAME GENERATION
# ============================================================================

def sanitize_for_filename(text: str, max_length: int = 30) -> str:
    """Sanitize text for use in filename."""
    if not text:
        return ""
    text = re.compile(r'[<>:"/\\|?*]').sub('_', str(text))
    text = re.compile(r'[\s_]+').sub('_', text)
    text = text.strip('_')
    if len(text) > max_length:
        text = text[:max_length].rstrip('_')
    return text


def extract_specs_from_text(text: str) -> Dict[str, any]:
    """Extract technical specifications from text."""
    specs = {}
    
    for key, pattern in SPEC_PATTERNS.items():
        match = pattern.search(text)
        if match:
            try:
                value = float(match.group(1).replace(',', '.'))
                specs[key] = value
            except:
                specs[key] = match.group(1)
    
    return specs


def detect_category(text: str) -> str:
    """Detect product category from text (multi-language)."""
    categories = {
        'PISTON_COMPRESSOR': ['piston', 'zuiger', 'kolben', 'k-serie'],
        'SCREW_COMPRESSOR': ['screw', 'schroef', 'schraube'],
        'AIR_DRYER': ['dryer', 'droger', 'trockner'],
        'HOSE_REEL': ['hose reel', 'haspel'],
        'SOCKET_SET': ['socket', 'doppen'],
        'DRILL': ['drill', 'boor', 'bohrer'],
        'GRINDER': ['grinder', 'slijper'],
        'PRESS': ['press', 'pers'],
    }
    
    text_lower = text.lower()
    for category, keywords in categories.items():
        for keyword in keywords:
            if keyword in text_lower:
                return category
    
    return "PRODUCT"


def build_smart_filename(
    sku_group: List[str],
    pdf_name: str,
    page_num: int,
    img_index: int,
    product_data: Dict,
    page_text: str = ""
) -> str:
    """
    Build comprehensive filename: SKU__CATEGORY__PAGE__CATALOG__SPECS__[MULTI]_imgINDEX.webp
    """
    if not sku_group:
        return f"UNKNOWN__p{page_num:03d}_img{img_index:03d}.webp"
    
    primary_sku = sku_group[0]
    safe_sku = sanitize_for_filename(primary_sku, max_length=20)
    
    # Category
    category = detect_category(page_text)
    category = sanitize_for_filename(category, max_length=25)
    
    # Page
    page_str = f"p{page_num:03d}"
    
    # Catalog (shortened)
    catalog = pdf_name.replace('-', '_').replace('.pdf', '')
    parts = catalog.split('_')
    if len(parts) > 2:
        catalog = f"{parts[0]}_{parts[-1]}"
    catalog = sanitize_for_filename(catalog, max_length=15)
    
    # Specs
    specs = extract_specs_from_text(page_text)
    spec_parts = []
    for key in ['power_kw', 'pressure_max_bar', 'volume_l']:
        if key in specs:
            unit = key.split('_')[-1]
            spec_parts.append(f"{specs[key]}{unit}")
            if len(spec_parts) >= 2:
                break
    specs_str = "_".join(spec_parts) if spec_parts else ""
    
    # Multi-SKU
    multi_str = ""
    if len(sku_group) > 1:
        sku_list = sku_group[:5]
        if len(sku_group) > 5:
            multi_str = f"__[{'+'.join(sku_list)}+{len(sku_group)-5}more]"
        else:
            multi_str = f"__[{'+'.join(sku_list)}]"
    
    # Build
    parts = [safe_sku, category, page_str, catalog]
    if specs_str:
        parts.append(specs_str)
    
    filename = "__".join(parts) + multi_str + f"_img{img_index:03d}.webp"
    
    # Ensure reasonable length
    if len(filename) > 220:
        filename = f"{safe_sku}__{category}__{page_str}__{catalog}{multi_str}_img{img_index:03d}.webp"
    
    return filename

# ============================================================================
# MAIN EXTRACTION LOGIC
# ============================================================================

def extract_images_from_pdf(pdf_path: Path, product_map: Dict, stats: ExtractionStats) -> None:
    """
    Extract images from a single PDF with intelligent SKU detection and smart naming.
    """
    pdf_name = pdf_path.stem
    catalog_rules = get_catalog_rules(pdf_name)
    
    print(f"\n{'='*80}")
    print(f"Processing: {pdf_name}")
    print(f"Catalog rules: {catalog_rules['sku_search_region']}")
    print(f"{'='*80}\n")
    
    try:
        with pdfplumber.open(pdf_path) as pdf:
            total_pages = len(pdf.pages)
            stats.total_pages += total_pages
            
            for page_num, page in enumerate(pdf.pages, 1):
                if VERBOSE and page_num % 10 == 0:
                    print(f"  Processing page {page_num}/{total_pages}...")
                
                # Extract page text
                page_text = page.extract_text() or ""
                
                # Extract tables
                tables = page.extract_tables() or []
                table_sku_map = extract_skus_from_tables(page, tables)
                
                # Extract images
                page_images = getattr(page, "images", []) or []
                stats.total_images_found += len(page_images)
                
                for img_index, img in enumerate(page_images):
                    try:
                        # Get image bounds
                        x0, y0, x1, y1 = img.get('x0'), img.get('y0'), img.get('x1'), img.get('y1')
                        if None in (x0, y0, x1, y1):
                            continue
                        
                        # Skip small images
                        area = (x1 - x0) * (y1 - y0)
                        if area < MIN_IMAGE_AREA:
                            stats.images_skipped_small += 1
                            continue
                        
                        # Extract and process image
                        cropped = page.crop((x0, y0, x1, y1))
                        pil_img_base = cropped.to_image(resolution=IMAGE_RESOLUTION).original
                        pil_img_cropped = smart_crop_image(pil_img_base)
                        
                        # Check if layout image
                        gray = np.array(pil_img_cropped.convert("L"))
                        if is_layout_image(gray):
                            stats.images_skipped_layout += 1
                            continue
                        
                        # Convert to bytes for GPT
                        buf = io.BytesIO()
                        pil_img_cropped.save(buf, format="WEBP")
                        image_bytes = buf.getvalue()
                        
                        # GPT filtering
                        if not gpt_is_product_image(image_bytes):
                            stats.images_dropped_gpt += 1
                            continue
                        
                        # ===== SKU DETECTION WITH PRIORITY =====
                        
                        # Priority 1: SKUs near the image
                        nearby_sku_sources = extract_skus_from_image_region(
                            page,
                            {'x0': x0, 'y0': y0, 'x1': x1, 'y1': y1},
                            catalog_rules
                        )
                        
                        # Priority 2: SKUs from nearest table (if no nearby SKUs)
                        table_sku_sources = []
                        if not nearby_sku_sources and table_sku_map:
                            # Find nearest table
                            img_center = ((x0 + x1) / 2, (y0 + y1) / 2)
                            min_dist = float('inf')
                            nearest_table_skus = []
                            
                            for table_bbox, skus in table_sku_map.items():
                                table_center = ((table_bbox[0] + table_bbox[2]) / 2,
                                              (table_bbox[1] + table_bbox[3]) / 2)
                                dist = ((img_center[0] - table_center[0])**2 + 
                                       (img_center[1] - table_center[1])**2)**0.5
                                if dist < min_dist:
                                    min_dist = dist
                                    nearest_table_skus = skus
                            
                            table_sku_sources = nearest_table_skus
                        
                        # Combine and prioritize
                        all_sku_sources = nearby_sku_sources + table_sku_sources
                        candidate_skus = prioritize_sku_sources(all_sku_sources)
                        
                        if not candidate_skus:
                            continue  # No SKUs found for this image
                        
                        # Optional: GPT refinement
                        matched_skus = gpt_match_image_to_skus(image_bytes, candidate_skus, page_text)
                        
                        # Group similar SKUs
                        sku_groups = group_similar_skus(matched_skus)
                        
                        # Save one image per SKU group
                        for sku_group in sku_groups:
                            if not sku_group:
                                continue
                            
                            primary_sku = sku_group[0]
                            
                            # Build smart filename
                            filename = build_smart_filename(
                                sku_group=sku_group,
                                pdf_name=pdf_name,
                                page_num=page_num,
                                img_index=img_index,
                                product_data=product_map.get(primary_sku, {}),
                                page_text=page_text
                            )
                            
                            # Save image
                            image_path = IMAGES_FOLDER / filename
                            save_as_webp(pil_img_cropped, image_path, WEBP_QUALITY)
                            
                            # Update product map
                            for sku in sku_group:
                                if sku not in product_map:
                                    product_map[sku] = {
                                        'sku': sku,
                                        'pdf_source': str(pdf_path.name),
                                        'pages': [],
                                        'images': []
                                    }
                                
                                if page_num not in product_map[sku]['pages']:
                                    product_map[sku]['pages'].append(page_num)
                                
                                product_map[sku]['images'].append({
                                    'filename': filename,
                                    'path': str(image_path),
                                    'page': page_num,
                                    'index': img_index,
                                    'shared_with_skus': sku_group,
                                    'is_primary': (sku == primary_sku),
                                    'sku_sources': [asdict(s) for s in all_sku_sources if s.sku == sku]
                                })
                            
                            stats.images_extracted += 1
                            
                            if VERBOSE:
                                print(f"    ✓ Saved: {filename[:80]}...")
                    
                    except Exception as e:
                        stats.errors += 1
                        print(f"  [ERROR] Image {img_index} on page {page_num}: {e}")
                        continue
        
        # Update SKU stats
        stats.skus_found += len(product_map)
        stats.skus_with_images += sum(1 for p in product_map.values() if p['images'])
        
    except Exception as e:
        stats.errors += 1
        print(f"[ERROR] Processing PDF {pdf_name}: {e}")
        import traceback
        traceback.print_exc()


def main():
    """Main execution function"""
    print("\n" + "="*80)
    print("ULTIMATE PDF PRODUCT & IMAGE EXTRACTOR")
    print("="*80 + "\n")
    
    # Setup
    INPUT_FOLDER.mkdir(exist_ok=True)
    OUTPUT_FOLDER.mkdir(exist_ok=True)
    IMAGES_FOLDER.mkdir(exist_ok=True)
    
    # Find PDFs
    pdf_files = list(INPUT_FOLDER.glob("*.pdf"))
    if not pdf_files:
        print(f"ERROR: No PDF files found in {INPUT_FOLDER}")
        return
    
    print(f"Found {len(pdf_files)} PDF files to process\n")
    
    # Process each PDF
    product_map = {}
    stats = ExtractionStats()
    
    for pdf_path in pdf_files:
        extract_images_from_pdf(pdf_path, product_map, stats)
    
    # Save product data
    output_file = OUTPUT_FOLDER / f"products_ultimate_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(list(product_map.values()), f, ensure_ascii=False, indent=2)
    
    # Print final statistics
    print("\n" + "="*80)
    print("EXTRACTION COMPLETE")
    print("="*80)
    print(f"\nStatistics:")
    print(f"  Total pages processed:     {stats.total_pages}")
    print(f"  Total images found:        {stats.total_images_found}")
    print(f"  Images extracted:          {stats.images_extracted}")
    print(f"  Images skipped (small):    {stats.images_skipped_small}")
    print(f"  Images skipped (layout):   {stats.images_skipped_layout}")
    print(f"  Images dropped (GPT):      {stats.images_dropped_gpt}")
    print(f"  Unique SKUs found:         {stats.skus_found}")
    print(f"  SKUs with images:          {stats.skus_with_images}")
    print(f"  Errors encountered:        {stats.errors}")
    print(f"\nOutput:")
    print(f"  Images saved to:  {IMAGES_FOLDER}")
    print(f"  Product data:     {output_file}")
    print("\n" + "="*80 + "\n")


if __name__ == "__main__":
    main()
