"""
Enrich the analysis JSON files with image paths
Images can be reused from dema-webshop frontend
"""
import json
from pathlib import Path

print("="*80)
print("ENRICHING JSONs WITH IMAGE PATHS")
print("="*80)

# Define the PDF files and their image output directories
pdf_configs = [
    {
        'name': 'PE-Buizen',
        'json_path': 'output/pe_buizen_analysis.json',
        'image_base_path': 'images/pe-buizen',
        'image_base_url': '/images/products/pe-buizen'  # Frontend URL path
    },
    {
        'name': 'Plat-Oprolbare',
        'json_path': 'output/plat_oprolbare_analysis.json',
        'image_base_path': 'images/plat-oprolbare',
        'image_base_url': '/images/products/plat-oprolbare'
    },
    {
        'name': 'Aandrijftechniek',
        'json_path': 'output/aandrijftechniek_analysis.json',
        'image_base_path': 'images/aandrijftechniek',
        'image_base_url': '/images/products/aandrijftechniek'
    }
]

for config in pdf_configs:
    print(f"\n{'='*80}")
    print(f"Processing: {config['name']}")
    print(f"{'='*80}")
    
    # Load the JSON
    with open(config['json_path'], 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    total_products = 0
    products_with_images = 0
    unique_images = set()
    
    # Process each page
    for page in data['pages']:
        for product in page['products_found']:
            total_products += 1
            
            if product.get('image_hash'):
                image_hash = product['image_hash']
                unique_images.add(image_hash)
                products_with_images += 1
                
                # Add image paths
                # Local file path (for extraction)
                image_filename = f"{image_hash}.webp"
                product['image_path'] = f"{config['image_base_path']}/{image_filename}"
                
                # Frontend URL (for webshop)
                product['image_url'] = f"{config['image_base_url']}/{image_filename}"
                
                # Alternative formats
                product['image_formats'] = {
                    'webp': f"{config['image_base_url']}/{image_hash}.webp",
                    'png': f"{config['image_base_url']}/{image_hash}.png",
                    'jpg': f"{config['image_base_url']}/{image_hash}.jpg"
                }
    
    # Update shared images with paths
    if 'shared_images' in data:
        for img_info in data['shared_images']:
            if 'image_hash' in img_info:
                image_hash = img_info['image_hash']
                image_filename = f"{image_hash}.webp"
                
                img_info['image_path'] = f"{config['image_base_path']}/{image_filename}"
                img_info['image_url'] = f"{config['image_base_url']}/{image_filename}"
                img_info['image_formats'] = {
                    'webp': f"{config['image_base_url']}/{image_hash}.webp",
                    'png': f"{config['image_base_url']}/{image_hash}.png",
                    'jpg': f"{config['image_base_url']}/{image_hash}.jpg"
                }
    
    # Update images_found with paths
    for page in data['pages']:
        for img_info in page['images_found']:
            if 'image_hash' in img_info:
                image_hash = img_info['image_hash']
                image_filename = f"{image_hash}.webp"
                
                img_info['image_path'] = f"{config['image_base_path']}/{image_filename}"
                img_info['image_url'] = f"{config['image_base_url']}/{image_filename}"
                img_info['image_formats'] = {
                    'webp': f"{config['image_base_url']}/{image_hash}.webp",
                    'png': f"{config['image_base_url']}/{image_hash}.png",
                    'jpg': f"{config['image_base_url']}/{image_hash}.jpg"
                }
    
    # Save enriched JSON
    output_path = config['json_path'].replace('.json', '_enriched.json')
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    
    print(f"\n✓ Enriched JSON saved to: {output_path}")
    print(f"\nStatistics:")
    print(f"  • Total products: {total_products}")
    print(f"  • Products with images: {products_with_images} ({products_with_images/total_products*100:.1f}%)")
    print(f"  • Unique images: {len(unique_images)}")
    print(f"\nImage paths added:")
    print(f"  • Local path: {config['image_base_path']}/<hash>.webp")
    print(f"  • Frontend URL: {config['image_base_url']}/<hash>.webp")
    
    # Show sample
    sample_product = None
    for page in data['pages']:
        for product in page['products_found']:
            if product.get('image_hash'):
                sample_product = product
                break
        if sample_product:
            break
    
    if sample_product:
        print(f"\n📸 Sample product image:")
        print(f"  Product: {sample_product['product_id']}")
        print(f"  Image hash: {sample_product['image_hash'][:50]}...")
        print(f"  Image URL: {sample_product['image_url']}")
        print(f"  Formats available:")
        for fmt, url in sample_product['image_formats'].items():
            print(f"    • {fmt}: {url}")

print(f"\n{'='*80}")
print(f"ENRICHMENT COMPLETE")
print(f"{'='*80}")
print(f"\n✅ All JSON files enriched with image paths!")
print(f"\n📁 Enriched files created:")
print(f"  • output/pe_buizen_analysis_enriched.json")
print(f"  • output/plat_oprolbare_analysis_enriched.json")
print(f"  • output/aandrijftechniek_analysis_enriched.json")
print(f"\n💡 These can be used directly in your frontend!")
print(f"   Simply reference product['image_url'] for display")
print("="*80)
