"""
Identify which SKUs are actual tools vs accessories and find their images
"""
import json
import re
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
IMAGE_DIR = PROJECT_ROOT / "product-images-by-pdf"
OUTPUT_DIR = PROJECT_ROOT / "output"

# User's list of problematic SKUs
SKUS = """
BL4020, BL4025, 81-6, B36-3, BL4040, BL4050F, DC40RA, DC40RB, ADPOO1, ADP10, DEAADP001G, 
BL4080F, AR04CD, N09-8, HR005G, HR005GM202, TW04GD201, TW004GZ, TW007GD201, TW007GM201, 
TW007GZ01, GA005G, BL4050, GA037GM201, GA037GT201, GA03, GA035GZ, GA036GZ, GA037GZO1, 
IPX4, PV001GZ, BL4, DC40, JR001GD, PT001GD101, PT001GZO1, PV001GM1O1, JR002G, JR002GM201, 
JR002GZ, JR001GZ, JR001GM201, JR001GD201, FN00GA202, FN001GA202, FN001GZ02, GA038GT201, 
GA038GZ01, GA038GT2, GA038GM201, HS010G, HS009G, RT001GZ16, RT001GM208, KP001GZ01, 
KP001GM202, D201, DK0126G401, DK0128G601, HS003G, JR001G, M3001GZ, LS004GZ01, LS003GZO1, 
LS002GZO1, BBLL11886600BB, BBLL11885500BB, BBLL11884400BB, BBLL11883300BB, BL1860B, 
BL1840B, BL1830B, 198720-9, 19077-8, 198091-4, 198116-4, 198170-8, 197629-2, 197626-8, 
197624, 197594-9, 197422-4, 933-6, 624-2, DC18R, 077-8, B 18, 94-9, 80-8, RC 30B, PL11, 
PDC01, ER 55, DC 11, DC18RD, BPS01, BL1850, BEAPDC1200A01, AD 88, 56169, 54329, 36179, 
BL18, 19693, BL1188, 7-8, 720-9, 091-4, DC18RE, L118830B, BL1840, DC18, 84-2, BL11883, 
BL11, K18, AA 8720-9, 8720-9, 8091-4, DC18RC, BL1188550B
"""

def classify_sku(sku):
    """Classify SKU as tool, battery, charger, or accessory"""
    sku_clean = sku.replace(' ', '').replace('-', '').upper()
    
    # Battery patterns
    if any(pattern in sku_clean for pattern in ['BL1', 'BL4', 'BL6', 'BBLL']):
        return 'battery', '🔋'
    
    # Charger patterns
    if any(pattern in sku_clean for pattern in ['DC1', 'DC2', 'DC3', 'DC4', 'DC6']):
        return 'charger', '🔌'
    
    # Adapter patterns
    if 'ADP' in sku_clean or 'BEAPDC' in sku_clean:
        return 'adapter', '🔌'
    
    # Tool patterns - these are actual tools!
    tool_patterns = {
        'HR': '🔨 Rotary Hammer',
        'TW': '🔧 Impact Wrench',
        'GA': '⚙️ Angle Grinder',
        'JR': '🪚 Reciprocating Saw',
        'PT': '🔧 Multi-Tool',
        'PV': '🔧 Power Tool',
        'HS': '⚫ Circular Saw',
        'RT': '🔄 Router',
        'KP': '✂️ Planer',
        'DK': '🧰 Combo Kit',
        'M3': '🪚 Miter Saw',
        'LS': '🪚 Slide Compound Saw',
        'FN': '📌 Nailer',
    }
    
    for prefix, description in tool_patterns.items():
        if sku_clean.startswith(prefix):
            return 'tool', description
    
    # Numeric codes (usually accessories)
    if re.match(r'^[\d\-]+$', sku_clean):
        return 'accessory', '🔩'
    
    # Short codes (accessories)
    if len(sku_clean) <= 4:
        return 'accessory', '🔩'
    
    # Unknown/other
    return 'unknown', '❓'

def find_images_in_folder(sku):
    """Find existing images for a SKU"""
    catalogs = ['makita-catalogus-2022-nl', 'makita-tuinfolder-2022-nl']
    found_images = []
    
    sku_clean = sku.replace(' ', '').replace('-', '').upper()
    
    for catalog in catalogs:
        catalog_dir = IMAGE_DIR / catalog
        if not catalog_dir.exists():
            continue
        
        for img_path in catalog_dir.glob('*'):
            img_name = img_path.stem.upper()
            
            # Check if SKU is in filename
            if sku_clean in img_name or sku.upper() in img_name:
                found_images.append({
                    'catalog': catalog,
                    'filename': img_path.name,
                    'path': str(img_path)
                })
    
    return found_images

def check_products_json(sku):
    """Check if SKU exists in products JSON"""
    products_file = OUTPUT_DIR / "products_ready_for_webshop.json"
    
    if not products_file.exists():
        return None
    
    with open(products_file, 'r', encoding='utf-8') as f:
        products = json.load(f)
    
    sku_clean = sku.replace(' ', '').replace('-', '').upper()
    
    for product in products:
        product_sku = product.get('sku', '').replace(' ', '').replace('-', '').upper()
        if sku_clean in product_sku or product_sku in sku_clean:
            return {
                'sku': product.get('sku'),
                'name': product.get('name'),
                'brand': product.get('brand'),
                'media_count': len(product.get('media', [])),
                'specs_count': len(product.get('specs', []))
            }
    
    return None

def main():
    print("="*80)
    print("ANALYZING MISSING/PROBLEMATIC SKUS")
    print("="*80)
    
    # Parse SKUs
    sku_list = [s.strip() for s in SKUS.replace('\n', ',').split(',') if s.strip()]
    
    print(f"\nAnalyzing {len(sku_list)} SKUs...")
    
    # Classify
    tools = []
    batteries = []
    chargers = []
    accessories = []
    unknown = []
    
    for sku in sku_list:
        category, icon = classify_sku(sku)
        images = find_images_in_folder(sku)
        product_data = check_products_json(sku)
        
        item = {
            'sku': sku,
            'category': category,
            'icon': icon,
            'images': images,
            'product_data': product_data
        }
        
        if category == 'tool':
            tools.append(item)
        elif category == 'battery':
            batteries.append(item)
        elif category == 'charger':
            chargers.append(item)
        elif category == 'accessory':
            accessories.append(item)
        else:
            unknown.append(item)
    
    # Report
    print("\n" + "="*80)
    print("CLASSIFICATION RESULTS")
    print("="*80)
    
    print(f"\n🔧 ACTUAL TOOLS: {len(tools)}")
    print(f"🔋 BATTERIES: {len(batteries)}")
    print(f"🔌 CHARGERS/ADAPTERS: {len(chargers)}")
    print(f"🔩 ACCESSORIES: {len(accessories)}")
    print(f"❓ UNKNOWN: {len(unknown)}")
    
    # Show tools that need images
    print("\n" + "="*80)
    print("🔧 ACTUAL TOOLS - NEED IMAGES")
    print("="*80)
    
    tools_missing_images = [t for t in tools if not t['images']]
    tools_have_images = [t for t in tools if t['images']]
    
    print(f"\nTools WITHOUT images: {len(tools_missing_images)}")
    print(f"Tools WITH images: {len(tools_have_images)}")
    
    if tools_missing_images:
        print(f"\n⚠️ TOOLS MISSING IMAGES (need to extract):")
        for tool in tools_missing_images:
            print(f"\n  {tool['icon']} {tool['sku']}")
            if tool['product_data']:
                print(f"    Found in products.json: {tool['product_data']['name']}")
                print(f"    Media: {tool['product_data']['media_count']}, Specs: {tool['product_data']['specs_count']}")
            else:
                print(f"    Not found in products.json")
    
    if tools_have_images:
        print(f"\n✅ TOOLS WITH IMAGES:")
        for tool in tools_have_images[:10]:
            print(f"\n  {tool['icon']} {tool['sku']}")
            print(f"    Images found: {len(tool['images'])}")
            for img in tool['images']:
                print(f"      - {img['catalog']}/{img['filename']}")
        
        if len(tools_have_images) > 10:
            print(f"\n  ... and {len(tools_have_images) - 10} more")
    
    # Show batteries/chargers that should be removed
    print("\n" + "="*80)
    print("🔋🔌 BATTERIES/CHARGERS - SHOULD BE REMOVED")
    print("="*80)
    
    accessories_with_images = [item for item in batteries + chargers if item['images']]
    
    if accessories_with_images:
        print(f"\n❌ Found {len(accessories_with_images)} battery/charger images still present:")
        for item in accessories_with_images[:10]:
            print(f"\n  {item['icon']} {item['sku']} ({item['category']})")
            for img in item['images']:
                print(f"      - {img['filename']}")
        
        if len(accessories_with_images) > 10:
            print(f"\n  ... and {len(accessories_with_images) - 10} more")
    else:
        print(f"\n✅ No battery/charger images found (good!)")
    
    # Summary with actionable steps
    print("\n" + "="*80)
    print("📋 ACTION ITEMS")
    print("="*80)
    
    print(f"\n1. ✅ Classification complete:")
    print(f"   - {len(tools)} actual tools identified")
    print(f"   - {len(batteries)} batteries identified")
    print(f"   - {len(chargers)} chargers/adapters identified")
    
    print(f"\n2. 🔍 Image status:")
    print(f"   - {len(tools_have_images)} tools already have images")
    print(f"   - {len(tools_missing_images)} tools need images extracted")
    
    if tools_missing_images:
        print(f"\n3. 📸 Tools needing image extraction:")
        missing_skus = [t['sku'] for t in tools_missing_images]
        print(f"   {', '.join(missing_skus[:20])}")
        if len(missing_skus) > 20:
            print(f"   ... and {len(missing_skus) - 20} more")
    
    if accessories_with_images:
        print(f"\n4. 🗑️ Battery/charger images to remove:")
        print(f"   {len(accessories_with_images)} images should be deleted")
    
    # Save results
    results_file = OUTPUT_DIR / "sku_classification_results.json"
    results = {
        'tools': tools,
        'batteries': batteries,
        'chargers': chargers,
        'accessories': accessories,
        'unknown': unknown,
        'summary': {
            'total_skus': len(sku_list),
            'tools': len(tools),
            'tools_with_images': len(tools_have_images),
            'tools_missing_images': len(tools_missing_images),
            'batteries': len(batteries),
            'chargers': len(chargers),
            'accessories': len(accessories)
        }
    }
    
    with open(results_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    print(f"\n💾 Results saved to: {results_file}")

if __name__ == '__main__':
    main()
