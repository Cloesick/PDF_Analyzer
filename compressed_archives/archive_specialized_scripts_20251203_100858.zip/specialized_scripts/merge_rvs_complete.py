"""
Merge RVS Images and Properties
================================
Combine extracted images and properties with product data
"""
import json
from pathlib import Path
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
PRODUCTS_JSON = PROJECT_ROOT / "output" / "products_ready_for_webshop.json"
IMAGES_JSON = PROJECT_ROOT / "output" / "rvs_extracted_products.json"
PROPERTIES_JSON = PROJECT_ROOT / "output" / "rvs_properties_extracted.json"
OUTPUT_JSON = PROJECT_ROOT / "output" / "rvs_complete_products.json"

def merge_rvs():
    print("=" * 80)
    print("MERGING RVS DATA")
    print("=" * 80)
    
    # Load data
    print("\n📦 Loading data...")
    with open(PRODUCTS_JSON, 'r', encoding='utf-8') as f:
        all_products = json.load(f)
    
    with open(IMAGES_JSON, 'r', encoding='utf-8') as f:
        extracted_images = json.load(f)
    
    with open(PROPERTIES_JSON, 'r', encoding='utf-8') as f:
        extracted_properties = json.load(f)
    
    # Build mappings
    images_by_sku = defaultdict(list)
    for item in extracted_images:
        sku = item['sku']
        images_by_sku[sku].append(item)
    
    props_by_sku = {}
    for item in extracted_properties:
        sku = item['sku']
        props_by_sku[sku] = item
    
    rvs_products = [p for p in all_products if 'rvs-draadfittingen' in p.get('pdf_source', '').lower()]
    print(f"   {len(rvs_products)} RVS products")
    print(f"   {len(images_by_sku)} SKUs with images")
    print(f"   {len(props_by_sku)} SKUs with properties")
    
    # Merge
    print("\n🔗 Merging...")
    stats = {
        'image_matches': 0,
        'property_matches': 0,
        'complete': 0,
        'no_match': 0
    }
    
    updated_products = []
    for product in all_products:
        # Only process RVS products
        if 'rvs-draadfittingen' not in product.get('pdf_source', '').lower():
            updated_products.append(product)
            continue
        
        sku = product.get('sku', '')
        has_image = False
        has_props = False
        
        # Try to match image
        if sku in images_by_sku:
            images = images_by_sku[sku]
            # Use first image
            img = images[0]
            product['image_url'] = f"/product-images/rvs-draadfittingen/{img['image_filename']}"
            product['image_source'] = 'improved_extraction'
            product['image_quality'] = {
                'color_variance': img['color_variance'],
                'shared_skus': img['skus_in_image']
            }
            stats['image_matches'] += 1
            has_image = True
        
        # Try to match properties
        if sku in props_by_sku:
            props_data = props_by_sku[sku]
            product['extracted_properties'] = props_data['properties']
            product['raw_specifications'] = props_data.get('raw_specifications', [])
            
            if not product.get('attributes'):
                product['attributes'] = {}
            product['attributes'].update(props_data['properties'])
            
            if not product.get('specifications'):
                product['specifications'] = []
            for spec_str in props_data.get('raw_specifications', []):
                if ':' in spec_str:
                    key, val = spec_str.split(':', 1)
                    product['specifications'].append({
                        'key': key.strip(),
                        'value': val.strip()
                    })
            
            stats['property_matches'] += 1
            has_props = True
        
        # Track completeness
        if has_image and has_props:
            stats['complete'] += 1
        elif not has_image and not has_props:
            stats['no_match'] += 1
        
        updated_products.append(product)
    
    # Save
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(updated_products, f, indent=2, ensure_ascii=False)
    
    # Summary
    print("\n" + "=" * 80)
    print("MERGE COMPLETE")
    print("=" * 80)
    
    rvs_with_images = len([p for p in updated_products 
                          if 'rvs-draadfittingen' in p.get('pdf_source', '').lower() 
                          and p.get('image_url')])
    
    rvs_with_props = len([p for p in updated_products 
                         if 'rvs-draadfittingen' in p.get('pdf_source', '').lower() 
                         and p.get('extracted_properties')])
    
    rvs_complete = len([p for p in updated_products 
                       if 'rvs-draadfittingen' in p.get('pdf_source', '').lower() 
                       and p.get('image_url') and p.get('extracted_properties')])
    
    print(f"\n📊 Match Statistics:")
    print(f"   Image matches:        {stats['image_matches']}")
    print(f"   Property matches:     {stats['property_matches']}")
    print(f"   Complete (both):      {stats['complete']}")
    print(f"   No matches:           {stats['no_match']}")
    
    print(f"\n📈 Coverage:")
    print(f"   Total RVS products:            {len(rvs_products)}")
    print(f"   ✅ With images:                {rvs_with_images} ({rvs_with_images/len(rvs_products)*100:.1f}%)")
    print(f"   ✅ With properties:            {rvs_with_props} ({rvs_with_props/len(rvs_products)*100:.1f}%)")
    print(f"   🎯 Complete (image + props):   {rvs_complete} ({rvs_complete/len(rvs_products)*100:.1f}%)")
    
    # Sample
    complete_products = [p for p in updated_products 
                        if 'rvs-draadfittingen' in p.get('pdf_source', '').lower() 
                        and p.get('image_url') and p.get('extracted_properties')]
    
    if complete_products:
        print(f"\n🔍 Sample Complete Product:")
        sample = complete_products[0]
        print(f"   SKU: {sample.get('sku')}")
        print(f"   Name: {sample.get('name')}")
        print(f"   Image: ✅ {sample.get('image_url', '')[:50]}...")
        print(f"   Properties: {len(sample.get('extracted_properties', {}))} fields")
        print(f"   Sample props: {list(sample.get('extracted_properties', {}).keys())}")
    
    print(f"\n💾 Saved to: {OUTPUT_JSON}")
    
    print(f"\n✨ IMPROVEMENT:")
    print(f"   Before: 0% with images, 0% with properties")
    print(f"   After:  {rvs_with_images/len(rvs_products)*100:.1f}% with images, {rvs_with_props/len(rvs_products)*100:.1f}% with properties")
    print(f"   Complete: {rvs_complete/len(rvs_products)*100:.1f}% have both!")

if __name__ == '__main__':
    merge_rvs()
