"""
Find and replace B&W shape images with better colored versions from PDFs
"""
import os
import json
from pathlib import Path
from PIL import Image
import numpy as np
import cv2
import fitz  # PyMuPDF
from collections import defaultdict
import shutil

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ROOT = Path(__file__).parent
INPUT_PDFS = PROJECT_ROOT / "input_pdfs"
WEBSHOP_IMAGES = Path("C:/Users/prova/Documents/Projects/DemaWebshop/dema-webshop/public/product-images")
OUTPUT_IMAGES = PROJECT_ROOT / "product-images-improved"
CATALOG_PATH = Path("C:/Users/prova/Documents/Projects/DemaWebshop/dema-webshop/src/data/catalog_products.json")

IMAGE_DPI = 300
MIN_COLOR_VARIANCE = 15  # Threshold to detect if image is just B&W
MIN_IMAGE_AREA = 5000  # Minimum area for a good image

# ============================================================================
# IMAGE ANALYSIS
# ============================================================================

def is_black_white_shape(image_path):
    """
    Detect if an image is just a black and white shape (silhouette/outline)
    Returns True if the image has very low color variance (mostly B&W)
    """
    try:
        img = Image.open(image_path)
        if img.mode != 'RGB':
            img = img.convert('RGB')
        
        img_array = np.array(img)
        
        # Check color variance
        r, g, b = img_array[:,:,0], img_array[:,:,1], img_array[:,:,2]
        rg_diff = np.abs(r.astype(int) - g.astype(int))
        rb_diff = np.abs(r.astype(int) - b.astype(int))
        gb_diff = np.abs(g.astype(int) - b.astype(int))
        avg_diff = (rg_diff.mean() + rb_diff.mean() + gb_diff.mean()) / 3
        
        # If very low color variance, it's likely just B&W
        if avg_diff < MIN_COLOR_VARIANCE:
            # Check if it's mostly black/white (shape outline)
            gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
            unique_values = len(np.unique(gray))
            
            # If very few unique gray values, it's likely a simple shape
            if unique_values < 50:  # Very few shades = simple shape
                return True, avg_diff, unique_values
        
        return False, avg_diff, None
        
    except Exception as e:
        print(f"    ⚠️ Error analyzing {image_path}: {e}")
        return False, 0, None

def extract_images_from_pdf_page(pdf_path, page_num):
    """
    Extract all images from a specific PDF page
    Returns list of (image_data, bbox, quality_score)
    """
    images = []
    
    try:
        doc = fitz.open(pdf_path)
        page = doc[page_num - 1]  # 0-indexed
        
        image_list = page.get_images(full=True)
        
        for img_idx, img_info in enumerate(image_list):
            xref = img_info[0]
            
            try:
                base_image = doc.extract_image(xref)
                image_bytes = base_image["image"]
                image_ext = base_image["ext"]
                
                # Convert to PIL Image
                from io import BytesIO
                img = Image.open(BytesIO(image_bytes))
                
                # Convert to RGB if needed
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                
                # Calculate quality score (colored images score higher)
                img_array = np.array(img)
                r, g, b = img_array[:,:,0], img_array[:,:,1], img_array[:,:,2]
                rg_diff = np.abs(r.astype(int) - g.astype(int))
                rb_diff = np.abs(r.astype(int) - b.astype(int))
                gb_diff = np.abs(g.astype(int) - b.astype(int))
                color_variance = (rg_diff.mean() + rb_diff.mean() + gb_diff.mean()) / 3
                
                # Check if image is large enough
                width, height = img.size
                area = width * height
                
                if area < MIN_IMAGE_AREA:
                    continue
                
                # Quality score: higher color variance = better
                quality_score = color_variance * (area / 10000)
                
                images.append({
                    'image': img,
                    'area': area,
                    'color_variance': color_variance,
                    'quality_score': quality_score,
                    'width': width,
                    'height': height
                })
                
            except Exception as e:
                continue
        
        doc.close()
        
    except Exception as e:
        print(f"    ⚠️ Error extracting from {pdf_path}: {e}")
    
    return images

# ============================================================================
# MAIN PROCESSING
# ============================================================================

def main():
    print("=" * 80)
    print("FIND AND REPLACE B&W SHAPE IMAGES WITH COLORED VERSIONS")
    print("=" * 80)
    
    # Load catalog
    print(f"\n📂 Loading catalog...")
    with open(CATALOG_PATH, 'r', encoding='utf-8') as f:
        catalog = json.load(f)
    print(f"   ✓ {len(catalog)} products loaded")
    
    # Create output directory
    OUTPUT_IMAGES.mkdir(exist_ok=True, parents=True)
    
    # Analyze current images
    print(f"\n🔍 Analyzing current product images...")
    bw_shape_products = []
    total_checked = 0
    
    for product in catalog:
        # Get current image path
        image_url = product.get('imageUrl') or (product.get('media', [{}])[0].get('url') if product.get('media') else None)
        
        if not image_url:
            continue
        
        # Convert URL to file path
        if image_url.startswith('/product-images/'):
            image_path = WEBSHOP_IMAGES / image_url.replace('/product-images/', '')
        else:
            continue
        
        if not image_path.exists():
            continue
        
        total_checked += 1
        
        # Check if it's a B&W shape
        is_bw, color_var, unique_vals = is_black_white_shape(image_path)
        
        if is_bw:
            bw_shape_products.append({
                'product': product,
                'current_image': image_path,
                'color_variance': color_var,
                'unique_values': unique_vals
            })
            
            if len(bw_shape_products) <= 10:  # Show first 10
                print(f"   🔲 {product.get('sku'):15} - B&W shape (variance={color_var:.1f}, shades={unique_vals})")
    
    print(f"\n   Total images checked: {total_checked}")
    print(f"   B&W shapes found:     {len(bw_shape_products)} ({len(bw_shape_products)/max(1,total_checked)*100:.1f}%)")
    
    if not bw_shape_products:
        print(f"\n✅ No B&W shape images found! All images are already good quality.")
        return
    
    # Find better colored versions
    print(f"\n🎨 Searching for better colored versions in PDFs...")
    
    improved_count = 0
    backup_created = False
    
    for idx, item in enumerate(bw_shape_products[:50]):  # Process first 50 to start
        product = item['product']
        sku = product.get('sku')
        pdf_source = product.get('pdf_source')
        source_pages = product.get('source_pages', [])
        
        if not pdf_source or not source_pages:
            continue
        
        print(f"\n   [{idx+1}/{min(50, len(bw_shape_products))}] {sku} from {pdf_source}")
        
        # Get PDF path
        pdf_path = INPUT_PDFS / pdf_source
        if not pdf_path.exists():
            print(f"      ⚠️ PDF not found")
            continue
        
        # Search for colored images on the product's pages
        best_image = None
        best_score = 0
        
        for page_num in source_pages:
            page_images = extract_images_from_pdf_page(pdf_path, page_num)
            
            for img_data in page_images:
                if img_data['quality_score'] > best_score:
                    best_score = img_data['quality_score']
                    best_image = img_data
        
        # If we found a better image, save it
        if best_image and best_image['color_variance'] > item['color_variance'] * 2:  # At least 2x better
            print(f"      ✓ Found better image! (variance: {item['color_variance']:.1f} → {best_image['color_variance']:.1f})")
            
            # Create backup on first replacement
            if not backup_created:
                backup_path = CATALOG_PATH.parent / 'catalog_products_backup_images.json'
                shutil.copy(CATALOG_PATH, backup_path)
                print(f"\n      💾 Backup created: {backup_path.name}")
                backup_created = True
            
            # Save improved image
            pdf_name = pdf_source.replace('.pdf', '')
            output_dir = OUTPUT_IMAGES / pdf_name
            output_dir.mkdir(exist_ok=True, parents=True)
            
            output_filename = f"{sku}_improved.webp"
            output_path = output_dir / output_filename
            
            # Save as WebP
            best_image['image'].save(output_path, 'WEBP', quality=90)
            
            # Update catalog
            new_image_url = f"/product-images/{pdf_name}/{output_filename}"
            product['imageUrl'] = new_image_url
            
            # Update media array if it exists
            if product.get('media'):
                product['media'][0]['url'] = new_image_url
            
            improved_count += 1
            print(f"      💾 Saved: {output_path.name}")
        else:
            print(f"      ⚠️ No better image found")
    
    # Save updated catalog
    if improved_count > 0:
        print(f"\n💾 Saving updated catalog...")
        with open(CATALOG_PATH, 'w', encoding='utf-8') as f:
            json.dump(catalog, f, ensure_ascii=False, indent=2)
        print(f"   ✓ Catalog updated")
        
        # Copy improved images to webshop
        print(f"\n📦 Copying improved images to webshop...")
        for item in OUTPUT_IMAGES.rglob('*.webp'):
            relative_path = item.relative_to(OUTPUT_IMAGES)
            dest_path = WEBSHOP_IMAGES / relative_path
            dest_path.parent.mkdir(exist_ok=True, parents=True)
            shutil.copy(item, dest_path)
        print(f"   ✓ {improved_count} images copied")
    
    # Summary
    print(f"\n{'='*80}")
    print(f"✅ IMAGE IMPROVEMENT COMPLETE")
    print(f"{'='*80}")
    print(f"   B&W shapes found:      {len(bw_shape_products)}")
    print(f"   Images improved:       {improved_count}")
    print(f"   Images saved to:       {OUTPUT_IMAGES}")
    
    if improved_count > 0:
        print(f"\n💡 Next steps:")
        print(f"   1. Check the improved images in: {OUTPUT_IMAGES}")
        print(f"   2. Restart dev server to see updated images")
        print(f"   3. Run this script again to process more B&W images")

if __name__ == '__main__':
    main()
