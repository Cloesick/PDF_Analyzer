#!/usr/bin/env python3
"""
Convert the good catalogus-aandrijftechniek-150922.json data
to grouped format for aandrijftechniek-grouped catalog page
"""

import json
from pathlib import Path
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
SOURCE_FILE = PROJECT_ROOT.parent / "DemaWebshop" / "dema-webshop" / "public" / "data" / "catalogs" / "catalogus-aandrijftechniek-150922.json"
OUTPUT_FILE = PROJECT_ROOT / "output" / "catalogus_aandrijftechniek_150922_grouped.json"
WEBSHOP_FILE = PROJECT_ROOT.parent / "DemaWebshop" / "dema-webshop" / "public" / "data" / "catalogus_aandrijftechniek_150922_grouped.json"

print("="*80)
print("CONVERTING AANDRIJFTECHNIEK TO GROUPED FORMAT")
print("="*80)

# Load source data
print(f"\n📖 Loading: {SOURCE_FILE.name}")
with open(SOURCE_FILE, 'r', encoding='utf-8') as f:
    products = json.load(f)

print(f"✅ Loaded {len(products)} products")

# Group products by page
print(f"\n🔗 Grouping products by page...")
products_by_page = defaultdict(list)

for product in products:
    pages = product.get('source', {}).get('pages', [])
    if pages:
        # Use first page as primary page
        primary_page = pages[0]
        products_by_page[primary_page].append(product)

print(f"✅ Found products on {len(products_by_page)} pages")

# Create product groups
product_groups = []

for page, page_products in sorted(products_by_page.items()):
    # Get first product for group info
    first_product = page_products[0]
    
    # Create variants
    variants = []
    for product in page_products:
        variant = {
            'sku': product['sku'],
            'label': product.get('name', product['sku']),
            'page_in_pdf': page,
            'properties': {},
            'attributes': product.get('attributes', {}),
            'image_paths': product.get('image_paths', []),
            'imageUrl': product.get('imageUrl', '')
        }
        
        # Add specs as properties
        for spec in product.get('specs', []):
            if 'key' in spec and 'value' in spec:
                variant['properties'][spec['key']] = spec['value']
        
        variants.append(variant)
    
    # Create group
    group = {
        'group_id': f"aandrijftechniek_page{page}",
        'type': 'product_group',
        'catalog': 'catalogus-aandrijftechniek-150922',
        'name': f"Page {page} - {first_product.get('category', 'Products')} ({len(variants)} variants)",
        'page_in_pdf': page,
        'media': [],
        'common_properties': {},
        'variants': variants,
        'variant_count': len(variants),
        'default_variant_sku': variants[0]['sku'] if variants else None,
        'brand': first_product.get('brand', 'Various'),
        'category': first_product.get('category', 'Aandrijftechniek'),
        'description': f"Page {page} products from catalogus-aandrijftechniek-150922"
    }
    
    # Add media from first product
    if first_product.get('media'):
        group['media'] = first_product['media']
    elif first_product.get('imageUrl'):
        group['media'] = [{
            'url': first_product['imageUrl'],
            'role': 'main'
        }]
    
    product_groups.append(group)

print(f"\n✅ Created {len(product_groups)} product groups")
print(f"📊 Total variants: {sum(g['variant_count'] for g in product_groups)}")

# Calculate coverage
groups_with_images = sum(1 for g in product_groups if g.get('media'))
coverage = (groups_with_images / len(product_groups) * 100) if product_groups else 0
print(f"🖼️  Groups with images: {groups_with_images}/{len(product_groups)} ({coverage:.1f}%)")

# Save output
print(f"\n💾 Saving to: {OUTPUT_FILE.name}")
with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
    json.dump(product_groups, f, indent=2, ensure_ascii=False)

print(f"📤 Copying to webshop: {WEBSHOP_FILE.name}")
with open(WEBSHOP_FILE, 'w', encoding='utf-8') as f:
    json.dump(product_groups, f, indent=2, ensure_ascii=False)

print(f"\n{'='*80}")
print("✅ CONVERSION COMPLETE!")
print(f"{'='*80}")
print(f"\n📊 Summary:")
print(f"   • Input products: {len(products)}")
print(f"   • Output groups: {len(product_groups)}")
print(f"   • Image coverage: {coverage:.1f}%")
print(f"   • Ready for: /catalog/aandrijftechniek-grouped")
