#!/usr/bin/env python3
"""
Complete deployment for bronpompen catalog - same approach as aandrijftechniek.

Steps:
1. Copy and rename images from PDF extraction folders
2. Map all 574 SKUs to images based on page numbers
3. Enrich grouped data with properties
4. Deploy to webshop
"""

import json
import shutil
from pathlib import Path
from collections import defaultdict
import re

def deploy_bronpompen():
    """Complete deployment pipeline for bronpompen"""
    
    print(f"\n{'='*80}")
    print(f"COMPLETE BRONPOMPEN DEPLOYMENT")
    print(f"{'='*80}\n")
    
    # ===================
    # STEP 1: COPY IMAGES
    # ===================
    print(f"{'='*80}")
    print(f"STEP 1: COPYING AND RENAMING IMAGES")
    print(f"{'='*80}\n")
    
    # Source folders
    source_folders = [
        Path('product-images-by-pdf/digitale-versie-pompentoebehoren-compressed'),
        Path('product-images-by-pdf/bronpompen')
    ]
    
    # Destination folder
    dest_folder = Path('../DemaWebshop/dema-webshop/public/images/products/bronpompen')
    dest_folder.mkdir(parents=True, exist_ok=True)
    
    # Copy images with new naming
    images_copied = 0
    for source in source_folders:
        if not source.exists():
            print(f"⚠️  Source not found: {source}")
            continue
        
        source_images = list(source.glob('*.webp')) + list(source.glob('*.jpeg')) + list(source.glob('*.png')) + list(source.glob('*.jpg'))
        print(f"📁 Source: {source.name}")
        print(f"   Images: {len(source_images)}")
        
        for img in source_images:
            # Extract page number from filename (e.g., p023_img00.webp)
            match = re.search(r'p(\d+)_img(\d+)', img.name)
            if match:
                page = int(match.group(1))
                img_num = int(match.group(2))
                
                # New naming: catalogus-bronpompen_pXXX_imgYY.extension
                new_name = f"catalogus-bronpompen_p{page:03d}_img{img_num:02d}{img.suffix}"
                dest_path = dest_folder / new_name
                
                shutil.copy2(img, dest_path)
                images_copied += 1
                
                if images_copied <= 5:
                    print(f"   ✅ {img.name} → {new_name}")
        
        if len(source_images) > 5:
            print(f"   ... and {len(source_images) - 5} more")
        print()
    
    print(f"✅ Total images copied: {images_copied}\n")
    
    # ===================
    # STEP 2: LOAD DATA
    # ===================
    print(f"{'='*80}")
    print(f"STEP 2: LOADING PRODUCT DATA")
    print(f"{'='*80}\n")
    
    # Load smart extracted data (has properties and page numbers)
    smart_file = Path('output/bronpompen_smart_extracted.json')
    with open(smart_file, 'r', encoding='utf-8') as f:
        smart_data = json.load(f)
    
    print(f"📊 Loaded smart extracted: {len(smart_data)} products")
    
    # Load current grouped data
    grouped_file = Path('../DemaWebshop/dema-webshop/public/data/bronpompen_grouped.json')
    with open(grouped_file, 'r', encoding='utf-8') as f:
        grouped_data = json.load(f)
    
    print(f"📊 Loaded grouped data: {len(grouped_data)} groups")
    
    # Create SKU lookup from smart data
    sku_lookup = {item['sku']: item for item in smart_data if 'sku' in item}
    print(f"📊 SKU lookup created: {len(sku_lookup)} SKUs\n")
    
    # ===================
    # STEP 3: MAP IMAGES
    # ===================
    print(f"{'='*80}")
    print(f"STEP 3: MAPPING IMAGES TO SKUs")
    print(f"{'='*80}\n")
    
    # Get all images
    all_images = list(dest_folder.glob('catalogus-bronpompen_*.webp'))
    all_images += list(dest_folder.glob('catalogus-bronpompen_*.jpeg'))
    all_images += list(dest_folder.glob('catalogus-bronpompen_*.png'))
    all_images += list(dest_folder.glob('catalogus-bronpompen_*.jpg'))
    
    print(f"🖼️  Total images available: {len(all_images)}")
    
    # Parse images by page
    images_by_page = defaultdict(list)
    for img in all_images:
        match = re.search(r'_p(\d+)_img(\d+)', img.name)
        if match:
            page = int(match.group(1))
            img_num = int(match.group(2))
            
            images_by_page[page].append({
                'page': page,
                'img_num': img_num,
                'filename': img.name,
                'path': f"/images/products/bronpompen/{img.name}"
            })
    
    # Sort images by page and image number
    for page in images_by_page:
        images_by_page[page].sort(key=lambda x: x['img_num'])
    
    print(f"📄 Pages with images: {len(images_by_page)} pages")
    
    # Group SKUs by page from smart data
    skus_by_page = defaultdict(list)
    for item in smart_data:
        page = item.get('page_in_pdf')
        sku = item.get('sku')
        if page and sku:
            skus_by_page[page].append(sku)
    
    print(f"📄 Pages with products: {len(skus_by_page)} pages\n")
    
    # Create SKU → Image mapping
    sku_to_image = {}
    images_used = set()
    mapped_count = 0
    
    for page in sorted(skus_by_page.keys()):
        skus = skus_by_page[page]
        images = images_by_page.get(page, [])
        
        if not images:
            if len(skus) <= 3:
                print(f"⚠️  Page {page}: {len(skus)} SKUs, but NO images")
            continue
        
        if mapped_count < 50:  # Show first few pages
            print(f"📄 Page {page}: {len(skus)} SKUs, {len(images)} images")
        
        # Map SKUs to images (cycle if more SKUs than images)
        for i, sku in enumerate(skus):
            img_index = i % len(images)
            image_info = images[img_index]
            
            sku_to_image[sku] = image_info['path']
            images_used.add(image_info['filename'])
            mapped_count += 1
    
    print(f"\n{'='*80}")
    print(f"IMAGE MAPPING SUMMARY")
    print(f"{'='*80}\n")
    print(f"✅ Total SKUs mapped: {mapped_count}")
    print(f"✅ Unique images used: {len(images_used)}")
    print(f"📊 Total images available: {len(all_images)}")
    print(f"⚠️  Unused images: {len(all_images) - len(images_used)}")
    
    # Save image mapping
    mapping_file = Path('../DemaWebshop/dema-webshop/public/data/bronpompen_image_mapping.json')
    with open(mapping_file, 'w', encoding='utf-8') as f:
        json.dump(sku_to_image, f, indent=2, ensure_ascii=False)
    
    print(f"\n✅ Saved mapping: {mapping_file.name}\n")
    
    # ===================
    # STEP 4: ENRICH WITH PROPERTIES
    # ===================
    print(f"{'='*80}")
    print(f"STEP 4: ENRICHING WITH PROPERTIES")
    print(f"{'='*80}\n")
    
    enriched_count = 0
    for group in grouped_data:
        for variant in group.get('variants', []):
            sku = variant.get('sku')
            if sku and sku in sku_lookup:
                smart_product = sku_lookup[sku]
                
                # Copy properties
                properties = smart_product.get('properties', {})
                
                variant['properties'] = properties
                variant['attributes'] = properties
                
                # Copy other useful fields
                for field in ['brand', 'category', 'description', 'page_in_pdf']:
                    if field in smart_product:
                        variant[field] = smart_product[field]
                
                enriched_count += 1
    
    print(f"✅ Variants enriched: {enriched_count}\n")
    
    # Save enriched grouped data
    with open(grouped_file, 'w', encoding='utf-8') as f:
        json.dump(grouped_data, f, indent=2, ensure_ascii=False)
    
    print(f"✅ Saved enriched data: {grouped_file.name}\n")
    
    # ===================
    # FINAL SUMMARY
    # ===================
    print(f"{'='*80}")
    print(f"DEPLOYMENT COMPLETE - BRONPOMPEN")
    print(f"{'='*80}\n")
    
    total_variants = sum(len(g.get('variants', [])) for g in grouped_data)
    
    print(f"📊 Total Groups: {len(grouped_data)}")
    print(f"📊 Total Products: {total_variants}")
    print(f"📊 Products with Images: {mapped_count} ({mapped_count/total_variants*100:.1f}%)")
    print(f"📊 Products with Properties: {enriched_count} ({enriched_count/total_variants*100:.1f}%)")
    print(f"📊 Images Used: {len(images_used)} / {len(all_images)} ({len(images_used)/len(all_images)*100:.1f}%)")
    
    print(f"\n✅ Ready for deployment!")
    print(f"   Next: npm run build && npm start\n")
    
    return {
        'groups': len(grouped_data),
        'products': total_variants,
        'with_images': mapped_count,
        'with_properties': enriched_count,
        'images_used': len(images_used),
        'images_available': len(all_images)
    }

if __name__ == '__main__':
    result = deploy_bronpompen()
    
    print(f"{'='*80}")
    print(f"✨ BRONPOMPEN DEPLOYMENT SUCCESS!")
    print(f"{'='*80}")
    print(f"  • {result['products']} total products")
    print(f"  • {result['with_images']} with images ({result['with_images']/result['products']*100:.1f}%)")
    print(f"  • {result['with_properties']} with properties ({result['with_properties']/result['products']*100:.1f}%)")
    print(f"  • {result['images_used']}/{result['images_available']} images used")
    print(f"{'='*80}\n")
