#!/usr/bin/env python3
"""
Fix aandrijftechniek catalog images by creating proper mapping
between the unconventionally named images and product groups (tables).

Strategy: One image per product group/table, shared by all SKU variants.
Recommended naming: catalogus-aandrijftechniek_pXXX_GroupName.jpeg
"""

import json
import re
from pathlib import Path
from collections import defaultdict

def analyze_image_mapping():
    """Analyze the image naming and create group-based mapping"""
    
    # Load grouped products data (better structure for table-based mapping)
    grouped_file = Path('../DemaWebshop/dema-webshop/public/data/aandrijftechniek_grouped.json')
    if not grouped_file.exists():
        print(f"❌ Grouped data not found: {grouped_file}")
        return
    
    with open(grouped_file, 'r', encoding='utf-8') as f:
        product_groups = json.load(f)
    
    # Filter aandrijftechniek products
    aandrijf_products = [p for p in products if p.get('catalog') == 'catalogus-aandrijftechniek-150922']
    
    print(f"\n{'='*70}")
    print(f"AANDRIJFTECHNIEK IMAGE MAPPING ANALYSIS")
    print(f"{'='*70}\n")
    print(f"Total products in catalog: {len(aandrijf_products)}")
    
    # Group by page
    products_by_page = defaultdict(list)
    for p in aandrijf_products:
        pages = p.get('source_pages', [])
        if pages:
            page = pages[0]
            products_by_page[page].append(p)
    
    print(f"Pages with products: {len(products_by_page)}")
    
    # Analyze image URLs
    image_paths = set()
    page_image_mapping = defaultdict(set)
    
    for p in aandrijf_products:
        media = p.get('media', [])
        for m in media:
            url = m.get('url', '')
            if url:
                image_paths.add(url)
                # Extract page number from URL
                match = re.search(r'_p(\d+)_img(\d+)', url)
                if match:
                    page_num = int(match.group(1))
                    img_num = int(match.group(2))
                    page_image_mapping[page_num].add(img_num)
    
    print(f"Unique image URLs in data: {len(image_paths)}")
    print(f"\nSample image URLs from JSON data:")
    for url in list(image_paths)[:5]:
        print(f"  {url}")
    
    # Check what's actually in the webshop folder
    webshop_img_folder = Path('../DemaWebshop/dema-webshop/public/images/products/aandrijftechniek')
    if webshop_img_folder.exists():
        actual_files = list(webshop_img_folder.glob('*.*'))
        print(f"\n\nActual files in webshop folder: {len(actual_files)}")
        print(f"Sample actual filenames:")
        for f in actual_files[:10]:
            print(f"  {f.name}")
        
        # Parse actual filenames
        actual_pages = defaultdict(list)
        for f in actual_files:
            match = re.search(r'page(\d+)_img(\d+)', f.name)
            if match:
                page = int(match.group(1))
                img = int(match.group(2))
                actual_pages[page].append((img, f.name))
        
        print(f"\n\nActual pages with images: {sorted(actual_pages.keys())[:20]}")
        
        # Create mapping strategy
        print(f"\n{'='*70}")
        print(f"MAPPING STRATEGY")
        print(f"{'='*70}\n")
        
        print("Option 1: Map by page number")
        print("-" * 70)
        for page in sorted(actual_pages.keys())[:5]:
            if page in products_by_page:
                products_on_page = products_by_page[page]
                images_on_page = actual_pages[page]
                print(f"\nPage {page}:")
                print(f"  Products: {len(products_on_page)} -> SKUs: {[p.get('sku') for p in products_on_page[:3]]}")
                print(f"  Images: {len(images_on_page)} -> Files: {[img[1] for img in images_on_page[:3]]}")
        
        # Generate JSON mapping file for the webshop
        image_mapping = {}
        
        for page, images in actual_pages.items():
            if page in products_by_page:
                products_on_page = products_by_page[page]
                images_sorted = sorted(images, key=lambda x: x[0])
                
                # Map images to products on the same page
                for i, (img_num, filename) in enumerate(images_sorted):
                    if i < len(products_on_page):
                        product = products_on_page[i]
                        sku = product.get('sku')
                        if sku:
                            # Map the actual filename to the product
                            image_mapping[sku] = f"/images/products/aandrijftechniek/{filename}"
        
        # Save mapping
        mapping_file = Path('../DemaWebshop/dema-webshop/public/data/aandrijftechniek_image_mapping.json')
        mapping_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(mapping_file, 'w', encoding='utf-8') as f:
            json.dump(image_mapping, f, indent=2, ensure_ascii=False)
        
        print(f"\n✅ Created image mapping: {mapping_file}")
        print(f"   Mapped {len(image_mapping)} SKUs to images")
        
        # Show sample mappings
        print(f"\nSample mappings:")
        for sku, img_path in list(image_mapping.items())[:10]:
            print(f"  {sku} -> {img_path}")
    else:
        print(f"\n❌ Webshop folder not found: {webshop_img_folder}")
    
    print(f"\n{'='*70}\n")

if __name__ == '__main__':
    analyze_image_mapping()
