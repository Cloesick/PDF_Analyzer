"""
Extract aandrijftechniek product specifications from tables

ALL tables have the SAME fixed column structure (left to right):
    Column 0: SKU (e.g., RLNUCP204)
    Column 1: Diameter inside (mm)
    Column 2: Lower bearing (lagerhuis = bearing housing, e.g., P204)
    Column 3: Tension bearing (spanlager = pillow block bearing, e.g., UC204G2)

Shared properties appear ABOVE tables and apply to all products:
    - Temperature: min/max (e.g., -20°C to +100°C)
    - Type: bearing type (e.g., "staand lagerblok")
    - Application (toepassing): usage (e.g., "machinebouw, industrie")
"""
import fitz
import json
import re
from pathlib import Path
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "catalogus-aandrijftechniek-150922.pdf"
OUTPUT_JSON = PROJECT_ROOT / "output" / "aandrijftechniek_specs.json"

# Translation mappings
TRANSLATIONS = {
    'lagerhuis': 'bearing_housing',
    'spanlager': 'pillow_block_bearing',
    'toepassing': 'application',
    'type': 'type',
    'temperatuur': 'temperature',
    'min': 'min',
    'max': 'max',
    'diameter': 'diameter',
}

def extract_temperature(text):
    """Extract temperature range from text"""
    # Pattern: -20°C tot +120°C or similar
    pattern = r'(-?\d+)\s*°[CF]?\s*(?:tot|to|-)\s*([+]?\d+)\s*°[CF]?'
    match = re.search(pattern, text, re.IGNORECASE)
    if match:
        return {
            'min_temp_c': int(match.group(1)),
            'max_temp_c': int(match.group(2))
        }
    return None

def extract_type_and_application(text_block):
    """Extract type and application from text above table"""
    lines = text_block.split('\n')
    result = {}
    
    for line in lines:
        line_lower = line.lower()
        
        # Type
        if 'type' in line_lower and ':' in line:
            type_value = line.split(':', 1)[1].strip()
            if type_value:
                result['type'] = type_value
        
        # Application/Toepassing
        if 'toepassing' in line_lower or 'application' in line_lower:
            if ':' in line:
                app_value = line.split(':', 1)[1].strip()
                if app_value:
                    result['application'] = app_value
            else:
                # Sometimes it's on the next line
                idx = lines.index(line)
                if idx + 1 < len(lines):
                    result['application'] = lines[idx + 1].strip()
    
    return result

def parse_table_data(table, shared_props):
    """Parse table with fixed column structure:
    Column 0: SKU
    Column 1: Diameter inside (mm)
    Column 2: Lower bearing (lagerhuis/bearing housing)
    Column 3: Tension bearing (spanlager/pillow block bearing)
    """
    if not table or len(table) < 2:
        return []
    
    # Skip header row
    rows = table[1:] if len(table) > 1 else table
    
    products = []
    
    # Fixed column positions (left to right)
    SKU_COL = 0
    DIAMETER_COL = 1
    BEARING_HOUSING_COL = 2
    PILLOW_BLOCK_COL = 3
    
    # Extract products
    for row in rows:
        if not row or all(not cell for cell in row):
            continue
        
        # Column 0: SKU
        if len(row) <= SKU_COL:
            continue
        
        sku_val = str(row[SKU_COL]).strip()
        # Match patterns like RLNUCP204, P200, etc.
        if not re.match(r'^[A-Z]{1,}[A-Z0-9]{2,}$', sku_val):
            continue
        
        sku = sku_val
        
        # Build product data
        product = {
            'sku': sku,
            **shared_props  # Add temperature, type, application
        }
        
        # Column 1: Diameter inside (mm)
        if len(row) > DIAMETER_COL:
            diameter_str = str(row[DIAMETER_COL]).strip()
            # Extract number
            diameter_match = re.search(r'(\d+(?:[.,]\d+)?)', diameter_str)
            if diameter_match:
                diameter = float(diameter_match.group(1).replace(',', '.'))
                product['diameter_mm'] = diameter
                product['inner_diameter_mm'] = diameter  # It's the inside diameter
        
        # Column 2: Lower bearing / Bearing housing (lagerhuis)
        if len(row) > BEARING_HOUSING_COL:
            lagerhuis = str(row[BEARING_HOUSING_COL]).strip()
            if lagerhuis and lagerhuis != '-' and lagerhuis.lower() not in ['none', 'n/a', '']:
                product['bearing_housing'] = lagerhuis
        
        # Column 3: Tension bearing / Pillow block bearing (spanlager)
        if len(row) > PILLOW_BLOCK_COL:
            spanlager = str(row[PILLOW_BLOCK_COL]).strip()
            if spanlager and spanlager != '-' and spanlager.lower() not in ['none', 'n/a', '']:
                product['pillow_block_bearing'] = spanlager
        
        products.append(product)
    
    return products

def process_pdf():
    """Process aandrijftechniek PDF with table structure"""
    print("=" * 80)
    print("EXTRACTING AANDRIJFTECHNIEK SPECIFICATIONS")
    print("=" * 80)
    
    doc = fitz.open(PDF_PATH)
    
    all_products = []
    stats = {
        'pages_processed': 0,
        'tables_found': 0,
        'products_extracted': 0,
        'with_temperature': 0,
        'with_type': 0,
        'with_application': 0,
        'with_diameter': 0,
    }
    
    print(f"\n📄 Processing: {PDF_PATH.name}")
    print(f"   Total pages: {len(doc)}")
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        
        if (page_num + 1) % 20 == 0:
            print(f"   Processing page {page_num + 1}... ({stats['products_extracted']} products found)")
        
        stats['pages_processed'] += 1
        
        # Get page text for context (properties above tables)
        page_text = page.get_text()
        
        # Extract shared properties
        shared_props = {}
        
        # Temperature
        temp_data = extract_temperature(page_text)
        if temp_data:
            shared_props.update(temp_data)
            stats['with_temperature'] += 1
        
        # Type and Application
        type_app = extract_type_and_application(page_text)
        shared_props.update(type_app)
        if 'type' in shared_props:
            stats['with_type'] += 1
        if 'application' in shared_props:
            stats['with_application'] += 1
        
        # Add page number
        shared_props['page_in_pdf'] = page_num + 1
        
        # Extract tables
        try:
            tables = page.find_tables()
            for table in tables:
                stats['tables_found'] += 1
                extracted = table.extract()
                products = parse_table_data(extracted, shared_props)
                
                for product in products:
                    all_products.append(product)
                    stats['products_extracted'] += 1
                    
                    if 'diameter_mm' in product:
                        stats['with_diameter'] += 1
                    
                    if stats['products_extracted'] <= 10:
                        print(f"      ✓ {product['sku']:15} ", end='')
                        if 'diameter_mm' in product:
                            print(f"📏 {product['diameter_mm']}mm ", end='')
                        if 'min_temp_c' in product:
                            print(f"🌡️ {product['min_temp_c']}°C to {product['max_temp_c']}°C ", end='')
                        print()
        except:
            pass
    
    doc.close()
    
    # Save results
    OUTPUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(all_products, f, ensure_ascii=False, indent=2)
    
    # Statistics
    print(f"\n📊 EXTRACTION STATISTICS:")
    print(f"   Pages processed:           {stats['pages_processed']}")
    print(f"   Tables found:              {stats['tables_found']}")
    print(f"   Products extracted:        {stats['products_extracted']}")
    print(f"   With temperature range:    {stats['with_temperature']}")
    print(f"   With type:                 {stats['with_type']}")
    print(f"   With application:          {stats['with_application']}")
    print(f"   With diameter:             {stats['with_diameter']}")
    
    # Show samples
    print(f"\n📋 SAMPLE PRODUCTS:")
    for product in all_products[:5]:
        print(f"\n   SKU: {product['sku']}")
        for key, value in product.items():
            if key != 'sku':
                print(f"      {key:25} {value}")
    
    print(f"\n💾 Output saved to: {OUTPUT_JSON}")
    print(f"\n{'='*80}")
    print("✅ EXTRACTION COMPLETE")
    print("="*80)
    
    return all_products

if __name__ == '__main__':
    process_pdf()
