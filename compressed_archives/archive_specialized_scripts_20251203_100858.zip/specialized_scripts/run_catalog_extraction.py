#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Execute catalog extraction for all PDFs in input_pdfs folder.
"""

import os
import sys
import json
from pathlib import Path
from datetime import datetime

# Fix Windows console encoding
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

# Add the archive folder to path so we can import jsoncreator
sys.path.insert(0, str(Path(__file__).parent / 'output' / 'archive' / 'catalog_extractions'))

from jsoncreator import IndustrialExtractor

def main():
    """Process all PDFs in input_pdfs folder"""
    
    print(f"\n{'='*80}")
    print(f"CATALOG EXTRACTION - BATCH PROCESSING")
    print(f"{'='*80}\n")
    
    # Configuration
    INPUT_FOLDER = Path(r"C:\Users\prova\Documents\Projects\PDF_Analyzer\input_pdfs")
    OUTPUT_FILE = Path("output/DEMA_Complete_Catalog.json")
    
    # Get OpenAI API key
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("❌ ERROR: OPENAI_API_KEY environment variable not set!")
        print("\nPlease set it with:")
        print('  $env:OPENAI_API_KEY = "sk-your-key-here"  # PowerShell')
        print('  export OPENAI_API_KEY="sk-your-key-here"  # Bash')
        return
    
    # Initialize extractor
    print(f"🔧 Initializing IndustrialExtractor...")
    extractor = IndustrialExtractor(api_key=api_key)
    
    # Find all PDFs
    pdf_files = list(INPUT_FOLDER.glob("*.pdf"))
    
    if not pdf_files:
        print(f"❌ No PDF files found in: {INPUT_FOLDER}")
        return
    
    print(f"📁 Found {len(pdf_files)} PDF files in: {INPUT_FOLDER}\n")
    
    # Process all PDFs
    all_products = []
    processed_count = 0
    error_count = 0
    
    start_time = datetime.now()
    
    for i, pdf_path in enumerate(pdf_files, 1):
        print(f"\n{'='*80}")
        print(f"[{i}/{len(pdf_files)}] Processing: {pdf_path.name}")
        print(f"{'='*80}\n")
        
        try:
            items = extractor.process_pdf(str(pdf_path))
            all_products.extend(items)
            processed_count += 1
            
            print(f"\n✅ Extracted {len(items)} products from {pdf_path.name}")
            print(f"   Total products so far: {len(all_products)}")
            
        except Exception as e:
            error_count += 1
            print(f"\n❌ ERROR processing {pdf_path.name}: {e}")
            print(f"   Continuing with next file...")
    
    # Save results
    print(f"\n{'='*80}")
    print(f"SAVING RESULTS")
    print(f"{'='*80}\n")
    
    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
        # Convert Pydantic models to dicts
        products_dict = [p.dict() for p in all_products]
        json.dump(products_dict, f, indent=2, ensure_ascii=False)
    
    # Calculate processing time
    elapsed = datetime.now() - start_time
    
    # Final summary
    print(f"{'='*80}")
    print(f"EXTRACTION COMPLETE!")
    print(f"{'='*80}\n")
    print(f"📊 Statistics:")
    print(f"   • PDFs processed: {processed_count}/{len(pdf_files)}")
    print(f"   • Total products: {len(all_products)}")
    print(f"   • Errors: {error_count}")
    print(f"   • Time elapsed: {elapsed}")
    print(f"\n✅ Output saved to: {OUTPUT_FILE}")
    print(f"   File size: {OUTPUT_FILE.stat().st_size / 1024:.1f} KB\n")
    
    # Show sample by category
    if all_products:
        print(f"{'='*80}")
        print(f"CATEGORY BREAKDOWN")
        print(f"{'='*80}\n")
        
        categories = {}
        for product in all_products:
            cat = product.category
            categories[cat] = categories.get(cat, 0) + 1
        
        for category, count in sorted(categories.items(), key=lambda x: x[1], reverse=True):
            print(f"   • {category}: {count} products")
        print()

if __name__ == '__main__':
    main()
