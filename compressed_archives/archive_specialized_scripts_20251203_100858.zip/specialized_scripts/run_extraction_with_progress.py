#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Execute catalog extraction with real-time progress display.
"""

import os
import sys
import json
from pathlib import Path
from datetime import datetime

# Fix Windows console encoding
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

# Add the archive folder to path
sys.path.insert(0, str(Path(__file__).parent / 'output' / 'archive' / 'catalog_extractions'))

from jsoncreator import IndustrialExtractor

def print_flush(msg):
    """Print and immediately flush"""
    print(msg, flush=True)

def main():
    """Process all PDFs in input_pdfs folder"""
    
    print_flush(f"\n{'='*80}")
    print_flush(f"CATALOG EXTRACTION - BATCH PROCESSING")
    print_flush(f"{'='*80}\n")
    
    # Configuration
    INPUT_FOLDER = Path(r"C:\Users\prova\Documents\Projects\PDF_Analyzer\input_pdfs")
    OUTPUT_FILE = Path("output/DEMA_Complete_Catalog.json")
    PROGRESS_FILE = Path("output/extraction_progress.txt")
    
    # Get OpenAI API key
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print_flush("❌ ERROR: OPENAI_API_KEY environment variable not set!")
        print_flush("\nPlease set it with:")
        print_flush('  $env:OPENAI_API_KEY = "sk-your-key-here"  # PowerShell')
        return
    
    # Initialize extractor
    print_flush(f"🔧 Initializing IndustrialExtractor...")
    extractor = IndustrialExtractor(api_key=api_key)
    
    # Find all PDFs
    pdf_files = sorted(list(INPUT_FOLDER.glob("*.pdf")))
    
    if not pdf_files:
        print_flush(f"❌ No PDF files found in: {INPUT_FOLDER}")
        return
    
    print_flush(f"📁 Found {len(pdf_files)} PDF files\n")
    
    # Process all PDFs
    all_products = []
    processed_count = 0
    error_count = 0
    
    start_time = datetime.now()
    
    for i, pdf_path in enumerate(pdf_files, 1):
        print_flush(f"\n{'='*80}")
        print_flush(f"[{i}/{len(pdf_files)}] Processing: {pdf_path.name}")
        print_flush(f"{'='*80}")
        
        try:
            items = extractor.process_pdf(str(pdf_path))
            all_products.extend(items)
            processed_count += 1
            
            print_flush(f"\n✅ Extracted {len(items)} products from {pdf_path.name}")
            print_flush(f"   Total products so far: {len(all_products)}")
            
            # Save progress after each PDF
            with open(PROGRESS_FILE, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}] {pdf_path.name}: {len(items)} products (total: {len(all_products)})\n")
            
        except Exception as e:
            error_count += 1
            print_flush(f"\n❌ ERROR processing {pdf_path.name}: {e}")
            print_flush(f"   Continuing with next file...")
            
            with open(PROGRESS_FILE, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}] {pdf_path.name}: ERROR - {e}\n")
    
    # Save results
    print_flush(f"\n{'='*80}")
    print_flush(f"SAVING RESULTS")
    print_flush(f"{'='*80}\n")
    
    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
        # Convert Pydantic models to dicts
        products_dict = [p.dict() for p in all_products]
        json.dump(products_dict, f, indent=2, ensure_ascii=False)
    
    # Calculate processing time
    elapsed = datetime.now() - start_time
    
    # Final summary
    print_flush(f"{'='*80}")
    print_flush(f"EXTRACTION COMPLETE!")
    print_flush(f"{'='*80}\n")
    print_flush(f"📊 Statistics:")
    print_flush(f"   • PDFs processed: {processed_count}/{len(pdf_files)}")
    print_flush(f"   • Total products: {len(all_products)}")
    print_flush(f"   • Errors: {error_count}")
    print_flush(f"   • Time elapsed: {elapsed}")
    print_flush(f"\n✅ Output saved to: {OUTPUT_FILE}")
    print_flush(f"   File size: {OUTPUT_FILE.stat().st_size / 1024:.1f} KB\n")
    
    # Show sample by category
    if all_products:
        print_flush(f"{'='*80}")
        print_flush(f"CATEGORY BREAKDOWN")
        print_flush(f"{'='*80}\n")
        
        categories = {}
        for product in all_products:
            cat = product.category
            categories[cat] = categories.get(cat, 0) + 1
        
        for category, count in sorted(categories.items(), key=lambda x: x[1], reverse=True):
            print_flush(f"   • {category}: {count} products")
        print_flush("")

if __name__ == '__main__':
    main()
