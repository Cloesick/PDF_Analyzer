"""
Link Extracted Makita Images to Products
=========================================
Match the extracted images with products in the webshop JSON
"""
import json
from pathlib import Path
from collections import defaultdict
from difflib import SequenceMatcher

def similar(a, b):
    """Calculate similarity ratio between two strings"""
    return SequenceMatcher(None, a.upper(), b.upper()).ratio()

def find_fuzzy_match(sku, available_skus, threshold=0.75):
    """Find best fuzzy match for SKU (threshold lowered to 75%)"""
    best_match = None
    best_ratio = 0
    
    for candidate in available_skus:
        ratio = similar(sku, candidate)
        if ratio > best_ratio and ratio >= threshold:
            best_ratio = ratio
            best_match = candidate
    
    return best_match, best_ratio if best_match else (None, 0)

def find_base_sku_match(sku, available_skus):
    """Try to match SKU variants to base SKU (e.g., DHS680ZJ -> DHS680)"""
    # Try removing common suffixes
    suffixes = ['ZJ', 'ZK', 'RT', 'RTJ', 'TJ', 'Z', 'GZ', 'LZ', 'MP', 'G']
    
    for suffix in suffixes:
        if sku.endswith(suffix):
            base = sku[:-len(suffix)]
            if base in available_skus:
                return base, suffix
    
    return None, None

PROJECT_ROOT = Path(__file__).parent
PRODUCTS_JSON = PROJECT_ROOT / "output" / "products_ready_for_webshop.json"
EXTRACTED_JSON = PROJECT_ROOT / "output" / "makita_extracted_products.json"
CATALOG_NAME = "makita-catalogus-2022-nl"
IMAGES_FOLDER = PROJECT_ROOT / "product-images-by-pdf" / CATALOG_NAME
OUTPUT_JSON = PROJECT_ROOT / "output" / "products_with_makita_images.json"

def main():
    print("=" * 80)
    print("LINKING MAKITA IMAGES TO PRODUCTS")
    print("=" * 80)
    
    # Load data
    print("\n📦 Loading data...")
    with open(PRODUCTS_JSON, 'r', encoding='utf-8') as f:
        all_products = json.load(f)
    
    with open(EXTRACTED_JSON, 'r', encoding='utf-8') as f:
        extracted_images = json.load(f)
    
    # Filter Makita products
    makita_products = [p for p in all_products if 'makita-catalogus-2022-nl' in p.get('pdf_source', '')]
    print(f"   {len(makita_products)} Makita products")
    print(f"   {len(extracted_images)} extracted image entries")
    
    # Build SKU to image mapping
    print("\n🔗 Building SKU mappings...")
    sku_to_images = defaultdict(list)
    for entry in extracted_images:
        sku = entry['sku']
        sku_to_images[sku].append(entry)
    
    print(f"   {len(sku_to_images)} unique SKUs have images")
    
    # Link images to products
    print("\n🎯 Matching products to images...")
    stats = {
        'matched': 0,
        'unmatched': 0,
        'multiple_images': 0,
        'page_matches': 0,
        'sku_only_matches': 0,
        'fuzzy_matches': 0,
        'gallery_images_added': 0
    }
    
    updated_products = []
    for product in all_products:
        # Check if this is a Makita product
        if 'makita-catalogus-2022-nl' not in product.get('pdf_source', ''):
            updated_products.append(product)
            continue
        
        sku = product.get('sku', '')
        product_pages = product.get('source', {}).get('pages', [])
        
        # Try exact match first
        matched_sku = sku
        is_fuzzy = False
        
        if sku not in sku_to_images:
            # Try fuzzy matching (75% threshold)
            fuzzy_sku, ratio = find_fuzzy_match(sku, sku_to_images.keys())
            if fuzzy_sku and ratio >= 0.75:
                matched_sku = fuzzy_sku
                is_fuzzy = True
                stats['fuzzy_matches'] += 1
                print(f"   🔗 Fuzzy match: {sku} → {fuzzy_sku} ({ratio*100:.1f}% similar)")
            else:
                # Try base SKU matching
                base_sku, suffix = find_base_sku_match(sku, sku_to_images.keys())
                if base_sku:
                    matched_sku = base_sku
                    is_fuzzy = True
                    stats['fuzzy_matches'] += 1
                    print(f"   🔧 Base SKU match: {sku} → {base_sku} (removed suffix: {suffix})")
        
        # Try to find image for this SKU (exact or fuzzy)
        if matched_sku in sku_to_images:
            images = sku_to_images[matched_sku]
            
            # Prefer images from the same page
            best_image = None
            for img in images:
                if product_pages and img['page_num'] in product_pages:
                    best_image = img
                    stats['page_matches'] += 1
                    break
            
            # If no page match, just use the first image
            if not best_image:
                best_image = images[0]
                stats['sku_only_matches'] += 1
            
            # Update product with image (support multiple images)
            product['image_url'] = f"/product-images/{CATALOG_NAME}/{best_image['image_filename']}"
            product['image_source'] = 'improved_extraction'
            if is_fuzzy:
                product['fuzzy_matched_sku'] = matched_sku
            product['image_quality'] = {
                'color_variance': best_image['color_variance'],
                'from_ocr': best_image.get('from_ocr', False),
                'from_nearby': best_image.get('from_nearby', False),
                'shared_skus': best_image['skus_in_image']
            }
            
            # Add gallery images if multiple available
            if len(images) > 1:
                gallery_images = []
                for img in images[:5]:  # Max 5 images per product
                    if img != best_image:
                        gallery_images.append(f"/product-images/{CATALOG_NAME}/{img['image_filename']}")
                if gallery_images:
                    product['gallery_images'] = gallery_images
            
            stats['matched'] += 1
            if len(images) > 1:
                stats['multiple_images'] += 1
            if 'gallery_images' in product:
                stats['gallery_images_added'] += 1
        else:
            stats['unmatched'] += 1
        
        updated_products.append(product)
    
    # Save updated products
    print("\n💾 Saving updated products...")
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(updated_products, f, indent=2)
    
    # Print summary
    print("\n" + "=" * 80)
    print("LINKING COMPLETE")
    print("=" * 80)
    
    print(f"\n📊 Results:")
    print(f"   Total Makita products:     {len(makita_products)}")
    print(f"   ✅ Matched with images:    {stats['matched']} ({stats['matched']/len(makita_products)*100:.1f}%)")
    print(f"   ❌ Still no images:        {stats['unmatched']} ({stats['unmatched']/len(makita_products)*100:.1f}%)")
    print(f"\n🎯 Match Quality:")
    print(f"   Same page matches:         {stats['page_matches']}")
    print(f"   SKU-only matches:          {stats['sku_only_matches']}")
    print(f"   Fuzzy matches:             {stats['fuzzy_matches']}")
    print(f"   Products with multiple images: {stats['multiple_images']}")
    print(f"   Products with image galleries: {stats['gallery_images_added']}")
    
    # Show unmatched products
    print(f"\n❌ Sample Unmatched Products (SKUs not found in extraction):")
    unmatched_products = [p for p in makita_products if not p.get('image_url')]
    for i, prod in enumerate(unmatched_products[:20], 1):
        pages = prod.get('source_pages', [])
        page_str = f"p{pages[0]}" if pages else "?"
        print(f"   {i:2d}. {prod['sku']:15s} | {page_str:4s} | {prod.get('name', 'N/A')[:50]}")
    
    # Show available SKUs that aren't in products
    print(f"\n💡 Sample SKUs Found in Images but Not in Products:")
    product_skus = {p['sku'] for p in makita_products}
    extra_skus = set(sku_to_images.keys()) - product_skus
    for i, sku in enumerate(sorted(extra_skus)[:20], 1):
        images = sku_to_images[sku]
        print(f"   {i:2d}. {sku:15s} | Found in {len(images)} images")
    print(f"\n   Total SKUs in images but not in products: {len(extra_skus)}")
    
    print(f"\n💾 Updated products saved to: {OUTPUT_JSON}")
    print(f"\n✅ Coverage improved from 0% to {stats['matched']/len(makita_products)*100:.1f}%!")

if __name__ == '__main__':
    main()
