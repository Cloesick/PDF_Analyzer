#!/usr/bin/env python3
"""
Enhanced Property Extraction with Icons and Metadata
Extracts more exhaustive product properties and assigns appropriate icons
for better frontend rendering
"""

import json
import re
from pathlib import Path
from typing import Dict, List, Any, Optional

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"
WEBSHOP_DATA = PROJECT_ROOT.parent / "DemaWebshop" / "dema-webshop" / "public" / "data"

# Property icons and metadata mapping
PROPERTY_METADATA = {
    # Dimensions
    "diameter_mm": {"icon": "⌀", "label": "Diameter", "unit": "mm", "type": "dimension", "color": "blue"},
    "diameter_inch": {"icon": "⌀", "label": "Diameter", "unit": "inch", "type": "dimension", "color": "blue"},
    "length_m": {"icon": "📏", "label": "Length", "unit": "m", "type": "dimension", "color": "blue"},
    "length_mm": {"icon": "📏", "label": "Length", "unit": "mm", "type": "dimension", "color": "blue"},
    "width_mm": {"icon": "↔️", "label": "Width", "unit": "mm", "type": "dimension", "color": "blue"},
    "height_mm": {"icon": "↕️", "label": "Height", "unit": "mm", "type": "dimension", "color": "blue"},
    
    # Weight
    "weight_kg": {"icon": "⚖️", "label": "Weight", "unit": "kg", "type": "physical", "color": "purple"},
    "weight_g": {"icon": "⚖️", "label": "Weight", "unit": "g", "type": "physical", "color": "purple"},
    
    # Pressure
    "pressure_bar": {"icon": "💨", "label": "Pressure", "unit": "bar", "type": "performance", "color": "red"},
    "pressure_max_bar": {"icon": "💨", "label": "Max Pressure", "unit": "bar", "type": "performance", "color": "red"},
    "pressure_work_bar": {"icon": "💨", "label": "Working Pressure", "unit": "bar", "type": "performance", "color": "red"},
    
    # Temperature
    "temperature_max": {"icon": "🌡️", "label": "Max Temp", "unit": "°C", "type": "performance", "color": "orange"},
    "temperature_min": {"icon": "🌡️", "label": "Min Temp", "unit": "°C", "type": "performance", "color": "orange"},
    "temperature_range": {"icon": "🌡️", "label": "Temp Range", "unit": "°C", "type": "performance", "color": "orange"},
    
    # Power & Electrical
    "power_kw": {"icon": "⚡", "label": "Power", "unit": "kW", "type": "electrical", "color": "yellow"},
    "power_hp": {"icon": "⚡", "label": "Power", "unit": "HP", "type": "electrical", "color": "yellow"},
    "voltage_v": {"icon": "🔌", "label": "Voltage", "unit": "V", "type": "electrical", "color": "yellow"},
    "current_a": {"icon": "🔌", "label": "Current", "unit": "A", "type": "electrical", "color": "yellow"},
    
    # Flow & Capacity
    "flow_rate_lpm": {"icon": "💧", "label": "Flow Rate", "unit": "L/min", "type": "performance", "color": "cyan"},
    "flow_rate_m3h": {"icon": "💧", "label": "Flow Rate", "unit": "m³/h", "type": "performance", "color": "cyan"},
    "capacity_l": {"icon": "📦", "label": "Capacity", "unit": "L", "type": "performance", "color": "cyan"},
    "head_m": {"icon": "📈", "label": "Head", "unit": "m", "type": "performance", "color": "green"},
    "head_max_m": {"icon": "📈", "label": "Max Head", "unit": "m", "type": "performance", "color": "green"},
    
    # Speed & Rotation
    "rpm": {"icon": "🔄", "label": "RPM", "unit": "rpm", "type": "performance", "color": "indigo"},
    "rpm_max": {"icon": "🔄", "label": "Max RPM", "unit": "rpm", "type": "performance", "color": "indigo"},
    "speed": {"icon": "🔄", "label": "Speed", "unit": "", "type": "performance", "color": "indigo"},
    
    # Material
    "material": {"icon": "🔨", "label": "Material", "unit": "", "type": "material", "color": "gray"},
    "coating": {"icon": "🎨", "label": "Coating", "unit": "", "type": "material", "color": "gray"},
    "finish": {"icon": "✨", "label": "Finish", "unit": "", "type": "material", "color": "gray"},
    
    # Connections
    "connection": {"icon": "🔗", "label": "Connection", "unit": "", "type": "connection", "color": "teal"},
    "connection_type": {"icon": "🔗", "label": "Connection Type", "unit": "", "type": "connection", "color": "teal"},
    "thread": {"icon": "🧵", "label": "Thread", "unit": "", "type": "connection", "color": "teal"},
    "thread_size": {"icon": "🧵", "label": "Thread Size", "unit": "", "type": "connection", "color": "teal"},
    
    # Size
    "size": {"icon": "📐", "label": "Size", "unit": "", "type": "dimension", "color": "blue"},
    "size_inch": {"icon": "📐", "label": "Size", "unit": "inch", "type": "dimension", "color": "blue"},
    "size_mm": {"icon": "📐", "label": "Size", "unit": "mm", "type": "dimension", "color": "blue"},
    
    # Other
    "torque": {"icon": "🔩", "label": "Torque", "unit": "Nm", "type": "performance", "color": "red"},
    "efficiency": {"icon": "⚙️", "label": "Efficiency", "unit": "%", "type": "performance", "color": "green"},
    "noise_level": {"icon": "🔊", "label": "Noise Level", "unit": "dB", "type": "performance", "color": "orange"},
    "protection_class": {"icon": "🛡️", "label": "Protection", "unit": "", "type": "safety", "color": "green"},
    "color": {"icon": "🎨", "label": "Color", "unit": "", "type": "visual", "color": "purple"},
    "ph_range": {"icon": "🧪", "label": "pH Range", "unit": "", "type": "chemical", "color": "pink"},
}

def extract_enhanced_properties(product: Dict) -> Dict[str, Any]:
    """Extract properties with enhanced metadata"""
    enhanced = {}
    
    # Get all raw properties
    raw_props = {}
    
    # From direct properties
    for key, value in product.items():
        if key not in ['sku', 'id', 'name', 'catalog', 'category', 'description', 
                       'media', 'image_paths', 'imageUrl', 'variants', 'source', 
                       'pdf_source', 'source_pages', 'page_in_pdf']:
            if value is not None and value != '':
                raw_props[key] = value
    
    # From attributes
    if 'attributes' in product and isinstance(product['attributes'], dict):
        raw_props.update(product['attributes'])
    
    # From specs
    if 'specs' in product and isinstance(product['specs'], list):
        for spec in product['specs']:
            if isinstance(spec, dict) and 'label' in spec and 'value' in spec:
                if spec['value'] is not None and spec['value'] != '':
                    # Normalize label to snake_case
                    label_key = spec['label'].lower().replace(' ', '_').replace('-', '_')
                    raw_props[label_key] = spec['value']
    
    # Enhance properties with metadata
    for key, value in raw_props.items():
        if key in PROPERTY_METADATA:
            metadata = PROPERTY_METADATA[key]
            enhanced[key] = {
                "value": value,
                "icon": metadata["icon"],
                "label": metadata["label"],
                "unit": metadata["unit"],
                "type": metadata["type"],
                "color": metadata["color"],
                "display": f"{value}{' ' + metadata['unit'] if metadata['unit'] else ''}"
            }
        else:
            # Unknown property - still include with basic metadata
            enhanced[key] = {
                "value": value,
                "icon": "📋",
                "label": key.replace('_', ' ').title(),
                "unit": "",
                "type": "other",
                "color": "gray",
                "display": str(value)
            }
    
    return enhanced

def enhance_grouped_catalog(catalog_key: str) -> Optional[Dict]:
    """Enhance a grouped catalog with property metadata"""
    print(f"\n{'='*80}")
    print(f"ENHANCING: {catalog_key.upper()}")
    print(f"{'='*80}")
    
    # Load grouped data
    filename = f"{catalog_key.replace('-', '_')}_grouped.json"
    input_file = OUTPUT_DIR / filename
    
    if not input_file.exists():
        print(f"  ⚠️  File not found: {filename}")
        return None
    
    with open(input_file, 'r', encoding='utf-8') as f:
        groups = json.load(f)
    
    print(f"  📦 Loaded {len(groups)} groups")
    
    enhanced_groups = []
    total_props = 0
    
    for group in groups:
        # Enhance common properties
        if 'common_properties' in group and group['common_properties']:
            enhanced_common = {}
            for key, value in group['common_properties'].items():
                if key in PROPERTY_METADATA:
                    metadata = PROPERTY_METADATA[key]
                    enhanced_common[key] = {
                        "value": value,
                        "icon": metadata["icon"],
                        "label": metadata["label"],
                        "unit": metadata["unit"],
                        "type": metadata["type"],
                        "color": metadata["color"],
                        "display": f"{value}{' ' + metadata['unit'] if metadata['unit'] else ''}"
                    }
            
            group['common_properties_enhanced'] = enhanced_common
        
        # Enhance variant properties
        if 'variants' in group:
            for variant in group['variants']:
                if 'properties' in variant and variant['properties']:
                    enhanced_props = {}
                    for key, value in variant['properties'].items():
                        if key in PROPERTY_METADATA:
                            metadata = PROPERTY_METADATA[key]
                            enhanced_props[key] = {
                                "value": value,
                                "icon": metadata["icon"],
                                "label": metadata["label"],
                                "unit": metadata["unit"],
                                "type": metadata["type"],
                                "color": metadata["color"],
                                "display": f"{value}{' ' + metadata['unit'] if metadata['unit'] else ''}"
                            }
                            total_props += 1
                    
                    variant['properties_enhanced'] = enhanced_props
        
        enhanced_groups.append(group)
    
    print(f"  ✅ Enhanced {total_props} properties across all variants")
    
    # Save enhanced data
    output_file = OUTPUT_DIR / f"{catalog_key.replace('-', '_')}_grouped_enhanced.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(enhanced_groups, f, indent=2, ensure_ascii=False)
    
    print(f"  💾 Saved: {output_file.name}")
    
    # Copy to webshop
    webshop_file = WEBSHOP_DATA / f"{catalog_key.replace('-', '_')}_grouped.json"
    with open(webshop_file, 'w', encoding='utf-8') as f:
        json.dump(enhanced_groups, f, indent=2, ensure_ascii=False)
    
    print(f"  📤 Copied to webshop: {webshop_file.name}")
    
    return {
        'catalog': catalog_key,
        'groups': len(enhanced_groups),
        'properties_enhanced': total_props
    }

def main():
    print("="*80)
    print("PROPERTY ENHANCEMENT WITH ICONS AND METADATA")
    print("="*80)
    
    # Catalogs to enhance
    catalogs = [
        "bronpompen",
        "catalogus-aandrijftechniek-150922",
        "centrifugaalpompen",
        "digitale-versie-pompentoebehoren-compressed",
        "dompelpompen",
        "drukbuizen",
        "kunststof-afvoerleidingen",
        "messing-draadfittingen"
    ]
    
    results = []
    for catalog in catalogs:
        result = enhance_grouped_catalog(catalog)
        if result:
            results.append(result)
    
    print(f"\n{'='*80}")
    print("SUMMARY")
    print(f"{'='*80}\n")
    
    if results:
        print(f"{'Catalog':<45s} {'Groups':<8s} {'Props Enhanced':<15s}")
        print("-" * 80)
        for r in results:
            print(f"{r['catalog']:<45s} {r['groups']:<8d} {r['properties_enhanced']:<15d}")
        
        total_groups = sum(r['groups'] for r in results)
        total_props = sum(r['properties_enhanced'] for r in results)
        
        print("-" * 80)
        print(f"{'TOTAL':<45s} {total_groups:<8d} {total_props:<15d}")
    
    print(f"\n{'='*80}")
    print(f"✅ COMPLETE - Enhanced {len(results)} catalogs")
    print(f"{'='*80}")
    
    print("\n📝 Property Metadata Categories:")
    categories = {}
    for prop, meta in PROPERTY_METADATA.items():
        cat = meta['type']
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(f"{meta['icon']} {meta['label']}")
    
    for category, props in sorted(categories.items()):
        print(f"\n  {category.upper()}:")
        for prop in sorted(props)[:5]:  # Show first 5
            print(f"    - {prop}")
        if len(props) > 5:
            print(f"    ... and {len(props) - 5} more")
    
    print(f"\n🎨 Enhanced properties now include:")
    print("   - Icon for visual representation")
    print("   - Label for display")
    print("   - Unit for measurements")
    print("   - Type for categorization")
    print("   - Color for UI styling")
    print("   - Display string (formatted)")

if __name__ == "__main__":
    main()
