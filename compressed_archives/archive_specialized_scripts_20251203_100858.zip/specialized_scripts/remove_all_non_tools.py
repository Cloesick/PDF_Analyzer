"""
Remove ALL battery, charger, and accessory images from Makita folders
This is a comprehensive cleanup based on the user's explicit list
"""
import os
import shutil
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
IMAGE_DIR = PROJECT_ROOT / "product-images-by-pdf"

# User's explicit list of problematic SKUs
PROBLEMATIC_SKUS = [
    # Batteries
    'BL4020', 'BL4025', 'BL4040', 'BL4050F', 'BL4050', 'BL4080F', 'BL4',
    'BL1860B', 'BL1840B', 'BL1830B', 'BL1850', 'BL1840', 'BL18', 'BL1188',
    'BL11883', 'BL11', 'BL1188550B', 'L118830B',
    'BBLL11886600BB', 'BBLL11885500BB', 'BBLL11884400BB', 'BBLL11883300BB',
    
    # Chargers
    'DC40RA', 'DC40RB', 'DC40', 'DC18R', 'DC18RD', 'DC18RE', 'DC18', 'DC18RC',
    'DC11',
    
    # Adapters
    'ADPOO1', 'ADP10', 'DEAADP001G', 'AD88', 'BEAPDC1200A01',
    
    # Accessories and misc
    'AR04CD', 'N09-8', 'IPX4', 'B36-3', 'B18', 'RC30B', 'PL11', 'PDC01',
    'ER55', 'BPS01', 'K18', 'AA8720-9',
    
    # Numeric codes (likely accessories)
    '81-6', '198720-9', '19077-8', '198091-4', '198116-4', '198170-8',
    '197629-2', '197626-8', '197624', '197594-9', '197422-4', '933-6',
    '624-2', '077-8', '94-9', '80-8', '56169', '54329', '36179', '19693',
    '7-8', '720-9', '091-4', '84-2', '8720-9', '8091-4', 'D201',
]

# Additional patterns to catch variations
PROBLEMATIC_PATTERNS = [
    'BL1', 'BL4', 'DC1', 'DC4', 'ADP', 'BEAPDC', 
    # Single/double letter-number combos (accessories)
    r'^\d+-\d+$', r'^\d+$', r'^[A-Z]\s*\d+$', r'^[A-Z]{2}\s*\d+$'
]

def is_problematic_sku(filename):
    """Check if filename contains problematic SKU"""
    # Get SKU from filename (remove extension and path)
    name = Path(filename).stem
    
    # Check exact matches
    for sku in PROBLEMATIC_SKUS:
        sku_clean = sku.replace(' ', '').replace('-', '').upper()
        name_clean = name.replace(' ', '').replace('-', '').replace('_', '').upper()
        
        if sku_clean in name_clean:
            return True, sku
    
    # Check patterns
    name_upper = name.upper()
    
    # Battery patterns
    if any(pattern in name_upper for pattern in ['BL1', 'BL4', 'BL6']):
        if not any(tool in name_upper for tool in ['DLM', 'DTM', 'DWM']):  # Not a tool model
            return True, 'Battery pattern'
    
    # Charger patterns
    if any(pattern in name_upper for pattern in ['DC1', 'DC2', 'DC3', 'DC4', 'DC6']):
        if not any(tool in name_upper for tool in ['DHS', 'DDF', 'DHR']):  # Not a tool model
            return True, 'Charger pattern'
    
    # Adapter patterns
    if 'ADP' in name_upper or 'ADAPTER' in name_upper:
        return True, 'Adapter pattern'
    
    return False, None

def cleanup_makita_folders():
    """Remove all non-tool images from Makita folders"""
    
    print("="*80)
    print("COMPREHENSIVE MAKITA CLEANUP - REMOVE ALL NON-TOOLS")
    print("="*80)
    
    catalogs = [
        'makita-catalogus-2022-nl',
        'makita-tuinfolder-2022-nl'
    ]
    
    total_removed = 0
    total_kept = 0
    removed_by_catalog = {}
    
    # Create removal backup folder
    backup_dir = PROJECT_ROOT / "removed-non-tools-final"
    backup_dir.mkdir(exist_ok=True)
    
    for catalog in catalogs:
        catalog_dir = IMAGE_DIR / catalog
        
        if not catalog_dir.exists():
            print(f"\n[SKIP] {catalog} - folder not found")
            continue
        
        print(f"\n{'='*80}")
        print(f"CLEANING: {catalog}")
        print(f"{'='*80}")
        
        # Get all images
        all_images = list(catalog_dir.glob('*.webp')) + list(catalog_dir.glob('*.jpg')) + list(catalog_dir.glob('*.png'))
        
        print(f"\nFound {len(all_images)} images")
        print(f"Checking against {len(PROBLEMATIC_SKUS)} problematic SKUs...")
        
        removed = []
        kept = []
        
        for img_path in all_images:
            is_bad, reason = is_problematic_sku(img_path.name)
            
            if is_bad:
                # Remove this image
                backup_path = backup_dir / catalog / img_path.name
                backup_path.parent.mkdir(parents=True, exist_ok=True)
                
                shutil.move(str(img_path), str(backup_path))
                removed.append((img_path.name, reason))
                total_removed += 1
            else:
                kept.append(img_path.name)
                total_kept += 1
        
        removed_by_catalog[catalog] = len(removed)
        
        # Show results
        print(f"\n✅ RESULTS:")
        print(f"  Removed: {len(removed)}")
        print(f"  Kept: {len(kept)}")
        
        if removed:
            print(f"\n❌ REMOVED IMAGES (first 20):")
            for name, reason in removed[:20]:
                print(f"  - {name} (matched: {reason})")
            
            if len(removed) > 20:
                print(f"  ... and {len(removed) - 20} more")
        
        if kept:
            print(f"\n✅ KEPT IMAGES (first 20):")
            for name in kept[:20]:
                print(f"  - {name}")
            
            if len(kept) > 20:
                print(f"  ... and {len(kept) - 20} more")
    
    # Final summary
    print("\n" + "="*80)
    print("CLEANUP COMPLETE")
    print("="*80)
    print(f"\nTotal images removed: {total_removed}")
    print(f"Total images kept: {total_kept}")
    
    for catalog, count in removed_by_catalog.items():
        print(f"  {catalog}: {count} removed")
    
    print(f"\n📁 Removed images backed up to: {backup_dir}")
    
    # Verify problematic SKUs are gone
    print("\n" + "="*80)
    print("VERIFICATION")
    print("="*80)
    
    remaining_bad = []
    
    for catalog in catalogs:
        catalog_dir = IMAGE_DIR / catalog
        if not catalog_dir.exists():
            continue
        
        for img_path in catalog_dir.glob('*'):
            is_bad, reason = is_problematic_sku(img_path.name)
            if is_bad:
                remaining_bad.append((catalog, img_path.name, reason))
    
    if remaining_bad:
        print(f"\n⚠️ WARNING: {len(remaining_bad)} problematic images still remain:")
        for catalog, name, reason in remaining_bad[:10]:
            print(f"  - {catalog}/{name} ({reason})")
    else:
        print(f"\n✅ SUCCESS: NO problematic images found!")
        print(f"✅ All batteries, chargers, and accessories removed!")
        print(f"✅ Only actual power tools remain!")

if __name__ == '__main__':
    cleanup_makita_folders()
