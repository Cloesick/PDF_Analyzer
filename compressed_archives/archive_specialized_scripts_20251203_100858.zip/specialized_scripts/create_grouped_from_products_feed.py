#!/usr/bin/env python3
"""
Create grouped catalog data from existing products feed
Uses the same structure as /products page but organizes into product groups
"""

import json
from pathlib import Path
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
PRODUCTS_FILE = PROJECT_ROOT.parent / "DemaWebshop" / "dema-webshop" / "public" / "data" / "products_for_shop.json"
EXTRACTION_DIR = PROJECT_ROOT / "output" / "archive" / "catalog_extractions"
OUTPUT_DIR = PROJECT_ROOT / "output"
WEBSHOP_DATA = PROJECT_ROOT.parent / "DemaWebshop" / "dema-webshop" / "public" / "data"

# Catalogs to process
TARGET_CATALOGS = [
    "pu-afzuigslangen",
    "slangkoppelingen",
    "slangklemmen"
]

def extract_properties(product):
    """Extract all properties from a product"""
    props = {}
    
    # From attributes
    if 'attributes' in product and isinstance(product['attributes'], dict):
        props.update(product['attributes'])
    
    # From specs
    if 'specs' in product and isinstance(product['specs'], list):
        for spec in product['specs']:
            if isinstance(spec, dict) and 'label' in spec and 'value' in spec:
                props[spec['label']] = spec['value']
    
    # Common fields to extract
    for key in ['diameter', 'diameter_mm', 'length', 'length_m', 'width', 'height', 
                'weight', 'weight_kg', 'pressure', 'pressure_bar', 'material', 
                'connection', 'thread', 'size', 'temperature']:
        if key in product:
            props[key] = product[key]
    
    return props

def get_image_url(product):
    """Extract the main image URL"""
    # Try imageUrl first
    if 'imageUrl' in product and product['imageUrl']:
        return product['imageUrl']
    
    # Try media array
    if 'media' in product and isinstance(product['media'], list):
        for media in product['media']:
            if isinstance(media, dict) and media.get('role') == 'main':
                return media.get('url')
    
    # Try image_paths
    if 'image_paths' in product and isinstance(product['image_paths'], list) and product['image_paths']:
        return product['image_paths'][0]
    
    return None

def group_products_by_image_and_page(products):
    """Group products that share the same image and page"""
    groups = defaultdict(list)
    
    for product in products:
        image_url = get_image_url(product)
        page = product.get('page_in_pdf') or product.get('source_pages', [0])[0]
        
        # Group by image + page
        key = f"{image_url}_{page}"
        groups[key].append(product)
    
    return groups

def create_product_group(products, catalog, group_index):
    """Create a product group from multiple products"""
    if not products:
        return None
    
    # Get common data from first product
    first = products[0]
    image_url = get_image_url(first)
    page = first.get('page_in_pdf') or first.get('source_pages', [0])[0]
    
    # Extract properties from all products to find common vs variant
    all_props = [extract_properties(p) for p in products]
    
    # Find common properties (same value across all products)
    common_props = {}
    variant_props = set()
    
    if all_props:
        first_props = all_props[0]
        for key, value in first_props.items():
            if all(props.get(key) == value for props in all_props):
                common_props[key] = value
            else:
                variant_props.add(key)
    
    # Create variants
    variants = []
    for product in products:
        props = extract_properties(product)
        
        # Variant-specific properties
        var_props = {k: v for k, v in props.items() if k in variant_props}
        
        variant = {
            "sku": product.get('sku', product.get('id', 'UNKNOWN')),
            "label": product.get('name') or product.get('sku', 'Product'),
            "properties": var_props,
            "attributes": var_props,  # Duplicate for compatibility
            "page_in_pdf": page
        }
        variants.append(variant)
    
    # Determine group name
    if len(variants) == 1:
        group_name = variants[0]['sku']
    else:
        # Try to find common prefix
        skus = [v['sku'] for v in variants]
        prefix = ""
        if skus:
            min_len = min(len(s) for s in skus)
            for i in range(min_len):
                if all(s[i] == skus[0][i] for s in skus):
                    prefix += skus[0][i]
                else:
                    break
        
        if prefix and len(prefix) >= 3:
            group_name = f"{prefix} Series"
        else:
            group_name = f"{catalog.title()} Products"
    
    # Create group
    group = {
        "group_id": f"page{page}_group{group_index}",
        "type": "product_group",
        "catalog": catalog,
        "name": group_name,
        "page_in_pdf": page,
        "media": [],
        "common_properties": common_props,
        "variants": variants,
        "variant_count": len(variants),
        "default_variant_sku": variants[0]['sku'] if variants else None,
        "brand": "Dema",
        "description": f"{group_name} - Available in {len(variants)} variant{'s' if len(variants) > 1 else ''}"
    }
    
    # Add image
    if image_url:
        group["media"] = [{
            "url": image_url.lstrip('/'),  # Remove leading slash
            "role": "main"
        }]
    
    return group

def process_catalog(catalog_key, all_products):
    """Process a single catalog"""
    print(f"\n{'='*80}")
    print(f"PROCESSING: {catalog_key.upper()}")
    print(f"{'='*80}")
    
    # Try to load from extraction file first (has full properties)
    extraction_file = EXTRACTION_DIR / f"{catalog_key.replace('-', '_')}_dynamic.json"
    
    if extraction_file.exists():
        print(f"📖 Loading from extraction file: {extraction_file.name}")
        with open(extraction_file, 'r', encoding='utf-8') as f:
            catalog_products = json.load(f)
        print(f"📦 Loaded {len(catalog_products)} products with full properties")
    else:
        # Fallback to products feed
        catalog_products = [
            p for p in all_products 
            if p.get('catalog') == catalog_key or 
               p.get('pdf_source', '').startswith(catalog_key) or
               catalog_key in p.get('id', '')
        ]
        
        if not catalog_products:
            print(f"⚠️  No products found for {catalog_key}")
            return None
        
        print(f"📦 Found {len(catalog_products)} products from feed")
    
    # Group by image and page
    grouped = group_products_by_image_and_page(catalog_products)
    print(f"🔗 Created {len(grouped)} groups")
    
    # Create product groups
    product_groups = []
    for idx, (key, products) in enumerate(grouped.items(), 1):
        group = create_product_group(products, catalog_key, idx)
        if group:
            product_groups.append(group)
    
    print(f"✅ Generated {len(product_groups)} product groups")
    print(f"   Total variants: {sum(g['variant_count'] for g in product_groups)}")
    
    # Save to output
    output_file = OUTPUT_DIR / f"{catalog_key.replace('-', '_')}_grouped.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(product_groups, f, indent=2, ensure_ascii=False)
    print(f"💾 Saved to: {output_file}")
    
    # Copy to webshop
    webshop_file = WEBSHOP_DATA / f"{catalog_key.replace('-', '_')}_grouped.json"
    with open(webshop_file, 'w', encoding='utf-8') as f:
        json.dump(product_groups, f, indent=2, ensure_ascii=False)
    print(f"📋 Copied to: {webshop_file}")
    
    # Show sample
    if product_groups:
        print(f"\n📦 Sample Group:")
        sample = product_groups[0]
        print(f"   Name: {sample['name']}")
        print(f"   Variants: {sample['variant_count']}")
        print(f"   SKUs: {', '.join(v['sku'] for v in sample['variants'][:3])}")
        if len(sample['variants']) > 3:
            print(f"         ... and {len(sample['variants']) - 3} more")
    
    return product_groups

def main():
    print("="*80)
    print("CREATE GROUPED DATA FROM PRODUCTS FEED")
    print("="*80)
    
    # Load products
    print(f"\n📖 Loading products from: {PRODUCTS_FILE}")
    
    if not PRODUCTS_FILE.exists():
        print(f"❌ Products file not found!")
        return
    
    with open(PRODUCTS_FILE, 'r', encoding='utf-8') as f:
        all_products = json.load(f)
    
    print(f"✅ Loaded {len(all_products)} products")
    
    # Process each catalog
    results = {}
    for catalog in TARGET_CATALOGS:
        groups = process_catalog(catalog, all_products)
        if groups:
            results[catalog] = groups
    
    # Summary
    print(f"\n{'='*80}")
    print("SUMMARY")
    print(f"{'='*80}")
    
    for catalog, groups in results.items():
        total_variants = sum(g['variant_count'] for g in groups)
        print(f"\n✓ {catalog}")
        print(f"   Groups: {len(groups)}")
        print(f"   Variants: {total_variants}")
    
    print(f"\n{'='*80}")
    print(f"✅ Complete! Processed {len(results)}/{len(TARGET_CATALOGS)} catalogs")
    print(f"{'='*80}")
    print("\n⚠️  IMPORTANT: Rebuild the frontend:")
    print("   cd ../DemaWebshop/dema-webshop")
    print("   npm run build")
    print("   npm run start")

if __name__ == "__main__":
    main()
