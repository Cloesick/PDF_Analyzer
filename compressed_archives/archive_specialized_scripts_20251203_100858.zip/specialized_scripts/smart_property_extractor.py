#!/usr/bin/env python3
"""
Smart Property Extractor - Advanced PDF Property Parsing

Intelligently extracts product properties from PDF tables with:
- Advanced header detection and mapping
- Multi-unit support (automatic conversion)
- Complex property parsing (ranges, dimensions, connections)
- Context-aware property identification
- Intelligent SKU detection
"""

import re
import json
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path

# Comprehensive property mapping with multiple variations and parsers
COMPREHENSIVE_PROPERTY_MAP = {
    # SKU / Product Code
    'bestelnr': {'property': 'sku', 'type': 'identifier', 'parser': 'sku'},
    'code': {'property': 'sku', 'type': 'identifier', 'parser': 'sku'},
    'artikelnr': {'property': 'sku', 'type': 'identifier', 'parser': 'sku'},
    'artikel': {'property': 'sku', 'type': 'identifier', 'parser': 'sku'},
    'art': {'property': 'sku', 'type': 'identifier', 'parser': 'sku'},
    'item': {'property': 'sku', 'type': 'identifier', 'parser': 'sku'},
    'product code': {'property': 'sku', 'type': 'identifier', 'parser': 'sku'},
    
    # Dimensions - Diameter
    'diameter': {'property': 'diameter_mm', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'mm'},
    'dia': {'property': 'diameter_mm', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'mm'},
    'ø': {'property': 'diameter_mm', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'mm'},
    'binnen dia': {'property': 'inner_diameter_mm', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'mm'},
    'id': {'property': 'inner_diameter_mm', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'mm'},
    'buiten dia': {'property': 'outer_diameter_mm', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'mm'},
    'od': {'property': 'outer_diameter_mm', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'mm'},
    'maat': {'property': 'size', 'type': 'dimension', 'parser': 'size'},
    'maten': {'property': 'dimensions', 'type': 'dimension', 'parser': 'dimensions'},
    'afmeting': {'property': 'dimensions', 'type': 'dimension', 'parser': 'dimensions'},
    
    # Dimensions - Length
    'lengte': {'property': 'length_m', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'm'},
    'length': {'property': 'length_m', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'm'},
    'rollengte': {'property': 'roll_length_m', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'm'},
    'l': {'property': 'length_mm', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'mm'},
    
    # Dimensions - Width/Height
    'breedte': {'property': 'width_mm', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'mm'},
    'width': {'property': 'width_mm', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'mm'},
    'hoogte': {'property': 'height_mm', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'mm'},
    'height': {'property': 'height_mm', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'mm'},
    'h': {'property': 'height_mm', 'type': 'dimension', 'parser': 'dimension', 'default_unit': 'mm'},
    
    # Pressure
    'werkdruk': {'property': 'pressure_work_bar', 'type': 'pressure', 'parser': 'pressure', 'default_unit': 'bar'},
    'working pressure': {'property': 'pressure_work_bar', 'type': 'pressure', 'parser': 'pressure', 'default_unit': 'bar'},
    'barstdruk': {'property': 'pressure_burst_bar', 'type': 'pressure', 'parser': 'pressure', 'default_unit': 'bar'},
    'burst pressure': {'property': 'pressure_burst_bar', 'type': 'pressure', 'parser': 'pressure', 'default_unit': 'bar'},
    'max druk': {'property': 'pressure_max_bar', 'type': 'pressure', 'parser': 'pressure', 'default_unit': 'bar'},
    'max pressure': {'property': 'pressure_max_bar', 'type': 'pressure', 'parser': 'pressure', 'default_unit': 'bar'},
    'druk': {'property': 'pressure_bar', 'type': 'pressure', 'parser': 'pressure', 'default_unit': 'bar'},
    'pressure': {'property': 'pressure_bar', 'type': 'pressure', 'parser': 'pressure', 'default_unit': 'bar'},
    
    # Temperature
    'temperatuur': {'property': 'temperature_max', 'type': 'temperature', 'parser': 'temperature', 'default_unit': '°C'},
    'temperature': {'property': 'temperature_max', 'type': 'temperature', 'parser': 'temperature', 'default_unit': '°C'},
    'max temp': {'property': 'temperature_max', 'type': 'temperature', 'parser': 'temperature', 'default_unit': '°C'},
    'min temp': {'property': 'temperature_min', 'type': 'temperature', 'parser': 'temperature', 'default_unit': '°C'},
    'temp bereik': {'property': 'temperature_range', 'type': 'temperature', 'parser': 'range'},
    
    # Weight
    'gewicht': {'property': 'weight_kg', 'type': 'weight', 'parser': 'weight', 'default_unit': 'kg'},
    'weight': {'property': 'weight_kg', 'type': 'weight', 'parser': 'weight', 'default_unit': 'kg'},
    'kg': {'property': 'weight_kg', 'type': 'weight', 'parser': 'weight', 'default_unit': 'kg'},
    
    # Power & Electrical
    'vermogen': {'property': 'power_kw', 'type': 'electrical', 'parser': 'power', 'default_unit': 'kW'},
    'power': {'property': 'power_kw', 'type': 'electrical', 'parser': 'power', 'default_unit': 'kW'},
    'pk': {'property': 'power_hp', 'type': 'electrical', 'parser': 'number', 'default_unit': 'HP'},
    'voltage': {'property': 'voltage_v', 'type': 'electrical', 'parser': 'voltage', 'default_unit': 'V'},
    'spanning': {'property': 'voltage_v', 'type': 'electrical', 'parser': 'voltage', 'default_unit': 'V'},
    'v': {'property': 'voltage_v', 'type': 'electrical', 'parser': 'voltage', 'default_unit': 'V'},
    'current': {'property': 'current_a', 'type': 'electrical', 'parser': 'number', 'default_unit': 'A'},
    'stroom': {'property': 'current_a', 'type': 'electrical', 'parser': 'number', 'default_unit': 'A'},
    
    # Flow & Capacity
    'capaciteit': {'property': 'capacity_l', 'type': 'capacity', 'parser': 'capacity', 'default_unit': 'L'},
    'capacity': {'property': 'capacity_l', 'type': 'capacity', 'parser': 'capacity', 'default_unit': 'L'},
    'debiet': {'property': 'flow_rate_lpm', 'type': 'flow', 'parser': 'flow_rate', 'default_unit': 'L/min'},
    'flow rate': {'property': 'flow_rate_lpm', 'type': 'flow', 'parser': 'flow_rate', 'default_unit': 'L/min'},
    'opvoerhoogte': {'property': 'head_m', 'type': 'performance', 'parser': 'dimension', 'default_unit': 'm'},
    'head': {'property': 'head_m', 'type': 'performance', 'parser': 'dimension', 'default_unit': 'm'},
    
    # Speed & Rotation
    'toeren': {'property': 'rpm', 'type': 'speed', 'parser': 'number', 'default_unit': 'rpm'},
    'rpm': {'property': 'rpm', 'type': 'speed', 'parser': 'number', 'default_unit': 'rpm'},
    'snelheid': {'property': 'speed', 'type': 'speed', 'parser': 'speed'},
    
    # Material
    'materiaal': {'property': 'material', 'type': 'material', 'parser': 'text'},
    'material': {'property': 'material', 'type': 'material', 'parser': 'text'},
    'coating': {'property': 'coating', 'type': 'material', 'parser': 'text'},
    'afwerking': {'property': 'finish', 'type': 'material', 'parser': 'text'},
    
    # Connections
    'aansluiting': {'property': 'connection', 'type': 'connection', 'parser': 'connection'},
    'connection': {'property': 'connection', 'type': 'connection', 'parser': 'connection'},
    'schroefdraad': {'property': 'thread', 'type': 'connection', 'parser': 'thread'},
    'thread': {'property': 'thread', 'type': 'connection', 'parser': 'thread'},
    'binnendraad': {'property': 'thread_female', 'type': 'connection', 'parser': 'thread'},
    'buitendraad': {'property': 'thread_male', 'type': 'connection', 'parser': 'thread'},
    
    # Other
    'kleur': {'property': 'color', 'type': 'visual', 'parser': 'text'},
    'color': {'property': 'color', 'type': 'visual', 'parser': 'text'},
    'type': {'property': 'type', 'type': 'category', 'parser': 'text'},
    'model': {'property': 'model', 'type': 'category', 'parser': 'text'},
    'serie': {'property': 'series', 'type': 'category', 'parser': 'text'},
    'bescherming': {'property': 'protection_class', 'type': 'safety', 'parser': 'text'},
    'ip': {'property': 'protection_class', 'type': 'safety', 'parser': 'text'},
}


class SmartPropertyParser:
    """Advanced property parser with intelligent type detection"""
    
    @staticmethod
    def parse_dimension(value: str, default_unit: str = 'mm') -> Dict[str, Any]:
        """Parse dimension with unit detection and conversion"""
        if not value:
            return None
        
        value_str = str(value).strip()
        
        # Try to extract number and unit
        # Patterns: "16mm", "16 mm", "1.5m", "1/2 inch", "16"
        patterns = [
            r'(\d+\.?\d*)\s*(mm|cm|m|inch|in|"|\')',
            r'(\d+\.?\d*)',
            r'(\d+)/(\d+)\s*(inch|in|"|\')',  # Fractional inches
        ]
        
        for pattern in patterns:
            match = re.search(pattern, value_str, re.IGNORECASE)
            if match:
                if '/' in pattern:  # Fractional
                    numerator = float(match.group(1))
                    denominator = float(match.group(2))
                    number = numerator / denominator
                    unit = match.group(3) if len(match.groups()) > 2 else default_unit
                else:
                    number = float(match.group(1))
                    unit = match.group(2) if len(match.groups()) > 1 else default_unit
                
                # Normalize unit
                unit = unit.lower().strip()
                if unit in ['"', 'inch', 'in', "'"]:
                    unit = 'inch'
                
                # Convert to default unit if needed
                if default_unit == 'mm':
                    if unit == 'cm':
                        number *= 10
                    elif unit == 'm':
                        number *= 1000
                    elif unit == 'inch':
                        number *= 25.4
                    return {'value': round(number, 2), 'unit': 'mm', 'original': value_str}
                elif default_unit == 'm':
                    if unit == 'mm':
                        number /= 1000
                    elif unit == 'cm':
                        number /= 100
                    return {'value': round(number, 2), 'unit': 'm', 'original': value_str}
                
                return {'value': number, 'unit': unit, 'original': value_str}
        
        return None
    
    @staticmethod
    def parse_pressure(value: str, default_unit: str = 'bar') -> Dict[str, Any]:
        """Parse pressure values"""
        if not value:
            return None
        
        value_str = str(value).strip()
        
        # Patterns: "10 bar", "10bar", "145 psi", "10"
        match = re.search(r'(\d+\.?\d*)\s*(bar|psi|kpa|mpa)?', value_str, re.IGNORECASE)
        if match:
            number = float(match.group(1))
            unit = match.group(2).lower() if match.group(2) else default_unit
            
            # Convert to bar
            if unit == 'psi':
                number *= 0.0689476
            elif unit == 'kpa':
                number *= 0.01
            elif unit == 'mpa':
                number *= 10
            
            return {'value': round(number, 2), 'unit': 'bar', 'original': value_str}
        
        return None
    
    @staticmethod
    def parse_temperature(value: str, default_unit: str = '°C') -> Dict[str, Any]:
        """Parse temperature values"""
        if not value:
            return None
        
        value_str = str(value).strip()
        
        # Patterns: "80°C", "80 C", "176 F", "80"
        match = re.search(r'(-?\d+\.?\d*)\s*°?(c|f)?', value_str, re.IGNORECASE)
        if match:
            number = float(match.group(1))
            unit = match.group(2).lower() if match.group(2) else 'c'
            
            # Convert to Celsius
            if unit == 'f':
                number = (number - 32) * 5/9
            
            return {'value': round(number, 1), 'unit': '°C', 'original': value_str}
        
        return None
    
    @staticmethod
    def parse_weight(value: str, default_unit: str = 'kg') -> Dict[str, Any]:
        """Parse weight values"""
        if not value:
            return None
        
        value_str = str(value).strip()
        
        # Patterns: "2.5 kg", "2500 g", "5.5 lbs"
        match = re.search(r'(\d+\.?\d*)\s*(kg|g|lbs|lb)?', value_str, re.IGNORECASE)
        if match:
            number = float(match.group(1))
            unit = match.group(2).lower() if match.group(2) else default_unit
            
            # Convert to kg
            if unit == 'g':
                number /= 1000
            elif unit in ['lbs', 'lb']:
                number *= 0.453592
            
            return {'value': round(number, 2), 'unit': 'kg', 'original': value_str}
        
        return None
    
    @staticmethod
    def parse_power(value: str, default_unit: str = 'kW') -> Dict[str, Any]:
        """Parse power values"""
        if not value:
            return None
        
        value_str = str(value).strip()
        
        # Patterns: "1.5 kW", "2 HP", "1500 W"
        match = re.search(r'(\d+\.?\d*)\s*(kw|w|hp|pk)?', value_str, re.IGNORECASE)
        if match:
            number = float(match.group(1))
            unit = match.group(2).lower() if match.group(2) else default_unit
            
            # Convert to kW
            if unit == 'w':
                number /= 1000
            elif unit in ['hp', 'pk']:
                number *= 0.7457
            
            return {'value': round(number, 2), 'unit': 'kW', 'original': value_str}
        
        return None
    
    @staticmethod
    def parse_voltage(value: str, default_unit: str = 'V') -> Dict[str, Any]:
        """Parse voltage values"""
        if not value:
            return None
        
        value_str = str(value).strip()
        
        # Patterns: "230V", "230 V", "12V/24V"
        numbers = re.findall(r'(\d+)', value_str)
        if numbers:
            # If multiple voltages, take the first common one
            voltage = int(numbers[0])
            return {'value': voltage, 'unit': 'V', 'original': value_str}
        
        return None
    
    @staticmethod
    def parse_flow_rate(value: str, default_unit: str = 'L/min') -> Dict[str, Any]:
        """Parse flow rate values"""
        if not value:
            return None
        
        value_str = str(value).strip()
        
        # Patterns: "100 L/min", "6 m3/h", "100 l/min"
        match = re.search(r'(\d+\.?\d*)\s*(l/min|lpm|m3/h|m³/h)?', value_str, re.IGNORECASE)
        if match:
            number = float(match.group(1))
            unit = match.group(2).lower() if match.group(2) else default_unit
            
            # Convert to L/min
            if unit in ['m3/h', 'm³/h']:
                number = number * 1000 / 60
                unit = 'L/min'
            
            return {'value': round(number, 2), 'unit': 'L/min', 'original': value_str}
        
        return None
    
    @staticmethod
    def parse_connection(value: str) -> str:
        """Parse connection type"""
        if not value:
            return None
        
        value_str = str(value).strip()
        
        # Common connection patterns
        conn_patterns = {
            r'g\s*(\d+)/(\d+)': lambda m: f"G {m.group(1)}/{m.group(2)}\"",
            r'r\s*(\d+)/(\d+)': lambda m: f"R {m.group(1)}/{m.group(2)}\"",
            r'(\d+)/(\d+)"': lambda m: f"{m.group(1)}/{m.group(2)}\"",
            r'(\d+)"': lambda m: f"{m.group(1)}\"",
        }
        
        for pattern, formatter in conn_patterns.items():
            match = re.search(pattern, value_str, re.IGNORECASE)
            if match:
                return formatter(match)
        
        return value_str
    
    @staticmethod
    def parse_thread(value: str) -> str:
        """Parse thread specification"""
        return SmartPropertyParser.parse_connection(value)
    
    @staticmethod
    def parse_range(value: str) -> Dict[str, Any]:
        """Parse range values (e.g., temperature range)"""
        if not value:
            return None
        
        value_str = str(value).strip()
        
        # Patterns: "-40 to +80", "-40/+80", "-40...+80"
        match = re.search(r'(-?\d+\.?\d*)\s*(?:to|tot|\.\.\.|\-|/)\s*(-?\d+\.?\d*)', value_str)
        if match:
            min_val = float(match.group(1))
            max_val = float(match.group(2))
            return {'min': min_val, 'max': max_val, 'original': value_str}
        
        return None
    
    @staticmethod
    def parse_size(value: str) -> str:
        """Parse size specification"""
        if not value:
            return None
        
        return str(value).strip()
    
    @staticmethod
    def parse_dimensions(value: str) -> Dict[str, Any]:
        """Parse complex dimensions (e.g., "16x1.5mm" or "1/2 inch")"""
        if not value:
            return None
        
        value_str = str(value).strip()
        
        # Pattern: "16x1.5" or "16 x 1.5"
        match = re.search(r'(\d+\.?\d*)\s*x\s*(\d+\.?\d*)', value_str, re.IGNORECASE)
        if match:
            return {
                'outer': float(match.group(1)),
                'wall_thickness': float(match.group(2)),
                'original': value_str
            }
        
        return value_str
    
    @staticmethod
    def parse_number(value: str) -> float:
        """Extract simple number"""
        if not value:
            return None
        
        match = re.search(r'(\d+\.?\d*)', str(value))
        return float(match.group(1)) if match else None
    
    @staticmethod
    def parse_text(value: str) -> str:
        """Clean text value"""
        if not value:
            return None
        
        return str(value).strip()
    
    @staticmethod
    def parse_sku(value: str) -> str:
        """Parse and validate SKU"""
        if not value:
            return None
        
        sku = str(value).strip()
        
        # Clean common prefixes/suffixes
        sku = re.sub(r'^(art\.?|code:?|item:?)\s*', '', sku, flags=re.IGNORECASE)
        
        return sku if sku else None


def normalize_header(text: str) -> str:
    """Normalize header text for matching"""
    if not text:
        return ''
    
    # Remove special characters, convert to lowercase
    normalized = text.lower().strip()
    normalized = re.sub(r'[:.()]', '', normalized)
    normalized = re.sub(r'\s+', ' ', normalized)
    
    return normalized


def match_header_to_property(header: str) -> Optional[Dict[str, Any]]:
    """Match a header to a known property"""
    normalized = normalize_header(header)
    
    # Direct match
    if normalized in COMPREHENSIVE_PROPERTY_MAP:
        return COMPREHENSIVE_PROPERTY_MAP[normalized]
    
    # Partial match (for composite headers)
    for key, prop_info in COMPREHENSIVE_PROPERTY_MAP.items():
        if key in normalized or normalized in key:
            return prop_info
    
    return None


def parse_property_value(value: Any, property_info: Dict[str, Any]) -> Any:
    """Parse a property value based on its type"""
    if value is None or value == '':
        return None
    
    parser_name = property_info.get('parser', 'text')
    parser = SmartPropertyParser()
    
    # Get the parser method
    parser_method = getattr(parser, f'parse_{parser_name}', parser.parse_text)
    
    # Get default unit if applicable
    default_unit = property_info.get('default_unit')
    
    try:
        if default_unit:
            result = parser_method(value, default_unit)
        else:
            result = parser_method(value)
        
        # For simple types, return just the value
        if isinstance(result, dict) and 'value' in result:
            return result['value']
        
        return result
    except Exception as e:
        # Fallback to text parsing
        return SmartPropertyParser.parse_text(value)


# Export functions
__all__ = [
    'COMPREHENSIVE_PROPERTY_MAP',
    'SmartPropertyParser',
    'normalize_header',
    'match_header_to_property',
    'parse_property_value',
]


if __name__ == "__main__":
    # Test the parsers
    parser = SmartPropertyParser()
    
    print("Testing Smart Property Parser:\n")
    
    test_cases = [
        ("16mm", parser.parse_dimension),
        ("1.5 m", parser.parse_dimension),
        ("1/2 inch", parser.parse_dimension),
        ("10 bar", parser.parse_pressure),
        ("145 psi", parser.parse_pressure),
        ("80°C", parser.parse_temperature),
        ("2.5 kg", parser.parse_weight),
        ("1.5 kW", parser.parse_power),
        ("230V", parser.parse_voltage),
        ("100 L/min", parser.parse_flow_rate),
        ("G 1/2\"", parser.parse_connection),
        ("-40 to +80", parser.parse_range),
    ]
    
    for test_value, test_parser in test_cases:
        if 'dimension' in test_parser.__name__:
            result = test_parser(test_value, 'mm')
        elif 'pressure' in test_parser.__name__:
            result = test_parser(test_value, 'bar')
        else:
            result = test_parser(test_value)
        print(f"{test_value:20s} → {result}")
