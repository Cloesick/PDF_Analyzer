"""
Clean up Makita images - remove specification diagrams and non-product images
"""
from pathlib import Path
import shutil

PROJECT_ROOT = Path(__file__).parent
IMAGE_DIR = PROJECT_ROOT / "product-images-by-pdf" / "makita-catalogus-2022-nl"
REMOVED_DIR = PROJECT_ROOT / "removed-images" / "makita-catalogus-2022-nl"

# Patterns that indicate non-product images
REMOVE_PATTERNS = [
    'voltage',      # Specification tables
    '_voltage',     # More spec tables
    'l_',          # Liter specifications
    'bar_',        # Pressure specifications
    'min_',        # Speed specifications
    'kw_',         # Power specifications
    'hp_',         # Horsepower specifications
]

def should_remove(filename):
    """Check if filename indicates a non-product image"""
    name_lower = filename.lower()
    
    for pattern in REMOVE_PATTERNS:
        if pattern in name_lower:
            return True
    
    # Remove very small images (likely icons/diagrams)
    if filename.startswith('0-') and '_p0' in filename:
        # Images starting with very low numbers are often specs
        try:
            num = int(filename.split('_')[0].split('-')[0])
            if num < 10000:  # Likely specification images
                return True
        except:
            pass
    
    return False

def main():
    print("="*80)
    print("CLEANING MAKITA IMAGES")
    print("="*80)
    
    REMOVED_DIR.mkdir(parents=True, exist_ok=True)
    
    images = list(IMAGE_DIR.glob("*.webp"))
    print(f"\nTotal images: {len(images)}")
    
    to_remove = []
    to_keep = []
    
    for img in images:
        if should_remove(img.name):
            to_remove.append(img)
        else:
            to_keep.append(img)
    
    print(f"Images to remove: {len(to_remove)}")
    print(f"Images to keep: {len(to_keep)}")
    
    if to_remove:
        print(f"\n[MOVING] Moving {len(to_remove)} non-product images...")
        
        for img in to_remove:
            dest = REMOVED_DIR / img.name
            shutil.move(str(img), str(dest))
        
        print(f"[DONE] Moved to: {REMOVED_DIR}")
    
    print(f"\n[SUMMARY]")
    print(f"  Cleaned: {len(to_remove)} images removed")
    print(f"  Remaining: {len(to_keep)} product images")
    
    # Show sample of removed
    if to_remove:
        print(f"\n[SAMPLE REMOVED] First 10:")
        for img in to_remove[:10]:
            print(f"  - {img.name}")

if __name__ == '__main__':
    main()
