"""
Replace old mixed images with new tool-only images
"""
from pathlib import Path
import shutil

PROJECT_ROOT = Path(__file__).parent
OLD_DIR = PROJECT_ROOT / "product-images-by-pdf"
BACKUP_DIR = PROJECT_ROOT / "backup-mixed-images"

CATALOGS = ["makita-catalogus-2022-nl", "makita-tuinfolder-2022-nl"]

# Non-tool SKU patterns to remove
NON_TOOL_PATTERNS = [
    'BL1', 'BL4',  # Batteries
    'DC18', 'DC40',  # Chargers (but not DC* tools)
    'ADP', 'DEAADP', 'BEAPDC',  # Adapters
    'PDC', 'BPS',  # Accessories
    'BBLL',  # Battery codes
]

def is_non_tool_filename(filename):
    """Check if filename represents a non-tool product"""
    name_upper = filename.upper()
    
    # Check for battery/charger/accessory patterns
    for pattern in NON_TOOL_PATTERNS:
        if name_upper.startswith(pattern):
            # Exception: DC tools (not chargers)
            if pattern.startswith('DC') and any(x in name_upper for x in ['DCG', 'DCL', 'DCM', 'DCW', 'DCJ', 'DCC']):
                continue  # This is a tool
            return True
    
    # Check for part numbers (only digits and dashes)
    if '_' in filename:
        sku_part = filename.split('_')[0]
        if sku_part.replace('-', '').isdigit():
            return True
    
    return False

def main():
    print("="*80)
    print("CLEANING UP - REMOVING NON-TOOL IMAGES")
    print("="*80)
    
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    
    total_removed = 0
    total_kept = 0
    
    for catalog in CATALOGS:
        catalog_dir = OLD_DIR / catalog
        
        if not catalog_dir.exists():
            print(f"\n[SKIP] {catalog} - folder not found")
            continue
        
        print(f"\n{catalog}:")
        
        images = list(catalog_dir.glob("*.webp"))
        print(f"  Total images: {len(images)}")
        
        to_remove = []
        to_keep = []
        
        for img in images:
            if is_non_tool_filename(img.name):
                to_remove.append(img)
            else:
                to_keep.append(img)
        
        print(f"  Non-tool images: {len(to_remove)}")
        print(f"  Tool images: {len(to_keep)}")
        
        # Move non-tools to backup
        if to_remove:
            backup_catalog = BACKUP_DIR / catalog
            backup_catalog.mkdir(parents=True, exist_ok=True)
            
            for img in to_remove:
                dest = backup_catalog / img.name
                shutil.move(str(img), str(dest))
            
            total_removed += len(to_remove)
            total_kept += len(to_keep)
            
            print(f"  [MOVED] {len(to_remove)} images to backup")
        
        # Show samples of what was removed
        if to_remove:
            print(f"\n  Sample removed (first 5):")
            for img in to_remove[:5]:
                print(f"    - {img.name}")
    
    print("\n" + "="*80)
    print("CLEANUP COMPLETE")
    print("="*80)
    print(f"\nSummary:")
    print(f"  Total removed: {total_removed}")
    print(f"  Total remaining: {total_kept}")
    print(f"\nBackup location: {BACKUP_DIR}")

if __name__ == '__main__':
    main()
