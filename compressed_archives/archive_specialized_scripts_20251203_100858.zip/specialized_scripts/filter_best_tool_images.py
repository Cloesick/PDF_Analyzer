"""
Filter extracted tool images to keep only the best quality product photos
Remove duplicates, page captures, and keep 1-2 best images per SKU
"""
import os
import shutil
from pathlib import Path
from PIL import Image
import numpy as np

PROJECT_ROOT = Path(__file__).parent
IMAGE_DIR = PROJECT_ROOT / "product-images-by-pdf" / "makita-catalogus-2022-nl"
BACKUP_DIR = PROJECT_ROOT / "extracted-images-backup"

# Recently extracted tool SKUs
EXTRACTED_TOOLS = [
    'PT001GD101', 'RT001GZ16', 'DK0126G401', 'TW007GD201', 'TW007GM201', 
    'TW007GZ01', 'GA037GM201', 'GA036GZ', 'GA038GM201', 'PV001GZ',
    'JR001GD', 'JR002GM201', 'JR001GZ', 'JR001GM201', 'JR001GD201',
    'FN00GA202', 'FN001GA202', 'FN001GZ02', 'KP001GZ01', 'HS009G'
]

def calculate_image_quality(img_path):
    """Calculate quality score for product image"""
    try:
        img = Image.open(img_path)
        img_array = np.array(img.convert('RGB'))
        
        # Size score (prefer larger images)
        width, height = img.size
        size_score = min(width * height / 100000, 10)
        
        # Color variance (more color = better product photo)
        r, g, b = img_array[:,:,0], img_array[:,:,1], img_array[:,:,2]
        color_variance = (
            np.std(r) + np.std(g) + np.std(b)
        ) / 3
        color_score = min(color_variance / 10, 10)
        
        # Edge density (more edges = more detail)
        gray = np.mean(img_array, axis=2)
        edges = np.abs(np.diff(gray, axis=0)).sum() + np.abs(np.diff(gray, axis=1)).sum()
        edge_score = min(edges / (width * height * 20), 10)
        
        # White space ratio (less white = better)
        white_pixels = np.sum((r > 240) & (g > 240) & (b > 240))
        white_ratio = white_pixels / (width * height)
        white_score = max(0, 10 - white_ratio * 10)
        
        # Total score
        total = size_score + color_score + edge_score + white_score
        
        return {
            'total': total,
            'size': size_score,
            'color': color_score,
            'edge': edge_score,
            'white': white_score,
            'dimensions': f"{width}x{height}"
        }
    
    except Exception as e:
        return {'total': 0, 'error': str(e)}

def filter_tool_images():
    """Keep only best 1-2 images per tool SKU"""
    
    print("="*80)
    print("FILTERING TOOL IMAGES - KEEP ONLY BEST QUALITY")
    print("="*80)
    
    # Create backup
    BACKUP_DIR.mkdir(exist_ok=True)
    
    total_before = 0
    total_after = 0
    
    for sku in EXTRACTED_TOOLS:
        print(f"\n{'='*80}")
        print(f"SKU: {sku}")
        print(f"{'='*80}")
        
        # Find all images for this SKU
        images = []
        for img_path in IMAGE_DIR.glob(f"{sku}*"):
            if img_path.is_file():
                images.append(img_path)
        
        if not images:
            print(f"  No images found")
            continue
        
        total_before += len(images)
        print(f"  Found {len(images)} images")
        
        # Score each image
        scored_images = []
        for img_path in images:
            quality = calculate_image_quality(img_path)
            scored_images.append({
                'path': img_path,
                'quality': quality
            })
        
        # Sort by quality
        scored_images.sort(key=lambda x: x['quality']['total'], reverse=True)
        
        # Keep top 2
        keep_count = min(2, len(scored_images))
        to_keep = scored_images[:keep_count]
        to_remove = scored_images[keep_count:]
        
        print(f"\n  Top {keep_count} images to keep:")
        for i, item in enumerate(to_keep, 1):
            q = item['quality']
            print(f"    {i}. {item['path'].name}")
            print(f"       Score: {q['total']:.1f} (size:{q['size']:.1f}, color:{q['color']:.1f}, edge:{q['edge']:.1f}, white:{q['white']:.1f})")
            print(f"       Dimensions: {q.get('dimensions', 'N/A')}")
        
        # Move extras to backup
        if to_remove:
            print(f"\n  Moving {len(to_remove)} low-quality images to backup:")
            
            backup_sku_dir = BACKUP_DIR / sku
            backup_sku_dir.mkdir(parents=True, exist_ok=True)
            
            for item in to_remove:
                backup_path = backup_sku_dir / item['path'].name
                shutil.move(str(item['path']), str(backup_path))
            
            print(f"    ✅ Moved to: {backup_sku_dir}")
        
        total_after += keep_count
    
    # Summary
    print("\n" + "="*80)
    print("FILTERING COMPLETE")
    print("="*80)
    
    print(f"\nImages before: {total_before}")
    print(f"Images after: {total_after}")
    print(f"Images removed: {total_before - total_after}")
    print(f"Reduction: {((total_before - total_after) / total_before * 100):.1f}%")
    
    print(f"\n✅ Kept best 1-2 images per tool")
    print(f"📁 Remaining images: {IMAGE_DIR}")
    print(f"📁 Backup of removed: {BACKUP_DIR}")
    
    # Verify final count
    remaining = list(IMAGE_DIR.glob("*"))
    print(f"\n📊 Total images in folder now: {len(remaining)}")

if __name__ == '__main__':
    filter_tool_images()
