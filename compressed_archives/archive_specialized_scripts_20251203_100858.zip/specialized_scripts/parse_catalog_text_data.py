"""
Parse catalog text data to extract complete product information
Including brands, series, properties, and SKUs
"""

import json
import re
from pathlib import Path
from collections import defaultdict

# Paths
INPUT_JSON = Path(r"C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop\public\data\catalogs\catalogus-aandrijftechniek-150922.json")
OUTPUT_DIR = Path(r"C:\Users\prova\Documents\Projects\PDF_Analyzer\output")
OUTPUT_JSON = OUTPUT_DIR / "catalogus_aandrijftechniek_enriched_complete.json"
OUTPUT_GROUPED = OUTPUT_DIR / "catalogus_aandrijftechniek_grouped_by_brand_final.json"
WEBSHOP_DATA = Path(r"C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop\public\data\aandrijftechniek-grouped.json")

# Complete product series definitions extracted from user's text
PRODUCT_SERIES = {
    # === LAGERS EN LAGERHUIZEN - ZELFINSTELLENDE LAGERBLOKKEN ===
    "NTN STAAND GIETIJZEREN LAGERBLOK P200 - P300": {
        "brand": "NTN",
        "series": "P200 - P300",
        "type": "Staand Lagerblok",
        "material": "gietijzer",
        "category": "Zelfinstellende Lagerblokken",
        "application": "machinebouw, industrie",
        "properties": {
            "temperatuurbereik": "-20° tot +100°C",
            "asbevestiging": "met stelschroeven",
            "productreeks_lagerhuis": "P200 - P300",
            "productreeks_lager": "UC200 - UC300"
        },
        "skus": ["RLNUCP204", "RLNUCP205", "RLNUCP206", "RLNUCP207", "RLNUCP208", 
                 "RLNUCP209", "RLNUCP210", "RLNUCP211", "RLNUCP212", "RLNUCP214", "RLNUCP311"],
        "sku_pattern": r"RLNUCP\d+"
    },
    "FK STAAND GIETIJZEREN LAGERBLOK P200 - P300": {
        "brand": "FK",
        "series": "P200 - P300",
        "type": "Staand Lagerblok",
        "material": "gietijzer",
        "category": "Zelfinstellende Lagerblokken",
        "application": "machinebouw, industrie",
        "properties": {
            "temperatuurbereik": "-20° tot +100°C",
            "asbevestiging": "met stelschroeven",
            "productreeks_lagerhuis": "P200 - P300",
            "productreeks_lager": "UC200 - UC300"
        },
        "skus": ["RLFUCP204", "RLFUCP205", "RLFUCP206", "RLFUCP207", "RLFUCP208",
                 "RLFUCP209", "RLFUCP210", "RLFUCP211", "RLFUCP212"],
        "sku_pattern": r"RLFUCP\d+"
    },
    "NTN-SNR STAAND GIETIJZEREN LAGERBLOK PW200 (PAE200)": {
        "brand": "NTN-SNR",
        "series": "PW200 (PAE200)",
        "type": "Staand Lagerblok",
        "material": "gietijzer",
        "category": "Zelfinstellende Lagerblokken",
        "application": "machinebouw, industrie",
        "properties": {
            "temperatuurbereik": "-20° tot +100°C",
            "asbevestiging": "met stelschroeven",
            "productreeks_lagerhuis": "PW200 (PAE200)",
            "productreeks_lager": "UC200"
        },
        "skus": ["RLNUCPW204", "RLNUCPW205", "RLNUCPW206", "RLNUCPW207", "RLNUCPW208",
                 "RLSUCPAE208", "RLNUCPW209", "RLNUCPW210"],
        "sku_pattern": r"RL(N|S)UC(PW|PAE)\d+"
    },
    "FK STAAND GIETIJZEREN LAGERBLOK PW200 (PAE200)": {
        "brand": "FK",
        "series": "PW200 (PAE200)",
        "type": "Staand Lagerblok",
        "material": "gietijzer",
        "category": "Zelfinstellende Lagerblokken",
        "application": "machinebouw, industrie",
        "properties": {
            "temperatuurbereik": "-20° tot +100°C",
            "asbevestiging": "met stelschroeven",
            "productreeks_lagerhuis": "PW200 (PAE200)",
            "productreeks_lager": "UC200"
        },
        "skus": ["RLFUCPW204", "RLFUCPW205", "RLFUCPW206", "RLFUCPW207", "RLFUCPW208"],
        "sku_pattern": r"RLFUCPW\d+"
    },
    "NTN-SNR VIERKANT GIETIJZEREN FLENSLAGERBLOK F200 - F300": {
        "brand": "NTN-SNR",
        "series": "F200 - F300",
        "type": "Flenslagerblok Vierkant",
        "material": "gietijzer",
        "category": "Zelfinstellende Lagerblokken",
        "application": "machinebouw, industrie",
        "properties": {
            "temperatuurbereik": "-20° tot +100°C",
            "productreeks_lagerhuis": "F200 - F300",
            "productreeks_lager": "UC200 - UC300 - UK200 - UK300"
        },
        "skus": ["RLNUCF204", "RLNUCF205", "RLNUCF206", "RLSUCF306", "RLNUCF207", "RLNUCF208",
                 "RLNUCF209", "RLNUCF309", "RLNUCF210", "RLNUKF211", "RLSUCF310", "RLNUCF211",
                 "RLNUKF312", "RLNUCF212", "RLNUKF213", "RLNUCF213", "RLNUCF214", "RLNUCF216"],
        "sku_pattern": r"RL(N|S)UC(F|KF)\d+"
    },
    "FK VIERKANT GIETIJZEREN FLENSLAGERBLOK F200": {
        "brand": "FK",
        "series": "F200",
        "type": "Flenslagerblok Vierkant",
        "material": "gietijzer",
        "category": "Zelfinstellende Lagerblokken",
        "skus": ["RLFUCF204", "RLFUCF205", "RLFUCF206", "RLFUCF207", "RLFUCF208",
                 "RLFUCF209", "RLFUCF210", "RLFUCF211", "RLFUCF212"],
        "sku_pattern": r"RLFUCF\d+"
    },
    "NTN ROND GIETIJZEREN FLENSLAGERBLOK FC200": {
        "brand": "NTN",
        "series": "FC200",
        "type": "Flenslagerblok Rond",
        "material": "gietijzer",
        "category": "Zelfinstellende Lagerblokken",
        "skus": ["RLNUCFC204", "RLNUCFC205", "RLNUCFC206", "RLNUCFC207", "RLNUCFC208",
                 "RLNUCFC209", "RLNUCFC210", "RLNUCFC211", "RLNUCFC212", "RLNUCFC214"],
        "sku_pattern": r"RLNUCFC\d+"
    },
    "NTN OVAAL GIETIJZEREN FLENSLAGERBLOK FL200-FL300": {
        "brand": "NTN",
        "series": "FL200 - FL300",
        "type": "Flenslagerblok Ovaal",
        "material": "gietijzer",
        "category": "Zelfinstellende Lagerblokken",
        "skus": ["RLNUCFL204", "RLNUCFL205", "RLNUCFL206", "RLNUCFL207", "RLNUCFL307",
                 "RLNUCFL208", "RLNUCFL209", "RLNUCFL210", "RLNUCFL211", "RLNUCFL212"],
        "sku_pattern": r"RLNUCFL\d+"
    },
    "FK OVAAL GIETIJZEREN FLENSLAGERBLOK FL200 - FL300": {
        "brand": "FK",
        "series": "FL200 - FL300",
        "type": "Flenslagerblok Ovaal",
        "material": "gietijzer",
        "category": "Zelfinstellende Lagerblokken",
        "skus": ["RLFUCFL204", "RLFUCFL205", "RLFUCFL206", "RLFUCFL207", "RLFUCFL208",
                 "RLFUCFL209", "RLFUCFL210", "RLFUCFL211", "RLFUCFL212"],
        "sku_pattern": r"RLFUCFL\d+"
    },
    
    # === SPANLAGERS ===
    "NTN-SNR SPANLAGER UC200": {
        "brand": "NTN-SNR",
        "series": "UC200",
        "type": "Spanlager",
        "category": "Spanlagers",
        "skus": ["RLNUC204", "RLNUC205", "RLNUC206", "RLNUC207", "RLNUC208", "RLNUC209",
                 "RLNUC210", "RLNUC211", "RLNUC212", "RLNUC214", "RLNUC216"],
        "sku_pattern": r"RLNUC\d{3}(?!F|FL|FC|PW)"  # UC but not UCF, UCFL, etc.
    },
    "SKF SPANLAGER YAR": {
        "brand": "SKF",
        "series": "YAR",
        "type": "Spanlager",
        "category": "Spanlagers",
        "skus": ["SKFYAR204", "SKFYAR205", "SKFYAR206", "SKFYAR207", "SKFYAR208",
                 "SKFYAR210", "SKFYAR211", "SKFYAR212", "SKFYAR213"],
        "sku_pattern": r"SKFYAR\d+"
    },
    
    # === KOGELLAGERS ===
    "NTN-SNR GROEFKOGELLAGER": {
        "brand": "NTN-SNR",
        "series": "6000 serie",
        "type": "Groefkogellager",
        "category": "Kogellagers",
        "sku_pattern": r"RL[NS]6\d+"
    },
    "SKF GROEFKOGELLAGER": {
        "brand": "SKF",
        "series": "6000 serie",
        "type": "Groefkogellager",
        "category": "Kogellagers",
        "sku_pattern": r"SKF6\d+"
    },
    
    # === KETTINGAANDRIJVINGEN ===
    "BTC BS ROLLENKETTING": {
        "brand": "BTC",
        "series": "BS",
        "type": "Rollenketting",
        "category": "Kettingaandrijvingen",
        "sku_pattern": r"R(KK|KS|KV)BS\d+"
    },
    "BTC ASA ROLLENKETTING": {
        "brand": "BTC",
        "series": "ASA",
        "type": "Rollenketting",
        "category": "Kettingaandrijvingen",
        "sku_pattern": r"R(KK|KS|KV)ASA\d+"
    },
    
    # === AANDRIJFASSEN ===
    "WALTERSCHEID W-SERIE": {
        "brand": "Walterscheid",
        "series": "W-serie",
        "type": "Aandrijfas",
        "category": "Aandrijfassen",
        "sku_pattern": r"CARDW\d+"
    },
    "WALTERSCHEID GAFFELS": {
        "brand": "Walterscheid",
        "series": "Gaffels",
        "type": "Gaffel",
        "category": "Aandrijfassen",
        "sku_pattern": r"CARG\d+"
    },
    "WALTERSCHEID KRUISSTUKKEN": {
        "brand": "Walterscheid",
        "series": "Kruisstukken",
        "type": "Kruisstuk",
        "category": "Aandrijfassen",
        "sku_pattern": r"CARS\d+"
    },
    
    # === AANDRIJFRIEMEN ===
    "OPTIBELT V-RIEM": {
        "brand": "Optibelt",
        "series": "Klassiek",
        "type": "V-Riem",
        "category": "Aandrijfriemen",
        "sku_pattern": r"VR(A|B|C|SPB|SPZ|AVX)\d+"
    },
    
    # === COMPONENT CODES ===
    "LAGERHUIS P-SERIE": {
        "brand": "Component",
        "series": "P-serie Lagerhuis",
        "type": "Lagerhuis",
        "category": "Lager Components",
        "sku_pattern": r"^P\d{3}$"
    },
    "LAGERHUIS F-SERIE": {
        "brand": "Component",
        "series": "F-serie Lagerhuis",
        "type": "Lagerhuis",
        "category": "Lager Components",
        "sku_pattern": r"^F[A-Z]?\d{3}$"
    },
    "SPANLAGER UC-SERIE": {
        "brand": "Component",
        "series": "UC-serie Spanlager",
        "type": "Spanlager",
        "category": "Lager Components",
        "sku_pattern": r"^UC\d{3}G?\d?L?\d?$"
    },
    "SPANLAGER UK-SERIE": {
        "brand": "Component",
        "series": "UK-serie Spanlager",
        "type": "Spanlager",
        "category": "Lager Components",
        "sku_pattern": r"^UK\d{3}G?\d?H?$"
    },
}

def find_matching_series(sku):
    """Find the best matching product series for a SKU"""
    
    # First check exact SKU matches
    for series_name, info in PRODUCT_SERIES.items():
        if "skus" in info and sku in info["skus"]:
            return series_name, info
    
    # Then check pattern matches
    for series_name, info in PRODUCT_SERIES.items():
        if "sku_pattern" in info:
            if re.match(info["sku_pattern"], sku):
                return series_name, info
    
    return None, None

def enrich_product(product):
    """Enrich a product with brand, series, and properties"""
    sku = product.get("sku", "")
    
    # Find matching series
    series_name, series_info = find_matching_series(sku)
    
    if series_info:
        # Update product with series information
        product["brand"] = series_info.get("brand", "Onbekend")
        product["series"] = series_info.get("series", "")
        product["product_type"] = series_info.get("type", "Product")
        product["subcategory"] = series_info.get("category", "Diverse")
        product["material"] = series_info.get("material")
        product["application"] = series_info.get("application")
        
        # Generate better name and description
        brand = product["brand"]
        ptype = product["product_type"]
        series = product.get("series", "")
        
        if series:
            product["name"] = f"{brand} {ptype} {sku}"
            product["description"] = f"{brand} {ptype} uit de {series} serie"
        else:
            product["name"] = f"{brand} {ptype} {sku}"
            product["description"] = f"{brand} {ptype}"
        
        # Add properties to attributes
        if not product.get("attributes"):
            product["attributes"] = {}
        
        if "properties" in series_info:
            product["attributes"].update(series_info["properties"])
        
        if series_info.get("material"):
            product["attributes"]["material"] = series_info["material"]
        if series_info.get("application"):
            product["attributes"]["toepassing"] = series_info["application"]
    
    return product

def main():
    print("=" * 80)
    print("COMPREHENSIVE AANDRIJFTECHNIEK CATALOG ENRICHMENT")
    print("=" * 80)
    
    # Load existing data
    print("\n📖 Loading existing catalog data...")
    with open(INPUT_JSON, 'r', encoding='utf-8') as f:
        products = json.load(f)
    print(f"   ✓ Loaded {len(products)} products")
    
    # Enrich all products
    print("\n🔍 Enriching products with brand and series data...")
    enriched_products = []
    brand_stats = defaultdict(int)
    category_stats = defaultdict(int)
    series_stats = defaultdict(int)
    unmatched_skus = []
    
    for i, product in enumerate(products):
        if (i + 1) % 100 == 0:
            print(f"   📊 Processed {i + 1}/{len(products)} products...")
        
        enriched = enrich_product(product)
        enriched_products.append(enriched)
        
        brand = enriched.get("brand", "Onbekend")
        category = enriched.get("subcategory", "Diverse")
        series = enriched.get("series", "")
        
        brand_stats[brand] += 1
        category_stats[category] += 1
        if series:
            series_stats[f"{brand} - {series}"] += 1
        
        if brand == "Onbekend":
            unmatched_skus.append(enriched.get("sku"))
    
    print(f"   ✓ Enriched {len(enriched_products)} products")
    
    # Save enriched products
    print("\n💾 Saving enriched catalog...")
    OUTPUT_DIR.mkdir(exist_ok=True)
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(enriched_products, f, indent=2, ensure_ascii=False)
    print(f"   ✓ Saved to: {OUTPUT_JSON}")
    
    # Create grouped structure
    print("\n📊 Creating grouped structure by brand and series...")
    grouped = defaultdict(lambda: defaultdict(list))
    
    for product in enriched_products:
        brand = product.get("brand", "Onbekend")
        series = product.get("series", "Overig")
        category = product.get("subcategory", "Diverse")
        
        if series and series != "Overig":
            group_key = f"{brand} - {series}"
        else:
            group_key = f"{brand} - {category}"
        
        grouped[brand][group_key].append(product)
    
    # Format grouped output
    output_groups = []
    for brand, series_dict in sorted(grouped.items(), key=lambda x: str(x[0]) if x[0] else "ZZZ"):
        for series_name, products_list in sorted(series_dict.items(), key=lambda x: str(x[0]) if x[0] else "ZZZ"):
            rep_product = products_list[0]
            
            group = {
                "group_id": series_name.lower().replace(" ", "-").replace("--", "-").replace("(", "").replace(")", ""),
                "group_name": series_name,
                "brand": brand,
                "category": rep_product.get("subcategory", "Diverse"),
                "series": rep_product.get("series", ""),
                "product_type": rep_product.get("product_type", "Product"),
                "material": rep_product.get("material"),
                "application": rep_product.get("application"),
                "product_count": len(products_list),
                "media": [],
                "variants": []
            }
            
            # Collect images
            all_images = []
            for prod in products_list:
                if prod.get("image_paths"):
                    all_images.extend(prod["image_paths"])
                elif prod.get("imageUrl"):
                    all_images.append(prod["imageUrl"])
            
            unique_images = list(dict.fromkeys(all_images))
            if unique_images:
                group["media"] = [
                    {"url": img, "role": "main" if i == 0 else "gallery", "type": "image"} 
                    for i, img in enumerate(unique_images[:15])
                ]
            
            # Add variants
            for prod in products_list:
                variant = {
                    "sku": prod["sku"],
                    "name": prod["name"],
                    "attributes": prod.get("attributes", {}),
                    "specs": prod.get("specs", []),
                    "image_url": prod.get("imageUrl"),
                    "pages": prod.get("source_pages", [])
                }
                group["variants"].append(variant)
            
            output_groups.append(group)
    
    # Save grouped output
    with open(OUTPUT_GROUPED, 'w', encoding='utf-8') as f:
        json.dump(output_groups, f, indent=2, ensure_ascii=False)
    print(f"   ✓ Created {len(output_groups)} product groups")
    print(f"   ✓ Saved to: {OUTPUT_GROUPED}")
    
    # Copy to webshop
    print("\n🌐 Copying to webshop...")
    with open(WEBSHOP_DATA, 'w', encoding='utf-8') as f:
        json.dump(output_groups, f, indent=2, ensure_ascii=False)
    print(f"   ✓ Saved to: {WEBSHOP_DATA}")
    
    # Print statistics
    print("\n" + "=" * 80)
    print("📈 ANALYSIS RESULTS")
    print("=" * 80)
    
    print(f"\n🏭 BRANDS ({len(brand_stats)} brands):")
    for brand, count in sorted(brand_stats.items(), key=lambda x: -x[1]):
        brand_str = str(brand) if brand else "None"
        print(f"   • {brand_str:20s} : {count:4d} products")
    
    print(f"\n📦 CATEGORIES ({len(category_stats)} categories):")
    for cat, count in sorted(category_stats.items(), key=lambda x: -x[1]):
        cat_str = str(cat) if cat else "None"
        print(f"   • {cat_str:35s} : {count:4d} products")
    
    print(f"\n📋 PRODUCT SERIES ({len(series_stats)} series):")
    for series, count in sorted(series_stats.items(), key=lambda x: -x[1]):
        series_str = str(series) if series else "None"
        print(f"   • {series_str:60s} : {count:4d} products")
    
    if unmatched_skus:
        print(f"\n⚠️  UNMATCHED SKUs ({len(unmatched_skus)} products):")
        print(f"   Sample: {', '.join(unmatched_skus[:10])}")
    
    print(f"\n✅ SUMMARY:")
    print(f"   • Total Products     : {len(enriched_products)}")
    print(f"   • Total Groups       : {len(output_groups)}")
    print(f"   • Brands Identified  : {len([b for b in brand_stats if b != 'Onbekend'])}")
    print(f"   • Categories         : {len(category_stats)}")
    print(f"   • Product Series     : {len(series_stats)}")
    print(f"   • Match Rate         : {((len(products) - len(unmatched_skus)) / len(products) * 100):.1f}%")
    
    print("\n" + "=" * 80)
    print("✅ COMPREHENSIVE ENRICHMENT COMPLETE!")
    print("=" * 80)

if __name__ == "__main__":
    main()
