#!/usr/bin/env python3
"""
Fix aandrijftechniek catalog images using GROUP-BASED mapping.

Key Insight: Products in the same table (group) share the same image.
- One image per product group (not per SKU)
- All SKU variants in a group reference the same image
- Recommended naming: catalogus-aandrijftechniek_pXXX_GroupName.jpeg

This reduces storage and matches the actual PDF structure.
"""

import json
import re
from pathlib import Path
from collections import defaultdict

def create_group_based_mapping():
    """Create image mapping based on product groups (tables)"""
    
    print(f"\n{'='*80}")
    print(f"AANDRIJFTECHNIEK GROUP-BASED IMAGE MAPPING")
    print(f"{'='*80}\n")
    
    # Load grouped products data
    grouped_file = Path('../DemaWebshop/dema-webshop/public/data/aandrijftechniek_grouped.json')
    if not grouped_file.exists():
        print(f"❌ Grouped data not found: {grouped_file}")
        return
    
    with open(grouped_file, 'r', encoding='utf-8') as f:
        product_groups = json.load(f)
    
    print(f"📊 Loaded {len(product_groups)} product groups")
    
    # Count total variants
    total_variants = sum(len(g.get('variants', [])) for g in product_groups)
    print(f"📦 Total SKU variants across all groups: {total_variants}")
    
    # Analyze actual image files
    webshop_img_folder = Path('../DemaWebshop/dema-webshop/public/images/products/aandrijftechniek')
    if not webshop_img_folder.exists():
        print(f"❌ Image folder not found: {webshop_img_folder}")
        return
    
    actual_files = list(webshop_img_folder.glob('*.*'))
    print(f"🖼️  Found {len(actual_files)} image files in folder")
    
    # Parse actual filenames by page
    images_by_page = defaultdict(list)
    for f in actual_files:
        # Match: pageXXX_imgYY.ext
        match = re.search(r'page(\d+)_img(\d+)', f.name)
        if match:
            page = int(match.group(1))
            img_num = int(match.group(2))
            images_by_page[page].append({
                'page': page,
                'img_num': img_num,
                'filename': f.name,
                'path': f
            })
    
    # Sort images by page and image number
    for page in images_by_page:
        images_by_page[page].sort(key=lambda x: x['img_num'])
    
    print(f"📄 Images distributed across {len(images_by_page)} pages")
    print(f"   Pages: {sorted(images_by_page.keys())}\n")
    
    # Create mapping: group_id -> image path, and sku -> image path
    group_to_image = {}
    sku_to_image = {}
    groups_by_page = defaultdict(list)
    
    # Organize groups by page
    for group in product_groups:
        page = group.get('page_in_pdf')
        if page:
            groups_by_page[page].append(group)
    
    print(f"{'='*80}")
    print(f"MAPPING STRATEGY: Page-based Group Assignment")
    print(f"{'='*80}\n")
    
    mapped_groups = 0
    mapped_skus = 0
    
    for page in sorted(groups_by_page.keys()):
        groups_on_page = groups_by_page[page]
        images_on_page = images_by_page.get(page, [])
        
        if not images_on_page:
            continue
        
        print(f"\n📄 Page {page}:")
        print(f"   Groups: {len(groups_on_page)}")
        print(f"   Images: {len(images_on_page)}")
        
        # Assign images to groups sequentially
        for i, image_info in enumerate(images_on_page):
            if i < len(groups_on_page):
                group = groups_on_page[i]
                group_id = group.get('group_id')
                group_name = group.get('family', group.get('name', 'unknown'))
                variants = group.get('variants', [])
                
                # Image path for webshop
                image_path = f"/images/products/aandrijftechniek/{image_info['filename']}"
                
                # Map the group
                group_to_image[group_id] = image_path
                mapped_groups += 1
                
                # Map ALL SKUs in this group to the same image (key insight!)
                for variant in variants:
                    sku = variant.get('sku')
                    if sku:
                        sku_to_image[sku] = image_path
                        mapped_skus += 1
                
                print(f"   ✓ Group '{group_name}' ({len(variants)} SKUs) -> {image_info['filename']}")
                if i == 0:  # Show SKUs for first group as example
                    skus = [v.get('sku') for v in variants[:5]]
                    if len(variants) > 5:
                        skus.append(f'...+{len(variants)-5} more')
                    print(f"     SKUs: {', '.join(skus)}")
    
    print(f"\n{'='*80}")
    print(f"MAPPING SUMMARY")
    print(f"{'='*80}\n")
    print(f"✅ Mapped Groups: {mapped_groups}")
    print(f"✅ Mapped SKUs: {mapped_skus} (multiple SKUs share same image)")
    print(f"📊 Efficiency: {mapped_skus} SKUs use only {len(images_by_page)} unique images")
    print(f"💾 Storage saved: ~{mapped_skus - len(set(sku_to_image.values()))} duplicate images avoided\n")
    
    # Save SKU mapping (for backward compatibility with existing code)
    sku_mapping_file = Path('../DemaWebshop/dema-webshop/public/data/aandrijftechniek_image_mapping.json')
    sku_mapping_file.parent.mkdir(parents=True, exist_ok=True)
    
    with open(sku_mapping_file, 'w', encoding='utf-8') as f:
        json.dump(sku_to_image, f, indent=2, ensure_ascii=False)
    
    print(f"✅ SKU Mapping saved: {sku_mapping_file}")
    print(f"   ({len(sku_to_image)} SKUs mapped to {len(set(sku_to_image.values()))} unique images)\n")
    
    # Save group mapping (new, more efficient)
    group_mapping_file = Path('../DemaWebshop/dema-webshop/public/data/aandrijftechniek_group_mapping.json')
    
    with open(group_mapping_file, 'w', encoding='utf-8') as f:
        json.dump(group_to_image, f, indent=2, ensure_ascii=False)
    
    print(f"✅ Group Mapping saved: {group_mapping_file}")
    print(f"   ({len(group_to_image)} groups mapped)\n")
    
    # Generate recommended naming scheme document
    print(f"{'='*80}")
    print(f"RECOMMENDED IMAGE NAMING FOR FUTURE")
    print(f"{'='*80}\n")
    print(f"Instead of: pageXXX_imgYY.jpeg")
    print(f"Use format: catalogus-aandrijftechniek_pXXX_GroupName.jpeg\n")
    print(f"Examples:")
    
    for page in sorted(list(groups_by_page.keys())[:5]):
        groups = groups_by_page[page][:2]  # First 2 groups
        images = images_by_page.get(page, [])
        for i, group in enumerate(groups):
            if i < len(images):
                family = group.get('family', 'unknown')
                current = images[i].get('filename', 'N/A')
                recommended = f"catalogus-aandrijftechniek_p{page:03d}_{family}.jpeg"
                print(f"   Current:     {current}")
                print(f"   Recommended: {recommended}")
                print()
    
    # Show sample mappings
    print(f"{'='*80}")
    print(f"SAMPLE SKU → IMAGE MAPPINGS")
    print(f"{'='*80}\n")
    
    sample_count = 0
    for sku, img_path in list(sku_to_image.items())[:15]:
        print(f"   {sku:<20} → {img_path}")
        sample_count += 1
    
    if len(sku_to_image) > 15:
        print(f"   ... and {len(sku_to_image) - 15} more SKUs\n")
    
    print(f"{'='*80}\n")
    
    return {
        'sku_mapping': sku_to_image,
        'group_mapping': group_to_image,
        'stats': {
            'total_groups': len(product_groups),
            'mapped_groups': mapped_groups,
            'total_skus': total_variants,
            'mapped_skus': mapped_skus,
            'unique_images': len(set(sku_to_image.values()))
        }
    }

if __name__ == '__main__':
    result = create_group_based_mapping()
    
    if result:
        stats = result['stats']
        print(f"✨ SUCCESS! Image mapping complete.")
        print(f"   {stats['mapped_skus']} SKUs now reference {stats['unique_images']} images")
        print(f"   (Each image shared by ~{stats['mapped_skus']//stats['unique_images']} SKUs on average)\n")
