#!/usr/bin/env python3
"""
Complete deployment for pompentoebehoren catalog.

This is the digitale-versie-pompentoebehoren-compressed catalog with 503 images.
"""

import json
import shutil
from pathlib import Path
from collections import defaultdict
import re

def deploy_pompentoebehoren():
    """Deploy pompentoebehoren with all images and properties"""
    
    print(f"\n{'='*80}")
    print(f"COMPLETE POMPENTOEBEHOREN DEPLOYMENT")
    print(f"{'='*80}\n")
    
    # ===================
    # STEP 1: COPY IMAGES
    # ===================
    print(f"{'='*80}")
    print(f"STEP 1: COPYING IMAGES")
    print(f"{'='*80}\n")
    
    source_folder = Path('product-images-by-pdf/digitale-versie-pompentoebehoren-compressed')
    dest_folder = Path('../DemaWebshop/dema-webshop/public/images/products/pompentoebehoren')
    dest_folder.mkdir(parents=True, exist_ok=True)
    
    if not source_folder.exists():
        print(f"❌ Source not found: {source_folder}")
        return
    
    source_images = list(source_folder.glob('*.webp')) + list(source_folder.glob('*.jpeg')) + list(source_folder.glob('*.png'))
    print(f"📁 Source: {source_folder.name}")
    print(f"   Images: {len(source_images)}\n")
    
    images_copied = 0
    for img in source_images:
        # Extract page number
        match = re.search(r'_p(\d+)_img(\d+)', img.name)
        if match:
            page = int(match.group(1))
            img_num = int(match.group(2))
            
            # New naming
            new_name = f"catalogus-pompentoebehoren_p{page:03d}_img{img_num:02d}{img.suffix}"
            dest_path = dest_folder / new_name
            
            shutil.copy2(img, dest_path)
            images_copied += 1
            
            if images_copied <= 5:
                print(f"   ✅ {img.name} → {new_name}")
    
    if images_copied > 5:
        print(f"   ... and {images_copied - 5} more")
    
    print(f"\n✅ Total images copied: {images_copied}\n")
    
    # ===================
    # STEP 2: LOAD DATA
    # ===================
    print(f"{'='*80}")
    print(f"STEP 2: LOADING DATA")
    print(f"{'='*80}\n")
    
    # Load grouped data
    grouped_file = Path('../DemaWebshop/dema-webshop/public/data/pompentoebehoren_grouped.json')
    if not grouped_file.exists():
        # Try digitale_versie name
        grouped_file = Path('../DemaWebshop/dema-webshop/public/data/digitale_versie_pompentoebehoren_compressed_grouped.json')
    
    with open(grouped_file, 'r', encoding='utf-8') as f:
        grouped_data = json.load(f)
    
    print(f"📊 Loaded grouped data: {len(grouped_data)} groups")
    
    total_variants = sum(len(g.get('variants', [])) for g in grouped_data)
    print(f"📊 Total variants: {total_variants}\n")
    
    # ===================
    # STEP 3: MAP IMAGES
    # ===================
    print(f"{'='*80}")
    print(f"STEP 3: MAPPING IMAGES")
    print(f"{'='*80}\n")
    
    # Get all copied images
    all_images = list(dest_folder.glob('catalogus-pompentoebehoren_*.webp'))
    all_images += list(dest_folder.glob('catalogus-pompentoebehoren_*.jpeg'))
    all_images += list(dest_folder.glob('catalogus-pompentoebehoren_*.png'))
    
    print(f"🖼️  Total images: {len(all_images)}")
    
    # Parse images by page
    images_by_page = defaultdict(list)
    for img in all_images:
        match = re.search(r'_p(\d+)_img(\d+)', img.name)
        if match:
            page = int(match.group(1))
            img_num = int(match.group(2))
            
            images_by_page[page].append({
                'page': page,
                'img_num': img_num,
                'filename': img.name,
                'path': f"/images/products/pompentoebehoren/{img.name}"
            })
    
    for page in images_by_page:
        images_by_page[page].sort(key=lambda x: x['img_num'])
    
    print(f"📄 Pages with images: {len(images_by_page)}")
    
    # Group SKUs by page
    skus_by_page = defaultdict(list)
    for group in grouped_data:
        page = group.get('page_in_pdf')
        for variant in group.get('variants', []):
            sku = variant.get('sku')
            if page and sku:
                skus_by_page[page].append(sku)
    
    print(f"📄 Pages with products: {len(skus_by_page)}\n")
    
    # Create mapping
    sku_to_image = {}
    images_used = set()
    mapped_count = 0
    
    pages_shown = 0
    for page in sorted(skus_by_page.keys()):
        skus = skus_by_page[page]
        images = images_by_page.get(page, [])
        
        if not images:
            continue
        
        if pages_shown < 20:
            print(f"📄 Page {page}: {len(skus)} SKUs, {len(images)} images")
            pages_shown += 1
        
        for i, sku in enumerate(skus):
            img_index = i % len(images)
            image_info = images[img_index]
            
            sku_to_image[sku] = image_info['path']
            images_used.add(image_info['filename'])
            mapped_count += 1
    
    if pages_shown >= 20:
        print(f"... and {len(skus_by_page) - pages_shown} more pages")
    
    print(f"\n{'='*80}")
    print(f"MAPPING SUMMARY")
    print(f"{'='*80}\n")
    print(f"✅ SKUs mapped: {mapped_count}")
    print(f"✅ Images used: {len(images_used)}")
    print(f"📊 Images available: {len(all_images)}")
    print(f"📊 Coverage: {mapped_count/total_variants*100:.1f}%")
    
    # Save mapping
    mapping_file = Path('../DemaWebshop/dema-webshop/public/data/pompentoebehoren_image_mapping.json')
    with open(mapping_file, 'w', encoding='utf-8') as f:
        json.dump(sku_to_image, f, indent=2, ensure_ascii=False)
    
    print(f"\n✅ Saved: {mapping_file.name}\n")
    
    # ===================
    # FINAL SUMMARY
    # ===================
    print(f"{'='*80}")
    print(f"DEPLOYMENT COMPLETE")
    print(f"{'='*80}\n")
    print(f"📊 Total Products: {total_variants}")
    print(f"📊 With Images: {mapped_count} ({mapped_count/total_variants*100:.1f}%)")
    print(f"📊 Images Used: {len(images_used)}/{len(all_images)}")
    print(f"\n✅ Ready to deploy!\n")
    
    return {
        'total': total_variants,
        'mapped': mapped_count,
        'images_used': len(images_used),
        'images_total': len(all_images)
    }

if __name__ == '__main__':
    result = deploy_pompentoebehoren()
    print(f"✨ Success: {result['mapped']} products with images!")
