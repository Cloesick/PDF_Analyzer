"""
UNIVERSAL IMAGE EXTRACTOR FOR ALL CATALOGS
===========================================
Comprehensive solution that:
- Processes all PDFs in input_pdfs folder
- Advanced gradient detection to filter out gradient/icon images
- Catalog-specific SKU patterns (Makita tools only, no batteries/chargers)
- Smart image quality filters
- Consistent naming: {SKU}_{catalog-name}_p{page}_img{idx}.webp
"""

import fitz
import pdfplumber
from PIL import Image
import cv2
import numpy as np
from pathlib import Path
import json
import io
import re
from collections import defaultdict

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ROOT = Path(__file__).parent
INPUT_PDFS = PROJECT_ROOT / "input_pdfs"
OUTPUT_IMAGES_BASE = PROJECT_ROOT / "product-images-by-pdf"
OUTPUT_JSON_DIR = PROJECT_ROOT / "output"

WEBP_QUALITY = 90
IMAGE_DPI = 300

# Image quality thresholds (BALANCED - reject gradients but allow product photos)
MIN_IMAGE_AREA = 15000  # Minimum area - avoid tiny icons
MIN_IMAGE_WIDTH = 130   # Minimum width in pixels
MIN_IMAGE_HEIGHT = 130  # Minimum height in pixels
MAX_ASPECT_RATIO = 4.0  # Maximum aspect ratio
MIN_COLOR_VARIANCE = 8  # Minimum color variance - reject flat colors/gradients
MIN_EDGE_DENSITY = 0.012 # Minimum edge density - require some detail
MAX_GRADIENT_SCORE = 0.60  # Maximum gradient score - reject obvious gradients
WEBP_QUALITY = 90

# ============================================================================
# CATALOG-SPECIFIC SKU PATTERNS
# ============================================================================

# Makita SKU patterns for ACTUAL TOOLS (not batteries/chargers/accessories)
MAKITA_TOOL_PATTERNS = [
    r'\b[A-Z]{2,4}\d{3,4}[A-Z]{1,4}\d{0,3}\b',  # DHS680RTJ, GA005GM201, HS010G, TW004GZ
    r'\b[A-Z]{2}\d{3}[A-Z]{2}\d{3}\b',          # TD001GD201, PT001GD101, UR002GZ01
    r'\b[A-Z]{3}\d{3}[A-Z]{2,4}\d*\b',          # DUC307ZX2, DCL280FZW, GA037GM201
]

# Makita exclusions (batteries, chargers, accessories)
MAKITA_EXCLUDE_PATTERNS = [
    r'^BL\d+',          # BL1830B, BL4020, BL4050F (batteries)
    r'^DC\d+',          # DC18R, DC40RA (chargers)
    r'^ADP\d+',         # ADP10, ADPOO1 (adapters)
    r'^DEAADP',         # DEAADP001G (adapters)
    r'^AD\d+',          # AD88 (accessories)
    r'^PDC\d+',         # PDC01, BPS01, BEAPDC (accessories)
    r'^BPS\d+',
    r'^BEAPDC',
    r'^PV\d+',          # PV001GZ (accessories)
    r'^DK\d+',          # DK0126G401 (accessories)
    r'^RC\d+',          # RC30B
    r'^PL\d+',          # PL11
    r'^ER\d+',          # ER55
    r'^AA\d+',          # AA8720-9
    r'^N\d+-\d+$',      # N09-8 (part numbers)
    r'^\d+-\d+$',       # 81-6, 933-6, 198720-9 (part numbers)
    r'^\d{5,6}$',       # 56169, 54329 (part numbers)
    r'^[A-Z]\d{1,2}$',  # B18, K18
    r'^IPX\d+$',        # IPX4 (rating)
    r'^[A-Z]{2}\d{1,2}$',  # AR04, GA03 (incomplete)
]

# Generic SKU patterns for other catalogs
GENERIC_SKU_PATTERNS = [
    r'\b\d{4,6}[-/]?\d{0,4}\b',  # 1234, 12345-67, etc.
    r'\b[A-Z]{2,4}[-\s]?\d{3,6}\b',  # ABC-1234, XY 5678
    r'\b\d{3,6}[-/][A-Z]{1,3}\b',  # 1234-AB, 567/X
]

# Catalog-specific patterns
CATALOG_PATTERNS = {
    'makita': {
        'sku_patterns': MAKITA_TOOL_PATTERNS,
        'exclude_patterns': MAKITA_EXCLUDE_PATTERNS,
        'validator': 'is_makita_tool'
    },
    'airpress': {
        'sku_patterns': GENERIC_SKU_PATTERNS,
        'exclude_patterns': [],
        'validator': None
    },
    'kranzle': {
        'sku_patterns': GENERIC_SKU_PATTERNS,
        'exclude_patterns': [],
        'validator': None
    },
    # Add more catalog-specific patterns as needed
    'default': {
        'sku_patterns': GENERIC_SKU_PATTERNS,
        'exclude_patterns': [],
        'validator': None
    }
}

# ============================================================================
# IMAGE QUALITY FILTERS
# ============================================================================

def detect_gradient(img_array):
    """Detect if image is a gradient (smooth color transition)"""
    height, width = img_array.shape[:2]
    
    # Check horizontal gradients
    h_gradients = []
    for y in [height//4, height//2, 3*height//4]:
        row = img_array[y, :]
        color_diffs = np.abs(np.diff(row.astype(float), axis=0))
        h_gradients.append(np.mean(color_diffs))
    
    # Check vertical gradients
    v_gradients = []
    for x in [width//4, width//2, 3*width//4]:
        col = img_array[:, x]
        color_diffs = np.abs(np.diff(col.astype(float), axis=0))
        v_gradients.append(np.mean(color_diffs))
    
    avg_gradient = (np.mean(h_gradients) + np.mean(v_gradients)) / 2
    
    # Calculate smoothness
    all_diffs = []
    for y in range(0, height, max(1, height//10)):
        row = img_array[y, :]
        all_diffs.extend(np.abs(np.diff(row.astype(float), axis=0)).flatten())
    for x in range(0, width, max(1, width//10)):
        col = img_array[:, x]
        all_diffs.extend(np.abs(np.diff(col.astype(float), axis=0)).flatten())
    
    smoothness = np.std(all_diffs)
    gradient_score = avg_gradient / (smoothness + 1)
    
    return gradient_score

def is_product_image(pil_image):
    """Determine if image is likely a REAL product photo, not icon/logo/diagram/gradient"""
    width, height = pil_image.size
    img_array = np.array(pil_image.convert('RGB'))
    
    # 1. SIZE FILTER
    area = width * height
    if area < MIN_IMAGE_AREA:
        return False, {'reason': 'too_small', 'area': area}
    
    if width < MIN_IMAGE_WIDTH or height < MIN_IMAGE_HEIGHT:
        return False, {'reason': 'dimensions_too_small', 'width': width, 'height': height}
    
    # 2. ASPECT RATIO
    aspect_ratio = max(width, height) / min(width, height)
    if aspect_ratio > MAX_ASPECT_RATIO:
        return False, {'reason': 'bad_aspect_ratio', 'ratio': aspect_ratio}
    
    # 3. GRADIENT DETECTION - Reject gradient images
    gradient_score = detect_gradient(img_array)
    if gradient_score > MAX_GRADIENT_SCORE:
        return False, {'reason': 'gradient_detected', 'gradient_score': gradient_score}
    
    # 4. COLOR VARIANCE
    r, g, b = img_array[:,:,0], img_array[:,:,1], img_array[:,:,2]
    rg_diff = np.abs(r.astype(int) - g.astype(int))
    rb_diff = np.abs(r.astype(int) - b.astype(int))
    gb_diff = np.abs(g.astype(int) - b.astype(int))
    color_variance = (rg_diff.mean() + rb_diff.mean() + gb_diff.mean()) / 3
    
    if color_variance < MIN_COLOR_VARIANCE:
        return False, {'reason': 'low_color_variance', 'variance': color_variance}
    
    # 5. EDGE DENSITY
    gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, 50, 150)
    edge_density = np.count_nonzero(edges) / area
    
    if edge_density < MIN_EDGE_DENSITY:
        return False, {'reason': 'low_edge_density', 'density': edge_density}
    
    # 6. BACKGROUND CHECK
    corner_size = 20
    corners = [
        img_array[0:corner_size, 0:corner_size],
        img_array[0:corner_size, -corner_size:],
        img_array[-corner_size:, 0:corner_size],
        img_array[-corner_size:, -corner_size:]
    ]
    
    bg_brightness = [np.mean(corner) for corner in corners]
    avg_bg_brightness = np.mean(bg_brightness)
    
    if avg_bg_brightness < 200:
        return False, {'reason': 'dark_background', 'brightness': avg_bg_brightness}
    
    # 7. CONTENT CHECK
    brightness = np.mean(gray)
    if brightness > 250:
        return False, {'reason': 'mostly_white', 'brightness': brightness}
    
    # 8. COLOR DISTRIBUTION
    unique_colors = len(np.unique(img_array.reshape(-1, 3), axis=0))
    color_richness = unique_colors / area
    
    if color_richness < 0.002:
        return False, {'reason': 'low_color_richness', 'richness': color_richness}
    
    # 9. UNIFORM COLOR CHECK
    flat_img = img_array.reshape(-1, 3)
    sample_size = min(10000, len(flat_img))
    sample = flat_img[np.random.choice(len(flat_img), sample_size, replace=False)]
    median_color = np.median(sample, axis=0)
    distances = np.sqrt(np.sum((sample - median_color)**2, axis=1))
    similar_ratio = np.sum(distances < 20) / len(distances)
    
    if similar_ratio > 0.8:
        return False, {'reason': 'uniform_color', 'uniformity': similar_ratio}
    
    # PASSED - likely a product photo
    return True, {
        'color_variance': color_variance,
        'edge_density': edge_density,
        'gradient_score': gradient_score,
        'aspect_ratio': aspect_ratio,
        'area': area
    }

# ============================================================================
# SKU EXTRACTION
# ============================================================================

def get_catalog_config(catalog_name):
    """Get SKU patterns for a specific catalog"""
    catalog_lower = catalog_name.lower()
    
    for key in CATALOG_PATTERNS:
        if key in catalog_lower:
            return CATALOG_PATTERNS[key]
    
    return CATALOG_PATTERNS['default']

def is_makita_tool(sku):
    """Validate Makita tool SKU (exclude batteries/chargers/accessories)"""
    if not sku or len(sku) < 4:
        return False
    
    sku_upper = sku.upper().strip()
    
    # Check exclusions first
    for pattern in MAKITA_EXCLUDE_PATTERNS:
        if re.match(pattern, sku_upper):
            return False
    
    # Check tool patterns
    for pattern in MAKITA_TOOL_PATTERNS:
        if re.match(pattern, sku_upper):
            return True
    
    return False

def extract_skus_from_text(text, catalog_config):
    """Extract SKUs from text using catalog-specific patterns"""
    skus = set()
    
    for pattern in catalog_config['sku_patterns']:
        matches = re.findall(pattern, text.upper())
        skus.update(matches)
    
    # Apply validator if specified
    if catalog_config['validator'] == 'is_makita_tool':
        skus = {sku for sku in skus if is_makita_tool(sku)}
    elif catalog_config['exclude_patterns']:
        # Filter using exclusion patterns
        filtered = set()
        for sku in skus:
            excluded = False
            for exclude_pattern in catalog_config['exclude_patterns']:
                if re.match(exclude_pattern, sku):
                    excluded = True
                    break
            if not excluded:
                filtered.add(sku)
        skus = filtered
    
    return skus

# ============================================================================
# MAIN EXTRACTION
# ============================================================================

def extract_images_from_pdf(pdf_path, catalog_name):
    """Extract product images from a single PDF"""
    print(f"\n{'='*80}")
    print(f"EXTRACTING: {catalog_name}")
    print(f"{'='*80}")
    
    output_images = OUTPUT_IMAGES_BASE / catalog_name
    output_images.mkdir(parents=True, exist_ok=True)
    
    catalog_config = get_catalog_config(catalog_name)
    
    doc_pymupdf = fitz.open(pdf_path)
    
    extracted_images = []
    stats = {
        'total_images': 0,
        'product_images': 0,
        'filtered': 0,
        'filter_reasons': defaultdict(int),
        'skus_found': set()
    }
    
    print(f"\nProcessing {len(doc_pymupdf)} pages...")
    
    # First pass: collect SKUs from all pages
    all_page_skus = {}
    
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page_num in range(len(pdf.pages)):
                page = pdf.pages[page_num]
                page_text = page.extract_text() or ""
                page_skus = extract_skus_from_text(page_text, catalog_config)
                all_page_skus[page_num] = list(page_skus)
                
                if (page_num + 1) % 20 == 0:
                    print(f"  Scanned {page_num + 1} pages for SKUs...")
    except Exception as e:
        print(f"  ⚠️ pdfplumber unavailable, using basic SKU detection")
        all_page_skus = {}
    
    # Second pass: extract images
    for page_num in range(len(doc_pymupdf)):
        page = doc_pymupdf[page_num]
        image_list = page.get_images()
        
        page_skus = all_page_skus.get(page_num, [])
        
        if (page_num + 1) % 20 == 0:
            print(f"  Page {page_num + 1}/{len(doc_pymupdf)} - Extracted {stats['product_images']} images")
        
        for img_idx, img in enumerate(image_list):
            stats['total_images'] += 1
            xref = img[0]
            
            try:
                base_image = doc_pymupdf.extract_image(xref)
                image_bytes = base_image["image"]
                pil_image = Image.open(io.BytesIO(image_bytes))
                
                # Check if it's a product image
                is_product, metrics = is_product_image(pil_image)
                
                if not is_product:
                    stats['filtered'] += 1
                    reason = metrics.get('reason', 'unknown')
                    stats['filter_reasons'][reason] += 1
                    continue
                
                # Generate filename
                if page_skus and len(page_skus) > min(img_idx, len(page_skus) - 1):
                    sku = page_skus[min(img_idx, len(page_skus) - 1)]
                else:
                    sku = f"{stats['product_images']:05d}"
                
                safe_sku = str(sku).replace(' ', '_').replace('/', '-').replace('\\', '-')
                filename = f"{safe_sku}_{catalog_name}_p{page_num+1:03d}_img{img_idx:02d}.webp"
                filepath = output_images / filename
                
                # Save image
                pil_image.save(filepath, 'WEBP', quality=WEBP_QUALITY)
                
                extracted_images.append({
                    'filename': filename,
                    'sku': sku,
                    'page': page_num + 1,
                    'metrics': metrics
                })
                
                stats['product_images'] += 1
                if isinstance(sku, str) and len(sku) > 3:
                    stats['skus_found'].add(sku)
                
            except Exception as e:
                continue
    
    doc_pymupdf.close()
    
    # Summary
    print(f"\n{'='*80}")
    print(f"✅ EXTRACTION COMPLETE: {catalog_name}")
    print(f"{'='*80}")
    print(f"Total images found:     {stats['total_images']}")
    print(f"✓ Product images:       {stats['product_images']}")
    print(f"⊘ Filtered out:         {stats['filtered']}")
    print(f"SKUs found:             {len(stats['skus_found'])}")
    
    print(f"\n🔍 Filter Breakdown:")
    for reason, count in sorted(stats['filter_reasons'].items(), key=lambda x: x[1], reverse=True)[:5]:
        print(f"  - {reason}: {count}")
    
    # Save metadata
    metadata_file = OUTPUT_JSON_DIR / f"{catalog_name}_images.json"
    OUTPUT_JSON_DIR.mkdir(parents=True, exist_ok=True)
    
    with open(metadata_file, 'w', encoding='utf-8') as f:
        json.dump({
            'catalog': catalog_name,
            'total_images': stats['product_images'],
            'images': extracted_images
        }, f, indent=2)
    
    print(f"\n💾 Saved {stats['product_images']} images to: {output_images}")
    print(f"📄 Metadata: {metadata_file}\n")
    
    return stats

def extract_all_catalogs():
    """Extract images from all PDFs in input_pdfs folder"""
    print("="*80)
    print("UNIVERSAL IMAGE EXTRACTOR")
    print("="*80)
    
    pdf_files = sorted(INPUT_PDFS.glob("*.pdf"))
    
    if not pdf_files:
        print(f"❌ No PDFs found in {INPUT_PDFS}")
        return
    
    print(f"\nFound {len(pdf_files)} PDF catalogs")
    
    total_stats = {
        'catalogs_processed': 0,
        'total_images_extracted': 0,
        'total_images_scanned': 0
    }
    
    for pdf_path in pdf_files:
        catalog_name = pdf_path.stem
        
        try:
            stats = extract_images_from_pdf(pdf_path, catalog_name)
            total_stats['catalogs_processed'] += 1
            total_stats['total_images_extracted'] += stats['product_images']
            total_stats['total_images_scanned'] += stats['total_images']
        except Exception as e:
            print(f"\n❌ Error processing {catalog_name}: {e}\n")
            continue
    
    # Final summary
    print("\n" + "="*80)
    print("🎉 ALL CATALOGS PROCESSED")
    print("="*80)
    print(f"Catalogs processed:     {total_stats['catalogs_processed']}")
    print(f"Total images scanned:   {total_stats['total_images_scanned']}")
    print(f"✅ Product images:      {total_stats['total_images_extracted']}")
    print(f"📁 Output folder:       {OUTPUT_IMAGES_BASE}")
    print("="*80)

if __name__ == "__main__":
    extract_all_catalogs()
