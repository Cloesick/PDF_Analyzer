"""
ENHANCED TABLE EXTRACTOR WITH HEADER PARSING
=============================================

This script extracts products from PDF tables with proper understanding of:
- Table headers (column meanings)
- Icons/symbols in cells (⚡, 🔧, etc.)
- Technical specifications with context
- All attributes properly labeled

Version: 3.0 - Semantic Table Extraction
"""

import pdfplumber
import re
import json
import os
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
import unicodedata

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ROOT = Path(__file__).parent
INPUT_FOLDER = PROJECT_ROOT / "input_pdfs"
OUTPUT_FOLDER = PROJECT_ROOT / "output"

VERBOSE = True

# ============================================================================
# HEADER SEMANTIC MAPPING
# ============================================================================

# Map common table headers to standardized property names
HEADER_MAPPINGS = {
    # Power-related
    'power': 'power_kw',
    'kw': 'power_kw',
    'pk': 'power_hp',
    'hp': 'power_hp',
    'vermogen': 'power_kw',
    'leistung': 'power_kw',
    'puissance': 'power_kw',
    
    # Pressure-related
    'pressure': 'pressure_max_bar',
    'bar': 'pressure_max_bar',
    'max bar': 'pressure_max_bar',
    'max.bar': 'pressure_max_bar',
    'druk': 'pressure_max_bar',
    'druck': 'pressure_max_bar',
    'pression': 'pressure_max_bar',
    'working pressure': 'pressure_max_bar',
    'burst pressure': 'pressure_burst_bar',
    
    # Voltage
    'voltage': 'voltage_v',
    'volt': 'voltage_v',
    'v': 'voltage_v',
    'spanning': 'voltage_v',
    
    # Flow
    'flow': 'flow_l_min',
    'l/min': 'flow_l_min',
    'liter/min': 'flow_l_min',
    'capacity': 'flow_l_min',
    'debiet': 'flow_l_min',
    
    # Dimensions
    'diameter': 'diameter_mm',
    'ø': 'diameter_mm',
    'dia': 'diameter_mm',
    'size': 'size_mm',
    'inner diameter': 'inner_diameter_mm',
    'outer diameter': 'outer_diameter_mm',
    'length': 'length_m',
    'lengte': 'length_m',
    
    # Weight & Volume
    'weight': 'weight_kg',
    'kg': 'weight_kg',
    'gewicht': 'weight_kg',
    'volume': 'volume_l',
    'liter': 'volume_l',
    'tank': 'volume_l',
    
    # Speed
    'rpm': 'rpm',
    't/min': 'rpm',
    'speed': 'rpm',
    'toeren': 'rpm',
    
    # Connection
    'connection': 'connection_type',
    'thread': 'thread_type',
    'aansluiting': 'connection_type',
    'anschluss': 'connection_type',
    
    # Material
    'material': 'material',
    'materiaal': 'material',
    
    # Product info
    'article': 'sku',
    'art.nr': 'sku',
    'art nr': 'sku',
    'item': 'sku',
    'code': 'sku',
    'model': 'model',
    'type': 'product_type',
    'description': 'description',
    'omschrijving': 'description',
}

# Icon/Symbol meanings
ICON_MEANINGS = {
    '⚡': 'electric',
    '🔧': 'mechanical',
    '💧': 'water/liquid',
    '🌡': 'temperature',
    '📏': 'dimension',
    '⚖': 'weight',
    '🔌': 'electrical_connection',
    '⬆': 'maximum',
    '⬇': 'minimum',
    '→': 'flow_direction',
    '●': 'standard',
    '○': 'optional',
    '✓': 'included',
    '✗': 'not_included',
}

# ============================================================================
# SKU PATTERNS
# ============================================================================

SKU_PATTERNS = [
    re.compile(r'\b([A-Z]{2,}\d+[-A-Z0-9]*)\b'),  # ABSBU016, HP123-N
    re.compile(r'\b(\d{6}(?:-[A-Z]+)?)\b'),        # 360501, 360501-N
    re.compile(r'\b(\d{5}-[A-Z]+)\b'),             # 36510-N
    re.compile(r'\b(X\d+)\b'),                     # X16
    re.compile(r'\b([A-Z]{1,2}\s?\d{3,}[-A-Z]*)\b'),  # A 123, K123
]

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def normalize_header(header: str) -> str:
    """Normalize header text for matching"""
    if not header:
        return ''
    # Remove special chars, lowercase, strip
    header = header.lower().strip()
    header = re.sub(r'[^\w\s/.-]', '', header)
    header = re.sub(r'\s+', ' ', header)
    return header

def map_header_to_property(header: str) -> Optional[str]:
    """Map a table header to a standardized property name"""
    normalized = normalize_header(header)
    
    # Check for exact matches
    if normalized in HEADER_MAPPINGS:
        return HEADER_MAPPINGS[normalized]
    
    # Check for partial matches
    for key, value in HEADER_MAPPINGS.items():
        if key in normalized or normalized in key:
            return value
    
    return None

def extract_icons(text: str) -> List[str]:
    """Extract icon meanings from text"""
    icons = []
    for char in text:
        if char in ICON_MEANINGS:
            icons.append(ICON_MEANINGS[char])
    return icons

def extract_numeric_value(text: str, unit: Optional[str] = None) -> Optional[float]:
    """Extract numeric value from text, optionally with unit"""
    if not text:
        return None
    
    # Remove common non-numeric characters
    cleaned = re.sub(r'[^\d.,\-+]', ' ', str(text))
    
    # Find numbers (handle European format with comma)
    numbers = re.findall(r'\d+[.,]?\d*', cleaned)
    if not numbers:
        return None
    
    try:
        # Take first number, convert comma to dot
        num_str = numbers[0].replace(',', '.')
        return float(num_str)
    except:
        return None

def validate_property_value(prop_name: str, value: float, text: str) -> bool:
    """Validate if a numeric value is reasonable for the given property"""
    if value is None or value < 0:
        return False
    
    # Reject if the text looks like a SKU (contains letters mixed with numbers)
    if re.search(r'[A-Z]', str(text), re.IGNORECASE):
        return False
    
    # Property-specific validation ranges
    validation_rules = {
        'length_m': (0.01, 200),        # Tubes: 1cm to 200m (reject crazy values)
        'diameter_mm': (0.1, 2000),     # Diameter: 0.1mm to 2m
        'inner_diameter_mm': (0.1, 2000),
        'outer_diameter_mm': (0.1, 2000),
        'size_mm': (0.1, 5000),
        'weight_kg': (0.001, 10000),    # 1g to 10 tons
        'volume_l': (0.1, 10000),       # 0.1L to 10,000L
        'pressure_max_bar': (0.1, 500), # 0.1 to 500 bar
        'pressure_burst_bar': (0.1, 1000),
        'voltage_v': (1, 1000),         # 1V to 1000V (no crazy voltages)
        'power_kw': (0.01, 1000),       # 10W to 1000kW
        'power_hp': (0.01, 1500),
        'flow_l_min': (0.1, 100000),    # 0.1 to 100,000 L/min
        'rpm': (1, 50000),              # 1 to 50,000 RPM
    }
    
    if prop_name in validation_rules:
        min_val, max_val = validation_rules[prop_name]
        return min_val <= value <= max_val
    
    return True  # If no specific rule, accept it

def looks_like_sku(text: str) -> bool:
    """Check if text looks like a SKU rather than a dimension"""
    if not text:
        return False
    text_str = str(text).strip()
    # Contains letters? Likely a SKU
    if re.search(r'[A-Za-z]', text_str):
        return True
    # Is a very large number (> 10000)? Could be a SKU
    if re.match(r'^\d{5,}$', text_str):
        return True
    return False

def find_skus_in_text(text: str) -> List[str]:
    """Find all SKUs in text"""
    if not text:
        return []
    
    skus = set()
    for pattern in SKU_PATTERNS:
        matches = pattern.findall(text)
        skus.update(matches)
    
    return list(skus)

# ============================================================================
# TABLE PARSING
# ============================================================================

def parse_table_with_headers(table: List[List[str]], page_num: int) -> List[Dict[str, Any]]:
    """Parse a table and extract products with proper header mapping"""
    if not table or len(table) < 2:
        return []
    
    # First row is usually headers
    headers = table[0]
    data_rows = table[1:]
    
    if VERBOSE:
        print(f"      Table headers: {headers}")
    
    # Map headers to property names
    header_map = {}
    for idx, header in enumerate(headers):
        if not header:
            continue
        prop_name = map_header_to_property(header)
        if prop_name:
            header_map[idx] = prop_name
            if VERBOSE:
                print(f"        Column {idx} '{header}' -> {prop_name}")
    
    # Extract products from rows
    products = []
    sku_column_idx = None
    
    # Find SKU column
    for idx, prop in header_map.items():
        if prop == 'sku':
            sku_column_idx = idx
            break
    
    for row_idx, row in enumerate(data_rows):
        if not row or all(not cell for cell in row):
            continue
        
        # Try to find SKU in the row
        sku = None
        if sku_column_idx is not None and sku_column_idx < len(row):
            sku = row[sku_column_idx]
        
        # If no SKU column, search all cells
        if not sku:
            for cell in row:
                found_skus = find_skus_in_text(str(cell))
                if found_skus:
                    sku = found_skus[0]
                    break
        
        if not sku:
            continue
        
        # Extract all properties from this row
        product = {
            'sku': sku.strip(),
            'page_in_pdf': page_num,
            'table_row': row_idx + 2,  # +2 because header is row 1, data starts at row 2
        }
        
        # Extract values from each column
        for col_idx, cell_value in enumerate(row):
            if col_idx not in header_map:
                continue
            
            prop_name = header_map[col_idx]
            if not cell_value:
                continue
            
            cell_str = str(cell_value).strip()
            
            # Skip if cell looks like a SKU (don't confuse SKUs with dimensions)
            if prop_name != 'sku' and looks_like_sku(cell_str):
                continue
            
            # Extract icons
            icons = extract_icons(cell_str)
            if icons:
                product[f'{prop_name}_icons'] = icons
            
            # Extract numeric value if applicable
            if any(x in prop_name for x in ['kw', 'hp', 'bar', 'voltage', 'weight', 'volume', 'flow', 'rpm', 'mm', 'length']):
                numeric_value = extract_numeric_value(cell_str)
                if numeric_value is not None:
                    # Validate the value before accepting it
                    if validate_property_value(prop_name, numeric_value, cell_str):
                        product[prop_name] = numeric_value
                    elif VERBOSE:
                        print(f"          ⚠️ Rejected {prop_name}={numeric_value} (from '{cell_str}') - out of range or invalid")
            else:
                # Store as text
                product[prop_name] = cell_str
        
        products.append(product)
    
    return products

def extract_text_products(text: str, page_num: int) -> List[Dict[str, Any]]:
    """Extract products from plain text (non-table areas)"""
    products = []
    
    # Find SKUs in text
    skus = find_skus_in_text(text)
    
    for sku in skus:
        # Find text context around SKU (within 200 chars)
        sku_pos = text.find(sku)
        context_start = max(0, sku_pos - 100)
        context_end = min(len(text), sku_pos + 100)
        context = text[context_start:context_end]
        
        product = {
            'sku': sku,
            'page_in_pdf': page_num,
            'context_text': context.strip(),
        }
        
        # Extract specs from context (with validation)
        # Power
        power_kw_match = re.search(r'(\d+(?:[.,]\d+)?)\s*kW', context, re.IGNORECASE)
        if power_kw_match:
            val = float(power_kw_match.group(1).replace(',', '.'))
            if validate_property_value('power_kw', val, power_kw_match.group(0)):
                product['power_kw'] = val
        
        power_hp_match = re.search(r'(\d+(?:[.,]\d+)?)\s*(?:hp|pk)', context, re.IGNORECASE)
        if power_hp_match:
            val = float(power_hp_match.group(1).replace(',', '.'))
            if validate_property_value('power_hp', val, power_hp_match.group(0)):
                product['power_hp'] = val
        
        # Pressure
        pressure_match = re.search(r'(\d+(?:[.,]\d+)?)\s*bar', context, re.IGNORECASE)
        if pressure_match:
            val = float(pressure_match.group(1).replace(',', '.'))
            if validate_property_value('pressure_max_bar', val, pressure_match.group(0)):
                product['pressure_max_bar'] = val
        
        # Voltage
        voltage_match = re.search(r'(\d+)\s*V', context, re.IGNORECASE)
        if voltage_match:
            val = int(voltage_match.group(1))
            if validate_property_value('voltage_v', val, voltage_match.group(0)):
                product['voltage_v'] = val
        
        # Volume
        volume_match = re.search(r'(\d+(?:[.,]\d+)?)\s*L(?!\s*[/])', context, re.IGNORECASE)
        if volume_match:
            val = float(volume_match.group(1).replace(',', '.'))
            if validate_property_value('volume_l', val, volume_match.group(0)):
                product['volume_l'] = val
        
        # Flow
        flow_match = re.search(r'(\d+(?:[.,]\d+)?)\s*L/min', context, re.IGNORECASE)
        if flow_match:
            val = float(flow_match.group(1).replace(',', '.'))
            if validate_property_value('flow_l_min', val, flow_match.group(0)):
                product['flow_l_min'] = val
        
        products.append(product)
    
    return products

# ============================================================================
# PDF PROCESSING
# ============================================================================

def process_pdf(pdf_path: Path) -> List[Dict[str, Any]]:
    """Process a single PDF and extract all products"""
    print(f"\n{'='*80}")
    print(f"Processing: {pdf_path.name}")
    print(f"{'='*80}")
    
    all_products = []
    
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page_num, page in enumerate(pdf.pages, 1):
                if VERBOSE and page_num % 10 == 0:
                    print(f"  Processing page {page_num}...")
                
                # Extract tables
                tables = page.extract_tables()
                for table_idx, table in enumerate(tables):
                    products = parse_table_with_headers(table, page_num)
                    if products:
                        if VERBOSE:
                            print(f"    ✓ Table {table_idx+1}: Found {len(products)} products")
                        all_products.extend(products)
                
                # Extract from plain text
                text = page.extract_text() or ''
                text_products = extract_text_products(text, page_num)
                if text_products:
                    if VERBOSE:
                        print(f"    ✓ Text: Found {len(text_products)} products")
                    all_products.extend(text_products)
        
        # Add catalog metadata
        catalog_name = pdf_path.stem
        for product in all_products:
            product['catalog'] = catalog_name
            product['pdf_source'] = pdf_path.name
        
        print(f"\n✅ Total products extracted: {len(all_products)}")
        
        return all_products
    
    except Exception as e:
        print(f"❌ Error processing {pdf_path.name}: {e}")
        return []

# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    print("="*80)
    print("ENHANCED TABLE EXTRACTOR WITH HEADER PARSING")
    print("="*80)
    
    # Create output folder
    OUTPUT_FOLDER.mkdir(exist_ok=True)
    
    # Get all PDFs
    pdf_files = list(INPUT_FOLDER.glob("*.pdf"))
    
    if not pdf_files:
        print(f"❌ No PDF files found in {INPUT_FOLDER}")
        return
    
    print(f"\nFound {len(pdf_files)} PDF files")
    
    # Process all PDFs
    all_products = []
    for pdf_path in pdf_files:
        products = process_pdf(pdf_path)
        all_products.extend(products)
    
    # Save results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = OUTPUT_FOLDER / f"products_enhanced_{timestamp}.json"
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_products, f, ensure_ascii=False, indent=2)
    
    print(f"\n{'='*80}")
    print(f"✅ EXTRACTION COMPLETE")
    print(f"{'='*80}")
    print(f"Total products extracted: {len(all_products)}")
    print(f"Output saved to: {output_file}")
    
    # Show statistics
    print(f"\n📊 STATISTICS:")
    
    # Count products by catalog
    by_catalog = defaultdict(int)
    for p in all_products:
        by_catalog[p.get('catalog', 'unknown')] += 1
    
    print(f"\nProducts by catalog:")
    for catalog, count in sorted(by_catalog.items(), key=lambda x: x[1], reverse=True)[:10]:
        print(f"  {catalog:40} {count:6} products")
    
    # Count properties
    prop_counts = defaultdict(int)
    for p in all_products:
        for key in p.keys():
            if key not in ['sku', 'catalog', 'pdf_source', 'page_in_pdf', 'table_row', 'context_text']:
                if p[key] not in [None, '', [], {}]:
                    prop_counts[key] += 1
    
    print(f"\nTop technical properties:")
    for prop, count in sorted(prop_counts.items(), key=lambda x: x[1], reverse=True)[:15]:
        pct = count / len(all_products) * 100
        print(f"  {prop:30} {count:6} ({pct:5.1f}%)")

if __name__ == "__main__":
    from datetime import datetime
    main()
