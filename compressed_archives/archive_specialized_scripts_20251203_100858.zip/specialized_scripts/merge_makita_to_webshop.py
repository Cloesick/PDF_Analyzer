"""
Merge new Makita data with translated properties and icons into webshop feed
"""
import json
from pathlib import Path
from datetime import datetime

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"
IMAGE_DIR = PROJECT_ROOT / "product-images-by-pdf"

def load_existing_webshop_data():
    """Load existing webshop products"""
    webshop_file = OUTPUT_DIR / "products_ready_for_webshop.json"
    if webshop_file.exists():
        with open(webshop_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []

def load_makita_translated_products():
    """Load new Makita products with translations and icons"""
    catalogs = [
        "makita-catalogus-2022-nl",
        "makita-tuinfolder-2022-nl"
    ]
    
    all_products = []
    
    for catalog in catalogs:
        translated_file = OUTPUT_DIR / f"{catalog}_products_translated.json"
        tools_file = OUTPUT_DIR / f"{catalog}_tools_extracted.json"
        
        if not translated_file.exists():
            continue
        
        # Load translated properties
        with open(translated_file, 'r', encoding='utf-8') as f:
            products = json.load(f)
        
        # Load image data
        images_by_sku = {}
        if tools_file.exists():
            with open(tools_file, 'r', encoding='utf-8') as f:
                images = json.load(f)
                for img in images:
                    sku = img.get('sku', '')
                    if sku not in images_by_sku:
                        images_by_sku[sku] = []
                    images_by_sku[sku].append(img)
        
        # Merge
        for product in products:
            sku = product['sku']
            
            # Skip unknown SKUs
            if sku.startswith('UNKNOWN_') or sku.startswith('TOOL_'):
                continue
            
            # Get images
            product_images = images_by_sku.get(sku, [])
            
            # Build product for webshop
            webshop_product = {
                'id': f"{catalog}:{sku}",
                'sku': sku,
                'name': sku,
                'brand': 'Makita',
                'catalog': catalog,
                'category': get_category_from_catalog(catalog),
                'description': generate_description(product),
                'attributes': product.get('properties', {}),
                'attributes_english': product.get('properties_translated', {}),
                'attributes_with_icons': product.get('properties_with_icons', {}),
                'specs': build_specs_array(product),
                'media': build_media_array(product_images, catalog),
                'price': build_price(product),
                'stock': {
                    'status': 'in_stock',
                    'quantity': None
                },
                'seo': {
                    'slug': sku.lower(),
                    'meta_title': f"{sku} | Makita {get_category_from_catalog(catalog)}",
                    'meta_description': f"{sku} - Makita power tool with {len(product.get('properties', {}))} specifications."
                },
                'source': {
                    'pdf_sources': [f"{catalog}.pdf"],
                    'pages': [product.get('page', 0)]
                },
                'product_category': get_category_from_catalog(catalog),
                'pdf_source': f"{catalog}.pdf",
                'source_pages': [product.get('page', 0)],
                'priceMode': 'fixed' if product.get('price_excl_btw_eur') else 'request_quote',
                'inStock': True
            }
            
            # Add image paths
            if product_images:
                webshop_product['image_paths'] = [
                    f"/product-images/{catalog}/{img['filename']}" 
                    for img in product_images
                ]
                webshop_product['imageUrl'] = webshop_product['image_paths'][0]
            
            all_products.append(webshop_product)
    
    return all_products

def get_category_from_catalog(catalog):
    """Determine category from catalog name"""
    if 'tuinfolder' in catalog:
        return 'Garden Tools'
    return 'Power Tools'

def generate_description(product):
    """Generate product description from properties"""
    props = product.get('properties_translated', {})
    
    if not props:
        return None
    
    # Build description from key properties
    desc_parts = []
    
    if 'Max. torque soft/hard' in props:
        desc_parts.append(f"Max torque: {props['Max. torque soft/hard']}")
    
    if 'Max. output power' in props:
        desc_parts.append(f"Power: {props['Max. output power']}")
    
    if 'Weight' in props:
        desc_parts.append(f"Weight: {props['Weight']}")
    
    if 'Included batteries' in props and props['Included batteries'] != '0':
        desc_parts.append(f"Batteries: {props['Included batteries']}")
    
    if desc_parts:
        return ' | '.join(desc_parts)
    
    return None

def build_specs_array(product):
    """Build specs array in webshop format with icons"""
    specs = []
    
    # Use properties with icons for visual display
    props_with_icons = product.get('properties_with_icons', {})
    props_english = product.get('properties_translated', {})
    
    for key, value in props_with_icons.items():
        specs.append({
            'name': key,
            'value': value,
            'value_plain': props_english.get(key, ''),
            'icon_display': True
        })
    
    return specs

def build_media_array(images, catalog):
    """Build media array from images"""
    if not images:
        return []
    
    media = []
    
    for idx, img in enumerate(images):
        media.append({
            'url': f"/product-images/{catalog}/{img['filename']}",
            'role': 'main' if idx == 0 else 'gallery',
            'type': 'image',
            'format': 'webp'
        })
    
    return media

def build_price(product):
    """Build price object"""
    price_excl = product.get('price_excl_btw_eur')
    price_incl = product.get('price_incl_btw_eur')
    
    if price_excl or price_incl:
        return {
            'amount': price_excl or price_incl,
            'currency': 'EUR',
            'excl_vat': price_excl,
            'incl_vat': price_incl,
            'display': f"€{price_excl:.2f}" if price_excl else None
        }
    
    return None

def merge_products(existing, new_makita):
    """Merge Makita products with existing, replacing old Makita data"""
    # Remove old Makita products
    non_makita = [
        p for p in existing 
        if 'makita' not in p.get('catalog', '').lower()
    ]
    
    # Add new Makita products
    merged = non_makita + new_makita
    
    return merged

def main():
    print("="*80)
    print("MERGING MAKITA DATA TO WEBSHOP")
    print("="*80)
    
    # Load data
    print("\n[LOADING] Existing webshop data...")
    existing = load_existing_webshop_data()
    print(f"  Found {len(existing)} existing products")
    
    print("\n[LOADING] New Makita products with translations...")
    new_makita = load_makita_translated_products()
    print(f"  Found {len(new_makita)} new Makita products")
    
    # Merge
    print("\n[MERGING] Combining products...")
    merged = merge_products(existing, new_makita)
    
    # Save
    output_file = OUTPUT_DIR / "products_ready_for_webshop.json"
    backup_file = OUTPUT_DIR / f"products_ready_for_webshop_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    
    # Backup existing
    if output_file.exists():
        print(f"\n[BACKUP] Creating backup...")
        with open(backup_file, 'w', encoding='utf-8') as f:
            json.dump(existing, f, indent=2, ensure_ascii=False)
        print(f"  Saved to: {backup_file.name}")
    
    # Save merged
    print(f"\n[SAVING] Writing merged data...")
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(merged, f, indent=2, ensure_ascii=False)
    
    print(f"  Saved to: {output_file}")
    
    # Statistics
    print("\n" + "="*80)
    print("MERGE COMPLETE")
    print("="*80)
    print(f"\nStatistics:")
    print(f"  Previous total: {len(existing)}")
    print(f"  New Makita products: {len(new_makita)}")
    print(f"  Final total: {len(merged)}")
    
    # Show sample
    if new_makita:
        print("\n" + "="*80)
        print("SAMPLE MAKITA PRODUCT (with icons)")
        print("="*80)
        
        sample = new_makita[0]
        print(f"\nSKU: {sample['sku']}")
        print(f"Brand: {sample['brand']}")
        print(f"Category: {sample['category']}")
        
        if sample.get('specs'):
            print(f"\nSpecifications (with icons):")
            for spec in sample['specs'][:5]:
                print(f"  {spec['value']}")
        
        if sample.get('price'):
            print(f"\n💰 Price: {sample['price']['display']}")
        
        if sample.get('media'):
            print(f"\n📷 Images: {len(sample['media'])} photos")

if __name__ == '__main__':
    main()
