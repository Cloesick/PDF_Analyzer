"""
Enrich ALL comprehensive analysis JSONs with image paths
"""
import json
from pathlib import Path

print("="*80)
print("ENRICHING ALL JSONs WITH IMAGE PATHS")
print("="*80)

output_dir = Path('output')
analysis_files = sorted(output_dir.glob('*_analysis.json'))

enriched_count = 0
total_products = 0
total_images = 0

for json_file in analysis_files:
    # Skip already enriched versions
    if '_enriched' in json_file.name:
        continue
    
    # Check if already enriched
    enriched_path = json_file.parent / f"{json_file.stem}_enriched.json"
    if enriched_path.exists():
        print(f"  ⏭️  Skipping {json_file.stem} (already enriched)")
        continue
    
    try:
        with open(json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Check if it's comprehensive (has pages)
        if 'pages' not in data:
            print(f"  ⏭️  Skipping {json_file.stem} (not comprehensive format)")
            continue
        
        print(f"\n{'='*80}")
        print(f"📄 Processing: {json_file.stem}")
        print(f"{'='*80}")
        
        pdf_name = json_file.stem.replace('_analysis', '')
        
        # Image paths configuration
        image_base_path = f'images/{pdf_name}'
        image_base_url = f'/images/products/{pdf_name}'
        
        products_with_images = 0
        unique_images = set()
        
        # Process each page
        for page in data['pages']:
            for product in page['products_found']:
                if product.get('image_hash'):
                    image_hash = product['image_hash']
                    unique_images.add(image_hash)
                    products_with_images += 1
                    
                    # Add image paths
                    image_filename = f"{image_hash}.webp"
                    product['image_path'] = f"{image_base_path}/{image_filename}"
                    product['image_url'] = f"{image_base_url}/{image_filename}"
                    
                    # Alternative formats
                    product['image_formats'] = {
                        'webp': f"{image_base_url}/{image_hash}.webp",
                        'png': f"{image_base_url}/{image_hash}.png",
                        'jpg': f"{image_base_url}/{image_hash}.jpg"
                    }
        
        # Update shared images with paths
        if 'shared_images' in data:
            for img_info in data['shared_images']:
                if 'image_hash' in img_info:
                    image_hash = img_info['image_hash']
                    image_filename = f"{image_hash}.webp"
                    
                    img_info['image_path'] = f"{image_base_path}/{image_filename}"
                    img_info['image_url'] = f"{image_base_url}/{image_filename}"
                    img_info['image_formats'] = {
                        'webp': f"{image_base_url}/{image_hash}.webp",
                        'png': f"{image_base_url}/{image_hash}.png",
                        'jpg': f"{image_base_url}/{image_hash}.jpg"
                    }
        
        # Update images_found with paths
        for page in data['pages']:
            for img_info in page['images_found']:
                if 'image_hash' in img_info:
                    image_hash = img_info['image_hash']
                    image_filename = f"{image_hash}.webp"
                    
                    img_info['image_path'] = f"{image_base_path}/{image_filename}"
                    img_info['image_url'] = f"{image_base_url}/{image_filename}"
                    img_info['image_formats'] = {
                        'webp': f"{image_base_url}/{image_hash}.webp",
                        'png': f"{image_base_url}/{image_hash}.png",
                        'jpg': f"{image_base_url}/{image_hash}.jpg"
                    }
        
        # Save enriched JSON
        with open(enriched_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        enriched_count += 1
        total_products += data.get('total_products', 0)
        total_images += len(unique_images)
        
        print(f"  ✓ Products: {data.get('total_products', 0)}")
        print(f"  ✓ Products with images: {products_with_images}")
        print(f"  ✓ Unique images: {len(unique_images)}")
        print(f"  ✓ Saved to: {enriched_path.name}")
        
    except Exception as e:
        print(f"  ✗ Error processing {json_file.name}: {e}")
        continue

print(f"\n{'='*80}")
print(f"ENRICHMENT COMPLETE")
print(f"{'='*80}")
print(f"\n✅ Enriched {enriched_count} JSON files")
print(f"  • Total products: {total_products:,}")
print(f"  • Total unique images: {total_images}")
print(f"\n📁 All enriched files saved with '_enriched.json' suffix")
print(f"💡 Ready for frontend integration!")
print("="*80)
