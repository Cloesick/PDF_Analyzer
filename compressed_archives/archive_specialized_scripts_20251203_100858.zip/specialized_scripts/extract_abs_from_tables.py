"""
Extract ABS-Persluchtbuizen products from PDF tables
Tables have columns: Bestelnr | Maat (or Maten) | Werkdruk | (optional SN, Keurmerk)
"""
import fitz
import json
import re
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "abs-persluchtbuizen.pdf"
OUTPUT_JSON = PROJECT_ROOT / "output" / "abs_table_specs.json"

def extract_diameter_from_maat(maat_str):
    """Extract diameter in mm from Maat string like '110 mm' or '16 mm x 3/8"'"""
    if not maat_str:
        return None
    
    # Clean string
    maat_str = str(maat_str).strip()
    
    # Pattern: "110 mm" or "16 mm x 3/8""
    match = re.search(r'(\d+)\s*mm', maat_str)
    if match:
        return int(match.group(1))
    
    return None

def extract_pressure(werkdruk_str):
    """Extract pressure in bar from Werkdruk string like '10 bar'"""
    if not werkdruk_str:
        return None
    
    # Clean string
    werkdruk_str = str(werkdruk_str).strip()
    
    # Pattern: "10 bar"
    match = re.search(r'(\d+(?:[.,]\d+)?)\s*bar', werkdruk_str)
    if match:
        return float(match.group(1).replace(',', '.'))
    
    return None

def process_pdf():
    """Process ABS-Persluchtbuizen PDF"""
    print("=" * 80)
    print("EXTRACTING ABS PRODUCTS FROM TABLES")
    print("=" * 80)
    
    doc = fitz.open(PDF_PATH)
    
    all_products = []
    stats = {
        'pages_processed': 0,
        'tables_found': 0,
        'products_extracted': 0,
        'with_diameter': 0,
        'with_pressure': 0
    }
    
    print(f"\n📄 Processing: {PDF_PATH.name}")
    print(f"   Total pages: {len(doc)}")
    print(f"\n⚡ Extracting products...")
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        stats['pages_processed'] += 1
        
        if (page_num + 1) % 5 == 0:
            print(f"   Processing page {page_num + 1}... ({stats['products_extracted']} products found)")
        
        # Extract tables
        try:
            tables = page.find_tables()
            for table in tables:
                stats['tables_found'] += 1
                extracted = table.extract()
                
                if not extracted or len(extracted) < 2:
                    continue
                
                # Check if this is an ABS product table
                # Should have headers: Bestelnr | Maat/Maten | Werkdruk | ...
                headers = extracted[0]
                if not any('bestelnr' in str(h).lower() for h in headers):
                    continue
                
                # Identify column positions
                bestelnr_col = None
                maat_col = None
                werkdruk_col = None
                
                for i, header in enumerate(headers):
                    h_lower = str(header).lower()
                    if 'bestelnr' in h_lower:
                        bestelnr_col = i
                    elif 'maat' in h_lower:  # Matches both "Maat" and "Maten"
                        maat_col = i
                    elif 'werkdruk' in h_lower:
                        werkdruk_col = i
                
                if bestelnr_col is None:
                    continue
                
                # Process rows
                for row in extracted[1:]:
                    if not row or len(row) <= bestelnr_col:
                        continue
                    
                    # Column 0 (or identified): SKU (Bestelnr)
                    sku = str(row[bestelnr_col]).strip()
                    if not sku or len(sku) < 2:
                        continue
                    
                    # Build product
                    product = {
                        'sku': sku,
                        'page_in_pdf': page_num + 1
                    }
                    
                    # Extract diameter from Maat column
                    if maat_col is not None and len(row) > maat_col:
                        diameter = extract_diameter_from_maat(row[maat_col])
                        if diameter:
                            product['diameter_mm'] = diameter
                            stats['with_diameter'] += 1
                    
                    # Extract pressure from Werkdruk column
                    if werkdruk_col is not None and len(row) > werkdruk_col:
                        pressure = extract_pressure(row[werkdruk_col])
                        if pressure:
                            product['pressure_max_bar'] = pressure
                            stats['with_pressure'] += 1
                    
                    all_products.append(product)
                    stats['products_extracted'] += 1
                    
                    if stats['products_extracted'] <= 15:
                        diameter_str = f"{product.get('diameter_mm', 'N/A'):>3}"
                        pressure_str = f"{product.get('pressure_max_bar', 'N/A'):>4}"
                        print(f"      ✓ {sku:15} | ø {diameter_str} mm | 🔧 {pressure_str} bar")
                        
        except Exception as e:
            continue
    
    doc.close()
    
    # Save results
    OUTPUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(all_products, f, ensure_ascii=False, indent=2)
    
    # Statistics
    print(f"\n📊 EXTRACTION STATISTICS:")
    print(f"   Pages processed:           {stats['pages_processed']}")
    print(f"   Tables found:              {stats['tables_found']}")
    print(f"   Products extracted:        {stats['products_extracted']}")
    print(f"   With diameter:             {stats['with_diameter']}")
    print(f"   With pressure:             {stats['with_pressure']}")
    
    # Show samples by type
    print(f"\n📋 SAMPLE PRODUCTS BY TYPE:")
    
    # Group by SKU prefix
    prefixes = {}
    for product in all_products:
        prefix = product['sku'][:4] if len(product['sku']) >= 4 else product['sku']
        if prefix not in prefixes:
            prefixes[prefix] = []
        prefixes[prefix].append(product)
    
    # Show samples for each prefix
    for prefix in sorted(prefixes.keys())[:10]:
        products = prefixes[prefix]
        sample = products[0]
        print(f"\n   {prefix}* series ({len(products)} products):")
        print(f"      Example: {sample['sku']}")
        if 'diameter_mm' in sample:
            print(f"      Diameter: {sample['diameter_mm']} mm")
        if 'pressure_max_bar' in sample:
            print(f"      Pressure: {sample['pressure_max_bar']} bar")
    
    print(f"\n💾 Output saved to: {OUTPUT_JSON}")
    print(f"\n{'='*80}")
    print("✅ EXTRACTION COMPLETE")
    print("="*80)
    
    return all_products

if __name__ == '__main__':
    process_pdf()
