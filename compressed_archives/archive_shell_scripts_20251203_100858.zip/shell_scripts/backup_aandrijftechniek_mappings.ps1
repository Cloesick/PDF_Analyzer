#!/usr/bin/env pwsh
# Backup script for aandrijftechniek mapping system
# Run this before making any changes to ensure you can rollback

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backupDir = "backups/aandrijftechniek_$timestamp"

Write-Host "`n🔒 BACKING UP AANDRIJFTECHNIEK MAPPING SYSTEM" -ForegroundColor Cyan
Write-Host "=" -NoNewline; Write-Host ("=" * 79) -ForegroundColor Cyan

# Create backup directory
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
Write-Host "`n📁 Backup location: $backupDir`n" -ForegroundColor Yellow

# Files to backup
$filesToBackup = @(
    @{
        Source = "..\DemaWebshop\dema-webshop\public\data\aandrijftechniek_image_mapping.json"
        Name = "SKU Mapping"
    },
    @{
        Source = "..\DemaWebshop\dema-webshop\public\data\aandrijftechniek_group_mapping.json"
        Name = "Group Mapping"
    },
    @{
        Source = "..\DemaWebshop\dema-webshop\public\data\aandrijftechniek_grouped.json"
        Name = "Grouped Data"
    },
    @{
        Source = "..\DemaWebshop\dema-webshop\src\app\catalog\aandrijftechniek-grouped\page.tsx"
        Name = "Frontend Code"
    }
)

$backupCount = 0

foreach ($file in $filesToBackup) {
    if (Test-Path $file.Source) {
        $destination = Join-Path $backupDir (Split-Path $file.Source -Leaf)
        Copy-Item $file.Source $destination -Force
        Write-Host "  ✅ Backed up: $($file.Name)" -ForegroundColor Green
        $backupCount++
    } else {
        Write-Host "  ⚠️  Not found: $($file.Name)" -ForegroundColor Yellow
    }
}

# Create backup manifest
$manifest = @{
    timestamp = $timestamp
    files_backed_up = $backupCount
    created_by = $env:USERNAME
    purpose = "Aandrijftechniek mapping system backup"
}

$manifest | ConvertTo-Json | Out-File (Join-Path $backupDir "manifest.json")

Write-Host "`n✅ Backup complete!" -ForegroundColor Green
Write-Host "   Files backed up: $backupCount" -ForegroundColor White
Write-Host "   Location: $backupDir`n" -ForegroundColor White

# List recent backups
Write-Host "📋 Recent backups:" -ForegroundColor Cyan
if (Test-Path "backups") {
    Get-ChildItem "backups" -Directory | Sort-Object Name -Descending | Select-Object -First 5 Name, CreationTime | Format-Table -AutoSize
}

Write-Host "`n💡 To restore: Copy files from backup folder back to original locations" -ForegroundColor Magenta
Write-Host ""
