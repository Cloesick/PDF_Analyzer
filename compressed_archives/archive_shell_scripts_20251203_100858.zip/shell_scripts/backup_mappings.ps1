# Backup script for aandrijftechniek mapping system

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backupDir = "backups/aandrijftechniek_$timestamp"

Write-Host ""
Write-Host "BACKING UP AANDRIJFTECHNIEK MAPPING SYSTEM" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# Create backup directory
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
Write-Host ""
Write-Host "Backup location: $backupDir" -ForegroundColor Yellow
Write-Host ""

# Files to backup
$filesToBackup = @(
    "..\DemaWebshop\dema-webshop\public\data\aandrijftechniek_image_mapping.json",
    "..\DemaWebshop\dema-webshop\public\data\aandrijftechniek_group_mapping.json",
    "..\DemaWebshop\dema-webshop\public\data\aandrijftechniek_grouped.json",
    "..\DemaWebshop\dema-webshop\src\app\catalog\aandrijftechniek-grouped\page.tsx"
)

$backupCount = 0

foreach ($file in $filesToBackup) {
    if (Test-Path $file) {
        $filename = Split-Path $file -Leaf
        $destination = Join-Path $backupDir $filename
        Copy-Item $file $destination -Force
        Write-Host "  Backed up: $filename" -ForegroundColor Green
        $backupCount++
    } else {
        Write-Host "  Not found: $file" -ForegroundColor Yellow
    }
}

# Create manifest
$manifest = @{
    timestamp = $timestamp
    files = $backupCount
    user = $env:USERNAME
}

$manifest | ConvertTo-Json | Out-File (Join-Path $backupDir "manifest.json")

Write-Host ""
Write-Host "Backup complete! Files backed up: $backupCount" -ForegroundColor Green
Write-Host ""
