# Copy all product images to webshop

$sourceRoot = "C:\Users\prova\Documents\Projects\PDF_Analyzer\product-images-by-pdf"
$destRoot = "C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop\public\product-images-by-pdf"

Write-Host "=" * 80
Write-Host "COPYING ALL PRODUCT IMAGES TO WEBSHOP"
Write-Host "=" * 80
Write-Host ""

# Create destination if it doesn't exist
if (-not (Test-Path $destRoot)) {
    New-Item -ItemType Directory -Path $destRoot -Force | Out-Null
    Write-Host "Created directory: $destRoot"
}

# Get all directories in source
$sourceDirs = Get-ChildItem $sourceRoot -Directory

$copiedCount = 0
$skippedCount = 0
$totalImages = 0

foreach ($dir in $sourceDirs) {
    $sourcePath = $dir.FullName
    $destPath = Join-Path $destRoot $dir.Name
    
    # Count images in source
    $images = Get-ChildItem $sourcePath -File -Filter "*.webp" -ErrorAction SilentlyContinue
    $imageCount = $images.Count
    
    if ($imageCount -eq 0) {
        Write-Host "  ⚠️  $($dir.Name): No images, skipping"
        $skippedCount++
        continue
    }
    
    # Copy directory
    try {
        if (Test-Path $destPath) {
            Remove-Item $destPath -Recurse -Force
        }
        Copy-Item $sourcePath $destPath -Recurse -Force
        Write-Host "  ✅ $($dir.Name): Copied $imageCount images"
        $copiedCount++
        $totalImages += $imageCount
    }
    catch {
        Write-Host "  ❌ $($dir.Name): Error - $_"
    }
}

Write-Host ""
Write-Host "=" * 80
Write-Host "SUMMARY"
Write-Host "=" * 80
Write-Host "Directories copied: $copiedCount"
Write-Host "Directories skipped: $skippedCount"
Write-Host "Total images: $totalImages"
Write-Host ""
Write-Host "✅ Images ready at: $destRoot"
Write-Host "=" * 80
