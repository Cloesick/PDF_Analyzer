#!/usr/bin/env pwsh
# Quick script to regenerate and deploy webshop data

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "   WEBSHOP DATA UPDATE SCRIPT" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Step 1: Regenerate statistics
Write-Host "🔄 Step 1: Generating global statistics..." -ForegroundColor Yellow
python calculate_stats.py
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Error generating statistics!" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "🔄 Step 2: Generating per-catalog metadata..." -ForegroundColor Yellow
python generate_catalog_data.py
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Error generating catalog data!" -ForegroundColor Red
    exit 1
}

# Step 2: Copy to webshop
Write-Host ""
Write-Host "📦 Step 3: Copying to webshop..." -ForegroundColor Yellow

$webshopPath = "..\DemaWebshop\dema-webshop\public"
if (-not (Test-Path $webshopPath)) {
    Write-Host "❌ Webshop path not found: $webshopPath" -ForegroundColor Red
    exit 1
}

Copy-Item "output\catalog_statistics.json" "$webshopPath\catalog_statistics.json" -Force
Copy-Item "output\catalogs_metadata.json" "$webshopPath\catalogs_metadata.json" -Force

# Verify files were copied
if ((Test-Path "$webshopPath\catalog_statistics.json") -and (Test-Path "$webshopPath\catalogs_metadata.json")) {
    Write-Host "✅ Files copied successfully!" -ForegroundColor Green
} else {
    Write-Host "❌ Error copying files!" -ForegroundColor Red
    exit 1
}

# Summary
Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "   ✅ WEBSHOP DATA UPDATED!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "📊 Files updated:" -ForegroundColor Cyan
Write-Host "   • catalog_statistics.json (global stats)" -ForegroundColor White
Write-Host "   • catalogs_metadata.json (26 catalogs)" -ForegroundColor White
Write-Host ""
Write-Host "🌐 View changes at:" -ForegroundColor Cyan
Write-Host "   • http://localhost:3000/catalogs" -ForegroundColor Yellow
Write-Host ""
Write-Host "💡 The webshop will automatically reload with the new data!" -ForegroundColor Magenta
Write-Host ""
