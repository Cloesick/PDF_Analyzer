"""
Debug Makita Tables - Show actual table structure
"""
import pdfplumber
import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "makita-catalogus-2022-nl.pdf"

# Search for pages with specific SKUs from your example
TARGET_SKUS = ['DF002GZ01', 'DF002GD201', 'DF001GZ01', 'DF001GM201', 
               'HP002GZ01', 'HP002GD201', 'HP001GZ01', 'HP001GM201']

print("="*80)
print("DEBUGGING MAKITA TABLES")
print("="*80)
print(f"\nSearching for SKUs: {', '.join(TARGET_SKUS[:4])}...")

with pdfplumber.open(PDF_PATH) as pdf:
    for page_num, page in enumerate(pdf.pages, 1):
        page_text = page.extract_text() or ""
        
        # Check if any target SKUs are on this page
        found_skus = [sku for sku in TARGET_SKUS if sku in page_text]
        
        if found_skus:
            print(f"\n{'='*80}")
            print(f"PAGE {page_num} - Found SKUs: {', '.join(found_skus)}")
            print(f"{'='*80}")
            
            tables = page.extract_tables()
            print(f"\nTotal tables on page: {len(tables)}")
            
            for table_idx, table in enumerate(tables):
                if not table:
                    continue
                
                # Check if table contains our SKUs
                table_text = str(table)
                if any(sku in table_text for sku in found_skus):
                    print(f"\n--- TABLE {table_idx + 1} (Contains target SKUs) ---")
                    print(f"Rows: {len(table)}, Columns: {len(table[0]) if table else 0}")
                    
                    # Show first few rows
                    print("\nFirst 10 rows:")
                    for i, row in enumerate(table[:10]):
                        print(f"Row {i}: {row[:8] if len(row) > 8 else row}")  # Show first 8 columns
                    
                    if len(table) > 10:
                        print(f"\n... and {len(table) - 10} more rows")
                    
                    # Save full table to JSON for inspection
                    debug_file = PROJECT_ROOT / f"debug_table_p{page_num}_t{table_idx+1}.json"
                    with open(debug_file, 'w', encoding='utf-8') as f:
                        json.dump(table, f, indent=2, ensure_ascii=False)
                    print(f"\n💾 Full table saved to: {debug_file.name}")
        
        if page_num >= 50:  # Only check first 50 pages
            break

print(f"\n{'='*80}\n")
