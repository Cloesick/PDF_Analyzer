"""
Verify SKU/order numbers and shared image usage across products
"""
import json
from collections import defaultdict

print("="*80)
print("SKU REFERENCES & SHARED IMAGE ANALYSIS")
print("="*80)

pdfs = [
    ('PE-Buizen', 'output/pe_buizen_analysis.json'),
    ('Plat-Oprolbare', 'output/plat_oprolbare_analysis.json'),
    ('Aandrijftechniek', 'output/aandrijftechniek_analysis.json')
]

all_skus = {}  # SKU -> list of (pdf, product_id)

for pdf_name, json_path in pdfs:
    print(f"\n{'='*80}")
    print(f"PDF: {pdf_name}")
    print(f"{'='*80}")
    
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # Check for SKU/order number fields
    sku_fields = ['order_number', 'article_number', 'product_code', 'sku', 'model']
    products_with_sku = 0
    sku_samples = []
    
    for page in data['pages']:
        for prod in page['products_found']:
            specs = prod['specifications']
            found_sku = False
            
            for sku_field in sku_fields:
                if sku_field in specs:
                    sku_value = specs[sku_field]
                    products_with_sku += 1
                    found_sku = True
                    
                    # Track this SKU
                    if sku_value not in all_skus:
                        all_skus[sku_value] = []
                    all_skus[sku_value].append((pdf_name, prod['product_id']))
                    
                    # Collect sample
                    if len(sku_samples) < 5:
                        sku_samples.append({
                            'product_id': prod['product_id'],
                            'sku_field': sku_field,
                            'sku_value': sku_value,
                            'page': prod['page_number']
                        })
                    break
    
    print(f"\n📋 SKU/ORDER NUMBER STATUS:")
    print(f"  Total products: {data['total_products']}")
    print(f"  Products with SKU/order numbers: {products_with_sku}")
    
    if products_with_sku > 0:
        print(f"  Coverage: {products_with_sku/data['total_products']*100:.1f}%")
        print(f"\n  Sample SKUs:")
        for sample in sku_samples[:3]:
            print(f"    • Page {sample['page']}: {sample['sku_field']} = '{sample['sku_value']}'")
    else:
        print(f"  ⚠️  No SKU/order numbers found in specifications")
    
    # Check shared images
    print(f"\n🖼️  SHARED IMAGE STATUS:")
    print(f"  Total images: {data['total_images']}")
    
    shared_images = data.get('shared_images', [])
    if shared_images:
        print(f"  Shared images: {len(shared_images)}")
        
        # Show top shared images
        sorted_shared = sorted(shared_images, key=lambda x: len(x.get('products', [])), reverse=True)
        print(f"\n  Top 5 most shared images:")
        for i, img_info in enumerate(sorted_shared[:5], 1):
            img_hash = img_info.get('image_hash', 'unknown')
            products = img_info.get('products', [])
            print(f"    {i}. {img_hash[:30]}... → {len(products)} products")
            
            # Check if these are table products
            table_products = [p for p in products if '_TBL' in p]
            if table_products:
                print(f"       ✓ {len(table_products)} are table products (sharing same image)")
    else:
        print(f"  ⚠️  No shared images tracked")

# Check for SKUs appearing in multiple PDFs
print(f"\n{'='*80}")
print(f"CROSS-PDF SKU ANALYSIS")
print(f"{'='*80}")

duplicate_skus = {sku: locations for sku, locations in all_skus.items() if len(locations) > 1}

if duplicate_skus:
    print(f"\n✓ Found {len(duplicate_skus)} SKUs appearing in multiple products:")
    for sku, locations in list(duplicate_skus.items())[:10]:
        print(f"\n  SKU: '{sku}'")
        for pdf_name, prod_id in locations:
            print(f"    • {pdf_name}: {prod_id}")
    
    if len(duplicate_skus) > 10:
        print(f"\n  ...and {len(duplicate_skus) - 10} more duplicate SKUs")
else:
    print(f"\n⚠️  No SKUs found appearing across multiple products/PDFs")

# Summary statistics
print(f"\n{'='*80}")
print(f"SUMMARY")
print(f"{'='*80}")

total_products = sum(len([p for page in json.load(open(path, 'r', encoding='utf-8'))['pages'] for p in page['products_found']]) for _, path in pdfs)
total_with_sku = sum(1 for locations in all_skus.values() for _ in locations)

print(f"\nOverall Statistics:")
print(f"  • Total products: {total_products}")
print(f"  • Products with SKU/order numbers: {total_with_sku} ({total_with_sku/total_products*100:.1f}%)")
print(f"  • Unique SKUs: {len(all_skus)}")

# Detailed shared image analysis
print(f"\n🖼️  Shared Image Summary:")
for pdf_name, json_path in pdfs:
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    shared_count = len([img for img in data.get('shared_images', []) if len(img.get('products', [])) > 1])
    print(f"  • {pdf_name}: {shared_count} shared images")
    
    # Count table products sharing images
    table_sharing = 0
    for img_info in data.get('shared_images', []):
        products = img_info.get('products', [])
        table_prods = [p for p in products if '_TBL' in p]
        if len(table_prods) > 1:
            table_sharing += 1
    
    if table_sharing > 0:
        print(f"    → {table_sharing} images shared by multiple table products")

print("="*80)
