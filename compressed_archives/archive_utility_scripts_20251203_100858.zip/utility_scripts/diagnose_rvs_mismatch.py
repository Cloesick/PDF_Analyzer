"""
Diagnose RVS SKU Mismatch
==========================
Find out why products aren't matching
"""
import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
PRODUCTS_JSON = PROJECT_ROOT / "output" / "products_ready_for_webshop.json"
IMAGES_JSON = PROJECT_ROOT / "output" / "rvs_extracted_products.json"
PROPERTIES_JSON = PROJECT_ROOT / "output" / "rvs_properties_extracted.json"

with open(PRODUCTS_JSON, 'r', encoding='utf-8') as f:
    all_products = json.load(f)

with open(IMAGES_JSON, 'r', encoding='utf-8') as f:
    extracted_images = json.load(f)

with open(PROPERTIES_JSON, 'r', encoding='utf-8') as f:
    extracted_properties = json.load(f)

# Get RVS product SKUs from database
rvs_products = [p for p in all_products if 'rvs-draadfittingen' in p.get('pdf_source', '').lower()]
db_skus = set(p['sku'] for p in rvs_products)

# Get extracted SKUs
image_skus = set(item['sku'] for item in extracted_images)
prop_skus = set(item['sku'] for item in extracted_properties)

print("=" * 80)
print("RVS SKU MISMATCH DIAGNOSIS")
print("=" * 80)

print(f"\n📊 SKU Counts:")
print(f"   Database SKUs:       {len(db_skus)}")
print(f"   Extracted (images):  {len(image_skus)}")
print(f"   Extracted (props):   {len(prop_skus)}")

print(f"\n🔍 Database SKUs (first 10):")
for sku in sorted(db_skus)[:10]:
    print(f"   - {sku}")

print(f"\n🔍 Extracted Image SKUs (first 10):")
for sku in sorted(image_skus)[:10]:
    print(f"   - {sku}")

print(f"\n🔍 Extracted Property SKUs (first 10):")
for sku in sorted(prop_skus)[:10]:
    print(f"   - {sku}")

# Check overlaps
db_image_overlap = db_skus & image_skus
db_prop_overlap = db_skus & prop_skus
all_overlap = db_skus & image_skus & prop_skus

print(f"\n📊 Overlaps:")
print(f"   DB ∩ Images:         {len(db_image_overlap)}")
print(f"   DB ∩ Properties:     {len(db_prop_overlap)}")
print(f"   DB ∩ Both:           {len(all_overlap)}")

if db_image_overlap:
    print(f"\n✅ Matching SKUs (DB ∩ Images):")
    for sku in sorted(db_image_overlap)[:5]:
        print(f"   - {sku}")

if db_prop_overlap:
    print(f"\n✅ Matching SKUs (DB ∩ Properties):")
    for sku in sorted(db_prop_overlap)[:5]:
        print(f"   - {sku}")

print("\n" + "=" * 80)
print("RECOMMENDATION")
print("=" * 80)
print("""
The SKUs in the original database don't match the extracted SKUs.
This could be because:
1. Different SKU formats in database vs PDF
2. Database has simplified SKUs, PDF has full codes
3. Need fuzzy matching or SKU mapping

Solution: Use fuzzy matching or check if one SKU contains another.
""")
