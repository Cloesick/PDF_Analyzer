"""
Verify if images are shared across different products/SKUs
"""
import json
from collections import defaultdict

print("="*80)
print("IMAGE SHARING ACROSS PRODUCTS/SKUs ANALYSIS")
print("="*80)

pdfs = [
    ('PE-Buizen', 'output/pe_buizen_analysis_enriched.json'),
    ('Plat-Oprolbare', 'output/plat_oprolbare_analysis_enriched.json'),
    ('Aandrijftechniek', 'output/aandrijftechniek_analysis_enriched.json')
]

for pdf_name, json_path in pdfs:
    print(f"\n{'='*80}")
    print(f"PDF: {pdf_name}")
    print(f"{'='*80}")
    
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # Map image hash to products
    image_to_products = defaultdict(list)
    
    for page in data['pages']:
        for prod in page['products_found']:
            if prod.get('image_hash'):
                image_hash = prod['image_hash']
                image_to_products[image_hash].append({
                    'product_id': prod['product_id'],
                    'description': prod['description'],
                    'page': prod['page_number'],
                    'specs': prod.get('specifications', {}),
                    'image_url': prod.get('image_url', 'N/A')
                })
    
    # Find shared images
    shared_images = {img: prods for img, prods in image_to_products.items() if len(prods) > 1}
    
    print(f"\n📊 STATISTICS:")
    print(f"  Total unique images: {len(image_to_products)}")
    print(f"  Images shared by multiple products: {len(shared_images)}")
    print(f"  Percentage of images shared: {len(shared_images)/len(image_to_products)*100:.1f}%")
    
    if shared_images:
        # Show top 3 most shared images
        sorted_shared = sorted(shared_images.items(), key=lambda x: len(x[1]), reverse=True)
        
        print(f"\n🖼️  TOP 3 MOST SHARED IMAGES:")
        for i, (img_hash, products) in enumerate(sorted_shared[:3], 1):
            print(f"\n  {i}. Image: {img_hash[:50]}...")
            print(f"     Shared by {len(products)} products")
            print(f"     Image URL: {products[0]['image_url']}")
            print(f"     Products using this image:")
            
            # Show first 5 products
            for prod in products[:5]:
                # Try to extract key identifying info
                specs = prod['specs']
                
                # Look for diameter or size
                diameter = specs.get('diameter', specs.get('diameter_mm', ''))
                if diameter and 'mm' not in str(diameter):
                    diameter = f"{diameter} mm"
                
                # Look for SKU/order number
                sku = specs.get('order_number', specs.get('article_number', specs.get('sku', '')))
                
                # Build identifier
                identifier_parts = []
                if sku:
                    identifier_parts.append(f"SKU:{sku}")
                if diameter:
                    identifier_parts.append(f"Ø{diameter}")
                
                identifier = ', '.join(identifier_parts) if identifier_parts else prod['description'][:50]
                
                print(f"       • {prod['product_id']} - {identifier}")
            
            if len(products) > 5:
                print(f"       ... and {len(products) - 5} more products")
    
    # Check if products with DIFFERENT specifications share images
    print(f"\n🔍 SPECIFICATION VARIANCE AMONG SHARED IMAGES:")
    
    examples_found = 0
    for img_hash, products in sorted_shared[:5]:
        # Check if products have different key specs
        diameters = set()
        pressures = set()
        materials = set()
        
        for prod in products:
            specs = prod['specs']
            if specs.get('diameter'):
                diameters.add(specs['diameter'])
            if specs.get('diameter_mm'):
                diameters.add(specs['diameter_mm'])
            if specs.get('pressure') or specs.get('working_pressure'):
                pressures.add(specs.get('pressure', specs.get('working_pressure')))
            if specs.get('material'):
                materials.add(specs['material'])
        
        if len(diameters) > 1 or len(pressures) > 1:
            examples_found += 1
            print(f"\n  Example {examples_found}: {len(products)} products share image")
            print(f"    Image: {img_hash[:50]}...")
            if len(diameters) > 1:
                print(f"    Different diameters: {', '.join(str(d) for d in list(diameters)[:5])}")
            if len(pressures) > 1:
                print(f"    Different pressures: {', '.join(str(p) for p in list(pressures)[:3])}")
            if len(materials) > 1:
                print(f"    Different materials: {', '.join(materials)}")
            print(f"    ✓ Same image represents multiple product variants!")

print(f"\n{'='*80}")
print(f"CONCLUSION")
print(f"{'='*80}")

print("""
✅ YES - Images are shared across different products!

This is CORRECT behavior because:
1. Product families share the same visual appearance
2. One product image represents multiple sizes/variants
3. Tables list all variants with shared product image above

Example: A pipe product image shows what PE pipes look like.
The table below lists 20+ diameter variants (20mm, 25mm, 32mm...)
All variants share that one image because they're the same product type.

Frontend Benefit:
- Fewer images to load/store
- Consistent product family visualization  
- One image per product category/family
""")

print("="*80)
