"""
Debug: Check ALL rows in the welding table to see which diameters are missing
"""
import pdfplumber
import json

pdf_path = 'input_pdfs/pe-buizen.pdf'

print("="*80)
print("DEBUG: COMPLETE WELDING TABLE EXTRACTION - Page 5")
print("="*80)

expected_diameters = [20, 25, 32, 40, 50, 63, 75, 90, 110, 125, 140, 160, 180, 200, 225, 250, 280, 315, 355, 400, 450, 500]

with pdfplumber.open(pdf_path) as pdf:
    page = pdf.pages[4]  # Page 5 (0-indexed)
    
    tables = page.extract_tables()
    table = tables[0]
    
    print(f"\nTotal rows in table: {len(table)}")
    print(f"Expected products: 22 (diameters: {', '.join(map(str, expected_diameters))})")
    
    print(f"\n{'='*80}")
    print(f"ALL TABLE ROWS (showing column 0 = diameter):")
    print(f"{'='*80}")
    
    found_diameters = []
    missing_diameters = []
    
    for row_idx, row in enumerate(table):
        col_0 = row[0] if row else None
        col_0_str = str(col_0).strip() if col_0 else 'None'
        
        # Check if it's a numeric diameter
        is_diameter = col_0_str.isdigit()
        
        if is_diameter:
            diameter_val = int(col_0_str)
            found_diameters.append(diameter_val)
            marker = "✓"
        else:
            marker = "✗"
        
        # Show first few columns
        sample_cols = [str(cell)[:20] if cell else 'None' for cell in row[:6]]
        print(f"  Row {row_idx:2d} {marker}: Col0='{col_0_str:<6}' | {' | '.join(sample_cols)}")
    
    print(f"\n{'='*80}")
    print(f"ANALYSIS:")
    print(f"{'='*80}")
    
    print(f"\nFound diameters ({len(found_diameters)}):")
    print(f"  {', '.join(map(str, found_diameters))}")
    
    missing_diameters = [d for d in expected_diameters if d not in found_diameters]
    
    if missing_diameters:
        print(f"\n⚠️  Missing diameters ({len(missing_diameters)}):")
        print(f"  {', '.join(map(str, missing_diameters))}")
        
        print(f"\n  These rows likely have empty/None in column 0 in the PDF")
        print(f"  This is common when PDFs use visual formatting instead of data in every cell")

# Now check the JSON output
print(f"\n{'='*80}")
print(f"JSON OUTPUT CHECK:")
print(f"{'='*80}")

with open('output/pe_buizen_analysis.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

page_5 = [p for p in data['pages'] if p['page_number'] == 5][0]
table_products = [p for p in page_5['products_found'] if '_TBL' in p['product_id']]

products_with_diameter = [p for p in table_products if 'diameter' in p['specifications']]
products_without_diameter = [p for p in table_products if 'diameter' not in p['specifications']]

print(f"\nTotal products from table: {len(table_products)}")
print(f"Products WITH diameter: {len(products_with_diameter)}")
print(f"Products WITHOUT diameter: {len(products_without_diameter)}")

if products_with_diameter:
    captured_diams = sorted([int(float(p['specifications']['diameter_mm'])) for p in products_with_diameter])
    print(f"\nCaptured diameters: {', '.join(map(str, captured_diams))}")

if products_without_diameter:
    print(f"\n⚠️  Products missing diameter:")
    for prod in products_without_diameter[:5]:
        specs = prod['specifications']
        print(f"  • {prod['product_id']}: Weld={specs.get('welding_time', 'N/A')}, V={specs.get('voltage', 'N/A')}, R={specs.get('resistance', 'N/A')}")

print("\n" + "="*80)
print("CONCLUSION:")
print("="*80)
print("\nThe PDF likely has the diameter column merged/formatted visually,")
print("showing the diameter only once per group of rows.")
print("\nWe need to:")
print("1. Track the last known diameter value")
print("2. Apply it to subsequent rows with empty diameter cells")
print("="*80)
