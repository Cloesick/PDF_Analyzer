"""
Check image formats across all catalog folders
"""

from pathlib import Path
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
IMAGES_DIR = PROJECT_ROOT / "product-images"

print("📊 Checking image formats across all catalogs...\n")

# Stats per catalog
by_catalog = {}
total_stats = defaultdict(int)

for catalog_dir in sorted(IMAGES_DIR.iterdir()):
    if not catalog_dir.is_dir():
        continue
    
    formats = defaultdict(int)
    
    for img_file in catalog_dir.glob("*"):
        if img_file.is_file():
            ext = img_file.suffix.lower()
            formats[ext] += 1
            total_stats[ext] += 1
    
    by_catalog[catalog_dir.name] = dict(formats)

# Print by catalog
print(f"{'Catalog':<45} {'WebP':>8} {'JPEG':>8} {'PNG':>8} {'Other':>8}")
print("-" * 80)

for catalog, formats in sorted(by_catalog.items()):
    webp = formats.get('.webp', 0)
    jpeg = formats.get('.jpeg', 0) + formats.get('.jpg', 0)
    png = formats.get('.png', 0)
    other = sum(v for k, v in formats.items() if k not in ['.webp', '.jpeg', '.jpg', '.png'])
    
    print(f"{catalog:<45} {webp:>8} {jpeg:>8} {png:>8} {other:>8}")

# Print totals
print("-" * 80)
webp_total = total_stats.get('.webp', 0)
jpeg_total = total_stats.get('.jpeg', 0) + total_stats.get('.jpg', 0)
png_total = total_stats.get('.png', 0)
other_total = sum(v for k, v in total_stats.items() if k not in ['.webp', '.jpeg', '.jpg', '.png'])
grand_total = sum(total_stats.values())

print(f"{'TOTAL':<45} {webp_total:>8} {jpeg_total:>8} {png_total:>8} {other_total:>8}")

print(f"\n📈 Summary:")
print(f"   Total images: {grand_total}")
print(f"   WebP: {webp_total} ({webp_total/grand_total*100:.1f}%)")
print(f"   JPEG: {jpeg_total} ({jpeg_total/grand_total*100:.1f}%)")
print(f"   PNG: {png_total} ({png_total/grand_total*100:.1f}%)")
if other_total:
    print(f"   Other: {other_total}")

if jpeg_total + png_total > 0:
    print(f"\n⚠️  Found {jpeg_total + png_total} non-WebP images")
    print(f"   These are old images that should be converted to WebP")
