"""
Verify that all critical safety specifications are being extracted
"""
import json
from pathlib import Path

# Check PE-buizen
print("=" * 70)
print("CHECKING PE-BUIZEN FOR CRITICAL SPECS")
print("=" * 70)

with open('output/pe_buizen_analysis.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

critical_specs = {
    'inner_diameter': [],
    'outer_diameter': [],
    'wall_thickness': [],
    'working_pressure': [],
    'burst_pressure': [],
    'weight_per_meter': [],
    'roll_length': [],
    'table_columns': []
}

table_products = 0
total_products = 0

for page in data['pages']:
    for product in page['products_found']:
        total_products += 1
        specs = product['specifications']
        
        # Check if it's a table product
        if '_TBL' in product['product_id']:
            table_products += 1
        
        # Check for critical specs
        for key in specs.keys():
            if key.startswith('table_'):
                critical_specs['table_columns'].append(key)
            elif 'inner_diameter' in key or 'binnen' in key:
                critical_specs['inner_diameter'].append(product['product_id'])
            elif 'outer_diameter' in key:
                critical_specs['outer_diameter'].append(product['product_id'])
            elif 'wall_thickness' in key or 'wand' in key:
                critical_specs['wall_thickness'].append(product['product_id'])
            elif 'working_pressure' in key or 'werkdruk' in key:
                critical_specs['working_pressure'].append(product['product_id'])
            elif 'burst_pressure' in key or 'barst' in key:
                critical_specs['burst_pressure'].append(product['product_id'])
            elif 'weight_per_meter' in key or 'gewicht' in key:
                critical_specs['weight_per_meter'].append(product['product_id'])
            elif 'roll_length' in key or 'rol' in key:
                critical_specs['roll_length'].append(product['product_id'])

print(f"\nTotal products: {total_products}")
print(f"Table products: {table_products}")
print(f"\nCritical specs found:")
for spec_name, products in critical_specs.items():
    if spec_name == 'table_columns':
        unique_cols = set(products)
        print(f"  • {spec_name}: {len(unique_cols)} unique columns")
        if unique_cols:
            print(f"    Columns: {list(unique_cols)[:10]}")
    else:
        print(f"  • {spec_name}: {len(products)} products")

# Show a sample table product
print("\n" + "=" * 70)
print("SAMPLE TABLE PRODUCT:")
print("=" * 70)

for page in data['pages']:
    for product in page['products_found']:
        if '_TBL' in product['product_id'] and product['specifications']:
            print(f"\nProduct ID: {product['product_id']}")
            print(f"Page: {product['page_number']}")
            print(f"Category: {product['category']}")
            print(f"Description: {product['description']}")
            print(f"\nSpecifications ({len(product['specifications'])} fields):")
            for key, value in sorted(product['specifications'].items()):
                print(f"  {key}: {value}")
            break
    else:
        continue
    break

print("\n" + "=" * 70)
