"""
Inspect RVS PDF to understand image and data structure
"""
import pdfplumber
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "rvs-draadfittingen.pdf"

def inspect_rvs():
    print("=" * 80)
    print("RVS PDF INSPECTION")
    print("=" * 80)
    
    pdf = pdfplumber.open(PDF_PATH)
    print(f"\n📄 PDF: {PDF_PATH.name}")
    print(f"   Total pages: {len(pdf.pages)}")
    
    # Check key pages (where most products are)
    sample_pages = [12, 18, 21, 22, 23]  # Pages with products
    
    for page_num in sample_pages:
        if page_num > len(pdf.pages):
            continue
            
        print(f"\n{'='*80}")
        print(f"PAGE {page_num}")
        print('='*80)
        
        page = pdf.pages[page_num - 1]
        
        # Extract text
        text = page.extract_text()
        if text:
            lines = text.split('\n')
            print(f"\n📝 Text ({len(lines)} lines):")
            print("   First 20 lines:")
            for i, line in enumerate(lines[:20], 1):
                print(f"   {i:2d}. {line[:75]}")
        
        # Extract tables
        tables = page.extract_tables()
        if tables:
            print(f"\n📊 Tables found: {len(tables)}")
            for i, table in enumerate(tables, 1):
                if table:
                    print(f"\n   Table {i}: {len(table)} rows x {len(table[0]) if table[0] else 0} cols")
                    print(f"   First 5 rows:")
                    for j, row in enumerate(table[:5], 1):
                        clean_row = [str(cell)[:25] if cell else '' for cell in row]
                        print(f"      Row {j}: {' | '.join(clean_row)}")
        else:
            print("\n📊 No tables found")
        
        # Check image count and positions
        print(f"\n🖼️  Images on page: {len(page.images)}")
    
    pdf.close()
    
    print("\n" + "=" * 80)
    print("ANALYSIS")
    print("=" * 80)
    print("""
Key findings to determine extraction strategy:
1. Are images B&W technical drawings or photos?
2. Are product specs in tables?
3. How are SKUs formatted?
4. What's the layout structure?
    """)

if __name__ == '__main__':
    inspect_rvs()
