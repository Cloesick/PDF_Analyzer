"""
Debug: Check what pdfplumber actually extracts from the welding table
"""
import pdfplumber

pdf_path = 'input_pdfs/pe-buizen.pdf'

print("="*80)
print("DEBUG: RAW TABLE EXTRACTION - Page 5")
print("="*80)

with pdfplumber.open(pdf_path) as pdf:
    page = pdf.pages[4]  # Page 5 (0-indexed)
    
    tables = page.extract_tables()
    
    print(f"\nFound {len(tables)} tables on page 5")
    
    for table_idx, table in enumerate(tables):
        if not table:
            continue
            
        print(f"\n{'='*80}")
        print(f"TABLE {table_idx}")
        print(f"{'='*80}")
        print(f"Rows: {len(table)}, Columns: {len(table[0]) if table else 0}")
        
        # Show first 5 rows
        print(f"\nFirst 5 rows (raw pdfplumber output):")
        for row_idx, row in enumerate(table[:5]):
            print(f"\n  Row {row_idx}:")
            for col_idx, cell in enumerate(row):
                print(f"    Col {col_idx}: '{cell}'")
        
        # Check if first column has the diameters
        print(f"\n  Checking if first column contains diameters...")
        diameters_found = []
        for row_idx, row in enumerate(table[1:6], start=1):  # Check rows 1-5
            if row and row[0]:
                first_col = str(row[0]).strip()
                if first_col.isdigit():
                    diameters_found.append(first_col)
                    print(f"    Row {row_idx}: '{first_col}' (looks like diameter!)")
        
        if diameters_found:
            print(f"\n  ✓ Found diameter values: {', '.join(diameters_found)}")
        else:
            print(f"\n  ⚠ No obvious diameter values in first column")
        
        # Show header row
        if table:
            print(f"\n  HEADER ROW:")
            headers = table[0]
            for col_idx, header in enumerate(headers):
                print(f"    Column {col_idx}: '{header}'")

print("\n" + "="*80)
print("If diameters are in the first column but not captured,")
print("it means the header might be empty or the extraction logic needs adjustment!")
print("="*80)
