"""
TEST IMAGE DATABASE
===================
Demonstrate the image database functionality
"""

import json
from pathlib import Path

# Load the image database
PROJECT_ROOT = Path(__file__).parent
IMAGE_INDEX = PROJECT_ROOT / "image-database" / "image_index.json"

with open(IMAGE_INDEX, 'r', encoding='utf-8') as f:
    db = json.load(f)

print("="*80)
print("IMAGE DATABASE TEST")
print("="*80)

# Show statistics
print(f"\n📊 Database Statistics:")
print(f"   Total Images:  {db['metadata']['total_images']}")
print(f"   Unique SKUs:   {db['metadata']['total_skus']}")
print(f"   Catalogs:      {db['metadata']['catalogs']}")

# Test 1: Direct lookup
print(f"\n🔍 Test 1: Direct SKU Lookup")
test_skus = ['GA005GM201', 'HR005G', 'HS010G', 'TW004GZ']
for sku in test_skus:
    if sku in db['sku_index']:
        entry = db['sku_index'][sku]
        img = entry['primary_image']
        print(f"   ✅ {sku}: {img['filename']} ({img['width']}x{img['height']})")
    else:
        print(f"   ❌ {sku}: Not found")

# Test 2: Flexible search (normalized)
print(f"\n🔎 Test 2: Flexible Search (case-insensitive, ignores spaces/dashes)")
flexible_tests = [
    ('GA005GM201', 'GA005GM201'),  # Exact
    ('ga-005-gm-201', 'GA005GM201'),  # With dashes, lowercase
    ('GA 005 GM201', 'GA005GM201'),  # With spaces
]

for test_input, expected_sku in flexible_tests:
    # Normalize the input
    normalized = test_input.upper().replace(' ', '').replace('-', '').replace('_', '')
    actual_sku = db['search_index'].get(normalized)
    
    if actual_sku:
        print(f"   ✅ '{test_input}' -> '{actual_sku}'")
    else:
        print(f"   ❌ '{test_input}' -> Not found")

# Test 3: Gallery (multiple images)
print(f"\n📸 Test 3: Products with Multiple Images")
count = 0
for sku, entry in db['sku_index'].items():
    if entry['image_count'] > 1:
        print(f"   {sku}: {entry['image_count']} images")
        count += 1
        if count >= 5:
            break

# Test 4: Catalog breakdown
print(f"\n📚 Test 4: Catalog Breakdown (Top 10)")
catalogs = sorted(
    db['catalog_index'].items(),
    key=lambda x: x[1]['image_count'],
    reverse=True
)[:10]

for catalog, data in catalogs:
    print(f"   {catalog:40s} {data['image_count']:4d} images, {data['sku_count']:4d} SKUs")

# Test 5: Sample image paths
print(f"\n🖼️  Test 5: Sample Image Paths")
sample_skus = list(db['sku_index'].keys())[:5]
for sku in sample_skus:
    entry = db['sku_index'][sku]
    img = entry['primary_image']
    print(f"   {sku}:")
    print(f"      File:    {img['filename']}")
    print(f"      Path:    {img['source_path']}")
    print(f"      Size:    {img['width']}x{img['height']} ({img['file_size_kb']} KB)")

# Test 6: Makita tools only (no batteries/chargers)
print(f"\n🔧 Test 6: Makita Products (Verify No Batteries/Chargers)")
makita_skus = [sku for sku in db['sku_index'].keys() 
               if any(catalog.startswith('makita') 
                     for catalog in [db['sku_index'][sku]['primary_image']['catalog']])]

# Check for excluded patterns
battery_patterns = ['BL', 'DC', 'ADP', 'DEAADP', 'PDC', 'BPS', 'BEAPDC', 'PV', 'DK']
batteries_found = [sku for sku in makita_skus if any(sku.startswith(pattern) for pattern in battery_patterns)]

print(f"   Total Makita products: {len(makita_skus)}")
print(f"   Batteries/chargers:    {len(batteries_found)}")
if batteries_found:
    print(f"   ⚠️ Found: {batteries_found[:5]}")
else:
    print(f"   ✅ No batteries/chargers found (correct!)")

# Test 7: Search functionality
print(f"\n🔎 Test 7: Partial Search")
search_term = "GA00"
matches = [sku for sku in db['sku_index'].keys() if search_term in sku][:10]
print(f"   Search for '{search_term}': {len(matches)} matches")
for sku in matches[:5]:
    print(f"      - {sku}")
if len(matches) > 5:
    print(f"      ... and {len(matches) - 5} more")

print(f"\n{'='*80}")
print("✅ IMAGE DATABASE TESTS COMPLETE")
print(f"{'='*80}\n")

# Summary
print("💡 Usage Examples:")
print("   Python:     image_db['sku_index']['GA005GM201']['primary_image']")
print("   JavaScript: imageDB.getImage('GA005GM201')")
print("   React:      <ProductImage sku='GA005GM201' />")
print("   API:        GET /api/image/GA005GM201")
