"""
Show sample of enriched product data with image paths
"""
import json

print("="*80)
print("ENRICHED PRODUCT DATA SAMPLES")
print("="*80)

# PE-Buizen sample
print("\n" + "="*80)
print("PE-BUIZEN - Sample Product")
print("="*80)

with open('output/pe_buizen_analysis_enriched.json', 'r', encoding='utf-8') as f:
    pe_data = json.load(f)

# Find a product with good data
sample_product = None
for page in pe_data['pages']:
    for prod in page['products_found']:
        if prod.get('image_hash') and len(prod.get('specifications', {})) > 5:
            sample_product = prod
            break
    if sample_product:
        break

if sample_product:
    print(f"\nProduct ID: {sample_product['product_id']}")
    print(f"Category: {sample_product['category']}")
    print(f"Description: {sample_product['description']}")
    
    print(f"\n📸 Image Information:")
    print(f"  • Image Hash: {sample_product['image_hash'][:60]}...")
    print(f"  • Image URL (WebP): {sample_product['image_url']}")
    print(f"  • Image Path (Local): {sample_product['image_path']}")
    
    print(f"\n  Alternative Formats:")
    for fmt, url in sample_product['image_formats'].items():
        print(f"    • {fmt.upper()}: {url}")
    
    print(f"\n🔧 Specifications ({len(sample_product['specifications'])} fields):")
    for key, value in list(sample_product['specifications'].items())[:8]:
        print(f"    • {key}: {value}")
    if len(sample_product['specifications']) > 8:
        print(f"    ... and {len(sample_product['specifications']) - 8} more")

# Plat-Oprolbare sample
print("\n" + "="*80)
print("PLAT-OPROLBARE - Sample Product")
print("="*80)

with open('output/plat_oprolbare_analysis_enriched.json', 'r', encoding='utf-8') as f:
    plat_data = json.load(f)

sample_product = None
for page in plat_data['pages']:
    for prod in page['products_found']:
        if prod.get('image_hash') and prod.get('specifications', {}).get('inner_diameter'):
            sample_product = prod
            break
    if sample_product:
        break

if sample_product:
    print(f"\nProduct ID: {sample_product['product_id']}")
    print(f"Category: {sample_product['category']}")
    
    print(f"\n📸 Image Information:")
    print(f"  • Image URL: {sample_product['image_url']}")
    
    specs = sample_product['specifications']
    print(f"\n🔧 Key Specifications:")
    if 'inner_diameter' in specs:
        print(f"    • Inner Diameter: {specs['inner_diameter']}")
    if 'working_pressure' in specs:
        print(f"    • Working Pressure: {specs['working_pressure']}")
    if 'burst_pressure' in specs:
        print(f"    • Burst Pressure: {specs['burst_pressure']}")

# Welding table sample
print("\n" + "="*80)
print("PE-BUIZEN - Welding Table Products (Shared Image)")
print("="*80)

welding_products = []
for page in pe_data['pages']:
    if page['page_number'] == 5:
        for prod in page['products_found']:
            if 'welding_time' in prod.get('specifications', {}):
                welding_products.append(prod)

if welding_products:
    print(f"\nFound {len(welding_products)} welding specification products")
    print(f"All sharing image: {welding_products[0]['image_url']}")
    
    print(f"\n📊 Sample welding products:")
    for prod in welding_products[1:6]:
        specs = prod['specifications']
        diameter = specs.get('diameter', 'N/A')
        welding = specs.get('welding_time', 'N/A')
        voltage = specs.get('voltage', 'N/A')
        print(f"  • {prod['product_id']}: Ø{diameter}, Weld:{welding}, V:{voltage}")
    print(f"  ... and {len(welding_products) - 5} more")

print("\n" + "="*80)
print("FRONTEND INTEGRATION EXAMPLE")
print("="*80)

print("""
// React/Vue/Angular Example:
{
  products.map(product => (
    <ProductCard
      key={product.product_id}
      image={product.image_url}
      imageSrcSet={{
        webp: product.image_formats.webp,
        jpg: product.image_formats.jpg
      }}
      title={product.description}
      specs={product.specifications}
    />
  ))
}

// Simple HTML Example:
<img 
  src="${product.image_url}" 
  alt="${product.description}"
  loading="lazy"
/>
""")

print("="*80)
print("✅ All products now have image URLs ready for frontend!")
print("="*80)
