import json

with open('output/pe_buizen_analysis.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

print("="*70)
print("COLUMN HEADERS - Page Locations")
print("="*70)

# Target columns to investigate
target_columns = ['maat', 'maten', 'water', 'sdr', 'werkdruk']

column_pages = {col: set() for col in target_columns}
column_samples = {col: [] for col in target_columns}

# Find pages containing each column
for page in data['pages']:
    page_num = page['page_number']
    
    for prod in page['products_found']:
        specs = prod['specifications']
        
        for key, value in specs.items():
            if key.startswith('table_'):
                clean_key = key.replace('table_', '')
                
                if clean_key in target_columns:
                    column_pages[clean_key].add(page_num)
                    
                    # Store sample with page context
                    if len(column_samples[clean_key]) < 5:
                        column_samples[clean_key].append({
                            'page': page_num,
                            'product_id': prod['product_id'],
                            'value': str(value)[:80],
                            'all_specs': {k.replace('table_', ''): v for k, v in specs.items() if k.startswith('table_')}
                        })

# Display results
for col in target_columns:
    pages = sorted(column_pages[col])
    print(f"\n{'='*70}")
    print(f"COLUMN: '{col}'")
    print(f"{'='*70}")
    print(f"Found on {len(pages)} pages: {pages[:10]}")
    if len(pages) > 10:
        print(f"... and {len(pages) - 10} more pages")
    
    print(f"\nSample occurrences with context:")
    for sample in column_samples[col]:
        print(f"\n  Page {sample['page']}: {sample['product_id']}")
        print(f"  → {col} = '{sample['value']}'")
        print(f"  → Row contains: {list(sample['all_specs'].keys())}")
        print(f"  → Full row: {sample['all_specs']}")

print("\n" + "="*70)
print("PDF FILE LOCATION")
print("="*70)
print("C:\\Users\\prova\\Documents\\Projects\\PDF_Analyzer\\input_pdfs\\pe-buizen.pdf")
print("\nOpen this PDF and check the pages listed above to see the actual table headers!")
print("="*70)
