import json
from pathlib import Path

data = json.load(open('output/products_ready_for_webshop.json'))
makita = [p for p in data if 'makita-catalogus-2022-nl' in p.get('pdf_source', '')]

print('Sample Makita product SKUs:')
for p in makita[:30]:
    pages = p.get('source_pages', ['?'])
    page = pages[0] if pages else '?'
    print(f"  {p['sku']:20s} | Page {str(page):4s} | {p.get('name', '')[:60]}")

print(f"\nTotal: {len(makita)} products")

# Check image filenames
print('\n\nSample image filenames:')
images_folder = Path('product-images-by-pdf/makita-catalogus-2022-nl')
for img in list(images_folder.glob('*.webp'))[:20]:
    print(f"  {img.name}")
