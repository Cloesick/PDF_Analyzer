import json

data = json.load(open('output/input_pdfs_analysis_v9.json'))
print(f"Total products: {len(data)}")

with_images = [p for p in data if p.get('images')]
print(f"Products with images field: {len(with_images)}")

if with_images:
    sample = with_images[0]
    print(f"\nSample:")
    print(f"  SKU: {sample['sku']}")
    print(f"  Catalog: {sample.get('catalog_name')}")
    print(f"  Images: {len(sample['images'])}")
    print(f"  First image: {sample['images'][0] if sample['images'] else 'None'}")
else:
    print("\n❌ No products have images!")
    print("Checking why...")
    sample = data[0]
    print(f"\nSample product structure:")
    print(f"  SKU: {sample.get('sku')}")
    print(f"  Keys: {list(sample.keys())}")
