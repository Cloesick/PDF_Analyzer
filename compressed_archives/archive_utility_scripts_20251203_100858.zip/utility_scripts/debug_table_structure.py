"""
Debug: Show exact table structure for a specific page
"""
import pdfplumber
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "makita-catalogus-2022-nl.pdf"

with pdfplumber.open(PDF_PATH) as pdf:
    # Check page 30 which we know has good data
    page = pdf.pages[29]  # 0-indexed
    
    print("="*80)
    print("PAGE 30 - FULL TABLE STRUCTURE")
    print("="*80)
    
    # Get text above tables
    text = page.extract_text()
    lines = text.split('\n')
    print("\nFirst 30 lines of text:")
    for idx, line in enumerate(lines[:30]):
        print(f"{idx:3d}: {line}")
    
    # Get tables
    tables = page.extract_tables()
    
    print(f"\n\nFOUND {len(tables)} TABLES\n")
    
    for table_idx, table in enumerate(tables):
        if len(table) > 5:  # Only show substantial tables
            print(f"\n{'='*80}")
            print(f"TABLE {table_idx + 1}")
            print(f"{'='*80}")
            print(f"Size: {len(table)} rows x {len(table[0])} columns")
            
            print(f"\nALL ROWS:")
            for row_idx, row in enumerate(table):
                print(f"\nRow {row_idx}:")
                for col_idx, cell in enumerate(row):
                    if cell and str(cell).strip():
                        print(f"  Col {col_idx}: '{cell}'")
