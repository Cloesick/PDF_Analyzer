"""
Verify that ALL table columns are being captured in the JSON output
"""
import json
import pdfplumber
from pathlib import Path

print("="*80)
print("COMPLETE TABLE COVERAGE VERIFICATION")
print("="*80)

# Check each PDF
pdfs = [
    ('PE-Buizen', 'input_pdfs/pe-buizen.pdf', 'output/pe_buizen_analysis.json'),
    ('Plat-Oprolbare', 'input_pdfs/plat-oprolbare-slangen.pdf', 'output/plat_oprolbare_analysis.json'),
    ('Aandrijftechniek', 'input_pdfs/catalogus-aandrijftechniek-150922.pdf', 'output/aandrijftechniek_analysis.json')
]

for pdf_name, pdf_path, json_path in pdfs:
    print(f"\n{'='*80}")
    print(f"PDF: {pdf_name}")
    print(f"{'='*80}")
    
    # Extract actual table headers from PDF
    actual_tables = {}
    with pdfplumber.open(pdf_path) as pdf:
        for page_num, page in enumerate(pdf.pages, start=1):
            tables = page.extract_tables()
            if tables:
                for table_idx, table in enumerate(tables):
                    if table and len(table) >= 2:
                        headers = [str(cell).strip() if cell else '' for cell in table[0]]
                        key = f"Page {page_num}, Table {table_idx}"
                        actual_tables[key] = {
                            'headers': [h for h in headers if h],
                            'rows': len(table) - 1,  # Exclude header
                            'columns': len(headers)
                        }
    
    # Load JSON to check what was captured
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # Collect all table columns from JSON
    captured_columns = set()
    table_products_by_page = {}
    
    for page in data['pages']:
        page_num = page['page_number']
        table_prods = [p for p in page['products_found'] if '_TBL' in p['product_id']]
        
        if table_prods:
            table_products_by_page[page_num] = len(table_prods)
            
            for prod in table_prods:
                for key in prod['specifications'].keys():
                    if key.startswith('table_'):
                        captured_columns.add(key.replace('table_', ''))
    
    print(f"\n📊 SUMMARY:")
    print(f"  Total tables found in PDF: {len(actual_tables)}")
    print(f"  Pages with table products in JSON: {len(table_products_by_page)}")
    print(f"  Unique column headers captured: {len(captured_columns)}")
    
    if actual_tables:
        print(f"\n📋 TABLE DETAILS:")
        total_expected_products = 0
        total_actual_products = sum(table_products_by_page.values())
        
        for key, info in sorted(actual_tables.items()):
            page_num = int(key.split(',')[0].split()[1])
            expected_rows = info['rows']
            total_expected_products += expected_rows
            actual_rows = table_products_by_page.get(page_num, 0)
            
            status = "✓" if actual_rows > 0 else "✗"
            print(f"  {status} {key}: {info['columns']} cols × {expected_rows} rows = {expected_rows} products expected")
            print(f"      Headers: {', '.join(info['headers'][:5])}")
            if len(info['headers']) > 5:
                print(f"              ...and {len(info['headers']) - 5} more")
            if actual_rows > 0:
                print(f"      ✓ Captured: {actual_rows} products from this page")
            else:
                print(f"      ⚠ WARNING: No products captured from this page!")
        
        print(f"\n📈 COVERAGE:")
        print(f"  Expected total products: {total_expected_products}")
        print(f"  Actual captured products: {total_actual_products}")
        coverage = (total_actual_products / total_expected_products * 100) if total_expected_products > 0 else 0
        print(f"  Coverage: {coverage:.1f}%")
        
        if coverage >= 95:
            print(f"  ✓ EXCELLENT - Nearly all table data captured!")
        elif coverage >= 80:
            print(f"  ⚠ GOOD - Most table data captured, some missing")
        else:
            print(f"  ✗ WARNING - Significant table data missing!")
    
    # Show sample of captured columns
    if captured_columns:
        print(f"\n📝 SAMPLE CAPTURED COLUMNS (first 15):")
        for col in sorted(list(captured_columns))[:15]:
            print(f"  • {col}")
        if len(captured_columns) > 15:
            print(f"  ...and {len(captured_columns) - 15} more")

print("\n" + "="*80)
print("VERIFICATION COMPLETE")
print("="*80)
