"""
Verify the current state of tool extraction
"""
from pathlib import Path
import re

PROJECT_ROOT = Path(__file__).parent
CATALOG_DIR = PROJECT_ROOT / "product-images-by-pdf" / "makita-catalogus-2022-nl"
TUINFOLDER_DIR = PROJECT_ROOT / "product-images-by-pdf" / "makita-tuinfolder-2022-nl"

# Tool SKU patterns
TOOL_PATTERNS = [
    r'^[A-Z]{2,4}\d{3,4}[A-Z]{1,4}\d{0,3}_',  # Real tool SKUs
]

# Non-tool patterns
NON_TOOL_PATTERNS = [
    r'^BL[14]',  # Batteries
    r'^DC[14]',  # Chargers (but not DCx tools)
    r'^\d{4,6}_',  # Numeric SKUs (accessories/parts)
]

def classify_filename(filename):
    """Classify if filename is tool or non-tool"""
    name_upper = filename.upper()
    
    # Check non-tools
    for pattern in NON_TOOL_PATTERNS:
        if re.match(pattern, name_upper):
            # Exception: DC tools
            if re.match(r'^DC[CGJLMW]', name_upper):
                return 'TOOL'
            return 'NON-TOOL'
    
    # Check tools
    for pattern in TOOL_PATTERNS:
        if re.match(pattern, name_upper):
            return 'TOOL'
    
    return 'UNKNOWN'

def main():
    print("="*80)
    print("VERIFYING TOOL EXTRACTION")
    print("="*80)
    
    for name, folder in [("Catalogus", CATALOG_DIR), ("Tuinfolder", TUINFOLDER_DIR)]:
        if not folder.exists():
            print(f"\n{name}: FOLDER NOT FOUND")
            continue
        
        images = list(folder.glob("*.webp"))
        
        tools = []
        non_tools = []
        unknown = []
        
        for img in images:
            classification = classify_filename(img.name)
            if classification == 'TOOL':
                tools.append(img)
            elif classification == 'NON-TOOL':
                non_tools.append(img)
            else:
                unknown.append(img)
        
        print(f"\n{name}:")
        print(f"  Total: {len(images)}")
        print(f"  Tools: {len(tools)}")
        print(f"  Non-tools: {len(non_tools)}")
        print(f"  Unknown: {len(unknown)}")
        
        if non_tools:
            print(f"\n  Sample non-tools:")
            for img in non_tools[:10]:
                print(f"    - {img.name}")
        
        if unknown:
            print(f"\n  Sample unknown:")
            for img in unknown[:10]:
                print(f"    - {img.name}")

if __name__ == '__main__':
    main()
