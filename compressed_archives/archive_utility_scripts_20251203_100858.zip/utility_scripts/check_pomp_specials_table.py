"""
Read pomp-specials PDF table and show actual values per SKU
"""
import fitz
from pathlib import Path

pdf_path = Path(__file__).parent / 'input_pdfs' / 'pomp-specials.pdf'

print("=" * 100)
print("READING POMP-SPECIALS TABLE - ACTUAL VALUES")
print("=" * 100)

doc = fitz.open(pdf_path)

# Read first few pages with tables
for page_num in range(min(8, len(doc))):
    page = doc[page_num]
    tables = list(page.find_tables())
    
    if not tables:
        continue
    
    print(f"\n{'='*100}")
    print(f"PAGE {page_num + 1}")
    print(f"{'='*100}")
    
    for table_num, table in enumerate(tables):
        print(f"\nTable {table_num + 1}:")
        
        # Get all rows
        rows = []
        for row in table.extract():
            rows.append(row)
        
        if not rows:
            continue
        
        # First row is header
        header = rows[0]
        print(f"\nHEADER: {header}")
        print(f"Columns: {len(header)}")
        
        # Print first 10 data rows
        print(f"\nFIRST 10 ROWS:")
        print("-" * 100)
        
        for i, row in enumerate(rows[1:11], 1):
            print(f"\nRow {i}:")
            for col_idx, value in enumerate(row):
                if col_idx < len(header):
                    print(f"  {header[col_idx]:20} = {value}")
                else:
                    print(f"  Column {col_idx}:      = {value}")

doc.close()
