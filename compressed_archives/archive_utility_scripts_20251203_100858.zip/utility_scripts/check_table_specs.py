import json

with open('output/pe_buizen_analysis.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

print("="*70)
print("VERIFYING ALL CRITICAL SPECIFICATIONS")
print("="*70)

# Find a sample table product with all columns
for page in data['pages']:
    for prod in page['products_found']:
        if '_TBL' in prod['product_id'] and len(prod['specifications']) > 5:
            print(f"\nSample Table Product: {prod['product_id']}")
            print(f"Page: {prod['page_number']}")
            print(f"Category: {prod['category']}")
            print(f"Description: {prod['description']}")
            print(f"\nAll Specifications ({len(prod['specifications'])} total):")
            
            # Group by type
            table_cols = {}
            parsed_specs = {}
            
            for key, value in sorted(prod['specifications'].items()):
                if key.startswith('table_'):
                    table_cols[key] = value
                else:
                    parsed_specs[key] = value
            
            print(f"\n  RAW TABLE COLUMNS ({len(table_cols)}):")
            for key, value in table_cols.items():
                print(f"    {key}: {value}")
            
            print(f"\n  PARSED SPECIFICATIONS ({len(parsed_specs)}):")
            for key, value in parsed_specs.items():
                print(f"    {key}: {value}")
            
            break
    else:
        continue
    break

# Count critical specs across all products
print("\n" + "="*70)
print("CRITICAL SPEC COVERAGE ACROSS ALL PRODUCTS")
print("="*70)

critical_fields = {
    'inner_diameter': 0,
    'outer_diameter': 0,
    'wall_thickness': 0,
    'working_pressure': 0,
    'burst_pressure': 0,
    'weight_per_meter': 0,
    'roll_length': 0,
}

table_column_types = set()
total_table_products = 0

for page in data['pages']:
    for prod in page['products_found']:
        if '_TBL' in prod['product_id']:
            total_table_products += 1
            specs = prod['specifications']
            
            # Count parsed specs
            for field in critical_fields.keys():
                if any(field in key for key in specs.keys()):
                    critical_fields[field] += 1
            
            # Collect table column types
            for key in specs.keys():
                if key.startswith('table_'):
                    table_column_types.add(key)

print(f"\nTotal table products: {total_table_products}")
print(f"\nCritical specifications found:")
for field, count in critical_fields.items():
    percentage = (count / total_table_products * 100) if total_table_products > 0 else 0
    print(f"  • {field}: {count}/{total_table_products} ({percentage:.1f}%)")

print(f"\nUnique table columns captured: {len(table_column_types)}")
print("Sample columns:")
for col in sorted(list(table_column_types))[:15]:
    print(f"  • {col}")

print("\n" + "="*70)
print("✓ VERIFICATION COMPLETE")
print("="*70)
