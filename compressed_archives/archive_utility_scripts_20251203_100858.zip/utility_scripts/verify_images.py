"""
Verify image extraction status and check if images are being saved
"""
import json
from pathlib import Path

print("="*80)
print("IMAGE EXTRACTION VERIFICATION")
print("="*80)

pdfs = [
    ('PE-Buizen', 'output/pe_buizen_analysis.json'),
    ('Plat-Oprolbare', 'output/plat_oprolbare_analysis.json'),
    ('Aandrijftechniek', 'output/aandrijftechniek_analysis.json')
]

total_images = 0
total_shared = 0
total_products_with_images = 0

for pdf_name, json_path in pdfs:
    print(f"\n{'='*80}")
    print(f"PDF: {pdf_name}")
    print(f"{'='*80}")
    
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    images_count = data['total_images']
    products_count = data['total_products']
    
    # Count products with images
    products_with_images = 0
    for page in data['pages']:
        for prod in page['products_found']:
            if prod.get('image_hash'):
                products_with_images += 1
    
    # Count shared images
    shared_images = len([img for img in data.get('shared_images', []) if len(img.get('products', [])) > 1])
    
    total_images += images_count
    total_shared += shared_images
    total_products_with_images += products_with_images
    
    print(f"\n📊 IMAGE METADATA:")
    print(f"  Total images extracted: {images_count}")
    print(f"  Total products: {products_count}")
    print(f"  Products linked to images: {products_with_images} ({products_with_images/products_count*100:.1f}%)")
    print(f"  Shared images: {shared_images}")
    
    # Show sample image data
    if data['pages']:
        for page in data['pages']:
            if page['images_found']:
                sample_img = page['images_found'][0]
                print(f"\n  Sample image metadata:")
                print(f"    Image hash: {sample_img['image_hash']}")
                print(f"    Page: {sample_img['page_number']}")
                print(f"    Dimensions: {sample_img['width']}x{sample_img['height']} px")
                print(f"    BBox: {sample_img['bbox']}")
                break

# Check if image files exist
print(f"\n{'='*80}")
print(f"IMAGE FILES CHECK")
print(f"{'='*80}")

image_dirs = [
    'output/images',
    'output/images/pe-buizen',
    'output/images/plat-oprolbare',
    'output/images/aandrijftechniek',
]

print(f"\nLooking for extracted image files...")
for img_dir in image_dirs:
    path = Path(img_dir)
    if path.exists():
        image_files = list(path.glob('*.png')) + list(path.glob('*.jpg'))
        print(f"  ✓ {img_dir}: {len(image_files)} image files")
    else:
        print(f"  ✗ {img_dir}: Directory does not exist")

print(f"\n{'='*80}")
print(f"SUMMARY")
print(f"{'='*80}")
print(f"\nTotal across all PDFs:")
print(f"  • Images in metadata: {total_images}")
print(f"  • Products linked to images: {total_products_with_images}")
print(f"  • Shared images identified: {total_shared}")

print(f"\n⚠️  IMAGE FILES STATUS:")
images_output_dir = Path('output/images')
if images_output_dir.exists():
    all_images = list(images_output_dir.rglob('*.png')) + list(images_output_dir.rglob('*.jpg'))
    if all_images:
        print(f"  ✓ Image files are being saved: {len(all_images)} files found")
    else:
        print(f"  ✗ No image files found in output/images/")
else:
    print(f"  ✗ Image extraction to files is NOT configured")
    print(f"  → Image metadata is captured in JSON")
    print(f"  → Actual image files are NOT being saved to disk")
    print(f"\n  ❓ Do you need the actual image files extracted?")

print("="*80)
