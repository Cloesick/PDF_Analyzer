"""
Test icon display - show how properties look with icons
"""
import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"

def display_product_with_icons(product, max_props=10):
    """Display a product with icons in a nice format"""
    print("\n" + "="*80)
    print(f"SKU: {product['sku']}")
    print(f"Page: {product['page']}")
    print("="*80)
    
    if product.get('properties_with_icons'):
        print("\nProduct Specifications:")
        print("-" * 80)
        
        for prop, value in list(product['properties_with_icons'].items())[:max_props]:
            print(f"  {value}")
        
        remaining = len(product['properties_with_icons']) - max_props
        if remaining > 0:
            print(f"  ... and {remaining} more properties")
    
    # Show prices
    if product.get('price_excl_btw_eur'):
        print(f"\n💰 Price excl. VAT: €{product['price_excl_btw_eur']:.2f}")
    if product.get('price_incl_btw_eur'):
        print(f"💰 Price incl. VAT: €{product['price_incl_btw_eur']:.2f}")

def main():
    print("="*80)
    print("ICON DISPLAY TEST")
    print("="*80)
    print("\nShowing how product properties look with icons...\n")
    
    # Load catalogus data
    catalogus_file = OUTPUT_DIR / "makita-catalogus-2022-nl_products_translated.json"
    tuinfolder_file = OUTPUT_DIR / "makita-tuinfolder-2022-nl_products_translated.json"
    
    # Show catalogus examples
    if catalogus_file.exists():
        with open(catalogus_file, 'r', encoding='utf-8') as f:
            catalogus_data = json.load(f)
        
        print("\n" + "#"*80)
        print("# CATALOGUS EXAMPLES (Power Tools)")
        print("#"*80)
        
        # Show first 3 products
        for product in catalogus_data[:3]:
            if product.get('properties_with_icons'):
                display_product_with_icons(product, max_props=8)
    
    # Show tuinfolder examples
    if tuinfolder_file.exists():
        with open(tuinfolder_file, 'r', encoding='utf-8') as f:
            tuinfolder_data = json.load(f)
        
        print("\n\n" + "#"*80)
        print("# TUINFOLDER EXAMPLES (Garden Tools)")
        print("#"*80)
        
        # Show first 3 products with properties
        count = 0
        for product in tuinfolder_data:
            if product.get('properties_with_icons') and len(product['properties_with_icons']) > 0:
                display_product_with_icons(product, max_props=8)
                count += 1
                if count >= 3:
                    break
    
    print("\n" + "="*80)
    print("ICON LEGEND")
    print("="*80)
    print("""
⚡ Power/Voltage/Speed    🔧 Torque              ⚖️ Weight
🔋 Battery               🔌 Charger             📏 Dimensions
✂️ Cutting               🔨 Drilling/Hammer     🔊 Noise
🏗️ Chassis/Build         🗑️ Collection bag      📦 Capacity
🌿 Garden features       💡 LED light           💰 Price
⚙️ Optional feature      ✅ Yes/Available       ❌ No/Not available
➖ Not applicable        🧱 Materials           📋 General info
    """)

if __name__ == '__main__':
    main()
