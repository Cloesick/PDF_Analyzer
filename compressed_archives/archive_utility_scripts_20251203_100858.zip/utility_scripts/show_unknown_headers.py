import json

with open('output/pe_buizen_analysis.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

print("="*70)
print("TABLE COLUMN HEADERS - Need Your Help!")
print("="*70)

# Collect all table columns and check which are parsed
all_table_columns = {}
parsed_fields = set()

for page in data['pages']:
    for prod in page['products_found']:
        specs = prod['specifications']
        
        # Collect table columns
        for key, value in specs.items():
            if key.startswith('table_'):
                clean_key = key.replace('table_', '')
                if clean_key not in all_table_columns:
                    all_table_columns[clean_key] = {
                        'count': 0,
                        'sample_values': set()
                    }
                all_table_columns[clean_key]['count'] += 1
                # Keep a few sample values
                if len(all_table_columns[clean_key]['sample_values']) < 3:
                    all_table_columns[clean_key]['sample_values'].add(str(value)[:50])
        
        # Collect parsed fields
        for key in specs.keys():
            if not key.startswith('table_'):
                parsed_fields.add(key)

print(f"\nTotal unique table column headers found: {len(all_table_columns)}")
print(f"Parsed specification types: {len(parsed_fields)}")

print("\n" + "="*70)
print("COLUMN HEADERS I NEED HELP WITH:")
print("="*70)
print("\nPlease tell me what these mean:\n")

# Sort by frequency
sorted_columns = sorted(all_table_columns.items(), key=lambda x: x[1]['count'], reverse=True)

for idx, (column_name, info) in enumerate(sorted_columns, 1):
    count = info['count']
    samples = list(info['sample_values'])
    
    print(f"{idx}. '{column_name}' (appears {count} times)")
    print(f"   Sample values: {', '.join(samples)}")
    
    # Try to guess what it might be
    guesses = []
    col_lower = column_name.lower()
    
    if any(term in col_lower for term in ['maat', 'diameter', 'ø']):
        guesses.append("→ Maybe: dimension/diameter?")
    if any(term in col_lower for term in ['druk', 'pressure', 'bar']):
        guesses.append("→ Maybe: pressure related?")
    if any(term in col_lower for term in ['lengte', 'length']):
        guesses.append("→ Maybe: length measurement?")
    if any(term in col_lower for term in ['gewicht', 'weight']):
        guesses.append("→ Maybe: weight measurement?")
    if any(term in col_lower for term in ['binnen', 'inner', 'buiten', 'outer']):
        guesses.append("→ Maybe: inner/outer measurement?")
    if any(term in col_lower for term in ['temp', 'tijd', 'time']):
        guesses.append("→ Maybe: time/temperature?")
    if any(term in col_lower for term in ['spanning', 'voltage', 'weerstand']):
        guesses.append("→ Maybe: electrical property?")
    
    if guesses:
        for guess in guesses:
            print(f"   {guess}")
    else:
        print(f"   → Unknown - please explain!")
    
    print()

print("="*70)
print("\nPlease tell me:")
print("1. What does each column header mean in English?")
print("2. What type of value it contains (dimension, pressure, weight, etc.)?")
print("3. What unit it should have (mm, bar, kg, etc.)?")
print("="*70)
