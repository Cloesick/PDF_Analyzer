"""
Verify Makita Products Pricing
Shows sample products with both price_excl and price_incl
"""
import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
DATA_FILE = PROJECT_ROOT / "output" / "makita_frontend_display.json"

print("="*80)
print("MAKITA PRICING VERIFICATION")
print("="*80)

with open(DATA_FILE, 'r', encoding='utf-8') as f:
    data = json.load(f)

products = data['products']

# Filter products with prices
products_with_prices = [
    p for p in products 
    if 'price_excl' in p['specifications'] and 'price_incl' in p['specifications']
]

print(f"\n📊 Statistics:")
print(f"   Total products: {len(products)}")
print(f"   Products with pricing: {len(products_with_prices)}")

print(f"\n💶 Sample Products with Both Prices:\n")

# Show first 10 products with prices
for i, product in enumerate(products_with_prices[:10], 1):
    specs = product['specifications']
    display = product['display']
    
    print(f"{i}. {product['sku']}")
    print(f"   Ex BTW:   {display.get('price_excl', 'N/A')}")
    print(f"   Incl BTW: {display.get('price_incl', 'N/A')}")
    
    # Verify calculation
    if 'price_excl' in specs and 'price_incl' in specs:
        excl = specs['price_excl']
        incl = specs['price_incl']
        calculated_incl = excl * 1.21
        diff = abs(incl - calculated_incl)
        
        if diff < 0.02:  # Allow 2 cent rounding difference
            print(f"   ✅ VAT calculation correct")
        else:
            print(f"   ⚠️ VAT mismatch: {incl} vs {calculated_incl:.2f}")
    print()

# Show specific SKUs from user's example
print(f"\n🎯 Your Example SKUs:\n")
example_skus = ['DF002GZ01', 'DF002GD201', 'DF001GZ01', 'DF001GM201', 
                'HP002GZ01', 'HP002GD201', 'HP001GZ01', 'HP001GM201']

for sku in example_skus:
    product = next((p for p in products if p['sku'] == sku), None)
    
    if product:
        display = product['display']
        print(f"✅ {sku}")
        print(f"   {display.get('price_excl', 'No price')}")
        print(f"   {display.get('price_incl', 'No price')}")
    else:
        print(f"❌ {sku} - Not found")
    print()

print("="*80)
