#!/usr/bin/env python3
#  -*- coding: utf-8 -*-
"""Test extraction on a single PDF"""

import os
import sys
import json
from pathlib import Path

# Fix Windows console encoding
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

# Add path
sys.path.insert(0, str(Path(__file__).parent / 'output' / 'archive' / 'catalog_extractions'))

from jsoncreator import IndustrialExtractor

def main():
    print("\n" + "="*80)
    print("TEST EXTRACTION - SINGLE PDF")
    print("="*80 + "\n")
    
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("ERROR: OPENAI_API_KEY not set!")
        return
    
    print(f"✓ API key found: {api_key[:20]}...")
    print(f"✓ Initializing extractor...\n")
    
    extractor = IndustrialExtractor(api_key=api_key)
    
    # Test with slangklemmen (small PDF)
    test_pdf = Path("input_pdfs/slangklemmen.pdf")
    
    if not test_pdf.exists():
        print(f"ERROR: {test_pdf} not found!")
        # List available PDFs
        pdfs = list(Path("input_pdfs").glob("*.pdf"))
        if pdfs:
            test_pdf = pdfs[0]
            print(f"Using first available PDF: {test_pdf.name}\n")
        else:
            print("No PDFs found in input_pdfs/")
            return
    
    print(f"Testing with: {test_pdf.name}")
    print(f"This will process each page with GPT-4...\n")
    print("="*80 + "\n")
    
    try:
        items = extractor.process_pdf(str(test_pdf))
        
        print("\n" + "="*80)
        print("RESULTS")
        print("="*80 + "\n")
        print(f"✓ Extracted {len(items)} products!")
        
        if items:
            print(f"\nSample product:")
            sample = items[0].dict()
            print(json.dumps(sample, indent=2))
        
        # Save
        output_file = Path("output/test_extraction.json")
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump([p.dict() for p in items], f, indent=2, ensure_ascii=False)
        
        print(f"\n✓ Saved to: {output_file}")
        print(f"\n✓ Test successful! The full extraction is ready to run.")
        
    except Exception as e:
        print(f"\nERROR: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()
