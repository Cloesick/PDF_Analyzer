"""
Check raw table columns for the welding table to see what's being captured
"""
import json

with open('output/pe_buizen_analysis.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

print("="*80)
print("RAW TABLE DATA - WELDING TABLE (Page 5)")
print("="*80)

# Get page 5
page_5 = [p for p in data['pages'] if p['page_number'] == 5][0]

# Get table products
table_prods = [p for p in page_5['products_found'] if '_TBL' in p['product_id']]

print(f"\nFound {len(table_prods)} table products on page 5")

# Show first product's ALL specifications
if table_prods:
    sample = table_prods[1]  # Second product (first might be header)
    print(f"\nSample product: {sample['product_id']}")
    print(f"Image: {sample.get('image_hash', 'none')[:50]}...")
    print(f"\nALL specifications:")
    
    specs = sample['specifications']
    
    # Separate raw table columns from parsed fields
    raw_cols = {k: v for k, v in specs.items() if k.startswith('table_')}
    parsed_fields = {k: v for k, v in specs.items() if not k.startswith('table_')}
    
    print(f"\n  RAW TABLE COLUMNS ({len(raw_cols)}):")
    for key, val in sorted(raw_cols.items()):
        print(f"    {key:<60} = '{val}'")
    
    print(f"\n  PARSED FIELDS ({len(parsed_fields)}):")
    for key, val in sorted(parsed_fields.items()):
        print(f"    {key:<60} = '{val}'")

# Show a few more products to see the pattern
print(f"\n{'='*80}")
print(f"SAMPLE OF TABLE PRODUCTS:")
print(f"{'='*80}")

print(f"\n{'Product':<20} {'Diameter':<10} {'Welding':<12} {'Voltage':<10} {'Resistance':<15}")
print(f"{'-'*20} {'-'*10} {'-'*12} {'-'*10} {'-'*15}")

for prod in table_prods[1:8]:  # Show products 2-8
    specs = prod['specifications']
    
    # Try to find diameter in various fields
    diameter = specs.get('diameter', 
               specs.get('diameter_mm',
               specs.get('table_nom_diam_(mm)',
               specs.get('table_mm', 'N/A'))))
    
    welding = specs.get('welding_time', 'N/A')
    voltage = specs.get('voltage', 'N/A')
    resistance = specs.get('resistance', 'N/A')
    
    print(f"{prod['product_id']:<20} {str(diameter):<10} {str(welding):<12} {str(voltage):<10} {str(resistance):<15}")

print(f"\n{'='*80}")
print("ANALYSIS:")
print("="*80)

# Check all table column names
all_table_cols = set()
for prod in table_prods:
    for key in prod['specifications'].keys():
        if key.startswith('table_'):
            all_table_cols.add(key)

print(f"\nAll unique table column names found:")
for col in sorted(all_table_cols):
    print(f"  • {col}")

print("\n✓ If 'table_nom_diam_(mm)' or similar exists, we need to parse it!")
print("="*80)
