"""
Verify that the newly added parsed fields are actually present in the JSON
"""
import json

print("="*80)
print("VERIFICATION OF NEWLY ADDED PARSED FIELDS")
print("="*80)

# Check PE-Buizen
print("\n" + "="*80)
print("PE-Buizen: Checking for NEW parsed fields")
print("="*80)

with open('output/pe_buizen_analysis.json', 'r', encoding='utf-8') as f:
    pe_data = json.load(f)

new_pe_fields = {
    'wall_thickness_imperial_value': 0,
    'waiting_time_2': 0,
    'waiting_time_2_minutes': 0,
}

for page in pe_data['pages']:
    for prod in page['products_found']:
        for field in new_pe_fields.keys():
            if field in prod['specifications']:
                new_pe_fields[field] += 1

print(f"\nNEW FIELDS FOUND:")
for field, count in new_pe_fields.items():
    status = "✓" if count > 0 else "✗"
    print(f"  {status} {field:<40} {count} occurrences")

# Show sample
for page in pe_data['pages']:
    for prod in page['products_found']:
        if 'wall_thickness_imperial_value' in prod['specifications']:
            print(f"\n  Sample product with imperial wall thickness:")
            print(f"    Product: {prod['product_id']}")
            print(f"    wall_thickness_imperial: {prod['specifications'].get('wall_thickness_imperial')}")
            print(f"    wall_thickness_imperial_value: {prod['specifications'].get('wall_thickness_imperial_value')}")
            break
    else:
        continue
    break

# Check Plat-Oprolbare
print("\n" + "="*80)
print("Plat-Oprolbare: Checking for NEW parsed fields")
print("="*80)

with open('output/plat_oprolbare_analysis.json', 'r', encoding='utf-8') as f:
    plat_data = json.load(f)

new_plat_fields = {
    'wall_thickness': 0,
    'wall_thickness_mm': 0,
    'tensile_strength': 0,
    'tensile_strength_ton': 0,
}

for page in plat_data['pages']:
    for prod in page['products_found']:
        for field in new_plat_fields.keys():
            if field in prod['specifications']:
                new_plat_fields[field] += 1

print(f"\nNEW FIELDS FOUND:")
for field, count in new_plat_fields.items():
    status = "✓" if count > 0 else "✗"
    print(f"  {status} {field:<40} {count} occurrences")

# Show sample
for page in plat_data['pages']:
    for prod in page['products_found']:
        if 'wall_thickness' in prod['specifications'] or 'tensile_strength' in prod['specifications']:
            print(f"\n  Sample product with new fields:")
            print(f"    Product: {prod['product_id']}")
            print(f"    wall_thickness: {prod['specifications'].get('wall_thickness', 'N/A')}")
            print(f"    tensile_strength: {prod['specifications'].get('tensile_strength', 'N/A')}")
            break
    else:
        continue
    break

# Check Aandrijftechniek
print("\n" + "="*80)
print("Aandrijftechniek: Checking for NEW parsed fields")
print("="*80)

with open('output/aandrijftechniek_analysis.json', 'r', encoding='utf-8') as f:
    aand_data = json.load(f)

new_aand_fields = {
    'width': 0,
    'width_mm': 0,
    'height': 0,
    'height_mm': 0,
    'bottom_width': 0,
    'pitch_length': 0,
    'bearing_clearance': 0,
    'bearing_housing': 0,
    'dynamic_load': 0,
    'dynamic_load_kn': 0,
    'static_load': 0,
    'static_load_kn': 0,
    'max_rpm_grease': 0,
    'max_rpm_oil': 0,
    'weight_per_meter': 0,
}

for page in aand_data['pages']:
    for prod in page['products_found']:
        for field in new_aand_fields.keys():
            if field in prod['specifications']:
                new_aand_fields[field] += 1

print(f"\nNEW FIELDS FOUND:")
for field, count in sorted(new_aand_fields.items(), key=lambda x: x[1], reverse=True):
    status = "✓" if count > 0 else "✗"
    print(f"  {status} {field:<40} {count} occurrences")

# Show sample
for page in aand_data['pages']:
    for prod in page['products_found']:
        if 'width' in prod['specifications'] or 'dynamic_load' in prod['specifications']:
            print(f"\n  Sample product with new fields:")
            print(f"    Product: {prod['product_id']}")
            specs = prod['specifications']
            if 'width' in specs:
                print(f"    width: {specs['width']}")
            if 'height' in specs:
                print(f"    height: {specs['height']}")
            if 'dynamic_load' in specs:
                print(f"    dynamic_load: {specs['dynamic_load']}")
            if 'bearing_clearance' in specs:
                print(f"    bearing_clearance: {specs['bearing_clearance']}")
            break
    else:
        continue
    break

print("\n" + "="*80)
print("VERIFICATION COMPLETE")
print("="*80)
