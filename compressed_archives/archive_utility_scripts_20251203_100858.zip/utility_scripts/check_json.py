import json

with open('output/pe_buizen_analysis.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

print(f"Total pages in JSON: {len(data['pages'])}")
print(f"Total products reported: {data['total_products']}")

page_prods = sum(len(p['products_found']) for p in data['pages'])
print(f"Actual products in pages: {page_prods}")

# Check for table products
table_prods = sum(1 for p in data['pages'] for prod in p['products_found'] if '_TBL' in prod['product_id'])
print(f"Table products: {table_prods}")

# Show first table product
for page in data['pages']:
    for prod in page['products_found']:
        if '_TBL' in prod['product_id']:
            print(f"\nFirst table product:")
            print(f"ID: {prod['product_id']}")
            print(f"Specs count: {len(prod['specifications'])}")
            print(f"Spec keys: {list(prod['specifications'].keys())[:10]}")
            break
    else:
        continue
    break
