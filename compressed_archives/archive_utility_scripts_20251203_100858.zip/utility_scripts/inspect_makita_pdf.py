"""
Inspect Makita PDF Structure
=============================
Check what data is available in the PDF for extraction
"""
import pdfplumber
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "makita-catalogus-2022-nl.pdf"

def inspect_pdf():
    print("=" * 80)
    print("MAKITA PDF STRUCTURE INSPECTION")
    print("=" * 80)
    
    pdf = pdfplumber.open(PDF_PATH)
    print(f"\n📄 PDF: {PDF_PATH.name}")
    print(f"   Total pages: {len(pdf.pages)}")
    
    # Check a few sample pages with products
    sample_pages = [2, 5, 10, 20, 30, 40]
    
    for page_num in sample_pages:
        if page_num > len(pdf.pages):
            continue
            
        print(f"\n{'='*80}")
        print(f"PAGE {page_num}")
        print('='*80)
        
        page = pdf.pages[page_num - 1]
        
        # Extract text
        text = page.extract_text()
        if text:
            lines = text.split('\n')
            print(f"\n📝 Text ({len(lines)} lines):")
            print("   First 15 lines:")
            for i, line in enumerate(lines[:15], 1):
                print(f"   {i:2d}. {line[:75]}")
        
        # Extract tables
        tables = page.extract_tables()
        if tables:
            print(f"\n📊 Tables found: {len(tables)}")
            for i, table in enumerate(tables, 1):
                if table:
                    print(f"\n   Table {i}: {len(table)} rows x {len(table[0]) if table[0] else 0} cols")
                    print(f"   First 3 rows:")
                    for j, row in enumerate(table[:3], 1):
                        # Clean None values
                        clean_row = [str(cell)[:30] if cell else '' for cell in row]
                        print(f"      Row {j}: {' | '.join(clean_row)}")
        else:
            print("\n📊 No tables found on this page")
        
        # Extract words with positions (to understand layout)
        words = page.extract_words()
        if words:
            print(f"\n📍 Words extracted: {len(words)}")
            # Show unique fonts
            fonts = set(w.get('fontname', 'unknown') for w in words)
            print(f"   Fonts used: {', '.join(sorted(fonts)[:5])}")
    
    pdf.close()
    
    print("\n" + "=" * 80)
    print("ANALYSIS")
    print("=" * 80)
    print("""
Based on the inspection, we need to determine:
1. Does Makita catalog use tables for product specs? ✓/✗
2. Are specs in structured text blocks? ✓/✗
3. Are there headers/labels we can parse? ✓/✗
4. What extraction strategy should we use?
    """)

if __name__ == '__main__':
    inspect_pdf()
