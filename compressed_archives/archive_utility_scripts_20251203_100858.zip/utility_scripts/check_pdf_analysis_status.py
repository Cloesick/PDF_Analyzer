"""
Check which PDFs have been analyzed with the comprehensive extraction
"""
import os
from pathlib import Path
import json

print("="*80)
print("PDF ANALYSIS STATUS CHECK")
print("="*80)

# List all PDFs
input_dir = Path('input_pdfs')
pdfs = sorted([f.stem for f in input_dir.glob('*.pdf')])

print(f"\nTotal PDFs in input_pdfs: {len(pdfs)}\n")

# Check which have comprehensive analysis JSONs (enriched versions)
output_dir = Path('output')

analyzed_pdfs = []
partial_analysis = []
no_analysis = []

for pdf_name in pdfs:
    # Check for enriched comprehensive analysis
    enriched_json = output_dir / f"{pdf_name.replace('-', '_')}_analysis_enriched.json"
    regular_json = output_dir / f"{pdf_name.replace('-', '_')}_analysis.json"
    
    # Check for old-style analysis
    grouped_json = output_dir / f"{pdf_name.replace('-', '_')}_grouped.json"
    images_json = output_dir / f"{pdf_name.replace('-', '_')}_images.json"
    
    if enriched_json.exists():
        # Load to get stats
        with open(enriched_json, 'r', encoding='utf-8') as f:
            data = json.load(f)
        analyzed_pdfs.append({
            'name': pdf_name,
            'type': 'COMPREHENSIVE + ENRICHED',
            'products': data.get('total_products', 0),
            'images': data.get('total_images', 0),
            'file': str(enriched_json)
        })
    elif regular_json.exists():
        with open(regular_json, 'r', encoding='utf-8') as f:
            data = json.load(f)
        analyzed_pdfs.append({
            'name': pdf_name,
            'type': 'COMPREHENSIVE (not enriched)',
            'products': data.get('total_products', 0),
            'images': data.get('total_images', 0),
            'file': str(regular_json)
        })
    elif grouped_json.exists() or images_json.exists():
        partial_analysis.append({
            'name': pdf_name,
            'type': 'OLD STYLE',
            'files': [str(f) for f in [grouped_json, images_json] if f.exists()]
        })
    else:
        no_analysis.append(pdf_name)

# Display results
print("="*80)
print("✅ COMPREHENSIVE ANALYSIS COMPLETE (3)")
print("="*80)
for item in analyzed_pdfs:
    print(f"\n📄 {item['name']}")
    print(f"   Type: {item['type']}")
    print(f"   Products: {item['products']}")
    print(f"   Images: {item['images']}")
    print(f"   File: {item['file']}")

if partial_analysis:
    print(f"\n{'='*80}")
    print(f"⚠️  PARTIAL/OLD STYLE ANALYSIS ({len(partial_analysis)})")
    print("="*80)
    print("\nThese have older analysis formats without comprehensive table extraction:")
    for item in partial_analysis:
        print(f"\n📄 {item['name']}")
        print(f"   Type: {item['type']}")
        print(f"   Files: {len(item['files'])} found")

if no_analysis:
    print(f"\n{'='*80}")
    print(f"❌ NO ANALYSIS FOUND ({len(no_analysis)})")
    print("="*80)
    print("\nThese PDFs have not been analyzed yet:")
    for pdf_name in no_analysis:
        print(f"   • {pdf_name}")

# Summary
print(f"\n{'='*80}")
print(f"SUMMARY")
print(f"{'='*80}")
print(f"\nTotal PDFs: {len(pdfs)}")
print(f"  ✅ Comprehensive analysis: {len(analyzed_pdfs)}")
print(f"  ⚠️  Partial/old analysis: {len(partial_analysis)}")
print(f"  ❌ No analysis: {len(no_analysis)}")

if partial_analysis or no_analysis:
    print(f"\n{'='*80}")
    print(f"RECOMMENDATIONS")
    print(f"{'='*80}")
    
    if partial_analysis:
        print(f"\n📋 PDFs with OLD STYLE analysis:")
        print(f"   These should be re-analyzed with comprehensive extraction:")
        for item in partial_analysis[:5]:
            print(f"   • {item['name']}")
        if len(partial_analysis) > 5:
            print(f"   ... and {len(partial_analysis) - 5} more")
    
    if no_analysis:
        print(f"\n📋 PDFs with NO analysis:")
        print(f"   These need initial comprehensive extraction:")
        for pdf_name in no_analysis[:5]:
            print(f"   • {pdf_name}")
        if len(no_analysis) > 5:
            print(f"   ... and {len(no_analysis) - 5} more")

print("="*80)
