import os
import json
import pdfplumber
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from openai import OpenAI

# ==========================================
# 1. THE POLYMORPHIC SCHEMA (Data Structure)
# ==========================================

class SourceMetadata(BaseModel):
    file_name: str
    page_index: int
    page_label: Optional[str] = None
    section_header: Optional[str] = None

class FluidSpecs(BaseModel):
    size_raw: Optional[str] = None
    connection_type: Optional[str] = None
    pressure_rating_bar: Optional[float] = None
    diameter_mm: Optional[float] = None
    # Specific to Storz/Couplings 
    lug_distance_mm: Optional[float] = None
    # Specific to Flanges 
    pitch_circle_diameter_mm: Optional[float] = None

class PumpSpecs(BaseModel):
    power_kw: Optional[float] = None
    voltage: Optional[str] = None
    flow_rate_m3h: Optional[float] = None
    head_max_m: Optional[float] = None
    # "Steek" in pump context 
    discharge_port: Optional[str] = None
    suction_port: Optional[str] = None
    # Specific to Submersible 
    solids_handling_mm: Optional[float] = None
    has_float_switch: Optional[bool] = None

class ClampSpecs(BaseModel):
    # From "Klembereik" 
    range_min_mm: Optional[float] = None
    range_max_mm: Optional[float] = None
    band_width_mm: Optional[float] = None
    material: Optional[str] = None

class CatalogItem(BaseModel):
    sku: str
    description: str
    category: str
    metadata: SourceMetadata
    # Polymorphic fields (only one populated per item)
    fluid_specs: Optional[FluidSpecs] = None
    pump_specs: Optional[PumpSpecs] = None
    clamp_specs: Optional[ClampSpecs] = None

# ==========================================
# 2. LOGIC CONFIGURATION (The "Brain")
# ==========================================

def get_extraction_logic(filename: str) -> Dict[str, str]:
    """
    Returns specific prompt instructions based on the file content analysis.
    """
    base_instruction = (
        "Extract products into JSON. You must track the 'section_header' from previous text "
        "if the current table has no header."
    )

    # Logic for Piston Pumps 
    if "zuigerpompen" in filename.lower():
        return {
            "category": "Pump",
            "prompt": base_instruction + (
                " SPECIAL RULE: If you see a column 'Steek', map it to 'discharge_port'. "
                "Do NOT map it to pitch circle. Map 'Aanzuig' to 'suction_port'. "
                "Map 'Opv.hoogte' to 'head_max_m'."
            )
        }

    # Logic for Hose Clamps 
    elif "slangklemmen" in filename.lower():
        return {
            "category": "Clamp",
            "prompt": base_instruction + (
                " SPECIAL RULE: Parse 'Klembereik' (e.g. '22-25') into 'range_min_mm' and 'range_max_mm'. "
                "Look for 'Breedte' and map to 'band_width_mm'. "
                "Inherit material (RVS/ALU) from the section header."
            )
        }

    # Logic for Couplings 
    elif "slangkoppelingen" in filename.lower():
        return {
            "category": "Coupling",
            "prompt": base_instruction + (
                " SPECIAL RULE: For 'Storz' items, look for 'KA' or 'Nokkenafstand' in the text "
                "and map to 'lug_distance_mm'. Keep raw size strings like 'Storz C'."
            )
        }

    # Logic for Stainless/Galva Fittings [1, 1]
    elif "fittingen" in filename.lower() or "buizen" in filename.lower():
        return {
            "category": "Fitting",
            "prompt": base_instruction + (
                " SPECIAL RULE: If 'Steekcirkel' is present (Flanges), map to 'pitch_circle_diameter_mm'. "
                "For Pipes, extract 'Wanddikte' to 'fluid_specs.wall_thickness_mm'."
            )
        }
    
    else:
        return {"category": "General", "prompt": base_instruction}

# ==========================================
# 3. THE EXTRACTION ENGINE
# ==========================================

class IndustrialExtractor:
    def __init__(self, api_key: str):
        self.client = OpenAI(api_key=api_key)

    def process_pdf(self, file_path: str) -> List[CatalogItem]:
        extracted_items = []
        filename = os.path.basename(file_path)
        logic = get_extraction_logic(filename)
        
        # State variables for context inheritance
        current_section_header = "Unknown"
        
        with pdfplumber.open(file_path) as pdf:
            print(f"Processing {filename} ({len(pdf.pages)} pages)... using mode: {logic['category']}")
            
            for i, page in enumerate(pdf.pages):
                page_num = i + 1
                
                # 1. Extract raw text and tables
                text = page.extract_text()
                
                # 2. Update context (heuristic: usually ALL CAPS lines at top)
                lines = text.split('\n')
                if lines and lines[0].isupper(): 
                    current_section_header = lines[0]

                # 3. Prepare payload for LLM
                # We send the text + the specific logic for this file type
                response = self.client.chat.completions.create(
                    model="gpt-4-turbo", # Or gpt-4o for vision capabilities
                    messages=[
                        {
                            "role": "system",
                            "content": (
                                f"{logic['prompt']} "
                                "Output strictly valid JSON list of objects matching the Schema."
                            )
                        },
                        {
                            "role": "user", 
                            "content": f"Context Header: {current_section_header}\nPage Text:\n{text}"
                        }
                    ],
                    response_format={"type": "json_object"}
                )
                
                # 4. Parse and Validate
                try:
                    data = json.loads(response.choices[0].message.content)
                    items = data.get("items", [])
                    
                    for item in items:
                        # Inject Provenance Data
                        item['metadata'] = {
                            "file_name": filename,
                            "page_index": page_num,
                            "section_header": current_section_header
                        }
                        # Validate against schema
                        validated_item = CatalogItem(**item)
                        extracted_items.append(validated_item)
                        
                except Exception as e:
                    print(f"Error on page {page_num}: {e}")

        return extracted_items

# ==========================================
# 4. EXECUTION
# ==========================================

# Usage Example:
# extractor = IndustrialExtractor(api_key="your-key-here")
# all_products = []
# for pdf in os.listdir("./pdfs"):
#     if pdf.endswith(".pdf"):
#         items = extractor.process_pdf(f"./pdfs/{pdf}")
#         all_products.extend(items)
#
# with open("DEMA_Complete_Catalog.json", "w") as f:
#     f.write(json.dumps([p.dict() for p in all_products], indent=2))