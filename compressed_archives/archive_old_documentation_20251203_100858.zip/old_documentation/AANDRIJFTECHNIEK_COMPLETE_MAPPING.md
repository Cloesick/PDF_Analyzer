# Aandrijftechniek Complete Image Mapping

## ✅ Final Implementation: Clean Filenames + Comprehensive Mapping

### 🎯 Strategy (Option 3)

**Keep Clean, Semantic Filenames:**
```
catalogus-aandrijftechniek_p020_RLNUC205.jpeg
catalogus-aandrijftechniek_p040_1105.jpeg
catalogus-aandrijftechniek_p088_1421.jpeg
```

**Use Mapping Files for Complexity:**
- `aandrijftechniek_group_mapping.json` - Maps 14 groups to 10 images
- `aandrijftechniek_image_mapping.json` - Maps 54 SKUs to 10 images

---

## 📊 Complete Mapping Overview

### Product Groups → Images

**All 14 groups now mapped:**

| Group | SKUs | Image | Shared? |
|-------|------|-------|---------|
| RLNUC205 | 2 | catalogus-aandrijftechniek_p020_RLNUC205.jpeg | ✅ (4 groups) |
| RLNUC206 | 2 | catalogus-aandrijftechniek_p020_RLNUC205.jpeg | ✅ (4 groups) |
| RLNUC207 | 2 | catalogus-aandrijftechniek_p020_RLNUC205.jpeg | ✅ (4 groups) |
| RLNUC208 | 2 | catalogus-aandrijftechniek_p020_RLNUC205.jpeg | ✅ (4 groups) |
| 1105 | 3 | catalogus-aandrijftechniek_p040_1105.jpeg | ❌ |
| RKKBS08 | 2 | catalogus-aandrijftechniek_p044_RKKBS08.jpeg | ✅ (2 groups) |
| RKKBS16 | 2 | catalogus-aandrijftechniek_p044_RKKBS08.jpeg | ✅ (2 groups) |
| RKKASA100 | 2 | catalogus-aandrijftechniek_p051_RKKASA100.jpeg | ❌ |
| RKKASA60 | 2 | catalogus-aandrijftechniek_p051_RKKASA60.jpeg | ❌ |
| RKKS55 | 4 | catalogus-aandrijftechniek_p052_RKKS55.jpeg | ❌ |
| CARDW2400 | 2 | catalogus-aandrijftechniek_p056_CARDW2400.jpeg | ❌ |
| CARDW2500 | 2 | catalogus-aandrijftechniek_p056_CARDW2500.jpeg | ❌ |
| CARBU12 | 2 | catalogus-aandrijftechniek_p070_CARBU12.jpeg | ❌ |
| 1421 | 25 | catalogus-aandrijftechniek_p088_1421.jpeg | ❌ |

**Total: 54 SKUs across 14 groups using 10 unique images**

---

## 🔗 Image Sharing Details

### Shared Images (2 images, 6 groups, 12 SKUs)

**1. Page 20 Image (Most Shared)**
```
catalogus-aandrijftechniek_p020_RLNUC205.jpeg
```
Shared by **4 product groups** (8 SKUs total):
- RLNUC205 Series: RLNUC205, RLNUC205G2L3
- RLNUC206 Series: RLNUC206, RLNUC206G2L3
- RLNUC207 Series: RLNUC207, RLNUC207G2L3
- RLNUC208 Series: RLNUC208, RLNUC208G2L3

**Reason**: All 4 groups appear in the same table on page 20

**2. Page 44 Image**
```
catalogus-aandrijftechniek_p044_RKKBS08.jpeg
```
Shared by **2 product groups** (4 SKUs total):
- RKKBS08 Series: RKKBS08B, RKKBS08B050
- RKKBS16 Series: RKKBS16B, RKKBS16BG

**Reason**: Both groups share the same table/section on page 44

---

### Single-Use Images (8 images, 8 groups, 42 SKUs)

| Image | Group | SKUs |
|-------|-------|------|
| catalogus-aandrijftechniek_p040_1105.jpeg | 1105 | 3 |
| catalogus-aandrijftechniek_p051_RKKASA100.jpeg | RKKASA100 | 2 |
| catalogus-aandrijftechniek_p051_RKKASA60.jpeg | RKKASA60 | 2 |
| catalogus-aandrijftechniek_p052_RKKS55.jpeg | RKKS55 | 4 |
| catalogus-aandrijftechniek_p056_CARDW2400.jpeg | CARDW2400 | 2 |
| catalogus-aandrijftechniek_p056_CARDW2500.jpeg | CARDW2500 | 2 |
| catalogus-aandrijftechniek_p070_CARBU12.jpeg | CARBU12 | 2 |
| catalogus-aandrijftechniek_p088_1421.jpeg | 1421 | 25 |

---

## 📈 Efficiency Metrics

### Storage Efficiency
- **54 SKUs** mapped to **10 unique images**
- **Efficiency**: ~81% reduction vs. per-SKU images
- **Average**: 5.4 SKUs per image
- **Max sharing**: 8 SKUs on one image (page 20)

### Mapping Accuracy
- **14/14 groups** mapped (100% coverage)
- **54/54 SKUs** mapped (100% coverage)
- **10/87 images** in use (targeted selection)
- **0 missing** mappings

---

## 🎯 How Mapping Works

### Group Mapping File
```json
{
  "page20_RLNUC205": "/images/products/aandrijftechniek/catalogus-aandrijftechniek_p020_RLNUC205.jpeg",
  "page20_RLNUC206": "/images/products/aandrijftechniek/catalogus-aandrijftechniek_p020_RLNUC205.jpeg",
  "page20_RLNUC207": "/images/products/aandrijftechniek/catalogus-aandrijftechniek_p020_RLNUC205.jpeg",
  "page20_RLNUC208": "/images/products/aandrijftechniek/catalogus-aandrijftechniek_p020_RLNUC205.jpeg"
}
```
**One image → multiple groups on same page**

### SKU Mapping File
```json
{
  "RLNUC205": "/images/products/aandrijftechniek/catalogus-aandrijftechniek_p020_RLNUC205.jpeg",
  "RLNUC205G2L3": "/images/products/aandrijftechniek/catalogus-aandrijftechniek_p020_RLNUC205.jpeg",
  "RLNUC206": "/images/products/aandrijftechniek/catalogus-aandrijftechniek_p020_RLNUC205.jpeg",
  "RLNUC206G2L3": "/images/products/aandrijftechniek/catalogus-aandrijftechniek_p020_RLNUC205.jpeg"
}
```
**All SKUs in groups point to the same shared image**

---

## 🔧 Frontend Integration

### Catalog Page Usage
The `aandrijftechniek-grouped/page.tsx` component:

1. **Loads mapping** on page mount:
   ```typescript
   const [imageMapping, setImageMapping] = useState<Record<string, string>>({});
   
   useEffect(() => {
     fetch('/data/aandrijftechniek_image_mapping.json')
       .then(res => res.json())
       .then(data => setImageMapping(data));
   }, []);
   ```

2. **Applies images** to product variants:
   ```typescript
   variants: group.variants.map((variant: any) => {
     const mappedImage = imageMapping[variant.sku];
     if (mappedImage) {
       return {
         ...variant,
         image: mappedImage,
         media: [{ url: mappedImage, role: 'main', type: 'image' }]
       };
     }
     return variant;
   })
   ```

3. **Renders** products with correct images automatically

---

## 🎨 Benefits of This Approach

### ✅ Clean Filenames
- **Semantic**: `catalogus-aandrijftechniek_p020_RLNUC205.jpeg`
- **Professional**: Catalog prefix on all files
- **Organized**: Page number + group name
- **Manageable**: Not too long, easy to read

### ✅ Flexible Mapping
- **Handles sharing**: Multiple groups can share one image
- **Scalable**: Easy to add more mappings
- **Maintainable**: Update mapping file, not filenames
- **Efficient**: Only 10 images for 54 SKUs

### ✅ Clear Documentation
- **Group mapping** shows group → image relationships
- **SKU mapping** shows exact SKU → image mappings
- **Self-documenting**: Filenames indicate product family
- **Transparent**: Easy to see what's mapped

---

## 🔄 Updating the Mapping

### Adding New Products

**If new SKUs added to existing group:**
1. They automatically use the group's image (no file changes needed)
2. Re-run mapping script to update SKU mapping

**If new group added:**
1. Add image: `catalogus-aandrijftechniek_pXXX_NewGroup.jpeg`
2. Re-run: `python complete_aandrijftechniek_mapping.py`
3. New group and SKUs automatically mapped

### Changing Images

**To update an image:**
1. Replace file in `/images/products/aandrijftechniek/`
2. Keep same filename
3. All SKUs/groups using that image updated automatically

**To rename an image:**
1. Rename file in folder
2. Update mapping files (or re-run mapping script)

---

## 📝 Quick Reference

### Files
```
DemaWebshop/dema-webshop/
├── public/
│   ├── images/products/aandrijftechniek/
│   │   ├── catalogus-aandrijftechniek_p020_RLNUC205.jpeg (8 SKUs)
│   │   ├── catalogus-aandrijftechniek_p040_1105.jpeg (3 SKUs)
│   │   ├── catalogus-aandrijftechniek_p044_RKKBS08.jpeg (4 SKUs)
│   │   └── ... (7 more images)
│   └── data/
│       ├── aandrijftechniek_grouped.json (14 groups)
│       ├── aandrijftechniek_group_mapping.json (14 groups → 10 images)
│       └── aandrijftechniek_image_mapping.json (54 SKUs → 10 images)
└── src/app/catalog/aandrijftechniek-grouped/page.tsx
```

### Commands
```bash
# Regenerate complete mapping
python complete_aandrijftechniek_mapping.py

# View group mappings
cat public/data/aandrijftechniek_group_mapping.json

# View SKU mappings
cat public/data/aandrijftechniek_image_mapping.json

# Check image usage
ls public/images/products/aandrijftechniek/catalogus-*.jpeg
```

---

## 🎯 Summary

**Final Implementation:**
- ✅ **14 product groups** fully mapped
- ✅ **54 SKUs** have correct image references
- ✅ **10 unique images** efficiently shared
- ✅ **2 images** shared by multiple groups (page 20, page 44)
- ✅ **8 images** dedicated to single groups
- ✅ **Clean filenames** maintained
- ✅ **Comprehensive mapping** ensures accuracy

**Result**: A scalable, efficient, and professional image management system that correctly maps all SKUs to their images while maintaining clean, semantic filenames! 🚀
