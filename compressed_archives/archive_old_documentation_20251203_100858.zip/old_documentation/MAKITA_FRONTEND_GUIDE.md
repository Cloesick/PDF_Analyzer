# Makita Products Frontend Integration Guide

## ✅ Problem Solved

Your Makita products now have:
- ✅ **English property keys** (torque, chuck_size, batteries, etc.)
- ✅ **Icons with labels** in display values
- ✅ **496 products** properly formatted

## 📊 Data Structure

Each product has two formats:

### 1. `specifications` - For Database/Filtering
Clean English keys for backend logic:
```json
{
  "sku": "DF002GD201",
  "specifications": {
    "voltage": "36 V (40Vmax)",
    "torque": "30 / 64 Nm",
    "chuck_size": "1,5 - 13 mm",
    "hammer_drill": "No",
    "batteries": "2 x BL4025",
    "charger": "DC40RA",
    "weight": "2,5 kg",
    "price_excl": "€ 485.00"
  }
}
```

### 2. `display` - For Frontend UI
Beautiful formatted strings with icons and **both prices** (ex and incl VAT):
```json
{
  "display": {
    "voltage": "⚡ 36 V (40Vmax)",
    "torque": "🔧 30 / 64 Nm (Torque)",
    "chuck_size": "🎯 1,5 - 13 mm (Chuck)",
    "hammer_drill": "🔨 No (Hammer)",
    "batteries": "🔋 2 x BL4025",
    "charger": "🔌 DC40RA",
    "weight": "⚖️ 2,5 kg",
    "price_excl": "💶 € 485.00 (ex BTW)",
    "price_incl": "💶 € 586.85 (incl BTW)"
  }
}
```

**Note:** If only one price is available, the system automatically calculates the other using 21% VAT rate.

## 🎯 Property Keys (English)

| English Key | Dutch Name | Icon | Label |
|------------|------------|------|-------|
| `voltage` | spanning | ⚡ | - |
| `torque` | max. koppel | 🔧 | Torque |
| `chuck_size` | boorkop | 🎯 | Chuck |
| `hammer_drill` | klopboorfunctie | 🔨 | Hammer |
| `batteries` | bijgeleverde accu's | 🔋 | - |
| `charger` | lader | 🔌 | - |
| `weight` | gewicht | ⚖️ | - |
| `power` | vermogen | ⚡ | Power |
| `rpm` | toerental | 🔄 | RPM |
| `price` | prijs | 💶 | - |
| `price_excl` | prijs excl. btw | 💶 | (ex) |
| `price_incl` | prijs incl. btw | 💶 | (incl) |

## 🚀 Frontend Usage

### React/TypeScript
```tsx
import makitaProducts from './makita_frontend_display.json';

interface MakitaProduct {
  sku: string;
  name: string;
  specifications: Record<string, string>;
  display: Record<string, string>;
}

function ProductCard({ sku }: { sku: string }) {
  const product = makitaProducts.products.find(p => p.sku === sku);
  
  if (!product) return <div>Product not found</div>;
  
  return (
    <div className="product-card">
      <h2>{product.sku}</h2>
      
      {/* Display formatted specs */}
      <div className="specs">
        {Object.values(product.display).map((spec, i) => (
          <div key={i} className="spec-item">{spec}</div>
        ))}
      </div>
      
      {/* Or access specific properties */}
      <div className="key-specs">
        <div>{product.display.voltage}</div>
        <div>{product.display.torque}</div>
        <div>{product.display.batteries}</div>
      </div>
      
      {/* Display both prices */}
      <div className="pricing">
        <div className="price-excl">{product.display.price_excl}</div>
        <div className="price-incl">{product.display.price_incl}</div>
      </div>
    </div>
  );
}
```

### Vue 3
```vue
<template>
  <div class="product-card">
    <h2>{{ product.sku }}</h2>
    
    <!-- Display all specs -->
    <div class="specs">
      <div v-for="(value, key) in product.display" :key="key" class="spec">
        {{ value }}
      </div>
    </div>
    
    <!-- Or specific properties -->
    <div class="key-info">
      <p>{{ product.display.voltage }}</p>
      <p>{{ product.display.torque }}</p>
      <p>{{ product.display.price_excl }}</p>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue';
import makitaData from './makita_frontend_display.json';

const props = defineProps(['sku']);

const product = computed(() => 
  makitaData.products.find(p => p.sku === props.sku)
);
</script>
```

### Plain JavaScript
```javascript
// Load data
fetch('/data/makita_frontend_display.json')
  .then(r => r.json())
  .then(data => {
    const product = data.products.find(p => p.sku === 'DF002GD201');
    
    // Display specs
    const specsHTML = Object.values(product.display)
      .map(spec => `<div class="spec">${spec}</div>`)
      .join('');
    
    document.getElementById('specs').innerHTML = specsHTML;
  });
```

## 🔍 Filtering/Searching

Use `specifications` for backend logic:

```typescript
// Filter by voltage
const products40V = makitaProducts.products.filter(
  p => p.specifications.voltage?.includes('40Vmax')
);

// Filter by price range
const affordableTools = makitaProducts.products.filter(p => {
  const price = parseFloat(p.specifications.price?.replace(/[^\d.]/g, ''));
  return price < 300;
});

// Search by torque
const highTorque = makitaProducts.products.filter(p => {
  const torque = p.specifications.torque;
  if (!torque) return false;
  const match = torque.match(/(\d+)\s*Nm/);
  return match && parseInt(match[1]) > 100;
});
```

## 📦 Sample Output (Formatted)

```
┌────────────────────────────────┐
│ Model: DF002GD201              │
│                                │
│ ⚡ 36 V (40Vmax)              │
│ 🔧 30 / 64 Nm (Torque)        │
│ 🎯 1,5 - 13 mm (Chuck)        │
│ 🔨 No (Hammer)                │
│ 🔋 2 x BL4025                 │
│ 🔌 DC40RA                     │
│ ⚖️ 2.5 kg                     │
│ 💶 € 175.00 (ex BTW)          │
│ 💶 € 211.75 (incl BTW)        │
└────────────────────────────────┘
```

## 🎨 CSS Styling Suggestions

```css
.product-card {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 20px;
  background: white;
}

.spec-item {
  padding: 8px 0;
  font-size: 14px;
  border-bottom: 1px solid #f5f5f5;
}

.spec-item:last-child {
  border-bottom: none;
}

/* Highlight key specs */
.key-specs {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
  margin-top: 16px;
}

.key-specs > div {
  background: #f5f5f5;
  padding: 12px;
  border-radius: 6px;
  font-weight: 500;
}

/* Pricing display */
.pricing {
  margin-top: 16px;
  padding: 16px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 8px;
  color: white;
}

.price-excl, .price-incl {
  padding: 8px 0;
  font-size: 16px;
  font-weight: 600;
}

.price-incl {
  font-size: 18px;
  border-top: 1px solid rgba(255,255,255,0.3);
  padding-top: 12px;
  margin-top: 8px;
}
```

## 🔄 Regenerating Data

If you need to update the formatted data:

```bash
python format_makita_for_frontend.py
```

This will regenerate `output/makita_frontend_display.json` with the latest data.

## 📁 Files

- **Data**: `output/makita_frontend_display.json` (496 products)
- **Script**: `format_makita_for_frontend.py` (formatter)
- **Guide**: `MAKITA_FRONTEND_GUIDE.md` (this file)

## ✅ All Properties Now Visible

Your properties are now properly reflected:
- ✅ **torque** → `🔧 30 / 64 Nm (Torque)`
- ✅ **chuck_size** (boorkop) → `🎯 1,5 - 13 mm (Chuck)`
- ✅ **hammer_drill** (klopboorfunctie) → `🔨 Yes/No (Hammer)`
- ✅ **batteries** → `🔋 2 x BL4025`
- ✅ **charger** → `🔌 DC40RA`
- ✅ **weight** → `⚖️ 2.5 kg`
- ✅ **voltage** → `⚡ 36 V (40Vmax)`
- ✅ **price_excl** → `💶 € 175.00 (ex BTW)`
- ✅ **price_incl** → `💶 € 211.75 (incl BTW)` *(auto-calculated at 21% VAT)*

## 💰 VAT Calculation

All products now show **both prices**:
- **Exclusive BTW (VAT)**: Price without tax
- **Inclusive BTW (VAT)**: Price with 21% tax included

If the source data only has one price, the system automatically calculates the other:
- `price_incl = price_excl × 1.21`
- `price_excl = price_incl ÷ 1.21`

**Examples:**
- € 175.00 (ex) → € 211.75 (incl)
- € 665.00 (ex) → € 804.65 (incl)
- € 485.00 (ex) → € 586.85 (incl)

All 496 Makita products are ready for your frontend! 🎉
