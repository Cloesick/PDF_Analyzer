# Statistics Banner - TSX Component Guide

## 📊 Real Statistics from Your Data

Your actual catalog statistics:
- **26** Catalogs
- **16,399** Total Products  
- **21** Categories
- **51,289** Product Images
- **93.8%** Image Coverage
- **3.1x** Average Images per Product

---

## 🎯 Component Version 1: Simple Banner (Recommended)

```tsx
import { StatsBanner } from './StatsBanner';

// In your page:
export default function YourPage() {
  return (
    <div>
      <StatsBanner />
      {/* Rest of your page */}
    </div>
  );
}
```

**Features:**
- Clean Tailwind design
- Hover animations
- Auto-loads statistics
- Brand color `#00ADEF`

---

## 🌈 Component Version 2: Extended Banner with 6 Stats

```tsx
import { StatsBannerExtended } from './StatsBanner';

// In your page:
export default function YourPage() {
  return (
    <div>
      <StatsBannerExtended />
      {/* Rest of your page */}
    </div>
  );
}
```

**Features:**
- Gradient background
- 6 statistics with icons
- Glass-morphism effect
- Fully responsive

---

## 📦 What's Included

### Files:
- `StatsBanner.tsx` - React component with 2 variants
- `calculate_stats.py` - Statistics generator
- `output/catalog_statistics.json` - Generated data

---

## 🔄 Updating Statistics

When your product data changes, regenerate the statistics:

```bash
python calculate_stats.py
```

This will:
- ✅ Scan all products from `products_ready_for_webshop_v2_comprehensive.json`
- ✅ Count catalogs, categories, images
- ✅ Calculate coverage percentages
- ✅ Save to `output/catalog_statistics.json`
- ✅ Display summary in terminal

---

## 📁 File Structure

```
├── calculate_stats.py              # Generate statistics
├── output/
│   └── catalog_statistics.json     # Generated stats (auto-updated)
├── StatsBanner.tsx                 # React component (2 variants)
└── STATS_BANNER_USAGE.md          # This guide
```

---

## 🎨 Customization

### Change the Brand Color

Edit `StatsBanner.tsx`:

```tsx
// Before
<div className="text-[#00ADEF]">

// After (example: purple)
<div className="text-[#8B5CF6]">
```

### Add More Stats

Edit the component to display additional statistics:

```tsx
<div className="text-center">
  <div className="text-3xl font-bold text-[#00ADEF]">
    {stats.yourCustomStat}
  </div>
  <div className="text-gray-600 font-medium">Your Label</div>
</div>
```

---

## 🚀 Quick Start

1. **Import** the component: `import { StatsBanner } from './StatsBanner'`
2. **Use** in your JSX: `<StatsBanner />`
3. **Ensure** `output/catalog_statistics.json` exists
4. **Run** `python calculate_stats.py` to generate stats
5. **Done!** Real statistics will load automatically

---

## 💡 Tips

- Banner auto-updates when you regenerate statistics
- Hover effects work on desktop (scale + color change)
- Responsive: Stacks on mobile, grid on desktop
- Can be placed anywhere in your component tree
- Uses Tailwind CSS (make sure it's configured in your project)
- TypeScript types are included

---

## 📊 Component API

```tsx
interface CatalogStats {
  totalProducts: number;
  catalogs: number;
  categories: number;
  productsWithImages: number;
  totalImages: number;
  imageCoverage: number;
  avgImagesPerProduct: number;
}
```

Both components automatically fetch from `/output/catalog_statistics.json`

---

## 🎉 Your Real Numbers

Based on your actual data:

| Metric | Value |
|--------|-------|
| 📚 Catalogs | **26** |
| 📦 Products | **16,399** |
| 🏷️ Categories | **21** |
| 🖼️ Images | **51,289** |
| 📊 Coverage | **93.8%** |
| 📸 Avg per Product | **3.1x** |

These impressive numbers are now showcased beautifully! 🎯
