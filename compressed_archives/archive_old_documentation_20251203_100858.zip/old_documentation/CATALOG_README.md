# 🎨 Beautiful Product Catalog System

Complete solution for displaying your 9757 products with high-quality images, PDF links, and detailed information.

---

## 📦 What You Have

### Extracted Data
- **9757 unique SKUs** with 100% image coverage
- **High-quality images** (300 DPI) organized by PDF catalog
- **JSON data** with SKU, images, page numbers, PDF sources
- **Smart grouping** - products sharing images are linked together

### File Structure
```
PDF_Analyzer/
├── output/
│   └── products_v2.3_TIMESTAMP.json          # Product data
├── product-images-by-pdf/
│   ├── airpress-catalogus-nl-fr/             # Images per catalog
│   ├── makita-catalogus-2022-nl/
│   └── ...
├── input_pdfs/                                # Original PDF catalogs
└── Catalog viewers (see below)
```

---

## 🌐 Option 1: Interactive HTML Catalog (Recommended)

**File:** `product_catalog.html`

### Features
✅ Beautiful grid layout with hover effects  
✅ Real-time search by SKU or catalog name  
✅ Filter by source catalog  
✅ Click cards to see all images & details  
✅ Direct links to PDF pages  
✅ Pagination (24 products per page)  
✅ Modal image galleries  
✅ Responsive design  

### How to Use
```bash
# Start the web server
python serve_catalog.py

# Open in browser
http://localhost:8080/product_catalog.html
```

**Perfect for:**
- Interactive browsing
- Customer-facing catalog
- Internal product lookup
- Mobile-friendly viewing

---

## 🖨️ Option 2: Printable Catalog

**File:** `print_catalog.html`

### Features
✅ Print-optimized layout  
✅ Table or grid view  
✅ All product images  
✅ A4 page format  
✅ Professional styling  

### How to Use
```bash
# Open in browser
http://localhost:8080/print_catalog.html

# Click "Print Catalog" button or Ctrl+P
# Save as PDF or print directly
```

**Perfect for:**
- Physical catalogs
- PDF exports
- Offline reference
- Customer quotes

---

## ⚛️ Option 3: React Component

**File:** `ProductCard.jsx`

### Features
✅ Reusable React component  
✅ TypeScript-ready  
✅ Modern hooks (useState)  
✅ Modal functionality  
✅ Fully customizable  

### How to Use
```jsx
import { ProductCard, ProductCatalog } from './ProductCard';
import productsData from './output/products_v2.3_TIMESTAMP.json';

function App() {
  return <ProductCatalog products={productsData} />;
}
```

**Perfect for:**
- React/Next.js applications
- E-commerce integration
- Custom web apps
- SPA (Single Page Applications)

---

## 🎯 Key Features Across All Options

### 1. **Product Images**
- High-quality 300 DPI extraction
- Multiple images per SKU
- Click to view full size
- Organized by PDF catalog

### 2. **PDF Integration**
- Direct links to source PDFs
- Page-specific navigation (`#page=5`)
- Quick reference back to source

### 3. **Smart Data**
- Shows which SKUs share images
- Multiple page locations per SKU
- Catalog source information
- Image count per product

### 4. **Search & Filter**
- Real-time search
- Filter by catalog
- Fast client-side filtering
- No backend required

---

## 📊 Usage Statistics

```
Total Products:    9,757
Total Images:      [varies by PDF]
Total Catalogs:    26
Image Format:      WebP (high quality, 90%)
Organization:      By PDF catalog folder
```

---

## 🚀 Quick Start

### For Interactive Viewing (Best Option)
```bash
# 1. Start the server
python serve_catalog.py

# 2. Open browser to:
http://localhost:8080/product_catalog.html

# 3. Browse, search, and click products!
```

### For Printing/PDF Export
```bash
# 1. Open print version
http://localhost:8080/print_catalog.html

# 2. Select view mode (Table or Grid)

# 3. Print or Save as PDF
```

---

## 🎨 Customization

### Colors & Branding
Edit the CSS in the HTML files:
```css
/* Main gradient colors */
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);

/* Change to your brand colors */
background: linear-gradient(135deg, #YOUR_COLOR_1 0%, #YOUR_COLOR_2 100%);
```

### Layout
```css
/* Products per row */
grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));

/* Change 320px to adjust card size */
```

### Images
- Images are in: `product-images-by-pdf/[catalog-name]/`
- Format: SKU_PDF_PAGE_SPECS[+ADDITIONAL_SKUS].webp
- Edit `MIN_IMAGE_AREA` in extractor to change size threshold

---

## 💡 Advanced Usage

### Embed in Website
```html
<!-- Option 1: iFrame -->
<iframe src="product_catalog.html" width="100%" height="800px"></iframe>

<!-- Option 2: Include React component -->
import { ProductCatalog } from './ProductCard';
```

### Export for CMS
The JSON format is perfect for:
- WordPress with custom post types
- Shopify product import
- WooCommerce
- Any CMS with JSON import

### API Integration
```javascript
// Serve the JSON via API
fetch('/api/products')
  .then(res => res.json())
  .then(products => {
    // Use ProductCard component
  });
```

---

## 🔗 Links in Product Cards

### Implemented Links
1. **View Details** → Opens modal with all images
2. **📄 PDF** → Opens source PDF catalog
3. **Page Links** → Opens PDF at specific page (`#page=5`)
4. **Image Click** → Opens full-size image in new tab

### Example Product Data
```json
{
  "sku": "ABSBU016",
  "pdf_source": "abs-persluchtbuizen.pdf",
  "pages": [5],
  "images": [
    {
      "filename": "ABSBU016_abs-persluchtbuizen_p005_10bar[+ABSBU020+ABSBU025].webp",
      "path": "C:\\...\\product-images-by-pdf\\abs-persluchtbuizen\\ABSBU016_...webp",
      "page": 5,
      "shared_with_skus": ["ABSBU016", "ABSBU020", "ABSBU025"],
      "is_primary": true
    }
  ]
}
```

---

## 📱 Mobile Responsive

All catalog views are fully responsive:
- ✅ Touch-friendly cards
- ✅ Mobile search
- ✅ Swipe-friendly modals
- ✅ Optimized images
- ✅ Fast loading

---

## 🎉 Summary

You now have **3 complete catalog systems**:

| Feature | HTML Catalog | Print Catalog | React Component |
|---------|--------------|---------------|-----------------|
| Interactive | ✅ | ❌ | ✅ |
| Printable | ❌ | ✅ | ❌ |
| Customizable | ⚠️ CSS | ⚠️ CSS | ✅✅✅ |
| PDF Links | ✅ | ✅ | ✅ |
| Image Galleries | ✅ | ❌ | ✅ |
| Search/Filter | ✅ | ✅ | ✅ |
| Best For | General use | Print/PDF | Web apps |

**Recommended:** Start with `product_catalog.html` for the best experience!

---

## 🆘 Need Help?

- Server not starting? Check port 8080 is free
- Images not loading? Verify paths in JSON match folder structure
- Want to customize? Edit the CSS/HTML directly
- Need React help? Check ProductCard.jsx for examples

---

**🎊 Your catalog is ready! Open http://localhost:8080/product_catalog.html to see it!**
