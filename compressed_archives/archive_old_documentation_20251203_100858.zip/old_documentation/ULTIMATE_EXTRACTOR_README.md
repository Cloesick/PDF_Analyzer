# Ultimate PDF Product & Image Extractor

## Overview

This is the **complete, production-ready** extraction system that combines the best practices from all previous scripts into one comprehensive solution.

## Key Features

### 🎯 **Intelligent SKU Detection with Priority System**
```
Priority 1: SKUs in/near the image (directly associated)
Priority 2: SKUs from nearest table (contextual)
Priority 3: SKUs from page text (fallback)
```

When an image has SKU text printed on it or immediately nearby, **it only gets that SKU** - not random SKUs from distant tables.

### 📊 **Catalog-Specific Rules**
The system automatically detects catalog type and applies custom extraction rules:

| Catalog | SKU Location | Margin | Table Layout |
|---------|--------------|--------|--------------|
| **Airpress** | Below images | 60px down | Vertical |
| **ABS** | Right of images | 200px right | Horizontal |
| **Default** | Surrounding | 20x40px | Auto |

### 🖼️ **Smart Image Naming**
```
Format: PRIMARY_SKU__CATEGORY__PAGE__CATALOG__SPECS__[ALL_SKUS]_imgINDEX.webp

Examples:
36510-N__PISTON_COMPRESSOR__p025__airpress_eng__5.5kW_10bar__[36510-N+36516-N+36525-N]_img000.webp
45349__SOCKET_SET__p042__airpress_eng__94pcs__[45349+45580+45780]_img001.webp
77301__DRILL__p018__airpress_eng__750W_img000.webp
```

### 🤖 **GPT-4 Vision Integration**
- **Image filtering**: Identifies real products vs diagrams/charts
- **SKU matching**: Determines which SKUs actually match the image content
- **Configurable**: Can be disabled if needed

### 🎨 **High-Quality Image Processing**
- Smart cropping (removes white space)
- Layout detection (skips lines, separators)
- High-quality .webp output (85 quality, method 6)
- Configurable resolution (default: 150 DPI)

### 📈 **Comprehensive Tracking**
- SKU source tracking (where each SKU was found)
- Detailed statistics per extraction
- Error handling with retry logic
- Verbose progress logging

## Installation

### Requirements
```bash
pip install pdfplumber pillow opencv-python numpy openai
```

### Environment Setup
```bash
# Set your OpenAI API key
export OPENAI_API_KEY="your-key-here"
```

## Usage

### Basic Usage
```bash
python ultimate_pdf_extractor.py
```

### Configuration

Edit the configuration section at the top of the script:

```python
# Folders
INPUT_FOLDER = PROJECT_ROOT / "input_pdfs"      # Put your PDFs here
OUTPUT_FOLDER = PROJECT_ROOT / "output"          # JSON output goes here
IMAGES_FOLDER = PROJECT_ROOT / "product-images-ultimate"  # Images saved here

# Quality settings
WEBP_QUALITY = 85                # 75-95 recommended
IMAGE_RESOLUTION = 150           # DPI for extraction
MIN_IMAGE_AREA = 10000           # Skip images smaller than ~100x100px

# GPT settings
USE_GPT_FILTERING = True         # Use GPT to filter non-product images
USE_GPT_SKU_MATCHING = True      # Use GPT to match SKUs to images
GPT_MODEL = "gpt-4o-mini"        # Or "gpt-4o" for better accuracy

# Processing
VERBOSE = True                   # Show detailed progress
MAX_RETRIES = 3                  # Retry failed operations
```

### Custom Catalog Rules

Add your own catalog-specific rules:

```python
CATALOG_RULES = {
    'your-catalog-name': {
        'sku_search_region': 'below_image',  # or 'right_of_image', 'surrounding'
        'sku_margin_y': 60,                  # Vertical search margin
        'sku_margin_x': 20,                  # Horizontal search margin
        'category_from': 'headers',          # or 'filename', 'text'
        'table_layout': 'vertical',          # or 'horizontal', 'auto'
    },
    # ... add more catalogs
}
```

## Output

### 1. Product Images
Location: `product-images-ultimate/`

Organized with descriptive names:
```
36510-N__PISTON_COMPRESSOR__p025__airpress_eng__5.5kW_10bar__[36510-N+36516-N+36525-N]_img000.webp
45349__SOCKET_SET__p042__airpress_eng__94pcs__[45349+45580+45780]_img001.webp
...
```

### 2. Product Data JSON
Location: `output/products_ultimate_YYYYMMDD_HHMMSS.json`

Structure:
```json
[
  {
    "sku": "36510-N",
    "pdf_source": "airpress-catalogus-eng.pdf",
    "pages": [25, 26],
    "images": [
      {
        "filename": "36510-N__PISTON_COMPRESSOR__p025__airpress_eng__5.5kW_10bar__[36510-N+36516-N+36525-N]_img000.webp",
        "path": "product-images-ultimate/...",
        "page": 25,
        "index": 0,
        "shared_with_skus": ["36510-N", "36516-N", "36525-N"],
        "is_primary": true,
        "sku_sources": [
          {
            "sku": "36510-N",
            "source_type": "nearby_text",
            "confidence": 1.0,
            "location": {"bbox": [...], "text": "..."}
          }
        ]
      }
    ]
  }
]
```

### 3. Extraction Statistics
Printed at the end:
```
===============================================================================
EXTRACTION COMPLETE
===============================================================================

Statistics:
  Total pages processed:     1,543
  Total images found:        4,231
  Images extracted:          1,847
  Images skipped (small):    892
  Images skipped (layout):   456
  Images dropped (GPT):      1,036
  Unique SKUs found:         2,145
  SKUs with images:          1,847
  Errors encountered:        3

Output:
  Images saved to:  product-images-ultimate/
  Product data:     output/products_ultimate_20241126_220530.json
```

## How It Works

### Step-by-Step Process

1. **Load PDF**
   - Detect catalog type
   - Apply catalog-specific rules

2. **Process Each Page**
   - Extract page text
   - Extract tables
   - Identify images

3. **For Each Image**
   - Check size (skip if too small)
   - Smart crop (remove whitespace)
   - Check if layout element (skip lines/separators)
   - **GPT filter** (real product?)

4. **SKU Detection (Priority System)**
   ```
   a) Search near image (±margin based on catalog rules)
      → If found: USE THESE ONLY ✓
   
   b) If no nearby SKUs found:
      → Find nearest table
      → Use table SKUs as fallback
   
   c) Optional: GPT refinement
      → Which SKUs actually match this image?
   ```

5. **Group Similar SKUs**
   - Group SKUs in same series (e.g., 36510-N, 36516-N, 36525-N)
   - Save ONE image per group

6. **Generate Smart Filename**
   - Primary SKU
   - Auto-detected category
   - Page number
   - Short catalog name
   - Top 2 specs (power, pressure, volume, etc.)
   - All SKUs in brackets

7. **Save & Track**
   - Save high-quality .webp
   - Update product map for all SKUs in group
   - Track SKU sources for debugging

## Priority System Explained

### Example 1: SKU Printed on Image

```
PDF Page showing compressor with "36510-N" printed on machine:

┌─────────────────┐
│  [Compressor]   │  ← Image with "36510-N" visible
│   36510-N       │  ← SKU text found in nearby_text
└─────────────────┘

Nearby Table:
┌──────────┬──────┐
│ 36510-N  │ ...  │
│ 36516-N  │ ...  │  ← These SKUs IGNORED
│ 36525-N  │ ...  │
└──────────┴──────┘

Result: Image assigned ONLY to 36510-N ✓
```

### Example 2: No Nearby SKU

```
PDF Page with image but no nearby text:

┌─────────────────┐
│  [Compressor]   │  ← Image (no nearby SKU found)
│                 │
└─────────────────┘

        ↓ (100px away)

Nearest Table:
┌──────────┬──────┐
│ 36510-N  │ ...  │
│ 36516-N  │ ...  │  ← Use these (fallback)
│ 36525-N  │ ...  │
└──────────┴──────┘

Result: Image shared by 36510-N, 36516-N, 36525-N
(because they're in same series and share the image)
```

## Troubleshooting

### Issue: No images extracted
**Solution:**
- Check if `input_pdfs/` folder has PDF files
- Verify images aren't too small (adjust `MIN_IMAGE_AREA`)
- Disable GPT filtering temporarily: `USE_GPT_FILTERING = False`

### Issue: Wrong SKUs assigned to images
**Solution:**
- Check catalog rules (adjust `sku_margin_x/y`)
- Review SKU sources in output JSON
- Enable GPT SKU matching: `USE_GPT_SKU_MATCHING = True`

### Issue: GPT errors
**Solution:**
- Verify `OPENAI_API_KEY` is set
- Check API quota/billing
- Temporarily disable: `USE_GPT_FILTERING = False`

### Issue: Filenames too long
**Solution:**
- The script auto-truncates long filenames
- Reduce `max_length` in `sanitize_for_filename()`

### Issue: Low image quality
**Solution:**
- Increase `WEBP_QUALITY` (85 → 90)
- Increase `IMAGE_RESOLUTION` (150 → 200)

## Advanced Usage

### Add New Category Detection
```python
categories = {
    'YOUR_CATEGORY': ['keyword1', 'keyword2', 'keyword3'],
    # ... add more
}
```

### Customize SKU Patterns
```python
SKU_PATTERNS = [
    re.compile(r'YOUR_PATTERN_HERE'),
    # ... add more
]
```

### Adjust Similarity Threshold
```python
def are_skus_similar(sku1: str, sku2: str, threshold: int = 500):
    # Lower = stricter grouping (100-300)
    # Higher = looser grouping (500-1000)
```

## Performance

**Typical Performance:**
- **Speed**: ~2-5 pages/second (with GPT enabled)
- **Storage**: ~40-60KB per .webp image
- **API Costs**: ~$0.01-0.02 per page (with GPT-4o-mini)

**Optimization Tips:**
- Disable GPT for faster processing (loses accuracy)
- Increase `MIN_IMAGE_AREA` to skip more small images
- Use `GPT_MODEL = "gpt-4o-mini"` for lower costs

## Comparison with Old System

| Feature | Old Extract.py | Ultimate Extractor |
|---------|---------------|-------------------|
| **SKU Priority** | ❌ All SKUs from table | ✅ Nearby SKUs prioritized |
| **Catalog Rules** | ❌ One-size-fits-all | ✅ Catalog-specific |
| **Smart Naming** | ❌ Basic SKU_PDF_PAGE | ✅ Full descriptive names |
| **Page Numbers** | ❌ Not in filename | ✅ Included |
| **Specs in Name** | ❌ No | ✅ Yes (power, pressure, etc.) |
| **GPT Filtering** | ✅ Yes | ✅ Yes |
| **GPT SKU Matching** | ✅ Yes | ✅ Yes + Priority |
| **SKU Source Tracking** | ❌ No | ✅ Yes (for debugging) |
| **Error Recovery** | ⚠️ Basic | ✅ Comprehensive |
| **Statistics** | ⚠️ Basic | ✅ Detailed |
| **Documentation** | ⚠️ Minimal | ✅ Complete |

## Next Steps

1. **Test on sample PDF** first
2. **Review output** in `product-images-ultimate/`
3. **Check JSON** for SKU source accuracy
4. **Adjust catalog rules** as needed
5. **Run on full catalog** set

## Support

For issues, review:
1. Console output for errors
2. `sku_sources` field in JSON (shows where SKUs came from)
3. Extraction statistics (identify bottlenecks)

---

**Ready to extract!** 🚀

Place your PDFs in `input_pdfs/` and run:
```bash
python ultimate_pdf_extractor.py
```
