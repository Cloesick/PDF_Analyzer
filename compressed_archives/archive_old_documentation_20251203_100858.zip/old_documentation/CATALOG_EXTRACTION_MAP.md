# Catalog Extraction Script Mapping

## ✅ Catalogs with Custom High-Quality Scripts

| Catalog | Custom Script | Output File | Quality | Notes |
|---------|---------------|-------------|---------|-------|
| **abs-persluchtbuizen** | `extract_abs_from_tables.py` | `abs_table_specs.json` | ⭐⭐⭐⭐⭐ | Custom diameter & pressure parsing |
| **slangkoppelingen** | `extract_slangkoppelingen_correct.py` | `slangkoppelingen_specs.json` | ⭐⭐⭐⭐⭐ | Custom "Maten" size parsing |
| **pomp-specials** | `extract_pomp_specials_correct_v2.py` | `pomp_specials_correct_v2.json` | ⭐⭐⭐⭐⭐ | Horizontal row reading |
| **aandrijftechniek** | `extract_aandrijf_specs.py` | `aandrijf_specs.json` | ⭐⭐⭐⭐⭐ | Custom bearing properties |
| **plat-oprolbare-slangen** | `extract_plat_oprolbare_correct.py` | `plat_oprolbare_specs.json` | ⭐⭐⭐⭐ | Basic table extraction |
| **rvs-draadfittingen** | `extract_rvs_improved.py` | `rvs_improved.json` | ⭐⭐⭐⭐ | Property parsing |
| **makita-catalogus** | `extract_makita_tools_only.py` | `makita_tools_only.json` | ⭐⭐⭐⭐⭐ | Complex table extraction |

---

## ⚠️ Catalogs Using Generic/Universal Scripts

| Catalog | Script Used | Output File | Quality | Issues |
|---------|-------------|-------------|---------|--------|
| **rubber-slangen** | `extract_single_catalog.py` | `rubber_slangen_dynamic.json` | ⭐⭐ | Headers as SKUs |
| **pu-afzuigslangen** | `extract_single_catalog.py` | `pu_afzuigslangen_dynamic.json` | ⭐⭐ | Headers as SKUs |
| **slangklemmen** | `extract_single_catalog.py` | `slangklemmen_dynamic.json` | ⭐⭐ | Headers as SKUs |
| **drukbuizen** | `extract_single_catalog.py` | `drukbuizen_dynamic.json` | ⭐⭐ | Headers as SKUs |
| **pe-buizen** | `extract_single_catalog.py` | `pe_buizen_dynamic.json` | ⭐⭐ | Headers as SKUs |
| **verzinkte-buizen** | `extract_single_catalog.py` | `verzinkte_buizen_dynamic.json` | ⭐⭐ | Headers as SKUs |

---

## ❌ Catalogs Not Yet Extracted

| Catalog | PDF File | Complexity | Recommended Approach |
|---------|----------|------------|---------------------|
| **messing-draadfittingen** | `messing-draadfittingen.pdf` | Medium | Custom script (similar to RVS) |
| **zwarte-draad-en-lasfittingen** | `zwarte-draad-en-lasfittingen (1).pdf` | Medium | Custom script |
| **kunststof-afvoerleidingen** | `kunststof-afvoerleidingen.pdf` | Medium | Improved universal |
| **centrifugaalpompen** | `centrifugaalpompen.pdf` | Complex | Custom script (pump specs) |
| **dompelpompen** | `dompelpompen.pdf` | Complex | Custom script (pump specs) |
| **bronpompen** | `bronpompen.pdf` | Complex | Custom script (pump specs) |
| **zuigerpompen** | `zuigerpompen (1).pdf` | Complex | Custom script (pump specs) |
| **pompentoebehoren** | `digitale-versie-pompentoebehoren-compressed.pdf` | Medium | Improved universal |
| **kranzle-catalogus** | `kranzle-catalogus-2021-nl-1.pdf` | Complex | Custom script |
| **airpress-catalogus** | `airpress-catalogus-nl-fr.pdf` | Complex | Custom script |

---

## 📊 Summary

| Status | Count | Percentage |
|--------|-------|------------|
| ✅ **Custom High-Quality** | 7 | 28% |
| ⚠️ **Generic Low-Quality** | 6 | 24% |
| ❌ **Not Extracted** | 12 | 48% |
| **TOTAL** | 25 | 100% |

---

## 🎯 Priority Actions

### **Immediate (Fix Existing):**
1. ✅ Improve `extract_single_catalog.py` to skip headers properly
2. ✅ Re-extract rubber-slangen, pu-afzuigslangen, slangklemmen, drukbuizen, pe-buizen, verzinkte-buizen
3. ✅ Improve image linking to associate one image per SKU group in table

### **Short-term (High-value catalogs):**
4. Create custom scripts for:
   - messing-draadfittingen (similar to RVS fittings)
   - zwarte-draad-en-lasfittingen (similar to RVS fittings)
   - centrifugaalpompen (pump specs)
   - dompelpompen (pump specs)

### **Long-term (Complete coverage):**
5. Create custom scripts for brand catalogs (Kranzle, Airpress)
6. Complete remaining catalogs with improved universal script

---

## 🔧 Extraction Quality Indicators

**⭐⭐⭐⭐⭐ Excellent:**
- Proper SKU detection
- All properties extracted
- Images linked correctly
- Grouping works perfectly

**⭐⭐⭐ Good:**
- SKUs mostly correct
- Main properties extracted
- Some images linked

**⭐⭐ Poor:**
- Headers picked up as SKUs
- Missing properties
- Few/no images linked

**⭐ Failed:**
- No products extracted
- Extraction errors
