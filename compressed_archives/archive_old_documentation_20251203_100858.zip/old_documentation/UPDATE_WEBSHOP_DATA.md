# Update Webshop Data - Quick Guide

## 🔄 Updating Product Statistics & Catalog Data

When your product data changes, follow these steps to update the webshop:

### Step 1: Regenerate Statistics

```bash
cd c:\Users\prova\Documents\Projects\PDF_Analyzer

# Generate overall statistics
python calculate_stats.py

# Generate per-catalog metadata
python generate_catalog_data.py
```

### Step 2: Copy to Webshop

```bash
# Copy global statistics
Copy-Item "output\catalog_statistics.json" "..\DemaWebshop\dema-webshop\public\catalog_statistics.json"

# Copy catalog metadata
Copy-Item "output\catalogs_metadata.json" "..\DemaWebshop\dema-webshop\public\catalogs_metadata.json"
```

### Step 3: Verify

The webshop will automatically reload with the new data! Visit:
- **http://localhost:3000/catalogs** - See updated catalog cards
- Check the stats banner at the top

---

## 📊 What Gets Generated

### 1. `catalog_statistics.json` (Global Stats)
Used by: **StatsBanner** component

```json
{
  "totalProducts": 16399,
  "catalogs": 26,
  "categories": 21,
  "totalImages": 51289,
  "imageCoverage": 93.8,
  "avgImagesPerProduct": 3.1
}
```

### 2. `catalogs_metadata.json` (Per-Catalog Data)
Used by: **Catalogs page**

```json
[
  {
    "id": "slangkoppelingen",
    "name": "Slangkoppelingen",
    "slug": "slangkoppelingen",
    "url": "/catalog/slangkoppelingen-grouped",
    "icon": "〰️",
    "category": "hoses",
    "totalProducts": 2201,
    "productsWithImages": 2200,
    "totalImages": 5472,
    "imageCoverage": 100.0,
    "categories": 3,
    "avgImagesPerProduct": 2.5,
    "description": "2,201 products with 100.0% image coverage"
  }
]
```

---

## 🎯 Current Statistics (Last Generated)

### Global
- **26** Catalogs
- **16,399** Total Products
- **51,289** Product Images
- **93.8%** Image Coverage
- **3.1x** Avg Images per Product

### By Category
- **Hoses**: 8 catalogs, 3,620 products
- **Pumps**: 7 catalogs, 3,598 products
- **Other**: 5 catalogs, 4,485 products
- **Tools**: 5 catalogs, 3,327 products
- **Technical**: 1 catalog, 1,369 products

### Top 5 Catalogs by Products
1. **Slangkoppelingen** - 2,201 products (100.0% coverage)
2. **Digitale Versie Pompentoebehoren** - 1,603 products (82.0% coverage)
3. **Pe Buizen** - 1,399 products (99.9% coverage)
4. **Drukbuizen** - 1,394 products (99.9% coverage)
5. **Catalogus Aandrijftechniek** - 1,369 products (87.7% coverage)

---

## 🔧 One-Command Update Script

Create a file: `update_webshop_data.ps1`

```powershell
#!/usr/bin/env pwsh
# Quick script to regenerate and deploy webshop data

Write-Host "🔄 Regenerating statistics..." -ForegroundColor Cyan
python calculate_stats.py
python generate_catalog_data.py

Write-Host "`n📦 Copying to webshop..." -ForegroundColor Cyan
Copy-Item "output\catalog_statistics.json" "..\DemaWebshop\dema-webshop\public\catalog_statistics.json"
Copy-Item "output\catalogs_metadata.json" "..\DemaWebshop\dema-webshop\public\catalogs_metadata.json"

Write-Host "`n✅ Webshop data updated!" -ForegroundColor Green
Write-Host "Visit http://localhost:3000/catalogs to see changes" -ForegroundColor Yellow
```

Then run:
```bash
.\update_webshop_data.ps1
```

---

## 📁 File Locations

### Source Data (PDF_Analyzer)
```
PDF_Analyzer/
├── calculate_stats.py              # Generate global stats
├── generate_catalog_data.py        # Generate per-catalog data
└── output/
    ├── products_ready_for_webshop_v2_comprehensive.json  # Source
    ├── catalog_statistics.json     # Generated global stats
    └── catalogs_metadata.json      # Generated catalog metadata
```

### Webshop Files (DemaWebshop)
```
dema-webshop/
├── public/
│   ├── catalog_statistics.json     # Copy here
│   └── catalogs_metadata.json      # Copy here
└── src/
    ├── components/
    │   └── StatsBanner.tsx          # Uses catalog_statistics.json
    └── app/
        └── catalogs/
            └── page.tsx             # Uses catalogs_metadata.json
```

---

## ✅ What's Dynamic Now

### Before (Hardcoded)
- ❌ Static catalog list with 8 catalogs
- ❌ Hardcoded product counts
- ❌ Manual stats updates needed

### After (Dynamic from JSON)
- ✅ **26 catalogs** loaded from JSON
- ✅ **Real product counts** per catalog
- ✅ **Real image coverage** percentages
- ✅ **Auto-categorization** (pumps, hoses, tools, etc.)
- ✅ **Auto-generated icons** based on catalog names
- ✅ **Live statistics banner** with total counts
- ✅ **Sortable by products**, images, coverage
- ✅ **Filterable by category**

---

## 🎨 Features Added

1. **Dynamic Stats Banner**
   - Shows real counts from all catalogs
   - Hover animations
   - Auto-updates when data changes

2. **Dynamic Catalog Cards**
   - Real product counts
   - Real image counts
   - Coverage badges (green/blue/yellow)
   - Category icons

3. **Smart Categorization**
   - Pumps: 🚰 💧 🌊
   - Hoses: 〰️ 🔗
   - Tools: 🔨 💨 🚿
   - Technical: ⚙️
   - Pipes: 🔩 📦

4. **Loading States**
   - Animated loading indicator
   - Graceful error handling
   - Fallback to cached data

---

## 🚀 Next Time Products Change

Just run:
```bash
python calculate_stats.py && python generate_catalog_data.py
Copy-Item "output\*.json" "..\DemaWebshop\dema-webshop\public\"
```

The webshop will auto-refresh with new data! 🎯
