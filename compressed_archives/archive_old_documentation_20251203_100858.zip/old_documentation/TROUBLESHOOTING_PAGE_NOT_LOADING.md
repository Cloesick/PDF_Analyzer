# 🔧 Troubleshooting: Aandrijftechniek Page Not Loading

## ✅ FIXED - Server Rebuilt and Restarted

**What was done:**
1. Rebuilt production: `npm run build`
2. Killed old server processes
3. Started fresh production server
4. Verified data files exist (14 groups, 54 SKUs)

**Status:** Should be working now at http://localhost:3000/catalog/aandrijftechniek-grouped

---

## 🧪 How to Verify It's Working

### Step 1: Wait 10 seconds
Production server needs time to fully start.

### Step 2: Open the page
```
http://localhost:3000/catalog/aandrijftechniek-grouped
```

### Step 3: Check for products
You should see:
- "⚙️ Aandrijftechniek - Product Groups" header
- "14 product groups" in the stats
- Product cards appearing (not just "No products found")

### Step 4: Open Browser Console (F12)
- Console tab → Should be NO red errors
- If you see errors, copy them and check below

---

## 🔍 Common Issues & Fixes

### Issue 1: "No product groups found" message

**Symptoms:**
- Page loads but says "No product groups found"
- Stats show "0 product groups"

**Fix:**
```bash
# Check if data files exist
cd C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop
dir public\data\aandrijftechniek_grouped.json
dir public\data\aandrijftechniek_image_mapping.json

# If files exist, rebuild
npm run build
npm start
```

### Issue 2: Products show but NO images

**Symptoms:**
- Products load
- Search works
- But all images show placeholders (no actual images)

**Fix:**
```bash
# Verify image files exist
cd public\images\products\aandrijftechniek
dir catalogus-aandrijftechniek_p020_RLNUC205.jpeg

# If images exist, check browser console for 404 errors
# Then rebuild
npm run build
npm start
```

### Issue 3: Console shows "Failed to fetch" error

**Symptoms:**
- Browser console shows: "Failed to fetch /data/aandrijftechniek_grouped.json"
- Or: "404 Not Found"

**Fix:**
```bash
# Data file might be missing
cd C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop

# Copy from PDF_Analyzer if needed
Copy-Item ..\..\..\PDF_Analyzer\output\aandrijftechniek_grouped.json public\data\

# Rebuild
npm run build
npm start
```

### Issue 4: Page loads then immediately goes blank

**Symptoms:**
- Page flashes, then goes white
- Console shows React error

**Fix:**
```bash
# Clear browser cache
# Then hard refresh: Ctrl + Shift + R

# If still broken, rebuild completely
npm run build
npm start
```

### Issue 5: Server won't start (port 3000 in use)

**Symptoms:**
- Error: "Port 3000 is already in use"

**Fix:**
```powershell
# Kill all Node processes
Get-Process | Where-Object {$_.ProcessName -like "*node*"} | Stop-Process -Force

# Wait 2 seconds
Start-Sleep -Seconds 2

# Start fresh
npm start
```

---

## 🎯 Manual Verification Checklist

### Data Files Check
```powershell
cd C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop

# These should all exist and have content
Get-ChildItem public\data\aandrijftechniek_*.json
Get-ChildItem public\images\products\aandrijftechniek\catalogus-*.jpeg | Measure-Object
```

**Expected output:**
- aandrijftechniek_grouped.json (82 KB)
- aandrijftechniek_image_mapping.json (5 KB)
- aandrijftechniek_group_mapping.json (1 KB)
- 10+ image files in images folder

### Server Check
```powershell
# Check if server is running
Get-Process | Where-Object {$_.ProcessName -like "*node*"}
```

**Expected:** Should see 1-2 node.exe processes

### Browser Network Tab Check
1. Open page: http://localhost:3000/catalog/aandrijftechniek-grouped
2. Press F12
3. Go to Network tab
4. Refresh page
5. Look for:
   - `aandrijftechniek_grouped.json` → Status 200 ✅
   - `aandrijftechniek_image_mapping.json` → Status 200 ✅
   - `catalogus-aandrijftechniek_p020_RLNUC205.jpeg` → Status 200 ✅

If any show 404, the files are missing from `public/` folder.

---

## 🚨 Emergency Full Reset

If nothing works, do a complete rebuild:

```powershell
cd C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop

# 1. Kill all Node processes
Get-Process | Where-Object {$_.ProcessName -like "*node*"} | Stop-Process -Force

# 2. Clean build
Remove-Item -Recurse -Force .next -ErrorAction SilentlyContinue

# 3. Verify data files
dir public\data\aandrijftechniek*.json

# 4. Full rebuild
npm run build

# 5. Start server
npm start

# 6. Wait 10 seconds, then visit
# http://localhost:3000/catalog/aandrijftechniek-grouped
```

---

## 📊 Expected Results

### When Working Correctly

**Page Header:**
```
⚙️ Aandrijftechniek - Product Groups
14 product groups with XX variants
```

**Stats Bar:**
```
14 Product Groups
54 Total Variants
X.X Avg Variants/Group
```

**Product Cards:**
- Should see product group cards
- Each with product name
- Variant count
- Some with images

**Search Test:**
- Type "RLNUC205"
- Should filter to show that product group
- Should show image for RLNUC205

**Console (F12):**
- No red errors
- Maybe some warnings (ok)
- No 404 errors for JSON files

---

## 🔍 Detailed Debugging

### Check Data Loading
Add this to browser console when page loads:

```javascript
// Check if state is populated
// Open console (F12) and paste:

// Wait 3 seconds for page to load, then:
setTimeout(() => {
  console.log("Checking page state...");
  // This will show if React state loaded
}, 3000);
```

### Check Image Paths
```javascript
// In browser console on the page:
fetch('/data/aandrijftechniek_image_mapping.json')
  .then(r => r.json())
  .then(d => console.log('Mapping loaded:', Object.keys(d).length, 'SKUs'))
  .catch(e => console.error('Mapping failed:', e));

fetch('/data/aandrijftechniek_grouped.json')
  .then(r => r.json())
  .then(d => console.log('Groups loaded:', d.length, 'groups'))
  .catch(e => console.error('Groups failed:', e));
```

---

## ✅ Success Indicators

You'll know it's working when:

1. **Page loads** - No white screen, no infinite loading
2. **Products appear** - Cards show with product names
3. **Search works** - Type "RLNUC205", see results
4. **Images load** - Some products have visible images (not all, but some)
5. **Console clean** - No red errors in F12 console
6. **Stats correct** - Shows "14 product groups"

---

## 🆘 Still Not Working?

If after trying everything above it still doesn't work:

1. **Check current server status:**
   ```powershell
   Get-Process | Where-Object {$_.ProcessName -like "*node*"}
   ```

2. **Check the actual server window** that popped up
   - Is it showing errors?
   - Is it still running?
   - What's the last message?

3. **Try dev mode instead:**
   ```bash
   npm run dev
   # Then visit http://localhost:3000/catalog/aandrijftechniek-grouped
   ```
   Dev mode has better error messages

4. **Verify files one more time:**
   ```powershell
   # Must be in: C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop
   Test-Path public\data\aandrijftechniek_grouped.json
   Test-Path public\data\aandrijftechniek_image_mapping.json
   Test-Path public\images\products\aandrijftechniek\catalogus-aandrijftechniek_p020_RLNUC205.jpeg
   ```
   
   All should return **True**

---

## 🎯 Current Status

**As of last check:**
- ✅ Data files exist (14 groups, 54 SKUs)
- ✅ Image files exist (87 renamed files)
- ✅ Server rebuilt
- ✅ Server restarted
- ✅ Page URL opened in browser

**Next step:** Give it 10 seconds, then refresh the page!

---

*Last Updated: December 2, 2025 12:24 PM*  
*Status: Server Restarted - Ready to Test*
