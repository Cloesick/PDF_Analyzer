# Aandrijftechniek Image Naming Guide

## 🎯 Key Insight: Group-Based Image Strategy

**One Image per Product Group/Table, Not per SKU**

Products in the same table (group) in the PDF are **variants** of the same product. They share:
- The same product image
- The same product family
- The same table/section in the PDF

Therefore, we only need **one image per group**, referenced by **all SKU variants** in that group.

---

## 📊 Efficiency Example

### Current Mapping (Page 88)
**One image** → **25 SKUs**
```json
{
  "14210001": "/images/products/aandrijftechniek/page088_img00.jpeg",
  "14210002": "/images/products/aandrijftechniek/page088_img00.jpeg",
  "14210003": "/images/products/aandrijftechniek/page088_img00.jpeg",
  ...
  "14210025": "/images/products/aandrijftechniek/page088_img00.jpeg"
}
```

**Storage Saved**: Instead of storing 25 duplicate images, we store 1 image used by all variants.

### Another Example (Page 52)
**One image** → **4 SKU variants**
```json
{
  "RKKS55RH1711": "/images/products/aandrijftechniek/page052_img00.jpeg",
  "RKKS55RH1712": "/images/products/aandrijftechniek/page052_img00.jpeg",
  "RKKS55RH2511": "/images/products/aandrijftechniek/page052_img00.jpeg",
  "RKKS55RH2512": "/images/products/aandrijftechniek/page052_img00.jpeg"
}
```

All four variants (RKKS55RH series) share the same product image.

---

## 📁 Recommended Naming Convention

### Current (Works but not ideal)
```
pageXXX_imgYY.jpeg
```
- Generic naming
- Doesn't indicate what product
- Hard to manage manually

### Recommended (Future)
```
catalogus-aandrijftechniek_pXXX_GroupName.jpeg
```

**Components:**
- `catalogus-aandrijftechniek` - Catalog identifier
- `pXXX` - Page number (3 digits, e.g., p020, p088)
- `GroupName` - Product family/group name
- `.jpeg` - File extension

---

## 🔄 Naming Examples

| Current Filename | Recommended Filename | Product Group | SKUs in Group |
|------------------|---------------------|---------------|---------------|
| `page020_img00.jpeg` | `catalogus-aandrijftechniek_p020_RLNUC205.jpeg` | RLNUC205 | 2 SKUs |
| `page040_img00.jpeg` | `catalogus-aandrijftechniek_p040_1105.jpeg` | 1105 | 3 SKUs |
| `page052_img00.jpeg` | `catalogus-aandrijftechniek_p052_RKKS55.jpeg` | RKKS55 | 4 SKUs |
| `page088_img00.jpeg` | `catalogus-aandrijftechniek_p088_1421.jpeg` | 1421 Series | 25 SKUs |

---

## ✅ Benefits of Group-Based Naming

### 1. **Storage Efficiency**
- **Before**: 46 SKUs × 1 image each = 46 images (if duplicated)
- **After**: 46 SKUs → 10 unique images = **~80% storage reduction**

### 2. **Easier Maintenance**
- Update one image → affects all related SKUs
- Clear relationship between image and product family
- No need to duplicate images for variants

### 3. **Semantic Naming**
- Filename tells you what product it is
- Easy to find images for specific products
- Self-documenting file structure

### 4. **Scalability**
- Adding new variants to existing groups? No new image needed
- Adding new groups? Add one image per group
- Predictable file count

---

## 🔧 How to Add New Images

### Step 1: Identify the Product Group

Look at the grouped data:
```json
{
  "group_id": "page20_RLNUC205",
  "family": "RLNUC205",
  "page_in_pdf": 20,
  "variants": [
    {"sku": "RLNUC205"},
    {"sku": "RLNUC205G2L3"}
  ]
}
```

### Step 2: Name the Image

Use format: `catalogus-aandrijftechniek_pXXX_GroupName.jpeg`

For the example above:
```
catalogus-aandrijftechniek_p020_RLNUC205.jpeg
```

### Step 3: Place the Image

Save to:
```
DemaWebshop/dema-webshop/public/images/products/aandrijftechniek/
```

### Step 4: Regenerate Mapping

Run the mapping script:
```bash
cd c:\Users\prova\Documents\Projects\PDF_Analyzer
python fix_aandrijftechniek_images_v2.py
```

This will:
- Detect the new image
- Map it to all SKUs in that group
- Update the mapping files

### Step 5: Verify

Check the webshop:
```
http://localhost:3000/catalog/aandrijftechniek-grouped
```

All SKUs in that group should now show the image.

---

## 📊 Current Statistics

### Overall Coverage
- **Total Product Groups**: 14
- **Total SKU Variants**: 54
- **Available Images**: 87 files
- **Mapped Groups**: 10
- **Mapped SKUs**: 46

### Efficiency Metrics
- **Unique Images Used**: 10
- **SKUs Covered**: 46
- **Average SKUs per Image**: ~4-5
- **Max SKUs per Image**: 25 (page 88)
- **Storage Efficiency**: ~80% reduction vs. per-SKU images

### Coverage by Page
- Page 20: 1 image → 2 SKUs (RLNUC205 series)
- Page 40: 1 image → 3 SKUs (1105 series)
- Page 44: 1 image → 2 SKUs (RKKBS08 series)
- Page 51: 2 images → 4 SKUs (2 groups)
- Page 52: 1 image → 4 SKUs (RKKS55 series)
- Page 56: 2 images → 4 SKUs (CARDW series)
- Page 70: 1 image → 2 SKUs (CARBU12 series)
- Page 88: 1 image → 25 SKUs (1421 series) ⭐

---

## 🎨 Comparison: Old vs New Approach

### Old Approach (Per-SKU Images)
```
/images/products/
  ├── RLNUC205.jpeg
  ├── RLNUC205G2L3.jpeg      ← Duplicate!
  ├── 14210001.jpeg
  ├── 14210002.jpeg          ← Duplicate!
  ├── 14210003.jpeg          ← Duplicate!
  └── ... (25 duplicate images for 1421 series)
```
**Problems:**
- ❌ Lots of duplicate files
- ❌ Hard to maintain
- ❌ Wasted storage
- ❌ Confusing naming

### New Approach (Group-Based Images)
```
/images/products/aandrijftechniek/
  ├── catalogus-aandrijftechniek_p020_RLNUC205.jpeg  → 2 SKUs
  ├── catalogus-aandrijftechniek_p088_1421.jpeg      → 25 SKUs
  └── ... (10 images total)
```

**Mapping File** does the work:
```json
{
  "RLNUC205": "/images/.../p020_RLNUC205.jpeg",
  "RLNUC205G2L3": "/images/.../p020_RLNUC205.jpeg",  ← Same image
  "14210001": "/images/.../p088_1421.jpeg",
  "14210002": "/images/.../p088_1421.jpeg",          ← Same image
  "14210025": "/images/.../p088_1421.jpeg"           ← Same image
}
```

**Benefits:**
- ✅ No duplicate files
- ✅ Easy to update (change one image → all SKUs updated)
- ✅ Efficient storage
- ✅ Clear, semantic naming

---

## 🔄 Migration Path (Optional)

If you want to rename existing images to the recommended format:

### Script to Generate Rename Commands

```powershell
# Read the group mapping
$mapping = Get-Content "public\data\aandrijftechniek_group_mapping.json" | ConvertFrom-Json

# Generate rename commands
foreach ($group in $mapping.PSObject.Properties) {
    $groupId = $group.Name
    $imagePath = $group.Value
    
    # Extract page and group name from group_id (e.g., "page20_RLNUC205")
    if ($groupId -match 'page(\d+)_(.+)') {
        $page = $matches[1]
        $groupName = $matches[2]
        $newName = "catalogus-aandrijftechniek_p$($page.PadLeft(3,'0'))_$groupName.jpeg"
        
        Write-Host "Rename: $imagePath -> $newName"
        # Uncomment to execute:
        # Rename-Item $imagePath $newName
    }
}
```

---

## 📝 Quick Reference

### Add New Group Image

1. **Identify**: Find group name from `aandrijftechniek_grouped.json`
2. **Name**: `catalogus-aandrijftechniek_p{page}_{group}.jpeg`
3. **Place**: In `public/images/products/aandrijftechniek/`
4. **Map**: Run `python fix_aandrijftechniek_images_v2.py`
5. **Verify**: Check catalog page

### Update Existing Image

1. **Replace**: Overwrite image file with same name
2. **Refresh**: Clear browser cache
3. **Done**: All SKUs in that group now use updated image

### Check Mapping

```bash
# See which image a SKU uses
cat public/data/aandrijftechniek_image_mapping.json | grep "RLNUC205"

# See all SKUs for a specific image
cat public/data/aandrijftechniek_image_mapping.json | grep "page088_img00.jpeg"
```

---

## 💡 Pro Tips

1. **Use descriptive group names** in filenames (e.g., `RLNUC205` instead of just `group1`)
2. **Keep page numbers** as they help locate products in the PDF
3. **One image per group** - never duplicate images for variants
4. **Update mapping** after adding/removing images
5. **Check webshop** to verify images render correctly

---

## 🎯 Summary

**The Golden Rule**: 
> One product group (table) = One image = Multiple SKUs

This approach:
- ✅ Saves ~80% storage
- ✅ Makes maintenance easier
- ✅ Matches the PDF structure
- ✅ Scales better with more products
- ✅ Uses semantic, self-documenting names

**Recommended naming**:
```
catalogus-aandrijftechniek_pXXX_GroupName.jpeg
```

Instead of the generic:
```
pageXXX_imgYY.jpeg
```

This makes your image library organized, efficient, and easy to manage! 🚀
