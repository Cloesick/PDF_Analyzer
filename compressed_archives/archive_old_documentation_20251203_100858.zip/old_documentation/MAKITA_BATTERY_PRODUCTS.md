# ✅ Makita Battery Products - Complete Table

## 📦 What Was Created

Battery products table with **exact format** you requested:
- ✅ SKU
- ✅ Product Name
- ✅ Specifications/Content
- ✅ Price (Excl. VAT)
- ✅ Price (Incl. VAT)

**Note:** "Li" always stands for Lithium (Li-ion = Lithium-ion)

## 📊 Complete Table

### Batteries

| SKU | Product Name | Specifications / Content | Price (Excl. VAT) | Price (Incl. VAT) |
|-----|--------------|--------------------------|-------------------|-------------------|
| 191L29-0 | Li-ion battery BL4020 | 40Vmax • 2.0 Ah • 0.69 kg • 22 min charge | € 125.00 | € 151.25 |
| 191B36-3 | Li-ion battery BL4025 | 40Vmax • 2.5 Ah • 0.71 kg • 28 min charge | € 135.00 | € 163.35 |
| 191B26-6 | Li-ion battery BL4040 | 40Vmax • 4.0 Ah • 1 kg • 45 min charge | € 195.00 | € 235.95 |
| 191L47-8 | Li-ion battery BL4050F | 40Vmax • 5.0 Ah • 1.3 kg • 50 min charge | € 219.00 | € 264.99 |
| 191X65-8 | Li-ion battery BL4080F | 40Vmax • 8.0 Ah • 2.0 kg • 80 min charge | € 315.00 | € 381.15 |

### Powerpacks (Kits)

| SKU | Product Name | Specifications / Content | Price (Excl. VAT) | Price (Incl. VAT) |
|-----|--------------|--------------------------|-------------------|-------------------|
| 191V07-0 | XGT Powerpack 2.0 Ah | Includes MAKPAC case | € 355.00 | € 429.55 |
| 191J81-6 | XGT Powerpack 2.5 Ah | Includes MAKPAC case | € 399.00 | € 482.79 |
| 191J65-4 | XGT Powerpack 4.0 Ah | Single battery + charger (No MAKPAC shown) | € 299.00 | € 361.79 |
| 191J97-1 | XGT Powerpack 4.0 Ah | Includes MAKPAC case | € 499.00 | € 603.79 |
| 191V35-5 | XGT Powerpack 5.0 Ah | Includes MAKPAC case | € 565.00 | € 683.65 |
| 191U00-8 | XGT Powerpack 4.0 Ah | Duo charger + MAKPAC | € 569.00 | € 688.49 |
| 191U28-6 | XGT Powerpack 4.0 Ah | 4 Batteries + Duo charger + MAKPAC | € 929.00 | € 1124.09 |
| 191U13-9 | XGT Powerpack 5.0 Ah | Duo charger + MAKPAC | € 639.00 | € 773.19 |
| 191U42-2 | XGT Powerpack 5.0 Ah | 4 Batteries + Duo charger + MAKPAC | € 1069.00 | € 1293.49 |
| 191Y97-1 | XGT Powerpack 8.0 Ah | 2x BL4080F + DC40RB in MAKPAC | € 799.00 | € 966.79 |

### Chargers & Adapters

| SKU | Product Name | Specifications / Content | Price (Excl. VAT) | Price (Incl. VAT) |
|-----|--------------|--------------------------|-------------------|-------------------|
| 191E07-8 | Charger DC40RA | Fast charger for XGT 40Vmax batteries | € 125.00 | € 151.25 |
| 191N09-8 | Duo fast charger DC40RB | Simultaneous charging of two XGT 40Vmax batteries | € 205.00 | € 248.05 |
| 191C10-7 | ADP10 Charging Adapter | Adapter to charge LXT 14.4V/18V batteries on XGT charger | € 59.50 | € 72.00 |
| DEAADP001G | ADP001 Charging Adapter | USB-adapter for XGT 40Vmax batteries | € 50.80 | € 61.50 |

## 📊 Summary Statistics

- **Batteries:** 5 products
- **Powerpacks:** 10 kits
- **Chargers:** 2 products
- **Adapters:** 2 products
- **Total:** 19 battery-related products

## 💡 Product Categories

### 1. **Batteries** (Li-ion)
All are **40Vmax XGT** lithium-ion batteries:
- **BL4020**: 2.0 Ah (€125 ex VAT)
- **BL4025**: 2.5 Ah (€135 ex VAT)
- **BL4040**: 4.0 Ah (€195 ex VAT)
- **BL4050F**: 5.0 Ah (€219 ex VAT)
- **BL4080F**: 8.0 Ah (€315 ex VAT)

### 2. **Powerpacks (Kits)**
Complete kits with batteries + chargers + MAKPAC case:
- **2.0 Ah kit**: €355 ex VAT
- **2.5 Ah kit**: €399 ex VAT
- **4.0 Ah kits**: €299-€929 ex VAT (various configurations)
- **5.0 Ah kits**: €565-€1069 ex VAT (various configurations)
- **8.0 Ah kit**: €799 ex VAT

### 3. **Chargers**
- **DC40RA**: Fast charger (€125 ex VAT)
- **DC40RB**: Duo fast charger for 2 batteries simultaneously (€205 ex VAT)

### 4. **Adapters**
- **ADP10**: Charge LXT 14.4V/18V batteries on XGT charger (€59.50 ex VAT)
- **ADP001**: USB adapter for XGT 40Vmax batteries (€50.80 ex VAT)

## 📁 Files Created

1. **`output/makita_batteries_formatted.json`** - Structured JSON data
2. **`output/makita_batteries_table.md`** - Markdown table
3. **`MAKITA_BATTERY_PRODUCTS.md`** - This complete document

## 🎯 JSON Structure for Frontend

```json
{
  "sku": "191L29-0",
  "category": "batteries",
  "product_name": "Li-ion battery BL4020",
  "specifications": "40Vmax • 2.0 Ah • 0.69 kg • 22 min charge",
  "prices": {
    "excl_vat": 125.0,
    "incl_vat": 151.25,
    "vat_rate": 0.21
  },
  "display": {
    "price_excl": "€ 125.00",
    "price_incl": "€ 151.25",
    "full_spec": "Li-ion battery BL4020 - 40Vmax • 2.0 Ah • 0.69 kg • 22 min charge"
  }
}
```

## 🚀 Frontend Usage

### React/TypeScript
```tsx
import batteryProducts from './makita_batteries_formatted.json';

function BatteryTable() {
  const batteries = batteryProducts.products.filter(p => p.category === 'batteries');
  
  return (
    <table>
      <thead>
        <tr>
          <th>SKU</th>
          <th>Product Name</th>
          <th>Specifications</th>
          <th>Price (Ex VAT)</th>
          <th>Price (Incl VAT)</th>
        </tr>
      </thead>
      <tbody>
        {batteries.map(battery => (
          <tr key={battery.sku}>
            <td>{battery.sku}</td>
            <td>{battery.product_name}</td>
            <td>{battery.specifications}</td>
            <td>{battery.display.price_excl}</td>
            <td>{battery.display.price_incl}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
```

### Filter by Category
```javascript
const batteries = products.filter(p => p.category === 'batteries');
const powerpacks = products.filter(p => p.category === 'powerpacks');
const chargers = products.filter(p => p.category === 'chargers');
const adapters = products.filter(p => p.category === 'adapters');
```

## ✅ All Your Requirements Met

✅ **SKU column** - All product codes included  
✅ **Product Name column** - Full names with "Li-ion battery" prefix  
✅ **Specifications/Content** - Voltage, capacity, weight, charge time  
✅ **Price (Excl. VAT)** - Prices without 21% tax  
✅ **Price (Incl. VAT)** - Prices with 21% tax included  
✅ **"Li" = Lithium** - Clearly noted throughout  
✅ **Separated categories** - Batteries, Powerpacks, Chargers & Adapters  
✅ **Both JSON and Markdown** - Ready for database and documentation  

All battery products are now structured and ready for your webshop! 🎉
