# 🎯 MAKITA CATALOG IMAGE IMPROVEMENT PLAN

**Date:** November 29, 2025  
**Goal:** Achieve better results and consistency for makita-catalogus-2022-nl images

---

## 📊 CURRENT STATUS (Diagnostic Results)

### **Critical Finding:**
- **1,734 Makita products** exist in the database
- **0% have images** (all 1,734 products missing images!)
- **2,909 images extracted** but NOT linked to products

### **The Problem:**
The images exist but aren't matched to products because:
1. Image filenames use codes like `0-1300`, `0-13600` 
2. Product SKUs are like `DEBWST06`, `TD001GD201`, `SK105DZ`
3. **No matching algorithm** connects them

###**Top Pages by Product Count:**
- Page 2: 120 products ⭐
- Page 34: 79 products
- Page 54: 64 products
- Page 55: 46 products
- Page 5: 42 products

---

## 🎯 TODAY'S OBJECTIVES

### **Phase 1: Diagnostic & Analysis** ✅
- [x] Analyze current image extraction status
- [x] Identify the linking problem
- [x] Understand Makita SKU patterns
- [x] Check what images exist

### **Phase 2: Improved Extraction**
- [ ] Extract images at high DPI (300)
- [ ] Use OCR to find SKUs in images
- [ ] Match with nearby page text
- [ ] Generate properly named files
- [ ] Clean and crop images

### **Phase 3: Quality Control**
- [ ] Filter non-product images
- [ ] Remove B&W silhouettes
- [ ] Ensure color images
- [ ] Validate SKU matches
- [ ] Check image consistency

### **Phase 4: Integration**
- [ ] Link extracted images to products
- [ ] Update products JSON
- [ ] Sync to webshop
- [ ] Validate final results

---

## 🛠️ TECHNICAL APPROACH

### **1. SKU Detection Strategy**

Makita uses multiple SKU formats:
```
Pattern 1: DHS680RTJ, GA7082, SK105DZ      (2-4 letters + 3-4 digits + optional letters)
Pattern 2: 28606, 13568, 81315             (5-6 digits)
Pattern 3: 199009-8, 197658-5              (6 digits - 1 digit)
Pattern 4: TD001GD201, PT001GD101          (Complex alphanumeric)
Pattern 5: DUC307ZX2, DCL280FZW            (Varies)
```

### **2. Image Extraction Strategy**

```python
For each page:
  1. Extract all images at 300 DPI
  2. Filter by size (> 15,000 px²)
  3. Check color variance (> 10 = color image)
  4. Run OCR on image to find embedded SKUs
  5. Find nearby text on page
  6. Match with table data
  7. Clean: remove white background, crop to product
  8. Save as high-quality WebP
  9. Generate filename: {SKU}_p{page}_img{index}.webp
```

### **3. Quality Filters**

**Keep images that:**
- Color variance > 10 (not just B&W outlines)
- Size > 100x100 px
- Aspect ratio < 3:1
- Contains or near a valid SKU

**Reject images that:**
- Pure B&W shapes (silhouettes)
- Decorative elements
- Diagrams/charts
- Too small or too thin

---

## 📁 OUTPUT STRUCTURE

```
product-images-makita-improved/
  ├── DEBWST06_p002_img01.webp
  ├── TD001GD201_p002_img02.webp
  ├── SK105DZ_p002_img03.webp
  └── ... (1,734 images expected)

output/
  └── makita_extracted_products.json
      [
        {
          "sku": "DEBWST06",
          "pdf_source": "makita-catalogus-2022-nl.pdf",
          "page_num": 2,
          "image_filename": "DEBWST06_p002_img01.webp",
          "skus_in_image": ["DEBWST06"],
          "color_variance": 45.2,
          "from_ocr": true,
          "from_nearby": true
        },
        ...
      ]
```

---

## 🚀 EXECUTION STEPS

### **Step 1: Run Improved Extractor**
```bash
python extract_makita_improved.py
```

**Expected output:**
- ~1,500-1,800 high-quality product images
- JSON with SKU mappings
- Color images, properly cropped
- Consistent naming convention

### **Step 2: Review & Validate**
```bash
python analyze_makita_images.py
```

**Check for:**
- Image coverage: > 80% products with images
- Color images: > 70% are color (not B&W)
- Size: Average > 200x200 px
- SKU matches: All images have valid SKUs

### **Step 3: Manual QA (Sample)**
- Check 20 random images
- Verify they match products
- Check image quality
- Look for issues

### **Step 4: Fix Issues**
If needed:
- Adjust color variance threshold
- Fine-tune SKU patterns
- Add manual mappings for problem cases
- Re-extract specific pages

### **Step 5: Integration**
```bash
# Link images to products
python link_makita_images.py

# Sync to webshop
python sync_makita_to_webshop.py
```

---

## 📈 SUCCESS METRICS

| Metric | Current | Target | Status |
|--------|---------|--------|--------|
| Products with images | 0% (0/1734) | >80% (>1387) | 🔴 |
| Color images | 0% | >70% | 🔴 |
| Image quality (avg) | N/A | >300x300px | 🔴 |
| SKU match accuracy | 0% | >95% | 🔴 |

---

## 🎯 EXPECTED RESULTS

**After completion:**
- ✅ ~1,500 Makita products with images (>80% coverage)
- ✅ High-quality color images
- ✅ Properly named and organized
- ✅ Accurate SKU matching
- ✅ Ready for webshop integration
- ✅ Consistent quality across catalog

---

## ⚠️ KNOWN CHALLENGES

### **Challenge 1: Multi-SKU Images**
- One image may show multiple products
- **Solution:** Create shared image entries, link to all SKUs

### **Challenge 2: OCR Accuracy**
- Some SKUs may not be readable
- **Solution:** Use multiple sources (OCR + nearby text + tables)

### **Challenge 3: B&W Images**
- Some products only have B&W outline images
- **Solution:** Mark as low-quality, attempt to find alternatives

### **Challenge 4: Complex Layouts**
- Makita catalog has dense layouts
- **Solution:** Use spatial analysis to match images to nearby text

---

## 📝 SCRIPTS CREATED

1. **`analyze_makita_images.py`** ✅
   - Diagnostic analysis
   - Quality metrics
   - Coverage statistics

2. **`extract_makita_improved.py`** ✅
   - High-DPI image extraction
   - OCR-powered SKU detection
   - Smart image cleaning
   - Proper file naming

3. **`check_makita_skus.py`** ✅
   - Quick SKU pattern viewer

4. **Next to create:**
   - `link_makita_images.py` - Connect images to products
   - `sync_makita_to_webshop.py` - Push to webshop
   - `fix_makita_issues.py` - Handle edge cases

---

## 🔄 ITERATIVE APPROACH

```
1. Extract → 2. Analyze → 3. Identify Issues → 4. Fix → 5. Re-extract
   ↑                                                            ↓
   └────────────────────────────────────────────────────────────┘
```

We'll iterate until we hit >80% coverage with good quality!

---

## 💡 LEARNINGS FOR OTHER CATALOGS

Once Makita is working well:
1. Document the winning strategy
2. Apply same approach to other problematic catalogs
3. Create a universal "smart extractor"
4. Build a catalog-specific configuration system

---

## 🎉 SUCCESS CRITERIA

**We're done when:**
- [x] Diagnostic shows the problem
- [ ] Extractor runs without errors
- [ ] >80% products have images
- [ ] >70% are color images
- [ ] Images are properly named
- [ ] SKUs match correctly
- [ ] Images are synced to webshop
- [ ] Manual QA passes (spot check 20 products)

---

**Status:** Phase 1 Complete ✅ | Ready for Phase 2 🚀
**Next Action:** Run `python extract_makita_improved.py`
