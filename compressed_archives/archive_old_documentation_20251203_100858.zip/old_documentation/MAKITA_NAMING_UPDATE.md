# Makita Extraction - Naming Convention Update ✅

## Summary

Updated the Makita extraction script to follow the **standard naming convention** used by all other catalog extraction scripts, ensuring seamless integration with the webshop linking system.

## Changes Made

### 1. Output Folder
**Before**: `product-images-makita-improved/`  
**After**: `product-images-by-pdf/makita-catalogus-2022-nl/`

This matches the standard folder structure where all catalog images are organized by PDF name.

### 2. Filename Format
**Before**: `{SKU}_p{page}_img{index}.webp`  
Example: `BL1850B_p113_img05.webp`

**After**: `{SKU}_{catalog}_p{page}_img{index}.webp`  
Example: `BL1850B_makita-catalogus-2022-nl_p113_img05.webp`

### 3. JSON Output Enhanced
Added catalog name and proper image URL to each entry:
```json
{
  "sku": "BL1850B",
  "pdf_source": "makita-catalogus-2022-nl.pdf",
  "catalog": "makita-catalogus-2022-nl",
  "image_filename": "BL1850B_makita-catalogus-2022-nl_p113_img05.webp",
  "image_url": "/product-images/makita-catalogus-2022-nl/BL1850B_makita-catalogus-2022-nl_p113_img05.webp"
}
```

## Benefits

✅ **Consistent Naming** - Matches naming used by `ultimate_pdf_extractor.py` and other scripts  
✅ **Easy Linking** - Product linking scripts can automatically find images by SKU  
✅ **Clear Organization** - Images organized by catalog in standard folder structure  
✅ **URL Compatibility** - Image URLs follow webshop routing convention  
✅ **No Conflicts** - Catalog name in filename prevents SKU collisions between catalogs

## Verification

Sample filenames generated:
```
00393_makita-catalogus-2022-nl_p047_img04.webp
BL1850B_makita-catalogus-2022-nl_p113_img05.webp
199009_makita-catalogus-2022-nl_p106_img14.webp
346809_makita-catalogus-2022-nl_p108_img01.webp
```

All 160 extracted images now follow this convention and are saved in:
`product-images-by-pdf/makita-catalogus-2022-nl/`

## Updated Scripts

1. **extract_makita_improved.py**
   - Changed `OUTPUT_IMAGES` path
   - Added `CATALOG_NAME` constant
   - Updated filename generation
   - Added `image_url` to JSON output

2. **link_makita_images.py**
   - Updated `IMAGES_FOLDER` path
   - Updated image URL generation

## Integration

The naming convention now matches the pattern expected by:
- `link_images_to_products.py`
- `build_shop_feed.py`
- `sync_images_and_rebuild.py`
- All other webshop integration scripts

## Next Steps

To link the improved images to products:
```bash
python link_makita_images.py
```

This will:
1. Load extracted images from the correct folder
2. Match SKUs to products
3. Update product entries with image URLs
4. Generate `products_with_makita_images.json`

---

**Status**: ✅ Complete  
**Date**: November 2025  
**Files Updated**: `extract_makita_improved.py`, `link_makita_images.py`
