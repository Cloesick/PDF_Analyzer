# Universal Image Extraction - Documentation

## 🎯 Overview

The **`extract_all_images_universal.py`** script is a comprehensive solution that replaces all previous image extraction scripts. It processes ALL PDFs in the `input_pdfs` folder with intelligent filtering to extract only real product photos.

## ✨ Key Features

### 1. **Advanced Gradient Detection**
- Detects and filters out gradient backgrounds (like those battery/charger images)
- Analyzes horizontal and vertical color transitions
- Calculates gradient smoothness score
- **Rejects images with gradient_score > 0.60**

### 2. **Multi-Layer Quality Filters**
Filters out non-product images using 9 quality checks:
- ✅ Size (min 130x130px, 15,000px² area)
- ✅ Aspect ratio (max 4:1)
- ✅ Gradient detection (blocks smooth color transitions)
- ✅ Color variance (min 8 - rejects flat colors)
- ✅ Edge density (min 0.012 - requires detail)
- ✅ Background check (requires white background)
- ✅ Content ratio (not mostly white/empty)
- ✅ Color richness (not just a few colors)
- ✅ Uniformity check (not single dominant color)

### 3. **Catalog-Specific SKU Patterns**

#### Makita Catalogs (Tool Exclusions)
The script specifically excludes Makita batteries, chargers, and accessories:
- **Batteries**: BL4020, BL4025, BL4040, BL4050F, BL4080F, BL1830B, BL1840B, BL1850, BL1860B, BL1188
- **Chargers**: DC40RA, DC40RB, DC18R, DC18RD, DC18RE, DC18RC, DC11
- **Adapters**: ADPOO1, ADP10, DEAADP001G
- **Accessories**: PDC01, BPS01, BEAPDC, PV001GZ, DK0126G401, RC30B, PL11, ER55, AR04CD
- **Part Numbers**: 81-6, 933-6, 198720-9, 197629-2, 56169, 54329, etc.
- **Ratings**: IPX4

Only **actual power tools** are extracted (e.g., GA005G, HR005G, HS010G, TW004GZ, JR001GD, PT001GD101, etc.)

#### Generic Catalogs
Uses flexible patterns for other catalogs:
- Numeric SKUs: 1234, 12345-67
- Alpha-numeric: ABC-1234, XY 5678
- Mixed formats: 1234-AB, 567/X

### 4. **Consistent Naming Convention**
All images follow: `{SKU}_{catalog-name}_p{page}_img{index}.webp`

Example: `GA005GM201_makita-catalogus-2022-nl_p045_img02.webp`

### 5. **Automatic Processing**
- Scans all PDFs in `input_pdfs/` folder
- No manual configuration needed
- Generates per-catalog metadata JSON files

## 📊 Test Results (All 26 Catalogs)

```
Total PDFs processed:     26 catalogs
Total images scanned:     10,982 images
✅ Product images:        811 images (7.4% quality rate)
⊘ Filtered out:           10,171 images (92.6%)
```

### Filter Breakdown (Top Reasons)
1. **gradient_detected**: 592 images - Smooth gradients rejected ✅
2. **low_color_variance**: 421 images - Flat/simple graphics
3. **too_small**: 1,422 images - Tiny icons
4. **dimensions_too_small**: 388 images - Narrow banners
5. **low_edge_density**: 135 images - No texture detail

### Sample Results by Catalog
- **makita-catalogus-2022-nl**: Real tools extracted, batteries/chargers blocked ✅
- **slangkoppelingen**: 31 product images
- **airpress-catalogus-eng**: 128 product images
- **kranzle-catalogus-2021-nl**: 94 product images

## 🚀 Usage

### Run for All Catalogs
```bash
python extract_all_images_universal.py
```

### Output Structure
```
product-images-by-pdf/
├── makita-catalogus-2022-nl/
│   ├── GA005GM201_makita-catalogus-2022-nl_p045_img02.webp
│   ├── HS010G_makita-catalogus-2022-nl_p067_img01.webp
│   └── ...
├── airpress-catalogus-eng/
├── kranzle-catalogus-2021-nl/
└── ...

output/
├── makita-catalogus-2022-nl_images.json
├── airpress-catalogus-eng_images.json
└── ...
```

## 🔧 Configuration

### Adjust Filter Thresholds
Edit the constants in the script:

```python
# More strict (fewer images, higher quality)
MIN_COLOR_VARIANCE = 15
MAX_GRADIENT_SCORE = 0.45
MIN_EDGE_DENSITY = 0.020

# More relaxed (more images, may include some gradients)
MIN_COLOR_VARIANCE = 5
MAX_GRADIENT_SCORE = 0.75
MIN_EDGE_DENSITY = 0.008
```

### Add Custom Catalog Patterns
```python
CATALOG_PATTERNS = {
    'your-catalog': {
        'sku_patterns': [r'\bYOUR-\d{4}\b'],
        'exclude_patterns': [r'^EXCL\d+'],
        'validator': None
    }
}
```

## ✅ Solved Problems

### Before (Multiple Scripts)
- ❌ 18 different extraction scripts
- ❌ Inconsistent naming
- ❌ Many gradient/battery images included
- ❌ Manual per-catalog configuration

### After (Universal Script)
- ✅ Single comprehensive script
- ✅ Consistent naming across all catalogs
- ✅ Advanced gradient filtering
- ✅ Makita battery/charger exclusion
- ✅ Automatic catalog detection
- ✅ 811 high-quality product images extracted

## 📝 Metadata JSON Format

Each catalog gets a metadata file:

```json
{
  "catalog": "makita-catalogus-2022-nl",
  "total_images": 45,
  "images": [
    {
      "filename": "GA005GM201_makita-catalogus-2022-nl_p045_img02.webp",
      "sku": "GA005GM201",
      "page": 45,
      "metrics": {
        "color_variance": 23.5,
        "edge_density": 0.045,
        "gradient_score": 0.32,
        "aspect_ratio": 1.2
      }
    }
  ]
}
```

## 🎯 Next Steps

The universal script is ready for production use. All product images are now extracted with:
- ✅ No gradient backgrounds
- ✅ No battery/charger images (Makita)
- ✅ Consistent naming
- ✅ High quality filtering

You can now use these images directly in your webshop!
