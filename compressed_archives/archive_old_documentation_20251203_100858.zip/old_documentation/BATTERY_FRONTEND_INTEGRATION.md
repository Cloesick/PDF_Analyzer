# 🔋 Battery Products Frontend Integration with Icons

## ✅ What's Ready

All battery products now have:
- ✅ **Structured properties** with icons
- ✅ **Consistent data format** across all products
- ✅ **Both prices** (excl/incl VAT)
- ✅ **Ready-to-use React components**

## 📊 Data Structure

Each battery product has properties with icons:

```json
{
  "sku": "191L29-0",
  "category": "batteries",
  "product_name": "Li-ion battery BL4020",
  "properties": {
    "voltage": {
      "value": "40Vmax",
      "icon": "⚡",
      "label": "Voltage"
    },
    "capacity": {
      "value": "2.0 Ah",
      "icon": "🔋",
      "label": "Capacity"
    },
    "weight": {
      "value": "0.69 kg",
      "icon": "⚖️",
      "label": "Weight"
    },
    "charge_time": {
      "value": "22 min",
      "icon": "⏱️",
      "label": "Charge Time"
    }
  },
  "prices": {
    "excl_vat": 125.0,
    "incl_vat": 151.25
  },
  "display": {
    "price_excl": "💶 € 125.00 (ex BTW)",
    "price_incl": "💶 € 151.25 (incl BTW)",
    "properties": {
      "voltage": "⚡ 40Vmax",
      "capacity": "🔋 2.0 Ah",
      "weight": "⚖️ 0.69 kg",
      "charge_time": "⏱️ 22 min"
    }
  }
}
```

## 🎨 Property Icons

| Property | Icon | Label | Example Value |
|----------|------|-------|---------------|
| **Voltage** | ⚡ | Voltage | 40Vmax |
| **Capacity** | 🔋 | Capacity | 2.0 Ah |
| **Weight** | ⚖️ | Weight | 0.69 kg |
| **Charge Time** | ⏱️ | Charge Time | 22 min |
| **Case** | 💼 | Case | MAKPAC case included |
| **Charger Type** | 🔌 | Charger | Fast charger / Duo charger |
| **Battery Count** | 🔋 | Batteries | 4 batteries |
| **Feature** | 🔄 | Feature | Simultaneous charging |
| **Adapter Type** | 🔌 | Type | USB adapter |
| **Compatibility** | 🔄 | Compatibility | LXT 14.4V/18V compatible |
| **Price** | 💶 | Price | € 125.00 (ex BTW) |

## 🚀 React Component Usage

### Option 1: Card View (Recommended)

```tsx
import React from 'react';
import batteryData from './makita_batteries_formatted.json';
import { BatteryCategoryTabs } from './BatteryProducts';

function BatteryPage() {
  return (
    <div className="container">
      <h1>Makita Battery Products</h1>
      <p>Li = Lithium-ion batteries</p>
      
      <BatteryCategoryTabs data={batteryData} />
    </div>
  );
}
```

This displays:
- Tabbed interface (All / Batteries / Powerpacks / Chargers / Adapters)
- Card layout with icons
- Properties displayed with icons
- Both prices visible

### Option 2: Custom Display

```tsx
import batteryData from './makita_batteries_formatted.json';

function BatteryCard({ product }) {
  return (
    <div className="battery-card">
      <h3>{product.product_name}</h3>
      <div className="sku">{product.sku}</div>
      
      {/* Display properties with icons */}
      <div className="properties">
        {Object.entries(product.properties).map(([key, prop]) => (
          <div key={key} className="property">
            <span className="icon">{prop.icon}</span>
            <div>
              <small>{prop.label}</small>
              <strong>{prop.value}</strong>
            </div>
          </div>
        ))}
      </div>
      
      {/* Pricing */}
      <div className="pricing">
        <div>{product.display.price_excl}</div>
        <div>{product.display.price_incl}</div>
      </div>
      
      <button>Add to Cart</button>
    </div>
  );
}

function BatteryList() {
  // Filter batteries
  const batteries = batteryData.products.filter(p => p.category === 'batteries');
  
  return (
    <div className="grid">
      {batteries.map(product => (
        <BatteryCard key={product.sku} product={product} />
      ))}
    </div>
  );
}
```

### Option 3: Table View

```tsx
function BatteryTable({ category }) {
  const products = batteryData.products.filter(
    p => !category || p.category === category
  );
  
  return (
    <table>
      <thead>
        <tr>
          <th>SKU</th>
          <th>Name</th>
          <th>Properties</th>
          <th>Price (Ex BTW)</th>
          <th>Price (Incl BTW)</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {products.map(product => (
          <tr key={product.sku}>
            <td>{product.sku}</td>
            <td>{product.product_name}</td>
            <td>
              {/* Show properties inline */}
              {Object.values(product.display.properties).map((prop, i) => (
                <span key={i} className="tag">{prop}</span>
              ))}
            </td>
            <td>€ {product.prices.excl_vat.toFixed(2)}</td>
            <td>€ {product.prices.incl_vat.toFixed(2)}</td>
            <td>
              <button>Add</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
```

## 🎯 Filtering & Searching

### By Category

```tsx
const batteries = batteryData.products.filter(p => p.category === 'batteries');
const powerpacks = batteryData.products.filter(p => p.category === 'powerpacks');
const chargers = batteryData.products.filter(p => p.category === 'chargers');
const adapters = batteryData.products.filter(p => p.category === 'adapters');
```

### By Voltage

```tsx
const voltage40V = batteryData.products.filter(
  p => p.properties.voltage?.value.includes('40V')
);
```

### By Capacity

```tsx
const highCapacity = batteryData.products.filter(p => {
  const capacity = p.properties.capacity?.value;
  if (!capacity) return false;
  const ah = parseFloat(capacity);
  return ah >= 4.0;
});
```

### By Price Range

```tsx
const affordable = batteryData.products.filter(
  p => p.prices.excl_vat <= 200
);
```

## 💅 Styling Examples

### Modern Card Design

```css
.battery-card {
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  padding: 24px;
  background: white;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  transition: all 0.2s;
}

.battery-card:hover {
  box-shadow: 0 8px 16px rgba(0,0,0,0.15);
  transform: translateY(-2px);
}

/* Property display with icons */
.property {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px 0;
}

.property .icon {
  font-size: 24px;
  width: 32px;
  text-align: center;
}

.property small {
  display: block;
  font-size: 11px;
  color: #6b7280;
  text-transform: uppercase;
  font-weight: 600;
  letter-spacing: 0.5px;
}

.property strong {
  display: block;
  font-size: 14px;
  color: #111827;
  font-weight: 500;
}

/* Pricing with gradient */
.pricing {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  padding: 16px;
  background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
  border-radius: 8px;
  color: white;
  margin: 16px 0;
}

.pricing > div {
  text-align: center;
}

.pricing small {
  display: block;
  opacity: 0.9;
  font-size: 11px;
  margin-bottom: 4px;
}

.pricing strong {
  display: block;
  font-size: 18px;
  font-weight: 700;
}
```

### Property Tags

```css
.property-tag {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  background: #f3f4f6;
  border-radius: 6px;
  font-size: 13px;
  margin: 4px;
  white-space: nowrap;
}

.property-tag:hover {
  background: #e5e7eb;
}
```

## 🔍 Vue 3 Example

```vue
<template>
  <div class="battery-products">
    <!-- Tabs -->
    <div class="tabs">
      <button
        v-for="cat in categories"
        :key="cat.key"
        :class="{ active: activeCategory === cat.key }"
        @click="activeCategory = cat.key"
      >
        {{ cat.label }} ({{ cat.count }})
      </button>
    </div>

    <!-- Grid -->
    <div class="grid">
      <div
        v-for="product in filteredProducts"
        :key="product.sku"
        class="battery-card"
      >
        <h3>{{ product.product_name }}</h3>
        <div class="sku">{{ product.sku }}</div>

        <!-- Properties with icons -->
        <div class="properties">
          <div
            v-for="(prop, key) in product.properties"
            :key="key"
            class="property"
          >
            <span class="icon">{{ prop.icon }}</span>
            <div>
              <small>{{ prop.label }}</small>
              <strong>{{ prop.value }}</strong>
            </div>
          </div>
        </div>

        <!-- Prices -->
        <div class="pricing">
          <div>{{ product.display.price_excl }}</div>
          <div>{{ product.display.price_incl }}</div>
        </div>

        <button @click="addToCart(product)">Add to Cart</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import batteryData from './makita_batteries_formatted.json';

const activeCategory = ref('all');

const categories = [
  { key: 'all', label: 'All Products', count: batteryData.products.length },
  { key: 'batteries', label: 'Batteries', count: batteryData.products.filter(p => p.category === 'batteries').length },
  { key: 'powerpacks', label: 'Powerpacks', count: batteryData.products.filter(p => p.category === 'powerpacks').length },
  { key: 'chargers', label: 'Chargers', count: batteryData.products.filter(p => p.category === 'chargers').length },
  { key: 'adapters', label: 'Adapters', count: batteryData.products.filter(p => p.category === 'adapters').length },
];

const filteredProducts = computed(() => {
  if (activeCategory.value === 'all') {
    return batteryData.products;
  }
  return batteryData.products.filter(p => p.category === activeCategory.value);
});

const addToCart = (product) => {
  console.log('Adding to cart:', product.sku);
  // Your cart logic here
};
</script>
```

## 📦 Files for Frontend

1. **`output/makita_batteries_formatted.json`** - Data with icons (19 products)
2. **`image-database/BatteryProducts.tsx`** - React components
3. **`BATTERY_FRONTEND_INTEGRATION.md`** - This guide

## ✅ Summary

**19 battery products** ready with:
- ✅ Icons for every property type
- ✅ Consistent structure (voltage, capacity, weight, charge time, etc.)
- ✅ Both prices (ex/incl BTW)
- ✅ React components ready to use
- ✅ Vue examples provided
- ✅ Responsive grid layout
- ✅ Category filtering

Copy the JSON and components to your frontend and you're ready to go! 🚀
