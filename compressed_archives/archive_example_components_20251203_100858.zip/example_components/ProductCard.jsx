/**
 * React Component - Product Card
 * Beautiful, reusable product card component for e-commerce
 */

import React, { useState } from 'react';

// Helper function to get icon for property
const getPropertyIcon = (key) => {
  const keyLower = key.toLowerCase();
  
  // Power & Electrical
  if (keyLower.includes('power') || keyLower.includes('watt') || keyLower.includes('kw') || keyLower.includes('hp')) return '⚡';
  if (keyLower.includes('voltage') || keyLower.includes('volt')) return '🔌';
  if (keyLower.includes('current') || keyLower.includes('ampere') || keyLower.includes('amp')) return '🔌';
  if (keyLower.includes('frequency') || keyLower.includes('hz')) return '〰️';
  
  // Flow & Air
  if (keyLower.includes('intake') || keyLower.includes('input_flow')) return '🌬️';
  if (keyLower.includes('outtake') || keyLower.includes('output') || keyLower.includes('flow')) return '💨';
  if (keyLower.includes('capacity') && keyLower.includes('air')) return '💨';
  
  // Pressure
  if (keyLower.includes('pressure') || keyLower.includes('bar') || keyLower.includes('psi')) return '🔧';
  
  // Volume & Tank & Capacity
  if (keyLower.includes('volume') || keyLower.includes('vol_') || keyLower.includes('_vol')) return '🗜️';
  if (keyLower.includes('tank') || keyLower.includes('capacity')) return '🗜️';
  if (keyLower.includes('liter') || keyLower.includes('litre')) return '📦';
  
  // Speed & RPM
  if (keyLower.includes('rpm') || keyLower.includes('speed') || keyLower.includes('rotation')) return '🔄';
  
  // Noise
  if (keyLower.includes('noise') || keyLower.includes('db') || keyLower.includes('sound')) return '🔊';
  
  // Tubes & Pipes - Check BEFORE general diameter
  if (keyLower.includes('inner') && (keyLower.includes('diameter') || keyLower.includes('tube') || keyLower.includes('pipe'))) return '⊙';
  if (keyLower.includes('outer') && (keyLower.includes('diameter') || keyLower.includes('tube') || keyLower.includes('pipe'))) return '◎';
  if (keyLower.includes('inner_tube') || keyLower.includes('innertube')) return '⊙';
  if (keyLower.includes('outer_tube') || keyLower.includes('outertube')) return '◎';
  
  // Dimensions - General
  if (keyLower.includes('dimension') || keyLower.includes('size') || (keyLower.includes('length') && keyLower.includes('width'))) return '📏';
  if (keyLower.includes('diameter') || keyLower.includes('ø') || keyLower.includes('diam')) return '⭕';
  if (keyLower.includes('length') && !keyLower.includes('wave')) return '📏';
  if (keyLower.includes('width') || keyLower.includes('breedte')) return '↔️';
  if (keyLower.includes('height') || keyLower.includes('hoogte')) return '↕️';
  if (keyLower.includes('thickness') || keyLower.includes('dikte') || keyLower.includes('wall')) return '📐';
  
  // Weight
  if (keyLower.includes('weight') || keyLower.includes('kg') || keyLower.includes('gram') || keyLower.includes('gewicht')) return '⚖️';
  
  // Material & Construction
  if (keyLower.includes('material') || keyLower.includes('materiaal')) return '🧱';
  if (keyLower.includes('piston')) return '🔩';
  if (keyLower.includes('cylinder')) return '⚙️';
  
  // Temperature
  if (keyLower.includes('temp')) return '🌡️';
  
  // Product Code
  if (keyLower.includes('code') || keyLower.includes('model')) return '🏷️';
  
  // Connection
  if (keyLower.includes('connection') || keyLower.includes('thread')) return '🔗';
  
  // Default
  return '▪️';
};

const formatPropertyValue = (key, value) => {
  if (typeof value === 'object' && value !== null) {
    return JSON.stringify(value);
  }
  return value;
};

const ProductCard = ({ product }) => {
  const [imageError, setImageError] = useState(false);
  const [showModal, setShowModal] = useState(false);

  const primaryImage = product.images?.[0]?.path || null;
  const imageSrc = imageError || !primaryImage
    ? "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200'%3E%3Crect fill='%23f0f0f0' width='200' height='200'/%3E%3Ctext x='50%25' y='50%25' fill='%23999' text-anchor='middle' dy='.3em'%3ENo Image%3C/text%3E%3C/svg%3E"
    : primaryImage.replace(/\\/g, '/');

  return (
    <>
      <div className="product-card" onClick={() => setShowModal(true)}>
        <div className="product-image-container">
          <img
            src={imageSrc}
            alt={product.sku}
            className="product-image"
            onError={() => setImageError(true)}
          />
          {product.images?.length > 1 && (
            <span className="image-count-badge">
              +{product.images.length - 1} more
            </span>
          )}
        </div>

        <div className="product-content">
          <h3 className="product-sku">{product.sku}</h3>
          
          <div className="product-source">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
              <polyline points="14 2 14 8 20 8" />
            </svg>
            {product.pdf_source.replace('.pdf', '')}
          </div>

          <div className="product-meta">
            <span className="meta-badge images-badge">
              🖼️ {product.images?.length || 0} image{product.images?.length !== 1 ? 's' : ''}
            </span>
          </div>

          {/* Properties - check 'properties', 'attributes', and 'specs' */}
          {(() => {
            let productProps = product.properties || product.attributes || {};
            
            // If specs array exists, convert it to object format
            if (product.specs && Array.isArray(product.specs) && product.specs.length > 0) {
              productProps = {};
              product.specs.forEach(spec => {
                if (spec.key && spec.value) {
                  productProps[spec.key] = spec.value;
                }
              });
            }
            
            return Object.keys(productProps).length > 0 && (
              <div className="product-properties">
                {Object.entries(productProps).map(([key, value]) => {
                  const icon = getPropertyIcon(key);
                  const displayValue = formatPropertyValue(key, value);
                  const displayKey = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                  return (
                    <div key={key} className="property-item">
                      <span className="property-icon">{icon}</span>
                      <span className="property-text">{displayKey}: {displayValue}</span>
                    </div>
                  );
                })}
              </div>
            );
          })()}

          <div className="product-actions">
            <a
              href={`/input_pdfs/${product.pdf_source}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-primary"
              onClick={(e) => e.stopPropagation()}
            >
              📄 Full PDF
            </a>
            <a
              href={`/input_pdfs/${product.pdf_source}#page=${product.pages?.[0]}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-secondary"
              onClick={(e) => e.stopPropagation()}
            >
              📍 Page {product.pages?.[0]}
            </a>
          </div>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <ProductModal
          product={product}
          onClose={() => setShowModal(false)}
        />
      )}
    </>
  );
};

const ProductModal = ({ product, onClose }) => {
  return (
    <div className="modal active" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>×</button>
        
        <div className="modal-header">
          <h2>{product.sku}</h2>
          <p>Source: {product.pdf_source}</p>
        </div>

        <div className="modal-body">
          <h3>📄 Available on Pages:</h3>
          <div className="modal-pages">
            {product.pages?.map(page => (
              <a
                key={page}
                href={`/input_pdfs/${product.pdf_source}#page=${page}`}
                target="_blank"
                rel="noopener noreferrer"
                className="page-link"
              >
                Page {page}
              </a>
            ))}
          </div>

          <h3 style={{ marginTop: '25px' }}>🖼️ Product Images:</h3>
          <div className="modal-images">
            {product.images?.map((img, idx) => (
              <div key={idx}>
                <img
                  src={img.path.replace(/\\/g, '/')}
                  alt={img.filename}
                  className="modal-image"
                  onClick={() => window.open(img.path.replace(/\\/g, '/'), '_blank')}
                />
                <p style={{ fontSize: '0.8rem', marginTop: '5px' }}>
                  {img.filename}
                </p>
                {img.shared_with_skus?.length > 1 && (
                  <p style={{ fontSize: '0.8rem', color: '#7f8c8d' }}>
                    Shared with: {img.shared_with_skus.filter(s => s !== product.sku).join(', ')}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// Example usage in a catalog page
const ProductCatalog = ({ products }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCatalog, setSelectedCatalog] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const productsPerPage = 24;

  // Filter products
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.pdf_source.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCatalog = !selectedCatalog || product.pdf_source === selectedCatalog;
    return matchesSearch && matchesCatalog;
  });

  // Pagination
  const totalPages = Math.ceil(filteredProducts.length / productsPerPage);
  const startIdx = (currentPage - 1) * productsPerPage;
  const paginatedProducts = filteredProducts.slice(startIdx, startIdx + productsPerPage);

  // Get unique catalogs
  const catalogs = [...new Set(products.map(p => p.pdf_source))];

  return (
    <div className="catalog-container">
      <header className="catalog-header">
        <h1>🛠️ Product Catalog</h1>
        <div className="catalog-stats">
          <div className="stat-card">
            <div className="stat-number">{products.length.toLocaleString()}</div>
            <div className="stat-label">Total Products</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">
              {products.reduce((sum, p) => sum + (p.images?.length || 0), 0).toLocaleString()}
            </div>
            <div className="stat-label">Product Images</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">{catalogs.length}</div>
            <div className="stat-label">Catalogs</div>
          </div>
        </div>
      </header>

      <div className="search-filter">
        <input
          type="text"
          placeholder="🔍 Search by SKU, catalog name..."
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setCurrentPage(1);
          }}
        />
        <select
          value={selectedCatalog}
          onChange={(e) => {
            setSelectedCatalog(e.target.value);
            setCurrentPage(1);
          }}
        >
          <option value="">All Catalogs</option>
          {catalogs.map(catalog => (
            <option key={catalog} value={catalog}>
              {catalog.replace('.pdf', '')}
            </option>
          ))}
        </select>
      </div>

      <div className="products-grid">
        {paginatedProducts.map(product => (
          <ProductCard key={product.sku} product={product} />
        ))}
      </div>

      {totalPages > 1 && (
        <div className="pagination">
          <button
            disabled={currentPage === 1}
            onClick={() => setCurrentPage(p => p - 1)}
          >
            ← Previous
          </button>
          
          {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
            <button
              key={page}
              className={page === currentPage ? 'active' : ''}
              onClick={() => setCurrentPage(page)}
            >
              {page}
            </button>
          ))}
          
          <button
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage(p => p + 1)}
          >
            Next →
          </button>
        </div>
      )}
    </div>
  );
};

export { ProductCard, ProductModal, ProductCatalog };
export default ProductCard;
