import React from 'react';

// Helper function to get icon for property
const getPropertyIcon = (key: string): string => {
  const keyLower = key.toLowerCase();
  
  // Power & Electrical
  if (keyLower.includes('power') || keyLower.includes('watt') || keyLower.includes('kw') || keyLower.includes('hp')) return '⚡';
  if (keyLower.includes('voltage') || keyLower.includes('volt')) return '🔌';
  if (keyLower.includes('current') || keyLower.includes('ampere') || keyLower.includes('amp')) return '🔌';
  if (keyLower.includes('frequency') || keyLower.includes('hz')) return '〰️';
  
  // Flow & Air
  if (keyLower.includes('intake') || keyLower.includes('input_flow')) return '🌬️';
  if (keyLower.includes('outtake') || keyLower.includes('output') || keyLower.includes('flow')) return '💨';
  if (keyLower.includes('capacity') && keyLower.includes('air')) return '💨';
  
  // Pressure
  if (keyLower.includes('pressure') || keyLower.includes('bar') || keyLower.includes('psi')) return '🔧';
  
  // Volume & Tank & Capacity
  if (keyLower.includes('volume') || keyLower.includes('vol_') || keyLower.includes('_vol')) return '🗜️';
  if (keyLower.includes('tank') || keyLower.includes('capacity')) return '🗜️';
  if (keyLower.includes('liter') || keyLower.includes('litre')) return '📦';
  
  // Speed & RPM
  if (keyLower.includes('rpm') || keyLower.includes('speed') || keyLower.includes('rotation')) return '🔄';
  
  // Noise
  if (keyLower.includes('noise') || keyLower.includes('db') || keyLower.includes('sound')) return '🔊';
  
  // Tubes & Pipes - Check BEFORE general diameter
  if (keyLower.includes('inner') && (keyLower.includes('diameter') || keyLower.includes('tube') || keyLower.includes('pipe'))) return '⊙';
  if (keyLower.includes('outer') && (keyLower.includes('diameter') || keyLower.includes('tube') || keyLower.includes('pipe'))) return '◎';
  if (keyLower.includes('inner_tube') || keyLower.includes('innertube')) return '⊙';
  if (keyLower.includes('outer_tube') || keyLower.includes('outertube')) return '◎';
  
  // Dimensions - General
  if (keyLower.includes('dimension') || keyLower.includes('size') || (keyLower.includes('length') && keyLower.includes('width'))) return '📏';
  if (keyLower.includes('diameter') || keyLower.includes('ø') || keyLower.includes('diam')) return '⭕';
  if (keyLower.includes('length') && !keyLower.includes('wave')) return '📏';
  if (keyLower.includes('width') || keyLower.includes('breedte')) return '↔️';
  if (keyLower.includes('height') || keyLower.includes('hoogte')) return '↕️';
  if (keyLower.includes('thickness') || keyLower.includes('dikte') || keyLower.includes('wall')) return '📐';
  if (keyLower.includes('angle') || keyLower.includes('°')) return '📐';
  
  // Weight
  if (keyLower.includes('weight') || keyLower.includes('kg') || keyLower.includes('gram') || keyLower.includes('gewicht')) return '⚖️';
  
  // Material & Construction
  if (keyLower.includes('material') || keyLower.includes('materiaal')) return '🧱';
  if (keyLower.includes('piston')) return '🔩';
  if (keyLower.includes('cylinder')) return '⚙️';
  
  // Temperature
  if (keyLower.includes('temp')) return '🌡️';
  
  // Product Code
  if (keyLower.includes('code') || keyLower.includes('model') || keyLower.includes('sku')) return '🏷️';
  
  // Connection
  if (keyLower.includes('connection') || keyLower.includes('thread')) return '🔗';
  
  // Category
  if (keyLower.includes('category') || keyLower.includes('categorie')) return '📦';
  
  // Default
  return '▪️';
};

// Color schemes for different property types
const getColorClasses = (index: number, key: string): string => {
  const keyLower = key.toLowerCase();
  
  // Specific colors for specific properties
  if (keyLower.includes('pressure') || keyLower.includes('bar')) {
    return 'bg-blue-50 text-blue-800 border-blue-200';
  }
  if (keyLower.includes('diameter') || keyLower.includes('ø')) {
    return 'bg-green-50 text-green-800 border-green-200';
  }
  if (keyLower.includes('length') || keyLower.includes('angle') || keyLower.includes('thickness')) {
    return 'bg-teal-50 text-teal-800 border-teal-200';
  }
  if (keyLower.includes('volume') || keyLower.includes('tank') || keyLower.includes('capacity')) {
    return 'bg-indigo-50 text-indigo-800 border-indigo-200';
  }
  if (keyLower.includes('power') || keyLower.includes('watt')) {
    return 'bg-yellow-50 text-yellow-800 border-yellow-200';
  }
  if (keyLower.includes('material') || keyLower.includes('category')) {
    return 'bg-emerald-50 text-emerald-800 border-emerald-200';
  }
  if (keyLower.includes('weight')) {
    return 'bg-purple-50 text-purple-800 border-purple-200';
  }
  
  // Fallback: cycle through colors
  const colors = [
    'bg-slate-50 text-slate-800 border-slate-200',
    'bg-gray-50 text-gray-800 border-gray-200',
    'bg-zinc-50 text-zinc-800 border-zinc-200',
    'bg-stone-50 text-stone-800 border-stone-200',
  ];
  return colors[index % colors.length];
};

interface PropertyBadgesProps {
  properties: Record<string, any>;
  maxDisplay?: number;
}

export const PropertyBadges: React.FC<PropertyBadgesProps> = ({ 
  properties, 
  maxDisplay = 5 
}) => {
  if (!properties || Object.keys(properties).length === 0) {
    return null;
  }

  // Filter out empty values and limit display
  const entries = Object.entries(properties)
    .filter(([_, value]) => value != null && value !== '')
    .slice(0, maxDisplay);

  return (
    <div className="mb-2 flex flex-wrap gap-1.5">
      {entries.map(([key, value], index) => {
        const icon = getPropertyIcon(key);
        const colorClasses = getColorClasses(index, key);
        const displayValue = String(value);
        
        return (
          <span
            key={key}
            className={`inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium border ${colorClasses}`}
          >
            {icon} {displayValue}
          </span>
        );
      })}
    </div>
  );
};

export default PropertyBadges;
