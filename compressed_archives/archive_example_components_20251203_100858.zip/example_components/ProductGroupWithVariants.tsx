/**
 * Product Group Component with Variant Selection
 * 
 * This component displays products from a table as a single product group
 * with a variant picker. All variants share the same image.
 * 
 * Example: ABSBU series products (ABSBU016, ABSBU020, ABSBU025, etc.)
 * share one image with different properties (diameter, length, etc.)
 */

import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { PropertyBadges } from './PropertyBadges';

// Helper function to get icon for property
const getPropertyIcon = (key: string): string => {
  const keyLower = key.toLowerCase();
  
  // Power & Electrical
  if (keyLower.includes('power') || keyLower.includes('watt') || keyLower.includes('kw') || keyLower.includes('hp')) return '⚡';
  if (keyLower.includes('voltage') || keyLower.includes('volt')) return '🔌';
  if (keyLower.includes('current') || keyLower.includes('ampere') || keyLower.includes('amp')) return '🔌';
  if (keyLower.includes('frequency') || keyLower.includes('hz')) return '〰️';
  
  // Flow & Air
  if (keyLower.includes('intake') || keyLower.includes('input_flow')) return '🌬️';
  if (keyLower.includes('outtake') || keyLower.includes('output') || keyLower.includes('flow')) return '💨';
  if (keyLower.includes('capacity') && keyLower.includes('air')) return '💨';
  
  // Pressure
  if (keyLower.includes('pressure') || keyLower.includes('bar') || keyLower.includes('psi')) return '🔧';
  
  // Volume & Tank & Capacity
  if (keyLower.includes('volume') || keyLower.includes('vol_') || keyLower.includes('_vol')) return '🗜️';
  if (keyLower.includes('tank') || keyLower.includes('capacity')) return '🗜️';
  if (keyLower.includes('liter') || keyLower.includes('litre')) return '📦';
  
  // Speed & RPM
  if (keyLower.includes('rpm') || keyLower.includes('speed') || keyLower.includes('rotation')) return '🔄';
  
  // Noise
  if (keyLower.includes('noise') || keyLower.includes('db') || keyLower.includes('sound')) return '🔊';
  
  // Tubes & Pipes - Check BEFORE general diameter
  if (keyLower.includes('inner') && (keyLower.includes('diameter') || keyLower.includes('tube') || keyLower.includes('pipe'))) return '⊙';
  if (keyLower.includes('outer') && (keyLower.includes('diameter') || keyLower.includes('tube') || keyLower.includes('pipe'))) return '◎';
  if (keyLower.includes('inner_tube') || keyLower.includes('innertube')) return '⊙';
  if (keyLower.includes('outer_tube') || keyLower.includes('outertube')) return '◎';
  
  // Dimensions - General
  if (keyLower.includes('dimension') || keyLower.includes('size') || (keyLower.includes('length') && keyLower.includes('width'))) return '📏';
  if (keyLower.includes('diameter') || keyLower.includes('ø') || keyLower.includes('diam')) return '⭕';
  if (keyLower.includes('length') && !keyLower.includes('wave')) return '📏';
  if (keyLower.includes('width') || keyLower.includes('breedte')) return '↔️';
  if (keyLower.includes('height') || keyLower.includes('hoogte')) return '↕️';
  if (keyLower.includes('thickness') || keyLower.includes('dikte') || keyLower.includes('wall')) return '📐';
  
  // Weight
  if (keyLower.includes('weight') || keyLower.includes('kg') || keyLower.includes('gram') || keyLower.includes('gewicht')) return '⚖️';
  
  // Material & Construction
  if (keyLower.includes('material') || keyLower.includes('materiaal')) return '🧱';
  if (keyLower.includes('piston')) return '🔩';
  if (keyLower.includes('cylinder')) return '⚙️';
  
  // Temperature
  if (keyLower.includes('temp')) return '🌡️';
  
  // Product Code
  if (keyLower.includes('code') || keyLower.includes('model') || keyLower.includes('sku')) return '🏷️';
  
  // Connection
  if (keyLower.includes('connection') || keyLower.includes('thread')) return '🔗';
  
  // Default
  return '▪️';
};

interface VariantProperty {
  diameter_mm?: number;
  diameter_display?: string;
  pressure_bar?: number;
  pressure_display?: string;
  length_m?: number;
  length_display?: string;
  wall_thickness_mm?: number;
  wall_thickness_display?: string;
}

interface ProductVariant {
  sku: string;
  label: string;
  properties: VariantProperty;
  page_in_pdf: number;
}

interface ProductMedia {
  url: string;
  role: string;
}

interface ProductGroup {
  group_id: string;
  type: string;
  catalog: string;
  family: string;
  name: string;
  page_in_pdf: number;
  media: ProductMedia[];
  common_properties: VariantProperty;
  variants: ProductVariant[];
  variant_count: number;
  default_variant_sku: string;
}

interface ProductGroupWithVariantsProps {
  productGroup: ProductGroup;
  onAddToCart?: (sku: string) => void;
}

export const ProductGroupWithVariants: React.FC<ProductGroupWithVariantsProps> = ({
  productGroup,
  onAddToCart,
}) => {
  const [selectedVariantSku, setSelectedVariantSku] = useState(
    productGroup.default_variant_sku
  );
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const selectedVariant = productGroup.variants.find(
    (v) => v.sku === selectedVariantSku
  );

  if (!selectedVariant) {
    return null;
  }

  const mainImage = productGroup.media.find((m) => m.role === 'main')?.url;

  const handleVariantChange = (sku: string) => {
    setSelectedVariantSku(sku);
    setIsDropdownOpen(false);
  };

  return (
    <div className="product-group-card bg-white rounded-lg shadow-md p-6 max-w-2xl">
      {/* Header */}
      <div className="mb-4">
        <h2 className="text-2xl font-bold text-gray-900">{productGroup.name}</h2>
        <p className="text-sm text-gray-500">
          {productGroup.variant_count} variants available
        </p>
      </div>

      {/* PDF Navigation Buttons */}
      <div className="flex gap-2 mb-4">
        <a
          href={`/input_pdfs/${productGroup.catalog}.pdf`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 px-4 py-2 bg-blue-600 text-white text-center rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
        >
          📄 Full PDF
        </a>
        <a
          href={`/input_pdfs/${productGroup.catalog}.pdf#page=${selectedVariant.page_in_pdf}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 text-center rounded-lg hover:bg-gray-300 transition-colors text-sm font-medium"
        >
          📍 Page {selectedVariant.page_in_pdf}
        </a>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Shared Image */}
        <div className="product-image">
          {mainImage ? (
            <img
              src={mainImage}
              alt={productGroup.name}
              className="w-full h-auto rounded-lg border border-gray-200"
            />
          ) : (
            <div className="w-full h-64 bg-gray-100 rounded-lg flex items-center justify-center">
              <span className="text-gray-400">No image available</span>
            </div>
          )}
          <p className="text-xs text-gray-400 mt-2 text-center">
            Image shared across all variants
          </p>
        </div>

        {/* Variant Selector & Properties */}
        <div className="product-details">
          {/* Variant Picker */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Variant:
            </label>
            <div className="relative">
              <button
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="w-full px-4 py-3 text-left bg-white border border-gray-300 rounded-lg shadow-sm hover:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500 flex items-center justify-between"
              >
                <span className="font-medium">{selectedVariant.label}</span>
                <ChevronDown
                  className={`w-5 h-5 transition-transform ${
                    isDropdownOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {isDropdownOpen && (
                <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {productGroup.variants.map((variant) => (
                    <button
                      key={variant.sku}
                      onClick={() => handleVariantChange(variant.sku)}
                      className={`w-full px-4 py-3 text-left hover:bg-blue-50 border-b border-gray-100 last:border-b-0 ${
                        variant.sku === selectedVariantSku
                          ? 'bg-blue-50 font-medium'
                          : ''
                      }`}
                    >
                      <div className="text-sm">{variant.label}</div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Property Badges - Colorful tags like the catalog */}
          <PropertyBadges properties={selectedVariant.properties} maxDisplay={6} />

          {/* Selected Variant Properties - Dynamic rendering */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">
              Product Specifications
            </h3>

            <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg p-4 space-y-2 border-l-4 border-blue-500">
              {/* SKU */}
              <div className="flex items-center gap-3 pb-2 border-b border-gray-200">
                <span className="text-lg">{getPropertyIcon('sku')}</span>
                <span className="text-xs font-medium text-gray-500 uppercase">SKU:</span>
                <span className="text-sm font-bold text-blue-600 ml-auto">
                  {selectedVariant.sku}
                </span>
              </div>

              {/* All variant properties dynamically rendered */}
              {Object.entries(selectedVariant.properties).map(([key, value], index, array) => {
                if (!value) return null;
                
                const icon = getPropertyIcon(key);
                const label = key
                  .replace(/_display$/, '')
                  .replace(/_/g, ' ')
                  .replace(/\b\w/g, (l) => l.toUpperCase());
                const isLast = index === array.length - 1;
                
                return (
                  <div
                    key={key}
                    className={`flex items-center gap-3 ${!isLast ? 'pb-2 border-b border-gray-200' : ''}`}
                  >
                    <span className="text-lg">{icon}</span>
                    <span className="text-xs font-medium text-gray-500 uppercase">{label}:</span>
                    <span className="text-sm font-semibold text-gray-900 ml-auto">
                      {String(value)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Common Properties (shared across all variants) - Dynamic rendering */}
          {Object.keys(productGroup.common_properties).length > 0 && (
            <div className="mt-4 p-3 bg-blue-50 rounded-lg">
              <p className="text-xs text-blue-700 font-medium mb-2">
                Common to all variants:
              </p>
              <div className="space-y-1">
                {Object.entries(productGroup.common_properties).map(([key, value]) => {
                  if (!value) return null;
                  
                  const icon = getPropertyIcon(key);
                  const label = key
                    .replace(/_display$/, '')
                    .replace(/_/g, ' ')
                    .replace(/\b\w/g, (l) => l.toUpperCase());
                  
                  return (
                    <p key={key} className="text-xs text-blue-600 flex items-center gap-2">
                      <span>{icon}</span>
                      <span>{label}: {String(value)}</span>
                    </p>
                  );
                })}
              </div>
            </div>
          )}

          {/* Add to Cart Button */}
          <button
            onClick={() => onAddToCart?.(selectedVariant.sku)}
            className="mt-6 w-full bg-blue-600 text-white font-semibold py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors shadow-sm"
          >
            Add to Cart - {selectedVariant.sku}
          </button>
        </div>
      </div>

      {/* Variant Quick Reference Table */}
      <div className="mt-8 border-t pt-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          All Available Variants
        </h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left font-medium text-gray-700">
                  SKU
                </th>
                <th className="px-4 py-3 text-left font-medium text-gray-700">
                  Diameter
                </th>
                <th className="px-4 py-3 text-left font-medium text-gray-700">
                  Pressure
                </th>
                <th className="px-4 py-3 text-left font-medium text-gray-700">
                  Length
                </th>
                <th className="px-4 py-3 text-center font-medium text-gray-700">
                  Action
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {productGroup.variants.map((variant) => (
                <tr
                  key={variant.sku}
                  className={`hover:bg-gray-50 ${
                    variant.sku === selectedVariantSku ? 'bg-blue-50' : ''
                  }`}
                >
                  <td className="px-4 py-3 font-medium text-gray-900">
                    {variant.sku}
                  </td>
                  <td className="px-4 py-3 text-gray-600">
                    {variant.properties.diameter_display || '-'}
                  </td>
                  <td className="px-4 py-3 text-gray-600">
                    {variant.properties.pressure_display || '-'}
                  </td>
                  <td className="px-4 py-3 text-gray-600">
                    {variant.properties.length_display || '-'}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <button
                      onClick={() => handleVariantChange(variant.sku)}
                      className="text-blue-600 hover:text-blue-800 font-medium text-xs"
                    >
                      Select
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ProductGroupWithVariants;
