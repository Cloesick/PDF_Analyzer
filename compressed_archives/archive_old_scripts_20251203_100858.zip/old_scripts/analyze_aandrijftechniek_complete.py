#!/usr/bin/env python3
"""
Complete Analysis for catalogus-aandrijftechniek.pdf

Fresh extraction from scratch:
1. Extract all images
2. Extract all SKUs and properties from tables
3. Apply smart property parsing
4. Match images to products
5. Create grouped data
"""

import fitz
import json
import re
from pathlib import Path
from PIL import Image
import io
from typing import Dict, List, Any, Optional
from collections import defaultdict
from smart_property_extractor import (
    match_header_to_property,
    parse_property_value
)

PROJECT_ROOT = Path(__file__).parent
INPUT_PDF = PROJECT_ROOT / "input_pdfs" / "catalogus-aandrijftechniek-150922.pdf"
OUTPUT_DIR = PROJECT_ROOT / "output"
IMAGE_OUTPUT = PROJECT_ROOT / "product-images-by-pdf" / "catalogus-aandrijftechniek-150922"

# Create output directories
IMAGE_OUTPUT.mkdir(parents=True, exist_ok=True)


def is_valid_sku(text: str) -> bool:
    """Check if text looks like a valid SKU"""
    if not text or not isinstance(text, str):
        return False
    
    text = str(text).strip()
    
    # Skip header keywords
    header_keywords = [
        'bestelnr', 'code', 'artikelnr', 'sku', 'artikel', 'type',
        'omschrijving', 'description', 'prijs', 'price', 'maat',
        'diameter', 'lengte', 'gewicht', 'item', 'product'
    ]
    
    if text.lower() in header_keywords:
        return False
    
    # Length checks
    if len(text) < 3 or len(text) > 25:
        return False
    
    # Must have some alphanumeric content
    if not re.search(r'[A-Za-z0-9]', text):
        return False
    
    # Good indicators for SKU
    has_digit = bool(re.search(r'\d', text))
    has_alpha = bool(re.search(r'[A-Za-z]', text))
    
    # Likely a SKU if it has both letters and numbers, or is purely numeric
    return (has_digit and has_alpha) or (has_digit and len(text) >= 4)


def extract_images_from_pdf(pdf_path: Path) -> List[Dict]:
    """Extract all images from PDF"""
    print(f"\n{'='*80}")
    print("STEP 1: EXTRACTING IMAGES")
    print(f"{'='*80}\n")
    
    doc = fitz.open(pdf_path)
    images_extracted = []
    total_images = 0
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        image_list = page.get_images(full=True)
        
        if not image_list:
            continue
        
        print(f"  📄 Page {page_num + 1}: Found {len(image_list)} images")
        
        for img_index, img in enumerate(image_list):
            try:
                xref = img[0]
                base_image = doc.extract_image(xref)
                image_bytes = base_image["image"]
                image_ext = base_image["ext"]
                
                # Create filename
                filename = f"p{page_num + 1:03d}_img{img_index:02d}.{image_ext}"
                image_path = IMAGE_OUTPUT / filename
                
                # Save image
                with open(image_path, "wb") as img_file:
                    img_file.write(image_bytes)
                
                # Convert to WebP for web use
                try:
                    pil_image = Image.open(io.BytesIO(image_bytes))
                    webp_filename = f"p{page_num + 1:03d}_img{img_index:02d}.webp"
                    webp_path = IMAGE_OUTPUT / webp_filename
                    pil_image.save(webp_path, "WEBP", quality=85)
                    
                    images_extracted.append({
                        'page': page_num + 1,
                        'index': img_index,
                        'filename': webp_filename,
                        'path': str(webp_path),
                        'relative_path': f"product-images-by-pdf/catalogus-aandrijftechniek-150922/{webp_filename}",
                        'width': pil_image.width,
                        'height': pil_image.height
                    })
                    total_images += 1
                except Exception as e:
                    print(f"    ⚠️  Could not convert to WebP: {e}")
                    
            except Exception as e:
                print(f"    ⚠️  Error extracting image: {e}")
    
    doc.close()
    
    print(f"\n  ✅ Extracted {total_images} images")
    print(f"  💾 Saved to: {IMAGE_OUTPUT}")
    
    return images_extracted


def is_header_row(row: List[str]) -> bool:
    """Check if row appears to be a header row"""
    if not row or not any(row):
        return False
    
    row_text = ' '.join(str(cell).lower() for cell in row if cell)
    
    header_indicators = [
        'bestelnr', 'code', 'artikel', 'type', 'omschrijving',
        'description', 'prijs', 'price', 'maat', 'afmeting',
        'diameter', 'lengte', 'gewicht', 'materiaal', 'spanning',
        'vermogen', 'toeren', 'rpm', 'kw', 'voltage'
    ]
    
    # If row contains 2+ header indicators, it's likely a header
    matches = sum(1 for indicator in header_indicators if indicator in row_text)
    return matches >= 2


def extract_tables_from_pdf(pdf_path: Path) -> List[Dict]:
    """Extract all tables with SKUs and properties"""
    print(f"\n{'='*80}")
    print("STEP 2: EXTRACTING TABLES & SKUs")
    print(f"{'='*80}\n")
    
    doc = fitz.open(pdf_path)
    all_products = []
    pages_with_data = 0
    total_properties = 0
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        
        try:
            tables = page.find_tables()
            if not tables or not tables.tables:
                continue
            
            page_products = []
            
            for table_idx, table in enumerate(tables.tables):
                try:
                    table_data = table.extract()
                    if not table_data or len(table_data) < 2:
                        continue
                    
                    # Find header row
                    header_row_idx = None
                    headers = []
                    header_map = {}
                    sku_column = None
                    
                    for row_idx, row in enumerate(table_data[:3]):
                        if is_header_row(row):
                            header_row_idx = row_idx
                            headers = row
                            
                            # Map headers to properties
                            for col_idx, header in enumerate(headers):
                                if not header:
                                    continue
                                
                                # Check for SKU column
                                header_lower = header.lower()
                                if any(kw in header_lower for kw in ['bestelnr', 'code', 'artikel', 'art.']):
                                    sku_column = col_idx
                                
                                prop_info = match_header_to_property(header)
                                if prop_info:
                                    header_map[col_idx] = {
                                        'header': header,
                                        'property': prop_info['property'],
                                        'info': prop_info
                                    }
                            break
                    
                    if header_row_idx is None:
                        continue
                    
                    # Extract products from data rows
                    for data_row_idx in range(header_row_idx + 1, len(table_data)):
                        data_row = table_data[data_row_idx]
                        
                        if not any(data_row):
                            continue
                        
                        # Get SKU
                        sku = None
                        if sku_column is not None and sku_column < len(data_row):
                            potential_sku = data_row[sku_column]
                            if is_valid_sku(potential_sku):
                                sku = str(potential_sku).strip()
                        
                        # If no SKU column found, scan first 3 columns
                        if not sku:
                            for i in range(min(3, len(data_row))):
                                if is_valid_sku(data_row[i]):
                                    sku = str(data_row[i]).strip()
                                    break
                        
                        if not sku:
                            continue
                        
                        # Extract properties
                        product = {
                            'sku': sku,
                            'catalog': 'catalogus-aandrijftechniek-150922',
                            'brand': 'Various',
                            'category': 'drive_technology',
                            'page_in_pdf': page_num + 1,
                            'table_index': table_idx,
                            'source': 'pdf_table',
                            'properties': {},
                            'raw_data': {}
                        }
                        
                        # Parse each column
                        for col_idx, col_info in header_map.items():
                            if col_idx >= len(data_row):
                                continue
                            
                            cell_value = data_row[col_idx]
                            if not cell_value or cell_value == '':
                                continue
                            
                            if col_info['property'] == 'sku':
                                continue
                            
                            parsed_value = parse_property_value(cell_value, col_info['info'])
                            
                            if parsed_value is not None:
                                product['properties'][col_info['property']] = parsed_value
                                product['raw_data'][col_info['header']] = cell_value
                                total_properties += 1
                        
                        page_products.append(product)
                        
                except Exception as e:
                    print(f"    ⚠️  Error processing table {table_idx}: {e}")
                    continue
            
            if page_products:
                pages_with_data += 1
                print(f"  📄 Page {page_num + 1}: Extracted {len(page_products)} SKUs")
                all_products.extend(page_products)
                
        except Exception as e:
            print(f"  ⚠️  Error on page {page_num + 1}: {e}")
            continue
    
    doc.close()
    
    print(f"\n  ✅ Extracted {len(all_products)} products from {pages_with_data} pages")
    print(f"  📊 Total properties: {total_properties}")
    
    if all_products and total_properties > 0:
        avg = total_properties / len(all_products)
        print(f"  📈 Average properties per SKU: {avg:.1f}")
    
    return all_products


def match_images_to_products(products: List[Dict], images: List[Dict]) -> None:
    """Match images to products based on page"""
    print(f"\n{'='*80}")
    print("STEP 3: MATCHING IMAGES TO PRODUCTS")
    print(f"{'='*80}\n")
    
    # Build image index by page
    images_by_page = defaultdict(list)
    for img in images:
        images_by_page[img['page']].append(img)
    
    matched = 0
    
    for product in products:
        page = product['page_in_pdf']
        
        if page in images_by_page:
            page_images = images_by_page[page]
            
            # For now, assign the first image on the page
            # More sophisticated matching can be added later
            if page_images:
                img = page_images[0]
                product['image'] = {
                    'url': img['relative_path'],
                    'filename': img['filename'],
                    'width': img['width'],
                    'height': img['height']
                }
                matched += 1
    
    print(f"  ✅ Matched {matched}/{len(products)} products to images")
    print(f"  📊 Coverage: {matched/len(products)*100:.1f}%")


def group_products_by_page(products: List[Dict]) -> List[Dict]:
    """Group products by page and similar properties"""
    print(f"\n{'='*80}")
    print("STEP 4: CREATING PRODUCT GROUPS")
    print(f"{'='*80}\n")
    
    # Group by page and table
    grouped = defaultdict(list)
    
    for product in products:
        page = product['page_in_pdf']
        table = product.get('table_index', 0)
        key = f"page{page}_table{table}"
        grouped[key].append(product)
    
    # Create group structures
    product_groups = []
    
    for group_key, group_products in grouped.items():
        # Get first product's page and image
        first_product = group_products[0]
        page = first_product['page_in_pdf']
        
        # Extract common properties
        common_props = {}
        variant_props = set()
        
        # Find properties that vary across variants
        if len(group_products) > 1:
            all_prop_keys = set()
            for p in group_products:
                all_prop_keys.update(p.get('properties', {}).keys())
            
            for prop_key in all_prop_keys:
                values = [p.get('properties', {}).get(prop_key) for p in group_products]
                unique_values = set(str(v) for v in values if v is not None)
                
                if len(unique_values) == 1:
                    # All same - common property
                    common_props[prop_key] = group_products[0]['properties'].get(prop_key)
                else:
                    # Varies - variant property
                    variant_props.add(prop_key)
        
        # Create variants
        variants = []
        for p in group_products:
            variant = {
                'sku': p['sku'],
                'label': p['sku'],
                'page_in_pdf': p['page_in_pdf'],
                'properties': {},
                'attributes': {}
            }
            
            # Add variant-specific properties
            for prop_key in variant_props:
                if prop_key in p.get('properties', {}):
                    variant['properties'][prop_key] = p['properties'][prop_key]
            
            # Add all properties to attributes for display
            variant['attributes'] = p.get('properties', {}).copy()
            
            variants.append(variant)
        
        # Create group
        group = {
            'group_id': f"aandrijftechniek_{group_key}",
            'type': 'product_group',
            'catalog': 'catalogus-aandrijftechniek-150922',
            'name': f"Page {page} Products ({len(variants)} variants)",
            'page_in_pdf': page,
            'media': [],
            'common_properties': common_props,
            'variants': variants,
            'variant_count': len(variants),
            'default_variant_sku': variants[0]['sku'] if variants else None,
            'brand': 'Various',
            'category': 'drive_technology',
            'description': f"Page {page} Products - {len(variants)} variants"
        }
        
        # Add image if available
        if first_product.get('image'):
            group['media'] = [{
                'url': first_product['image']['url'],
                'role': 'main'
            }]
        
        product_groups.append(group)
    
    # Sort by page
    product_groups.sort(key=lambda x: x['page_in_pdf'])
    
    print(f"  ✅ Created {len(product_groups)} product groups")
    print(f"  📊 Total variants: {sum(g['variant_count'] for g in product_groups)}")
    
    return product_groups


def generate_analysis_report(products: List[Dict], images: List[Dict], groups: List[Dict]) -> Dict:
    """Generate comprehensive analysis report"""
    print(f"\n{'='*80}")
    print("STEP 5: GENERATING ANALYSIS REPORT")
    print(f"{'='*80}\n")
    
    # Count properties
    total_properties = sum(len(p.get('properties', {})) for p in products)
    properties_by_type = defaultdict(int)
    
    for p in products:
        for prop_key in p.get('properties', {}).keys():
            properties_by_type[prop_key] += 1
    
    # Pages with data
    pages_with_products = len(set(p['page_in_pdf'] for p in products))
    pages_with_images = len(set(img['page'] for img in images))
    
    # Groups with images
    groups_with_images = sum(1 for g in groups if g.get('media'))
    
    report = {
        'catalog': 'catalogus-aandrijftechniek-150922',
        'pdf_file': 'catalogus-aandrijftechniek-150922.pdf',
        'extraction_date': str(Path.cwd()),
        'summary': {
            'total_skus': len(products),
            'total_images': len(images),
            'total_groups': len(groups),
            'total_properties': total_properties,
            'avg_properties_per_sku': round(total_properties / len(products), 2) if products else 0,
            'pages_with_products': pages_with_products,
            'pages_with_images': pages_with_images,
            'groups_with_images': groups_with_images,
            'image_coverage': round(groups_with_images / len(groups) * 100, 1) if groups else 0
        },
        'properties_found': dict(sorted(properties_by_type.items(), key=lambda x: x[1], reverse=True)),
        'top_10_properties': dict(list(sorted(properties_by_type.items(), key=lambda x: x[1], reverse=True))[:10])
    }
    
    print(f"  📊 Total SKUs: {report['summary']['total_skus']}")
    print(f"  🖼️  Total Images: {report['summary']['total_images']}")
    print(f"  📦 Product Groups: {report['summary']['total_groups']}")
    print(f"  🏷️  Total Properties: {report['summary']['total_properties']}")
    print(f"  📈 Avg Props/SKU: {report['summary']['avg_properties_per_sku']}")
    print(f"  📄 Pages with Products: {report['summary']['pages_with_products']}")
    print(f"  🖼️  Image Coverage: {report['summary']['image_coverage']}%")
    
    return report


def main():
    print("="*80)
    print("COMPLETE ANALYSIS: CATALOGUS-AANDRIJFTECHNIEK")
    print("="*80)
    print(f"\n📄 PDF: {INPUT_PDF.name}")
    print(f"🎯 Starting fresh extraction from scratch...\n")
    
    if not INPUT_PDF.exists():
        print(f"❌ Error: PDF not found at {INPUT_PDF}")
        return
    
    # Step 1: Extract images
    images = extract_images_from_pdf(INPUT_PDF)
    
    # Step 2: Extract tables and SKUs
    products = extract_tables_from_pdf(INPUT_PDF)
    
    if not products:
        print("\n❌ No products found in PDF!")
        return
    
    # Step 3: Match images to products
    match_images_to_products(products, images)
    
    # Step 4: Create groups
    groups = group_products_by_page(products)
    
    # Step 5: Generate report
    report = generate_analysis_report(products, images, groups)
    
    # Save all data
    print(f"\n{'='*80}")
    print("SAVING DATA")
    print(f"{'='*80}\n")
    
    # Save raw products
    products_file = OUTPUT_DIR / "aandrijftechniek_products_raw.json"
    with open(products_file, 'w', encoding='utf-8') as f:
        json.dump(products, f, indent=2, ensure_ascii=False)
    print(f"  💾 Raw products: {products_file.name}")
    
    # Save grouped data
    grouped_file = OUTPUT_DIR / "catalogus_aandrijftechniek_150922_grouped.json"
    with open(grouped_file, 'w', encoding='utf-8') as f:
        json.dump(groups, f, indent=2, ensure_ascii=False)
    print(f"  💾 Grouped data: {grouped_file.name}")
    
    # Save images metadata
    images_file = OUTPUT_DIR / "aandrijftechniek_images.json"
    with open(images_file, 'w', encoding='utf-8') as f:
        json.dump(images, f, indent=2, ensure_ascii=False)
    print(f"  💾 Images metadata: {images_file.name}")
    
    # Save analysis report
    report_file = OUTPUT_DIR / "aandrijftechniek_analysis_report.json"
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    print(f"  💾 Analysis report: {report_file.name}")
    
    # Copy to webshop
    webshop_data = PROJECT_ROOT.parent / "DemaWebshop" / "dema-webshop" / "public" / "data"
    if webshop_data.exists():
        webshop_file = webshop_data / "catalogus_aandrijftechniek_150922_grouped.json"
        with open(webshop_file, 'w', encoding='utf-8') as f:
            json.dump(groups, f, indent=2, ensure_ascii=False)
        print(f"  📤 Copied to webshop: {webshop_file.name}")
    
    print(f"\n{'='*80}")
    print("✅ ANALYSIS COMPLETE!")
    print(f"{'='*80}")
    print(f"\n📊 Results Summary:")
    print(f"   • {len(products)} SKUs extracted")
    print(f"   • {len(images)} images extracted")
    print(f"   • {len(groups)} product groups created")
    print(f"   • {report['summary']['image_coverage']}% image coverage")
    print(f"   • {report['summary']['avg_properties_per_sku']} avg properties per SKU")
    print(f"\n✨ All data saved and ready to use!")


if __name__ == "__main__":
    main()
