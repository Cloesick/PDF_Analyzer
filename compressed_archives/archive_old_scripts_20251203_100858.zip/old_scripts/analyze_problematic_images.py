"""
Analyze the problematic Makita images to understand what's being extracted
"""
from pathlib import Path
import json
from PIL import Image
import cv2
import numpy as np

PROJECT_ROOT = Path(__file__).parent
IMAGE_DIR = PROJECT_ROOT / "product-images-by-pdf" / "makita-catalogus-2022-nl"

# Problematic SKUs from user
PROBLEM_SKUS = [
    "BL4020", "BL4025", "BL4040", "BL4050F", "BL4080F", "BL1860B", "BL1850B", "BL1840B", "BL1830B",
    "DC40RA", "DC40RB", "DC18R", "DC18RD", "DC18RE", "DC18RC", "DC40",
    "ADPOO1", "ADP10", "DEAADP001G", "BEAPDC1200A01", "AD88",
    "PDC01", "BPS01", "81-6", "933-6", "624-2"
]

def analyze_image_type(image_path):
    """Analyze what type of product this image shows"""
    img = Image.open(image_path)
    img_array = np.array(img.convert('RGB'))
    
    width, height = img.size
    aspect_ratio = max(width, height) / min(width, height)
    
    # Analyze color
    r, g, b = img_array[:,:,0], img_array[:,:,1], img_array[:,:,2]
    
    # Check for green (battery indicator)
    green_dominant = np.mean(g) > np.mean(r) and np.mean(g) > np.mean(b)
    
    # Check for black plastic (many batteries/chargers)
    dark_pixels = np.sum((r < 50) & (g < 50) & (b < 50))
    dark_ratio = dark_pixels / (width * height)
    
    # Check for rectangular shape (batteries are very rectangular)
    gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, 50, 150)
    
    return {
        'width': width,
        'height': height,
        'aspect_ratio': aspect_ratio,
        'green_dominant': green_dominant,
        'dark_ratio': dark_ratio,
        'filename': image_path.name
    }

def main():
    print("="*80)
    print("ANALYZING PROBLEMATIC MAKITA IMAGES")
    print("="*80)
    
    images = list(IMAGE_DIR.glob("*.webp"))
    
    print(f"\nTotal images in folder: {len(images)}")
    
    # Find images matching problem SKUs
    problem_images = []
    
    for img_path in images:
        filename = img_path.name.upper()
        for sku in PROBLEM_SKUS:
            if sku.upper() in filename:
                problem_images.append(img_path)
                break
    
    print(f"Found {len(problem_images)} images matching problem SKUs")
    
    # Analyze each
    print("\n" + "="*80)
    print("ANALYSIS OF PROBLEM IMAGES")
    print("="*80)
    
    results = []
    for img_path in problem_images[:20]:  # First 20
        try:
            analysis = analyze_image_type(img_path)
            results.append(analysis)
            
            print(f"\n{analysis['filename']}")
            print(f"  Size: {analysis['width']}x{analysis['height']}")
            print(f"  Aspect: {analysis['aspect_ratio']:.2f}")
            print(f"  Green dominant: {analysis['green_dominant']}")
            print(f"  Dark ratio: {analysis['dark_ratio']:.2f}")
        except Exception as e:
            print(f"\nERROR: {img_path.name} - {e}")
    
    print("\n" + "="*80)
    print("CATEGORIES DETECTED")
    print("="*80)
    
    # Group by SKU prefix
    batteries = [img for img in problem_images if any(x in img.name.upper() for x in ['BL1', 'BL4'])]
    chargers = [img for img in problem_images if any(x in img.name.upper() for x in ['DC18', 'DC40'])]
    accessories = [img for img in problem_images if any(x in img.name.upper() for x in ['ADP', 'PDC', 'BPS'])]
    
    print(f"\nBatteries (BL*): {len(batteries)}")
    print(f"Chargers (DC*): {len(chargers)}")
    print(f"Accessories: {len(accessories)}")
    
    # Show samples
    print("\n" + "="*80)
    print("SAMPLE FILENAMES")
    print("="*80)
    
    print("\nBatteries:")
    for img in batteries[:5]:
        print(f"  - {img.name}")
    
    print("\nChargers:")
    for img in chargers[:5]:
        print(f"  - {img.name}")
    
    print("\nAccessories:")
    for img in accessories[:5]:
        print(f"  - {img.name}")

if __name__ == '__main__':
    main()
