"""
FINAL MAKITA TABLE EXTRACTOR
=============================
Extracts comparison tables and creates beautiful JSON with icons.

Handles tables where:
- Row 1: Product SKUs (DF002GZ01, DF002GD201, DF001GZ01, etc.)
- Column 1: Property names in Dutch
- Cells: Property values

Output includes specs + display with icons for frontend
"""

import pdfplumber
import json
import re
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "makita-catalogus-2022-nl.pdf"
OUTPUT_JSON = PROJECT_ROOT / "output" / "makita_comparison_tables.json"

# Property mappings with icons
PROPS = {
    'spanning': {'key': 'voltage', 'icon': '⚡'},
    'voltage': {'key': 'voltage', 'icon': '⚡'},
    'max. koppel zacht / hard': {'key': 'torque', 'icon': '🔧', 'label': 'Torque'},
    'max. koppel': {'key': 'torque', 'icon': '🔧', 'label': 'Torque'},
    'boorkop': {'key': 'chuck_size', 'icon': '🎯'},
    'klopboorfunctie': {'key': 'hammer_drill', 'icon': '🔨', 'type': 'bool'},
    'bijgeleverde accu\'s': {'key': 'batteries', 'icon': '🔋'},
    'bijgeleverde accu': {'key': 'batteries', 'icon': '🔋'},
    'accu': {'key': 'batteries', 'icon': '🔋'},
    'lader': {'key': 'charger', 'icon': '🔌'},
    'gewicht': {'key': 'weight', 'icon': '⚖️'},
    'prijs in € excl. btw': {'key': 'price_excl', 'icon': '💶', 'label': '(ex)', 'type': 'price'},
    'incl. btw': {'key': 'price_incl', 'icon': '💶', 'label': '(incl)', 'type': 'price'},
    'vermogen': {'key': 'power', 'icon': '⚡'},
    'toerental': {'key': 'rpm', 'icon': '🔄'},
    'toeren': {'key': 'rpm', 'icon': '🔄'},
    'max. toerental': {'key': 'max_rpm', 'icon': '🔄'},
    'zaagcapaciteit': {'key': 'saw_capacity', 'icon': '📏'},
    'zaagblad': {'key': 'blade', 'icon': '⚙️'},
    'schijf': {'key': 'disc', 'icon': '◯'},
    'diameter': {'key': 'diameter', 'icon': '◯'},
}

def is_sku(text):
    """Check if text looks like a Makita SKU"""
    if not text or len(str(text).strip()) < 5:
        return False
    text = str(text).strip()
    # Makita tool SKUs: 2-4 letters, 3-4 digits, optional letters+digits
    return bool(re.match(r'^[A-Z]{2,4}\d{3,4}[A-Z0-9]*$', text.upper()))

def parse_price(val):
    """Extract price"""
    if not val:
        return None
    val = str(val).replace('€', '').replace('.', '').replace(',', '.').strip()
    m = re.search(r'(\d+\.?\d*)', val)
    return float(m.group(1)) if m else None

def parse_bool(val):
    """Parse boolean"""
    if not val:
        return False
    v = str(val).strip().lower()
    return v not in ['', '-', 'nee', 'no', 'n.v.t.']

def clean(val):
    """Clean value"""
    if not val:
        return None
    v = str(val).strip()
    return None if v in ['', '-', 'None', 'n.v.t.'] else v

def find_prop(name):
    """Find property config"""
    if not name:
        return None
    n = name.lower().strip()
    for key, cfg in PROPS.items():
        if key in n:
            return cfg
    return None

def extract_from_table(table, page_num):
    """Extract products from comparison table"""
    if not table or len(table) < 3:
        return []
    
    # Find header row with SKUs
    header_idx = None
    sku_cols = []
    
    for idx in range(min(5, len(table))):
        row = table[idx]
        if not row:
            continue
        
        # Count SKUs in this row (skip first column)
        skus = []
        for col_idx, cell in enumerate(row[1:], 1):
            if cell and is_sku(cell):
                skus.append({'sku': str(cell).strip(), 'col': col_idx})
        
        if len(skus) >= 2:  # Found comparison table
            header_idx = idx
            sku_cols = skus
            break
    
    if not sku_cols:
        return []
    
    # Initialize products
    products = []
    for s in sku_cols:
        products.append({
            'sku': s['sku'],
            'col': s['col'],
            'page': page_num,
            'specs': {},
            'display': {}
        })
    
    # Extract properties from rows after header
    for row_idx in range(header_idx + 1, len(table)):
        row = table[row_idx]
        if not row or len(row) < 2:
            continue
        
        prop_name = row[0]
        if not prop_name:
            continue
        
        cfg = find_prop(str(prop_name))
        if not cfg:
            continue
        
        # Extract value for each product
        for p in products:
            if p['col'] >= len(row):
                continue
            
            val = row[p['col']]
            ptype = cfg.get('type', 'text')
            
            # Parse value
            if ptype == 'price':
                parsed = parse_price(val)
            elif ptype == 'bool':
                parsed = parse_bool(val)
            else:
                parsed = clean(val)
            
            if parsed is None:
                continue
            
            key = cfg['key']
            icon = cfg['icon']
            label = cfg.get('label', '')
            
            # Store spec
            p['specs'][key] = parsed
            
            # Create display
            if ptype == 'bool':
                disp = f"{icon} {'Yes' if parsed else 'No'}"
            elif ptype == 'price':
                disp = f"{icon} € {parsed:.2f} {label}".strip()
            else:
                disp = f"{icon} {parsed}"
                if label:
                    disp += f" ({label})"
            
            p['display'][key] = disp
    
    # Keep products with specs
    return [p for p in products if p['specs']]

def main():
    print("="*80)
    print("MAKITA COMPARISON TABLE EXTRACTOR - FINAL")
    print("="*80)
    
    all_products = {}
    stats = {'pages': 0, 'tables': 0, 'products_found': 0}
    
    print(f"\n📄 Processing: {PDF_PATH.name}\n")
    
    with pdfplumber.open(PDF_PATH) as pdf:
        for page_num, page in enumerate(pdf.pages, 1):
            stats['pages'] += 1
            tables = page.extract_tables()
            
            if not tables:
                continue
            
            for tidx, table in enumerate(tables):
                stats['tables'] += 1
                products = extract_from_table(table, page_num)
                
                if products:
                    print(f"  ✅ Page {page_num}, Table {tidx+1}: {len(products)} products")
                    for p in products:
                        print(f"     {p['sku']}: {list(p['specs'].keys())}")
                        if p['sku'] in all_products:
                            all_products[p['sku']]['specs'].update(p['specs'])
                            all_products[p['sku']]['display'].update(p['display'])
                        else:
                            all_products[p['sku']] = {
                                'sku': p['sku'],
                                'page': p['page'],
                                'specifications': p['specs'],
                                'display': p['display']
                            }
                            stats['products_found'] += 1
            
            if page_num % 20 == 0:
                print(f"\n  📊 Scanned {page_num} pages, found {len(all_products)} products\n")
    
    # Create output
    output = {
        'metadata': {
            'source': 'makita-catalogus-2022-nl',
            'total_products': len(all_products),
            'pages_scanned': stats['pages'],
            'tables_scanned': stats['tables']
        },
        'products': list(all_products.values())
    }
    
    # Save
    OUTPUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print(f"\n{'='*80}")
    print("✅ EXTRACTION COMPLETE")
    print(f"{'='*80}")
    print(f"\nStatistics:")
    print(f"  Pages scanned:     {stats['pages']}")
    print(f"  Tables scanned:    {stats['tables']}")
    print(f"  Products extracted: {len(all_products)}")
    print(f"\n💾 Output: {OUTPUT_JSON}")
    
    # Show beautiful samples
    print(f"\n📦 Sample Products (Frontend Format):\n")
    for sku, p in list(all_products.items())[:5]:
        print(f"┌{'─'*40}┐")
        print(f"│ Model: {sku:34s} │")
        print(f"│{' '*40}│")
        for v in p['display'].values():
            print(f"│ {v:38s} │")
        if 'price_excl' in p['specifications']:
            print(f"│ 💶 € {p['specifications']['price_excl']:.2f} (ex){' '*19}│")
        print(f"└{'─'*40}┘\n")
    
    print(f"{'='*80}\n")
    
    return output

if __name__ == "__main__":
    main()
