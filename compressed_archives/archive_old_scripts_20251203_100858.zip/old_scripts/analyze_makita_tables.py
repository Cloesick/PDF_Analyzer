"""
Analyze Makita PDF Table Structure
===================================
Investigate how tables are structured in the Makita catalog
"""
import pdfplumber
from pathlib import Path
import json

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "makita-catalogus-2022-nl.pdf"

def analyze_tables(start_page=1, end_page=20):
    """Analyze table structure in first pages"""
    print("=" * 80)
    print("ANALYZING MAKITA TABLE STRUCTURE")
    print("=" * 80)
    
    with pdfplumber.open(PDF_PATH) as pdf:
        for page_num in range(start_page - 1, min(end_page, len(pdf.pages))):
            page = pdf.pages[page_num]
            
            print(f"\n{'='*80}")
            print(f"PAGE {page_num + 1}")
            print(f"{'='*80}")
            
            # Try to find tables
            tables = page.extract_tables()
            
            if tables:
                print(f"\n[OK] Found {len(tables)} table(s) on page {page_num + 1}")
                
                for table_idx, table in enumerate(tables):
                    print(f"\nTABLE {table_idx + 1}:")
                    print(f"   Rows: {len(table)}")
                    print(f"   Columns: {len(table[0]) if table else 0}")
                    
                    # Show first few rows
                    print(f"\n   First 5 rows:")
                    for row_idx, row in enumerate(table[:5]):
                        print(f"   Row {row_idx}: {row[:5]}")  # First 5 columns
                    
                    # Check for vertical headers (first row has product names)
                    if table:
                        first_row = table[0]
                        print(f"\n   First row (potential product names):")
                        for idx, cell in enumerate(first_row[:8]):
                            if cell:
                                print(f"      Col {idx}: '{cell[:50]}...' " if len(str(cell)) > 50 else f"      Col {idx}: '{cell}'")
                    
                    # Check for price patterns
                    print(f"\n   Looking for prices...")
                    price_found = False
                    for row_idx, row in enumerate(table[:10]):
                        for col_idx, cell in enumerate(row):
                            if cell and isinstance(cell, str):
                                # Look for euro symbols, price patterns
                                if 'EUR' in cell or 'excl' in cell.lower() or 'incl' in cell.lower() or 'btw' in cell.lower() or ',' in cell:
                                    print(f"      Row {row_idx}, Col {col_idx}: '{cell}'")
                                    price_found = True
                    
                    if not price_found:
                        print(f"      No obvious price markers found")
                    
                    print("\n   " + "-" * 76)
            else:
                print(f"\n[NO TABLES] No tables found on page {page_num + 1}")
                
                # Try to extract text to see what's there
                text = page.extract_text()
                if text:
                    lines = text.split('\n')[:10]
                    print(f"\n   First 10 lines of text:")
                    for idx, line in enumerate(lines):
                        print(f"   {idx}: {line[:80]}")

if __name__ == '__main__':
    # Analyze first 20 pages to understand table structure
    analyze_tables(start_page=1, end_page=20)
