"""
AANDRIJFTECHNIEK CATALOG ANALYZER
==================================

Comprehensive analysis script for catalogus-aandrijftechniek-150922.pdf that:
- Extracts all text content organized by page
- Identifies and categorizes products (motors, gearboxes, drives)
- Tracks which products share the same images
- Creates a structured data output with product relationships

Author: PDF Analyzer System
"""

import pdfplumber
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, asdict, field
import hashlib

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ROOT = Path(__file__).parent
INPUT_PDF = PROJECT_ROOT / "input_pdfs" / "catalogus-aandrijftechniek-150922.pdf"
OUTPUT_DIR = PROJECT_ROOT / "output"
OUTPUT_JSON = OUTPUT_DIR / "aandrijftechniek_analysis.json"

# Product detection patterns for drive technology
PRODUCT_PATTERNS = [
    re.compile(r'\b([A-Z]{2,}\d+[-A-Z0-9]*)\b'),  # Product codes
    re.compile(r'\b(M\d+[A-Z]?)\b'),  # Motor codes like M132
    re.compile(r'\b(\d+x\d+(?:x\d+)?)\b', re.IGNORECASE),  # Dimensions
    re.compile(r'\b(IE[1-4])\b', re.IGNORECASE),  # Efficiency classes
    re.compile(r'\b(\d+mm)\b', re.IGNORECASE),  # Measurements
]

# Category keywords for drive technology
CATEGORY_KEYWORDS = {
    'motoren': ['motor', 'motoren', 'elektromotor', 'electric motor', 'engine'],
    'tandwielkasten': ['tandwielkast', 'gearbox', 'versnellingsbak', 'reducer', 'reduction'],
    'frequentie_omvormers': ['frequentie', 'omvormer', 'frequency', 'inverter', 'vfd', 'variable frequency'],
    'koppeling': ['koppeling', 'coupling', 'koppelen', 'connect'],
    'reductoren': ['reductor', 'reduction', 'reductie'],
    'aandrijving': ['aandrijving', 'drive', 'transmission'],
    'lagers': ['lager', 'bearing', 'kogellager'],
    'rem': ['rem', 'brake', 'remmen'],
    'accessoires': ['accessoire', 'accessory', 'toebehoren', 'hulpstuk'],
}

# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class ProductItem:
    """Represents a single product found in the PDF"""
    product_id: str
    page_number: int
    category: str
    description: str
    specifications: Dict[str, str]
    text_snippet: str
    image_hash: Optional[str] = None
    shared_image_with: List[str] = field(default_factory=list)
    coordinates: Optional[Dict] = None
    
@dataclass
class ImageInfo:
    """Information about an image in the PDF"""
    image_hash: str
    page_number: int
    image_index: int
    bbox: Dict
    width: int
    height: int
    products_using_image: List[str] = field(default_factory=list)
    
@dataclass
class PageAnalysis:
    """Analysis results for a single page"""
    page_number: int
    text_content: str
    products_found: List[ProductItem]
    images_found: List[ImageInfo]
    detected_category: str
    word_count: int
    
@dataclass
class PDFAnalysisResults:
    """Complete analysis results for the PDF"""
    pdf_name: str
    total_pages: int
    total_products: int
    total_images: int
    categories: Dict[str, int]
    pages: List[PageAnalysis]
    product_image_mapping: Dict[str, List[str]]
    shared_images: List[Dict]
    
# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def compute_image_hash(image_bytes: bytes) -> str:
    """Compute a hash for an image to detect duplicates"""
    return hashlib.md5(image_bytes).hexdigest()

def extract_specifications(text: str) -> Dict[str, str]:
    """Extract technical specifications from text"""
    specs = {}
    
    # Power rating (kW) with units
    power_match = re.search(r'(\d+(?:[.,]\d+)?)\s*kW', text, re.IGNORECASE)
    if power_match:
        value = power_match.group(1).replace(',', '.')
        specs['power'] = f"{value} kW"
        specs['power_kw'] = value
    
    # Power rating (HP) with units
    hp_match = re.search(r'(\d+(?:[.,]\d+)?)\s*(?:HP|PK)', text, re.IGNORECASE)
    if hp_match:
        value = hp_match.group(1).replace(',', '.')
        specs['power_hp_rating'] = f"{value} HP"
        specs['power_hp'] = value
    
    # RPM (revolutions per minute) with units
    rpm_match = re.search(r'(\d+)\s*(?:rpm|t/min|min-1)', text, re.IGNORECASE)
    if rpm_match:
        specs['speed'] = f"{rpm_match.group(1)} rpm"
        specs['rpm'] = rpm_match.group(1)
    
    # Voltage with units
    voltage_match = re.search(r'(\d+)\s*V(?:olt)?', text, re.IGNORECASE)
    if voltage_match:
        specs['voltage'] = f"{voltage_match.group(1)} V"
        specs['voltage_v'] = voltage_match.group(1)
    
    # Frequency with units
    freq_match = re.search(r'(\d+)\s*Hz', text, re.IGNORECASE)
    if freq_match:
        specs['frequency'] = f"{freq_match.group(1)} Hz"
        specs['frequency_hz'] = freq_match.group(1)
    
    # Torque with units
    torque_match = re.search(r'(\d+(?:[.,]\d+)?)\s*Nm', text, re.IGNORECASE)
    if torque_match:
        value = torque_match.group(1).replace(',', '.')
        specs['torque'] = f"{value} Nm"
        specs['torque_nm'] = value
    
    # Efficiency class
    efficiency_match = re.search(r'\b(IE[1-4])\b', text, re.IGNORECASE)
    if efficiency_match:
        specs['efficiency_class'] = efficiency_match.group(1).upper()
    
    # Protection class
    ip_match = re.search(r'\b(IP\s*\d{2})\b', text, re.IGNORECASE)
    if ip_match:
        specs['protection_class'] = ip_match.group(1).replace(' ', '')
    
    # Frame size
    frame_match = re.search(r'\b([1-4]\d{2}[SMLC]?)\b', text)
    if frame_match:
        specs['frame_size'] = frame_match.group(1)
    
    # Gear ratio
    ratio_match = re.search(r'i\s*=\s*(\d+(?:[.,:\s]\d+)?)', text, re.IGNORECASE)
    if not ratio_match:
        ratio_match = re.search(r'ratio\s*:?\s*(\d+(?:[.,:\s]\d+)?)', text, re.IGNORECASE)
    if ratio_match:
        specs['gear_ratio'] = ratio_match.group(1).replace(',', '.').replace(' ', ':')
    
    # Weight with units
    weight_match = re.search(r'(\d+(?:[.,]\d+)?)\s*kg', text, re.IGNORECASE)
    if weight_match:
        value = weight_match.group(1).replace(',', '.')
        specs['weight'] = f"{value} kg"
        specs['weight_kg'] = value
    
    # Mounting position
    mounting_match = re.search(r'\b([BVH]\d+)\b', text)
    if mounting_match:
        specs['mounting_position'] = mounting_match.group(1)
    
    # Poles
    poles_match = re.search(r'(\d)\s*-?pol[es]*', text, re.IGNORECASE)
    if poles_match:
        specs['poles'] = poles_match.group(1)
    
    return specs

def extract_table_data(page) -> List[Dict]:
    """Extract table data with headers for better categorization"""
    table_products = []
    
    try:
        tables = page.extract_tables()
        if not tables:
            return table_products
        
        print(f"    → Found {len(tables)} tables on page")
        
        for table_idx, table in enumerate(tables):
            if not table or len(table) < 2:  # Need at least header + 1 row
                print(f"    → Table {table_idx}: Skipped (too small or empty)")
                continue
            
            print(f"    → Table {table_idx}: {len(table)} rows, {len(table[0]) if table else 0} columns")
            
            # First row is typically the header
            headers = [str(cell).strip() if cell else '' for cell in table[0]]
            
            # Process each data row
            for row_idx, row in enumerate(table[1:], start=1):
                if not row or all(not cell for cell in row):
                    continue
                
                row_data = {}
                for col_idx, (header, cell) in enumerate(zip(headers, row)):
                    if cell:
                        cell_value = str(cell).strip()
                        if header and cell_value:
                            # Clean header name
                            clean_header = header.lower().replace(' ', '_').replace('.', '')
                            row_data[clean_header] = cell_value
                
                # Extract specifications from the row data
                specs = {}
                description_parts = []
                
                # First, store ALL columns as raw data (critical)
                for key, value in row_data.items():
                    specs[f'table_{key}'] = value
                
                # Now parse specific specifications with units
                for key, value in row_data.items():
                    
                    # Power (kW)
                    if any(term in key for term in ['power', 'vermogen', 'kw']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            val = num_match.group(1).replace(',', '.')
                            specs['power'] = f"{val} kW"
                            specs['power_kw'] = val
                    
                    # Power (HP)
                    if any(term in key for term in ['hp', 'pk']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            val = num_match.group(1).replace(',', '.')
                            specs['power_hp_rating'] = f"{val} HP"
                            specs['power_hp'] = val
                    
                    # RPM / Speed
                    if any(term in key for term in ['rpm', 'toeren', 'speed']):
                        num_match = re.search(r'(\d+)', value)
                        if num_match:
                            specs['speed'] = f"{num_match.group(1)} rpm"
                            specs['rpm'] = num_match.group(1)
                    
                    # Voltage
                    if any(term in key for term in ['voltage', 'spanning', 'volt']):
                        num_match = re.search(r'(\d+)', value)
                        if num_match:
                            specs['voltage'] = f"{num_match.group(1)} V"
                            specs['voltage_v'] = num_match.group(1)
                    
                    # Frequency
                    if any(term in key for term in ['frequency', 'frequentie', 'hz']):
                        num_match = re.search(r'(\d+)', value)
                        if num_match:
                            specs['frequency'] = f"{num_match.group(1)} Hz"
                            specs['frequency_hz'] = num_match.group(1)
                    
                    # Torque
                    if any(term in key for term in ['torque', 'koppel', 'nm']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            val = num_match.group(1).replace(',', '.')
                            specs['torque'] = f"{val} Nm"
                            specs['torque_nm'] = val
                    
                    # Weight (including q in kg/m)
                    if any(term in key for term in ['weight', 'gewicht', 'kg']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            val = num_match.group(1).replace(',', '.')
                            if 'kg/m' in key or '/m' in key or 'q' in key:
                                specs['weight_per_meter'] = f"{val} kg/m"
                                specs['weight_per_meter_kg'] = val
                            else:
                                specs['weight'] = f"{val} kg"
                                specs['weight_kg'] = val
                    
                    # CRITICAL: Width (breedte)
                    if any(term in key for term in ['breedte', 'width']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            val = num_match.group(1).replace(',', '.')
                            specs['width'] = f"{val} mm"
                            specs['width_mm'] = val
                    
                    # CRITICAL: Height (hoogte)
                    if any(term in key for term in ['hoogte', 'height']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            val = num_match.group(1).replace(',', '.')
                            specs['height'] = f"{val} mm"
                            specs['height_mm'] = val
                    
                    # CRITICAL: Bottom width (bodembreedte)
                    if any(term in key for term in ['bodem', 'bottom']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            val = num_match.group(1).replace(',', '.')
                            specs['bottom_width'] = f"{val} mm"
                            specs['bottom_width_mm'] = val
                    
                    # CRITICAL: Pitch length (steeklengte)
                    if any(term in key for term in ['steeklengte', 'pitch']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            val = num_match.group(1).replace(',', '.')
                            specs['pitch_length'] = f"{val} mm"
                            specs['pitch_length_mm'] = val
                    
                    # CRITICAL: Bearing clearance (lagerspeling)
                    if any(term in key for term in ['lagerspeling', 'clearance', 'speling']):
                        specs['bearing_clearance'] = value.upper()
                    
                    # CRITICAL: Bearing housing (lagerhuis)
                    if any(term in key for term in ['lagerhuis', 'bearing_housing', 'housing']):
                        specs['bearing_housing'] = value
                    
                    # CRITICAL: Dynamic load (dynamische belasting)
                    if any(term in key for term in ['dynamische', 'dynamic']) and any(term in key for term in ['belasting', 'load']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            val = num_match.group(1).replace(',', '.')
                            specs['dynamic_load'] = f"{val} kN"
                            specs['dynamic_load_kn'] = val
                    
                    # CRITICAL: Static load (statische belasting)
                    if any(term in key for term in ['statische', 'static']) and any(term in key for term in ['belasting', 'load']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            val = num_match.group(1).replace(',', '.')
                            specs['static_load'] = f"{val} kN"
                            specs['static_load_kn'] = val
                    
                    # CRITICAL: Maximum RPM with grease (vetsmering)
                    if any(term in key for term in ['vetsmering', 'grease']):
                        num_match = re.search(r'(\d+)', value)
                        if num_match:
                            specs['max_rpm_grease'] = f"{num_match.group(1)} rpm"
                            specs['max_rpm_grease_value'] = num_match.group(1)
                    
                    # CRITICAL: Maximum RPM with oil (oliesmering)
                    if any(term in key for term in ['oliesmering', 'oil']) and 'rpm' in key:
                        num_match = re.search(r'(\d+)', value)
                        if num_match:
                            specs['max_rpm_oil'] = f"{num_match.group(1)} rpm"
                            specs['max_rpm_oil_value'] = num_match.group(1)
                    
                    # Frame size
                    if any(term in key for term in ['frame', 'bouw']) and 'maat' not in key:
                        specs['frame_size'] = value
                    
                    # Efficiency class
                    if any(term in key for term in ['efficiency', 'ie']):
                        specs['efficiency_class'] = value.upper()
                    
                    # Protection class
                    if any(term in key for term in ['protection', 'ip']):
                        specs['protection_class'] = value.upper()
                    
                    # Type/Model
                    if any(term in key for term in ['type', 'model', 'artikel']):
                        specs['model'] = value
                        description_parts.append(value)
                    
                    # Order numbers
                    if any(term in key for term in ['bestelnr', 'order', 'code']):
                        specs['order_number'] = value
                        description_parts.append(f"Order: {value}")
                
                if specs or description_parts:
                    table_products.append({
                        'table_index': table_idx,
                        'row_index': row_idx,
                        'specifications': specs,
                        'description_parts': description_parts,
                        'raw_data': row_data
                    })
    
    except Exception as e:
        print(f"  Warning: Error extracting table data: {e}")
    
    return table_products

def detect_category(text: str) -> str:
    """Detect product category based on text content"""
    text_lower = text.lower()
    
    category_scores = defaultdict(int)
    for category, keywords in CATEGORY_KEYWORDS.items():
        for keyword in keywords:
            count = text_lower.count(keyword.lower())
            category_scores[category] += count
    
    if category_scores:
        return max(category_scores.items(), key=lambda x: x[1])[0]
    
    return 'algemeen'  # General

def extract_product_codes(text: str) -> List[str]:
    """Extract potential product codes from text"""
    codes = set()
    
    for pattern in PRODUCT_PATTERNS:
        matches = pattern.findall(text)
        codes.update(matches)
    
    return sorted(list(codes))

def find_products_in_text(text: str, page_num: int, category: str) -> List[ProductItem]:
    """Identify individual products from text content"""
    products = []
    
    # Split text into potential product blocks
    blocks = re.split(r'\n\s*\n|\n{3,}', text)
    
    for block_idx, block in enumerate(blocks):
        if len(block.strip()) < 15:  # Skip very short blocks
            continue
        
        # Extract product codes from this block
        codes = extract_product_codes(block)
        
        # Check if this block contains product-relevant keywords
        has_product_keywords = any(
            keyword in block.lower() 
            for keywords in CATEGORY_KEYWORDS.values() 
            for keyword in keywords
        )
        
        if codes or has_product_keywords:
            # Create a product entry
            primary_code = codes[0] if codes else f"PROD_{block_idx}"
            specs = extract_specifications(block)
            
            # Extract a clean description
            lines = [line.strip() for line in block.split('\n') if line.strip()]
            description = ' '.join(lines[:2])  # Take first 2 lines
            
            product = ProductItem(
                product_id=f"P{page_num:03d}_{block_idx:03d}_{primary_code}",
                page_number=page_num,
                category=category,
                description=description[:200],  # Limit description length
                specifications=specs,
                text_snippet=block[:300],  # Keep snippet for context
            )
            
            products.append(product)
    
    return products

def extract_images_from_page(page, page_num: int) -> List[ImageInfo]:
    """Extract all images from a page with metadata"""
    images = []
    
    try:
        if hasattr(page, 'images'):
            for img_idx, img in enumerate(page.images):
                try:
                    # Extract image bbox
                    bbox = {
                        'x0': img.get('x0', 0),
                        'y0': img.get('y0', 0),
                        'x1': img.get('x1', 0),
                        'y1': img.get('y1', 0),
                    }
                    
                    image_info = ImageInfo(
                        image_hash=f"img_p{page_num}_i{img_idx}_{hash(str(bbox))}",
                        page_number=page_num,
                        image_index=img_idx,
                        bbox=bbox,
                        width=int(bbox['x1'] - bbox['x0']),
                        height=int(bbox['y1'] - bbox['y0']),
                    )
                    
                    images.append(image_info)
                    
                except Exception as e:
                    print(f"  Warning: Could not process image {img_idx} on page {page_num}: {e}")
                    continue
    except Exception as e:
        print(f"  Warning: Could not extract images from page {page_num}: {e}")
    
    return images

def link_products_to_images(products: List[ProductItem], images: List[ImageInfo]) -> None:
    """Link products to their associated images based on proximity"""
    if not images:
        return
    
    for product in products:
        # For simplicity, assign the first image on the page
        if images:
            closest_image = images[0]
            product.image_hash = closest_image.image_hash
            closest_image.products_using_image.append(product.product_id)

# ============================================================================
# MAIN ANALYSIS FUNCTION
# ============================================================================

def analyze_pdf() -> PDFAnalysisResults:
    """
    Main function to analyze the Aandrijftechniek catalog
    Returns comprehensive analysis results
    """
    print(f"\n{'='*70}")
    print(f"ANALYZING PDF: {INPUT_PDF.name}")
    print(f"{'='*70}\n")
    
    if not INPUT_PDF.exists():
        raise FileNotFoundError(f"PDF not found: {INPUT_PDF}")
    
    pages_analysis = []
    all_products = []
    all_images = []
    category_counts = defaultdict(int)
    
    with pdfplumber.open(INPUT_PDF) as pdf:
        total_pages = len(pdf.pages)
        print(f"Total pages: {total_pages}\n")
        
        for page_num, page in enumerate(pdf.pages, start=1):
            print(f"Processing page {page_num}/{total_pages}...")
            
            # Extract text
            text = page.extract_text() or ""
            word_count = len(text.split())
            
            # Detect category for this page
            page_category = detect_category(text)
            category_counts[page_category] += 1
            
            # Extract table data first (more structured)
            table_data = extract_table_data(page)
            
            # Collect all products for this page
            page_products = []
            
            # Convert table data to products
            for table_item in table_data:
                specs = table_item['specifications']
                desc_parts = table_item['description_parts']
                
                # Create product ID
                order_num = specs.get('order_number', f"T{table_item['table_index']}R{table_item['row_index']}")
                product_id = f"P{page_num:03d}_TBL{table_item['table_index']}_{order_num}"
                
                # Build description
                if desc_parts:
                    description = ' - '.join(desc_parts)
                else:
                    description = f"Table product from page {page_num}"
                
                product = ProductItem(
                    product_id=product_id,
                    page_number=page_num,
                    category=page_category,
                    description=description[:200],
                    specifications=specs,
                    text_snippet=f"Table {table_item['table_index']}, Row {table_item['row_index']}",
                )
                page_products.append(product)
                all_products.append(product)
            
            # Find products in text (for non-table content)
            text_products = find_products_in_text(text, page_num, page_category)
            page_products.extend(text_products)
            all_products.extend(text_products)
            
            # Extract images
            images = extract_images_from_page(page, page_num)
            all_images.extend(images)
            
            # Link products to images (link both table and text products)
            link_products_to_images(page_products, images)
            
            # Create page analysis with ALL products from this page
            page_analysis = PageAnalysis(
                page_number=page_num,
                text_content=text[:500] + "..." if len(text) > 500 else text,
                products_found=page_products,  # Now includes BOTH table and text products
                images_found=images,
                detected_category=page_category,
                word_count=word_count,
            )
            pages_analysis.append(page_analysis)
            
            print(f"  > Found {len(page_products)} products ({len(table_data)} from tables), {len(images)} images")
            print(f"  ✓ Category: {page_category}")
            print(f"  ✓ Word count: {word_count}")
    
    # Analyze shared images
    image_to_products = defaultdict(list)
    for product in all_products:
        if product.image_hash:
            image_to_products[product.image_hash].append(product.product_id)
    
    shared_images = [
        {
            'image_hash': img_hash,
            'product_count': len(prod_ids),
            'products': prod_ids
        }
        for img_hash, prod_ids in image_to_products.items()
        if len(prod_ids) > 1
    ]
    
    # Update products with shared image information
    for shared_img in shared_images:
        img_hash = shared_img['image_hash']
        prod_ids = shared_img['products']
        
        for product in all_products:
            if product.image_hash == img_hash:
                product.shared_image_with = [pid for pid in prod_ids if pid != product.product_id]
    
    # Create final results
    results = PDFAnalysisResults(
        pdf_name=INPUT_PDF.name,
        total_pages=total_pages,
        total_products=len(all_products),
        total_images=len(all_images),
        categories=dict(category_counts),
        pages=pages_analysis,
        product_image_mapping=dict(image_to_products),
        shared_images=shared_images,
    )
    
    return results

def save_results(results: PDFAnalysisResults) -> None:
    """Save analysis results to JSON file"""
    OUTPUT_DIR.mkdir(exist_ok=True)
    
    # Convert dataclasses to dictionaries
    results_dict = {
        'pdf_name': results.pdf_name,
        'total_pages': results.total_pages,
        'total_products': results.total_products,
        'total_images': results.total_images,
        'categories': results.categories,
        'pages': [
            {
                'page_number': page.page_number,
                'text_content': page.text_content,
                'products_found': [asdict(p) for p in page.products_found],
                'images_found': [asdict(img) for img in page.images_found],
                'detected_category': page.detected_category,
                'word_count': page.word_count,
            }
            for page in results.pages
        ],
        'product_image_mapping': results.product_image_mapping,
        'shared_images': results.shared_images,
    }
    
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(results_dict, f, indent=2, ensure_ascii=False)
    
    print(f"\n{'='*70}")
    print(f"✓ Results saved to: {OUTPUT_JSON}")
    print(f"{'='*70}")

def print_summary(results: PDFAnalysisResults) -> None:
    """Print a human-readable summary of the analysis"""
    print(f"\n{'='*70}")
    print(f"ANALYSIS SUMMARY")
    print(f"{'='*70}\n")
    
    print(f"PDF Name: {results.pdf_name}")
    print(f"Total Pages: {results.total_pages}")
    print(f"Total Products Found: {results.total_products}")
    print(f"Total Images Found: {results.total_images}")
    
    print(f"\nCategories Distribution:")
    for category, count in sorted(results.categories.items(), key=lambda x: x[1], reverse=True):
        print(f"  • {category}: {count} pages")
    
    print(f"\nShared Images:")
    print(f"  • {len(results.shared_images)} images are shared between multiple products")
    
    if results.shared_images:
        print(f"\nTop Shared Images:")
        for idx, shared in enumerate(sorted(results.shared_images, key=lambda x: x['product_count'], reverse=True)[:5], 1):
            print(f"  {idx}. Image {shared['image_hash'][:16]}... used by {shared['product_count']} products")
            print(f"     Products: {', '.join(shared['products'][:3])}")
            if len(shared['products']) > 3:
                print(f"     ... and {len(shared['products']) - 3} more")
    
    print(f"\nPage-by-Page Summary:")
    for page in results.pages[:10]:
        print(f"  Page {page.page_number}: {len(page.products_found)} products, "
              f"{len(page.images_found)} images, category: {page.detected_category}")
    
    if len(results.pages) > 10:
        print(f"  ... and {len(results.pages) - 10} more pages")
    
    print()

# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    try:
        # Run analysis
        results = analyze_pdf()
        
        # Print summary
        print_summary(results)
        
        # Save results
        save_results(results)
        
        print(f"\n✓ Analysis complete! Check {OUTPUT_JSON} for detailed results.\n")
        
    except Exception as e:
        print(f"\n✗ Error during analysis: {e}")
        import traceback
        traceback.print_exc()
        exit(1)
