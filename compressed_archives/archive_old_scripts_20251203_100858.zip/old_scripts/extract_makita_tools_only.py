"""
Extract ONLY actual Makita power tools - NO batteries, chargers, or accessories
Improved SKU detection from tables with proper formats like DDG460ZX7, UR002GZ01, etc.
"""
import fitz
import pdfplumber
from PIL import Image
import cv2
import numpy as np
from pathlib import Path
import json
import io
import re

# Try to import pytesseract, but make it optional
try:
    import pytesseract
    pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
    OCR_AVAILABLE = True
except:
    OCR_AVAILABLE = False
    print("[WARNING] pytesseract not available - OCR disabled")

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "product-images-by-pdf"
OUTPUT_JSON_DIR = PROJECT_ROOT / "output"

WEBP_QUALITY = 90
IMAGE_DPI = 300

# === TOOL-ONLY FILTERING ===

# SKU patterns for ACTUAL TOOLS (not batteries/chargers/accessories)
TOOL_SKU_PATTERNS = [
    r'\b[A-Z]{2,4}\d{3,4}[A-Z]{1,4}\d{0,3}\b',  # DDG460ZX7, GA005GM201, HS010G
    r'\b[A-Z]{2}\d{3}[A-Z]{2}\d{3}\b',          # UR002GZ01, TW004GM201
    r'\b[A-Z]{3}\d{3}[A-Z]{2,4}\d*\b',          # DHS680RTJ, DUC307ZX2
]

# Exclusion patterns for NON-TOOLS
EXCLUDE_SKU_PATTERNS = [
    r'^BL\d+',          # BL1830B, BL4020, BL4050F (batteries)
    r'^DC\d+',          # DC18R, DC40RA (chargers)
    r'^ADP\d+',         # ADP10, ADPOO1 (adapters)
    r'^DEAADP',         # DEAADP001G (adapters)
    r'^AD\d+',          # AD88 (accessories)
    r'^PDC\d+',         # PDC01 (accessories)
    r'^BPS\d+',         # BPS01 (accessories)
    r'^BEAPDC',         # BEAPDC1200A01 (accessories)
    r'^\d+-\d+$',       # 81-6, 933-6, 198720-9 (part numbers)
    r'^\d{5,6}$',       # 56169, 54329 (part numbers)
    r'^[A-Z]\d{1,2}$',  # B18, PL11, ER55 (accessories)
    r'^IPX\d+$',        # IPX4 (rating, not a product)
]

def is_tool_sku(sku):
    """Check if SKU represents an actual power tool"""
    if not sku or len(sku) < 4:
        return False
    
    sku_upper = sku.upper().strip()
    
    # Check exclusions first
    for pattern in EXCLUDE_SKU_PATTERNS:
        if re.match(pattern, sku_upper):
            return False
    
    # Check if matches tool patterns
    for pattern in TOOL_SKU_PATTERNS:
        if re.match(pattern, sku_upper):
            return True
    
    return False

def is_tool_image(pil_image):
    """Check if image shows an actual power tool, not battery/charger/accessory"""
    img_array = np.array(pil_image.convert('RGB'))
    width, height = pil_image.size
    
    # === SIZE CHECKS ===
    if width < 200 or height < 200:
        return False, {'reason': 'too_small', 'size': f'{width}x{height}'}
    
    if width * height < 50000:
        return False, {'reason': 'insufficient_area', 'area': width * height}
    
    # === ASPECT RATIO ===
    aspect_ratio = max(width, height) / min(width, height)
    
    # Batteries are very flat/wide (ratio > 2.0)
    if aspect_ratio > 2.2:
        return False, {'reason': 'battery_aspect', 'ratio': aspect_ratio}
    
    # Tools are more square/vertical
    if aspect_ratio > 3.0:
        return False, {'reason': 'extreme_aspect', 'ratio': aspect_ratio}
    
    # === COLOR ANALYSIS ===
    r, g, b = img_array[:,:,0], img_array[:,:,1], img_array[:,:,2]
    
    # Battery images often have green LEDs
    green_pixels = np.sum((g > 150) & (g > r * 1.2) & (g > b * 1.2))
    green_ratio = green_pixels / (width * height)
    
    if green_ratio > 0.1:  # More than 10% bright green = likely battery
        return False, {'reason': 'battery_green', 'green_ratio': green_ratio}
    
    # Color variance (tools have complex surfaces)
    color_variance = np.std(r) + np.std(g) + np.std(b)
    
    if color_variance < 30:
        return False, {'reason': 'low_color_variance', 'variance': color_variance}
    
    # === TEXTURE ANALYSIS ===
    gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
    
    # Edge density
    edges = cv2.Canny(gray, 50, 150)
    edge_density = np.sum(edges > 0) / (width * height)
    
    if edge_density < 0.03:
        return False, {'reason': 'low_edge_density', 'density': edge_density}
    
    if edge_density > 0.30:  # Too many edges = diagram/text
        return False, {'reason': 'excessive_edges', 'density': edge_density}
    
    # === CONTENT CHECK ===
    white_pixels = np.sum((r > 240) & (g > 240) & (b > 240))
    white_ratio = white_pixels / (width * height)
    
    if white_ratio > 0.90:
        return False, {'reason': 'mostly_white', 'ratio': white_ratio}
    
    # Dark ratio (chargers are often black plastic)
    dark_pixels = np.sum((r < 40) & (g < 40) & (b < 40))
    dark_ratio = dark_pixels / (width * height)
    
    # Chargers are often >50% solid black
    if dark_ratio > 0.60 and color_variance < 40:
        return False, {'reason': 'charger_black', 'dark_ratio': dark_ratio}
    
    # === BRIGHTNESS ===
    avg_brightness = np.mean(gray)
    if avg_brightness > 245:
        return False, {'reason': 'too_bright', 'brightness': avg_brightness}
    
    return True, {
        'color_variance': color_variance,
        'edge_density': edge_density,
        'aspect_ratio': aspect_ratio
    }

def extract_skus_from_image_ocr(pil_image):
    """Extract SKUs that appear within the image frame using OCR"""
    if not OCR_AVAILABLE:
        return []
    
    try:
        # OCR the image
        text = pytesseract.image_to_string(pil_image, config='--psm 6')
        
        found_skus = []
        for pattern in TOOL_SKU_PATTERNS:
            matches = re.findall(pattern, text.upper())
            found_skus.extend(matches)
        
        # Filter for actual tools
        tool_skus = [sku for sku in found_skus if is_tool_sku(sku)]
        
        return list(dict.fromkeys(tool_skus))  # Remove duplicates
    except:
        return []

def extract_skus_from_page_text(page_text):
    """Extract tool SKUs from page text"""
    found_skus = []
    
    for pattern in TOOL_SKU_PATTERNS:
        matches = re.findall(pattern, page_text.upper())
        found_skus.extend(matches)
    
    # Filter for actual tools
    tool_skus = [sku for sku in found_skus if is_tool_sku(sku)]
    
    return list(dict.fromkeys(tool_skus))

def extract_skus_from_tables(tables):
    """Extract SKUs from table cells - handles formats like DDG460ZX7, UR002GZ01, etc."""
    found_skus = []
    
    for table in tables:
        for row in table:
            for cell in row:
                if not cell:
                    continue
                
                cell_text = str(cell).upper().strip()
                
                # Check for tool SKU patterns
                for pattern in TOOL_SKU_PATTERNS:
                    matches = re.findall(pattern, cell_text)
                    found_skus.extend(matches)
                
                # Handle concatenated SKUs like "UR007GM101UR006GM101"
                # Split on capital letters followed by digits
                parts = re.findall(r'[A-Z]{2,4}\d{3,4}[A-Z]{1,4}\d{0,3}', cell_text)
                found_skus.extend(parts)
    
    # Filter for actual tools
    tool_skus = [sku for sku in found_skus if is_tool_sku(sku)]
    
    return list(dict.fromkeys(tool_skus))

def extract_pdf(pdf_path, catalog_name):
    """Extract tool images and SKUs from PDF"""
    print("="*80)
    print(f"EXTRACTING: {catalog_name}")
    print("="*80)
    
    output_images = OUTPUT_DIR / catalog_name
    output_images.mkdir(parents=True, exist_ok=True)
    
    doc = fitz.open(pdf_path)
    extracted_images = []
    
    stats = {
        'total_images': 0,
        'tool_images': 0,
        'filtered': 0,
        'filter_reasons': {},
        'skus_from_ocr': 0,
        'skus_from_text': 0,
        'skus_from_tables': 0
    }
    
    print(f"\nProcessing {len(doc)} pages...")
    
    # First pass: collect all SKUs from tables
    all_page_skus = {}
    
    with pdfplumber.open(pdf_path) as pdf:
        for page_num in range(len(pdf.pages)):
            page = pdf.pages[page_num]
            page_text = page.extract_text() or ""
            tables = page.extract_tables() or []
            
            # Get SKUs from text and tables
            text_skus = extract_skus_from_page_text(page_text)
            table_skus = extract_skus_from_tables(tables)
            
            all_page_skus[page_num] = {
                'text': text_skus,
                'tables': table_skus,
                'all': list(dict.fromkeys(text_skus + table_skus))
            }
            
            if (page_num + 1) % 10 == 0:
                print(f"  Scanned {page_num + 1} pages for SKUs...")
    
    print(f"\n[SKU DETECTION] Found SKUs on {len([p for p in all_page_skus.values() if p['all']])} pages")
    
    # Second pass: extract images
    print(f"\n[IMAGE EXTRACTION] Processing images...")
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        image_list = page.get_images()
        
        page_skus = all_page_skus.get(page_num, {}).get('all', [])
        
        if (page_num + 1) % 10 == 0:
            print(f"  Page {page_num + 1}/{len(doc)} - Extracted {stats['tool_images']} tools")
        
        for img_idx, img in enumerate(image_list):
            stats['total_images'] += 1
            xref = img[0]
            
            try:
                base_image = doc.extract_image(xref)
                image_bytes = base_image["image"]
                pil_image = Image.open(io.BytesIO(image_bytes))
                
                # Check if it's a tool image
                is_tool, metrics = is_tool_image(pil_image)
                
                if not is_tool:
                    stats['filtered'] += 1
                    reason = metrics.get('reason', 'unknown')
                    stats['filter_reasons'][reason] = stats['filter_reasons'].get(reason, 0) + 1
                    continue
                
                # Get SKUs for this image
                image_skus = extract_skus_from_image_ocr(pil_image)
                
                if image_skus:
                    primary_sku = image_skus[0]
                    stats['skus_from_ocr'] += 1
                elif page_skus:
                    primary_sku = page_skus[min(img_idx, len(page_skus) - 1)]
                    stats['skus_from_text'] += 1
                else:
                    primary_sku = f"TOOL_{stats['tool_images']:05d}"
                
                # Build filename
                all_skus = list(dict.fromkeys(image_skus + page_skus[:3]))  # Up to 3 SKUs
                
                if len(all_skus) > 1:
                    sku_tag = f"[+{'+'.join(all_skus[1:4])}]"  # Max 3 additional SKUs
                else:
                    sku_tag = ""
                
                filename = f"{primary_sku}_{catalog_name}_p{page_num+1:03d}{sku_tag}.webp"
                filepath = output_images / filename
                
                # Save
                pil_image.save(filepath, 'WEBP', quality=WEBP_QUALITY)
                
                extracted_images.append({
                    'sku': primary_sku,
                    'page': page_num + 1,
                    'filename': filename,
                    'all_skus': all_skus,
                    'metrics': metrics
                })
                
                stats['tool_images'] += 1
                
            except Exception as e:
                continue
    
    doc.close()
    
    # Save JSON
    output_json = OUTPUT_JSON_DIR / f"{catalog_name}_tools_extracted.json"
    with open(output_json, 'w', encoding='utf-8') as f:
        json.dump(extracted_images, f, indent=2, ensure_ascii=False)
    
    # Print summary
    print("\n" + "="*80)
    print("EXTRACTION COMPLETE")
    print("="*80)
    print(f"\nStatistics:")
    print(f"  Total images scanned: {stats['total_images']}")
    print(f"  Tool images extracted: {stats['tool_images']}")
    print(f"  Filtered out: {stats['filtered']}")
    print(f"\nSKU sources:")
    print(f"  From OCR (in image): {stats['skus_from_ocr']}")
    print(f"  From page text/tables: {stats['skus_from_text']}")
    print(f"\nFilter breakdown:")
    for reason, count in sorted(stats['filter_reasons'].items(), key=lambda x: x[1], reverse=True)[:10]:
        print(f"  {reason}: {count}")
    print(f"\nOutput:")
    print(f"  Images: {output_images}")
    print(f"  JSON: {output_json}")
    
    return extracted_images, stats

def main():
    # Extract both PDFs
    catalogs = [
        (PROJECT_ROOT / "input_pdfs" / "makita-catalogus-2022-nl.pdf", "makita-catalogus-2022-nl"),
        (PROJECT_ROOT / "input_pdfs" / "makita-tuinfolder-2022-nl.pdf", "makita-tuinfolder-2022-nl"),
    ]
    
    all_results = {}
    
    for pdf_path, catalog_name in catalogs:
        if not pdf_path.exists():
            print(f"\n[SKIP] {pdf_path} not found")
            continue
        
        images, stats = extract_pdf(pdf_path, catalog_name)
        all_results[catalog_name] = {'images': len(images), 'stats': stats}
    
    # Final summary
    print("\n" + "="*80)
    print("FINAL SUMMARY")
    print("="*80)
    
    total_tools = sum(r['images'] for r in all_results.values())
    print(f"\nTotal tool images extracted: {total_tools}")
    
    for catalog, result in all_results.items():
        print(f"\n{catalog}:")
        print(f"  Tools: {result['images']}")
        print(f"  Filtered: {result['stats']['filtered']}")

if __name__ == '__main__':
    main()
