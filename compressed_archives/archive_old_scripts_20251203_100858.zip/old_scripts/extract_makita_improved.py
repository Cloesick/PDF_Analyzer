"""
IMPROVED MAKITA CATALOG EXTRACTOR
==================================
Targeted extraction for makita-catalogus-2022-nl with better SKU detection and image matching.

Strategy:
1. Extract images from each page at high DPI (300)
2. Use OCR on images to find embedded SKU text
3. Match with nearby text on the page
4. Use table data for additional context
5. Generate consistent, high-quality images
"""

import pdfplumber
import fitz  # PyMuPDF
import re
import json
from pathlib import Path
from PIL import Image
from collections import defaultdict
# import pytesseract  # Optional - works without it
import cv2
import numpy as np
from io import BytesIO

# Enable verbose output
VERBOSE = False  # Set to True to see every filtered image

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "makita-catalogus-2022-nl.pdf"
CATALOG_NAME = "makita-catalogus-2022-nl"
OUTPUT_IMAGES = PROJECT_ROOT / "product-images-by-pdf" / CATALOG_NAME
OUTPUT_JSON = PROJECT_ROOT / "output" / "makita_extracted_products.json"

IMAGE_DPI = 300
# BALANCED MODE: Quality extraction (reject gradients, icons, non-products)
MIN_IMAGE_AREA = 15000  # Minimum area - avoid tiny icons
MIN_IMAGE_WIDTH = 130   # Minimum width in pixels
MIN_IMAGE_HEIGHT = 130  # Minimum height in pixels
MAX_ASPECT_RATIO = 4.0  # Maximum aspect ratio - allow some variety
MIN_COLOR_VARIANCE = 8  # Minimum color variance - reject flat colors/gradients (relaxed)
MIN_EDGE_DENSITY = 0.012 # Minimum edge density - require some detail (relaxed)
MAX_GRADIENT_SCORE = 0.60  # Maximum gradient score - only block obvious gradients (relaxed)
MIN_TEXTURE_COMPLEXITY = 0.08  # Minimum texture complexity (relaxed)
WEBP_QUALITY = 90

# Makita SKU patterns for ACTUAL TOOLS (not batteries/chargers/accessories)
MAKITA_SKU_PATTERNS = [
    r'\b[A-Z]{2,4}\d{3,4}[A-Z]{1,4}\d{0,3}\b',  # DHS680RTJ, GA005GM201, HS010G, TW004GZ
    r'\b[A-Z]{2}\d{3}[A-Z]{2}\d{3}\b',          # TD001GD201, PT001GD101, UR002GZ01
    r'\b[A-Z]{3}\d{3}[A-Z]{2,4}\d*\b',          # DUC307ZX2, DCL280FZW, GA037GM201
]

# Exclusion patterns for NON-TOOLS (batteries, chargers, accessories, part numbers)
EXCLUDE_SKU_PATTERNS = [
    r'^BL\d+',          # BL1830B, BL4020, BL4050F, BL1860B, BL1850, BL1840, BL1188 (batteries)
    r'^DC\d+',          # DC18R, DC40RA, DC18RD, DC18RE, DC18RC, DC40, DC11 (chargers)
    r'^ADP\d+',         # ADP10, ADPOO1 (adapters)
    r'^DEAADP',         # DEAADP001G (adapters)
    r'^AD\d+',          # AD88 (accessories)
    r'^PDC\d+',         # PDC01 (accessories)
    r'^BPS\d+',         # BPS01 (accessories)
    r'^BEAPDC',         # BEAPDC1200A01 (accessories)
    r'^PV\d+',          # PV001GZ, PV001GM1O1 (accessories)
    r'^DK\d+',          # DK0126G401, DK0128G601 (accessories)
    r'^RC\d+',          # RC30B (accessories)
    r'^PL\d+',          # PL11 (accessories)
    r'^ER\d+',          # ER55 (accessories)
    r'^AA\d+',          # AA8720-9 (accessories)
    r'^N\d+-\d+$',      # N09-8 (part numbers)
    r'^\d+-\d+$',       # 81-6, 933-6, 198720-9, 199009-8, 197658-5 (part numbers)
    r'^\d{5,6}$',       # 56169, 54329, 19693 (part numbers)
    r'^[A-Z]\d{1,2}$',  # B18, K18 (accessories)
    r'^IPX\d+$',        # IPX4 (rating, not a product)
    r'^[A-Z]{2}\d{1,2}$',  # AR04, GA03 (incomplete SKUs or accessories)
]

# ============================================================================
# SKU DETECTION
# ============================================================================

def is_tool_sku(sku):
    """Check if SKU represents an actual power tool (not battery/charger/accessory)"""
    if not sku or len(sku) < 4:
        return False
    
    sku_upper = sku.upper().strip()
    
    # Check exclusions first
    for pattern in EXCLUDE_SKU_PATTERNS:
        if re.match(pattern, sku_upper):
            return False
    
    # Check if matches tool patterns
    for pattern in MAKITA_SKU_PATTERNS:
        if re.match(pattern, sku_upper):
            return True
    
    return False

def extract_skus_from_text(text):
    """Extract all potential Makita TOOL SKUs from text (excluding batteries/chargers/accessories)"""
    skus = set()
    for pattern in MAKITA_SKU_PATTERNS:
        matches = re.findall(pattern, text)
        skus.update(matches)
    
    # Filter out non-tool SKUs
    tool_skus = {sku for sku in skus if is_tool_sku(sku)}
    return tool_skus

def extract_text_from_image(pil_image):
    """Use OCR to extract text from image (optional, returns empty if not available)"""
    try:
        import pytesseract
        # Convert to grayscale for better OCR
        img_array = np.array(pil_image.convert('L'))
        
        # Apply thresholding
        _, thresh = cv2.threshold(img_array, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        # OCR
        text = pytesseract.image_to_string(Image.fromarray(thresh), lang='eng')
        return text
    except ImportError:
        # OCR not available, rely on nearby text instead
        return ""
    except Exception as e:
        print(f"  ⚠️ OCR error: {e}")
        return ""

def find_nearby_text(page, bbox, radius=50):
    """Find text near an image bbox"""
    x0, y0, x1, y1 = bbox
    
    # Expand search area
    search_bbox = (
        max(0, x0 - radius),
        max(0, y0 - radius),
        x1 + radius,
        y1 + radius
    )
    
    # Get words in search area
    nearby_words = []
    for word in page.extract_words():
        wx0, wy0, wx1, wy1 = word['x0'], word['top'], word['x1'], word['bottom']
        
        # Check if word is in search area
        if (wx0 >= search_bbox[0] and wx1 <= search_bbox[2] and
            wy0 >= search_bbox[1] and wy1 <= search_bbox[3]):
            nearby_words.append(word['text'])
    
    return ' '.join(nearby_words)

# ============================================================================
# IMAGE PROCESSING
# ============================================================================

def detect_gradient(img_array):
    """Detect if image is a gradient (smooth color transition)"""
    # Sample multiple horizontal and vertical lines
    height, width = img_array.shape[:2]
    
    # Check horizontal gradients (left to right)
    h_gradients = []
    for y in [height//4, height//2, 3*height//4]:
        row = img_array[y, :]
        # Calculate color change rate
        color_diffs = np.abs(np.diff(row.astype(float), axis=0))
        h_gradients.append(np.mean(color_diffs))
    
    # Check vertical gradients (top to bottom)
    v_gradients = []
    for x in [width//4, width//2, 3*width//4]:
        col = img_array[:, x]
        color_diffs = np.abs(np.diff(col.astype(float), axis=0))
        v_gradients.append(np.mean(color_diffs))
    
    avg_gradient = (np.mean(h_gradients) + np.mean(v_gradients)) / 2
    
    # Calculate gradient smoothness (standard deviation of color changes)
    all_h_diffs = []
    all_v_diffs = []
    for y in range(0, height, max(1, height//10)):
        row = img_array[y, :]
        all_h_diffs.extend(np.abs(np.diff(row.astype(float), axis=0)).flatten())
    for x in range(0, width, max(1, width//10)):
        col = img_array[:, x]
        all_v_diffs.extend(np.abs(np.diff(col.astype(float), axis=0)).flatten())
    
    smoothness = np.std(all_h_diffs + all_v_diffs)
    
    # Low smoothness + consistent gradient = likely a gradient image
    gradient_score = avg_gradient / (smoothness + 1)  # Normalized score
    
    return gradient_score

def calculate_texture_complexity(gray):
    """Calculate texture complexity using local binary patterns concept"""
    try:
        # Use Laplacian variance as a measure of texture
        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        variance = laplacian.var()
        
        # Calculate local standard deviation
        mean_filter = cv2.blur(gray.astype(float), (5, 5))
        sq_diff = (gray.astype(float) - mean_filter) ** 2
        local_var = cv2.blur(sq_diff, (5, 5))
        texture_score = np.mean(np.sqrt(local_var))
        
        # Normalize and handle edge cases
        normalized_score = texture_score / 100.0
        if np.isnan(normalized_score) or np.isinf(normalized_score):
            return 0.0
        return normalized_score
    except:
        return 0.0  # Return low complexity on error

def is_product_image(pil_image):
    """Determine if image is likely a REAL product photo (tool), not icon/logo/diagram/gradient"""
    width, height = pil_image.size
    img_array = np.array(pil_image.convert('RGB'))
    
    # 1. SIZE FILTER - Must be substantial
    area = width * height
    if area < MIN_IMAGE_AREA:
        return False, {'reason': 'too_small', 'area': area}
    
    if width < MIN_IMAGE_WIDTH or height < MIN_IMAGE_HEIGHT:
        return False, {'reason': 'dimensions_too_small', 'width': width, 'height': height}
    
    # 2. ASPECT RATIO - Real product photos are roughly square/rectangular, not extreme
    aspect_ratio = max(width, height) / min(width, height)
    if aspect_ratio > MAX_ASPECT_RATIO:
        return False, {'reason': 'bad_aspect_ratio', 'ratio': aspect_ratio}
    
    # 3. GRADIENT DETECTION - Reject gradient images
    gradient_score = detect_gradient(img_array)
    if gradient_score > MAX_GRADIENT_SCORE:
        return False, {'reason': 'gradient_detected', 'gradient_score': gradient_score}
    
    # 4. COLOR VARIANCE - Real photos have color depth, icons/logos/gradients are flat
    r, g, b = img_array[:,:,0], img_array[:,:,1], img_array[:,:,2]
    rg_diff = np.abs(r.astype(int) - g.astype(int))
    rb_diff = np.abs(r.astype(int) - b.astype(int))
    gb_diff = np.abs(g.astype(int) - b.astype(int))
    color_variance = (rg_diff.mean() + rb_diff.mean() + gb_diff.mean()) / 3
    
    if color_variance < MIN_COLOR_VARIANCE:
        return False, {'reason': 'low_color_variance', 'variance': color_variance}
    
    # 5. EDGE DENSITY - Real photos have detail/texture, simple graphics don't
    gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, 50, 150)
    edge_density = np.count_nonzero(edges) / area
    
    if edge_density < MIN_EDGE_DENSITY:
        return False, {'reason': 'low_edge_density', 'density': edge_density}
    
    # 6. TEXTURE COMPLEXITY - Real product photos have texture detail (DISABLED - unreliable)
    texture_complexity = calculate_texture_complexity(gray)
    # if texture_complexity < MIN_TEXTURE_COMPLEXITY:
    #     return False, {'reason': 'low_texture_complexity', 'texture': texture_complexity}
    
    # 7. BACKGROUND CHECK - Real product photos typically have uniform/white background
    # Check corner pixels (background)
    corner_size = 20
    corners = [
        img_array[0:corner_size, 0:corner_size],
        img_array[0:corner_size, -corner_size:],
        img_array[-corner_size:, 0:corner_size],
        img_array[-corner_size:, -corner_size:]
    ]
    
    bg_brightness = [np.mean(corner) for corner in corners]
    avg_bg_brightness = np.mean(bg_brightness)
    
    # Product photos usually have bright (white) backgrounds
    if avg_bg_brightness < 200:  # Stricter white background requirement
        return False, {'reason': 'dark_background', 'brightness': avg_bg_brightness}
    
    # 8. CONTENT RATIO - Check if there's actual content (not mostly white)
    brightness = np.mean(gray)
    if brightness > 250:  # Almost completely white = empty/logo
        return False, {'reason': 'mostly_white', 'brightness': brightness}
    
    # 9. COLOR DISTRIBUTION - Real photos have distributed colors, not just a few
    unique_colors = len(np.unique(img_array.reshape(-1, 3), axis=0))
    color_richness = unique_colors / area
    
    if color_richness < 0.002:  # Too few colors = simple graphic or gradient
        return False, {'reason': 'low_color_richness', 'richness': color_richness}
    
    # 10. CHECK FOR SINGLE DOMINANT COLOR (like solid color blocks)
    # Flatten and get color histogram
    flat_img = img_array.reshape(-1, 3)
    # Check if >80% of pixels are similar (within 20 units of each other)
    sample_size = min(10000, len(flat_img))
    sample = flat_img[np.random.choice(len(flat_img), sample_size, replace=False)]
    median_color = np.median(sample, axis=0)
    distances = np.sqrt(np.sum((sample - median_color)**2, axis=1))
    similar_ratio = np.sum(distances < 20) / len(distances)
    
    if similar_ratio > 0.8:  # Too uniform
        return False, {'reason': 'uniform_color', 'uniformity': similar_ratio}
    
    # PASSED ALL TESTS - This is likely a real product photo!
    return True, {
        'color_variance': color_variance,
        'edge_density': edge_density,
        'texture_complexity': texture_complexity,
        'gradient_score': gradient_score,
        'aspect_ratio': aspect_ratio,
        'area': area,
        'color_richness': color_richness,
        'bg_brightness': avg_bg_brightness,
        'uniformity': similar_ratio
    }

def clean_and_crop_image(pil_image):
    """Remove white background and crop to product"""
    try:
        img_array = np.array(pil_image.convert('RGB'))
        
        # Convert to grayscale
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
        
        # Threshold to find object
        _, mask = cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY_INV)
        
        # Find contours
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return pil_image
        
        # Get bounding box of largest contour
        largest_contour = max(contours, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(largest_contour)
        
        # Add padding
        padding = 20
        x = max(0, x - padding)
        y = max(0, y - padding)
        w = min(img_array.shape[1] - x, w + 2 * padding)
        h = min(img_array.shape[0] - y, h + 2 * padding)
        
        # Crop
        cropped = pil_image.crop((x, y, x + w, y + h))
        return cropped
    except:
        return pil_image

# ============================================================================
# MAIN EXTRACTION
# ============================================================================

def extract_makita_catalog():
    """Extract products and images from Makita catalog"""
    
    print("=" * 80)
    print("MAKITA CATALOG EXTRACTOR - IMPROVED")
    print("=" * 80)
    
    if not PDF_PATH.exists():
        print(f"❌ PDF not found: {PDF_PATH}")
        return
    
    print(f"\n📄 Processing: {PDF_PATH.name}")
    
    # Create output folder
    OUTPUT_IMAGES.mkdir(parents=True, exist_ok=True)
    
    # Open PDF with both libraries
    pdf_plumber = pdfplumber.open(PDF_PATH)
    pdf_pymupdf = fitz.open(PDF_PATH)
    
    extracted_products = []
    stats = {
        'pages_processed': 0,
        'images_found': 0,
        'images_extracted': 0,
        'images_filtered_out': 0,
        'filter_reasons': defaultdict(int),
        'skus_found': set(),
        'products_created': 0
    }
    
    print(f"\n📊 Total pages: {len(pdf_plumber.pages)}")
    
    # Process each page
    for page_num in range(1, len(pdf_plumber.pages) + 1):
        print(f"\n📄 Page {page_num}...")
        stats['pages_processed'] += 1
        
        # Get page from both libraries
        page_plumber = pdf_plumber.pages[page_num - 1]
        page_pymupdf = pdf_pymupdf[page_num - 1]
        
        # Extract all text from page for context
        page_text = page_plumber.extract_text() or ""
        page_skus = extract_skus_from_text(page_text)
        print(f"   Found {len(page_skus)} potential SKUs on page")
        
        # Get images from page
        image_list = page_pymupdf.get_images(full=True)
        print(f"   Found {len(image_list)} images")
        stats['images_found'] += len(image_list)
        
        # Process each image
        for img_idx, img_info in enumerate(image_list):
            try:
                xref = img_info[0]
                
                # Extract image
                base_image = pdf_pymupdf.extract_image(xref)
                image_bytes = base_image["image"]
                
                # Convert to PIL
                pil_image = Image.open(BytesIO(image_bytes))
                if pil_image.mode != 'RGB':
                    pil_image = pil_image.convert('RGB')
                
                # Check if it's a REAL product image (actual tool photo)
                is_product, quality_info = is_product_image(pil_image)
                if not is_product:
                    reason = quality_info.get('reason', 'unknown')
                    stats['images_filtered_out'] += 1
                    stats['filter_reasons'][reason] += 1
                    if VERBOSE:
                        print(f"   ⊘ Image {img_idx}: Filtered out ({reason})")
                    continue
                
                print(f"   ✓ Image {img_idx}: PRODUCT DETECTED (variance={quality_info.get('color_variance', 0):.1f}, edges={quality_info.get('edge_density', 0):.4f}, gradient={quality_info.get('gradient_score', 0):.3f}, texture={quality_info.get('texture_complexity', 0):.3f})")
                
                # Get image location on page
                img_rects = page_pymupdf.get_image_rects(xref)
                if img_rects:
                    rect = img_rects[0]
                    bbox = (rect.x0, rect.y0, rect.x1, rect.y1)
                    
                    # Find nearby text
                    nearby_text = find_nearby_text(page_plumber, bbox, radius=100)
                    nearby_skus = extract_skus_from_text(nearby_text)
                else:
                    nearby_text = ""
                    nearby_skus = set()
                
                # Extract text from image itself (OCR)
                image_text = extract_text_from_image(pil_image)
                image_skus = extract_skus_from_text(image_text)
                
                # Combine all SKU sources
                all_skus = image_skus | nearby_skus | page_skus
                
                if not all_skus:
                    print(f"   ⊘ Image {img_idx}: No SKUs found")
                    continue
                
                # Clean and crop image
                cleaned_image = clean_and_crop_image(pil_image)
                
                # Generate filename following standard naming convention
                primary_sku = sorted(all_skus)[0]  # Use first alphabetically
                safe_sku = primary_sku.replace(' ', '_').replace('/', '-').replace('\\', '-')
                
                # Standard format: {SKU}_{catalog}_{page}_img{index}.webp
                filename = f"{safe_sku}_{CATALOG_NAME}_p{page_num:03d}_img{img_idx:02d}.webp"
                filepath = OUTPUT_IMAGES / filename
                
                # Save image
                cleaned_image.save(filepath, format='WEBP', quality=WEBP_QUALITY)
                stats['images_extracted'] += 1
                
                print(f"   💾 Saved: {filename} (SKU: {primary_sku})")
                
                # Create product entry for each SKU
                for sku in all_skus:
                    extracted_products.append({
                        'sku': sku,
                        'pdf_source': PDF_PATH.name,
                        'catalog': CATALOG_NAME,
                        'page_num': page_num,
                        'image_index': img_idx,
                        'image_filename': filename,
                        'image_path': str(filepath),
                        'image_url': f"/product-images/{CATALOG_NAME}/{filename}",
                        'skus_in_image': sorted(list(all_skus)),
                        'color_variance': float(quality_info.get('color_variance', 0)),
                        'edge_density': float(quality_info.get('edge_density', 0)),
                        'quality_metrics': quality_info,
                        'from_ocr': sku in image_skus,
                        'from_nearby': sku in nearby_skus,
                        'from_page': sku in page_skus
                    })
                    stats['skus_found'].add(sku)
                    stats['products_created'] += 1
                
            except Exception as e:
                print(f"   ⚠️ Error processing image {img_idx}: {e}")
                continue
        
        # Progress update every 10 pages
        if page_num % 10 == 0:
            print(f"\n   📊 Progress: Scanned {page_num} pages...")
            print(f"      ✓ Extracted {stats['images_extracted']} product images")
            print(f"      ⊘ Filtered out {stats['images_filtered_out']} non-products")
            print(f"      📦 Found {len(stats['skus_found'])} unique SKUs so far")
    
    # Close PDFs
    pdf_plumber.close()
    pdf_pymupdf.close()
    
    # Save results
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(extracted_products, f, indent=2)
    
    # Print comprehensive summary
    print("\n" + "=" * 80)
    print("✅ EXTRACTION COMPLETE!")
    print("=" * 80)
    print(f"\n📊 Final Statistics:")
    print(f"   Pages scanned:        {stats['pages_processed']}")
    print(f"   Images found:         {stats['images_found']}")
    print(f"   ✓ Product images:     {stats['images_extracted']} (ACTUAL TOOLS)")
    print(f"   ⊘ Filtered out:       {stats['images_filtered_out']} (icons/logos/diagrams)")
    print(f"   Unique SKUs found:    {len(stats['skus_found'])}")
    print(f"   Product entries:      {stats['products_created']}")
    
    print(f"\n🔍 Filter Breakdown:")
    for reason, count in sorted(stats['filter_reasons'].items(), key=lambda x: -x[1])[:5]:
        print(f"   - {reason}: {count} images")
    
    extraction_rate = (stats['images_extracted'] / stats['images_found'] * 100) if stats['images_found'] > 0 else 0
    print(f"\n✨ Quality Rate: {extraction_rate:.1f}% of images were actual product photos")
    
    print(f"\n💾 Output Saved:")
    print(f"   📁 Images folder: {OUTPUT_IMAGES}/")
    print(f"   📄 JSON file:     {OUTPUT_JSON}")
    print(f"\n🎉 Scanned total {stats['images_found']} images, extracted {stats['images_extracted']} product photos!")
    
    return extracted_products

if __name__ == '__main__':
    extract_makita_catalog()
