"""
MESSING DRAADFITTINGEN PDF ANALYZER
======================

Comprehensive analysis script for messing-draadfittingen.pdf that:
- Extracts all text content organized by page
- Identifies and categorizes products
- Tracks which products share the same images
- Creates a structured data output with product relationships

Author: PDF Analyzer System
"""

import pdfplumber
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, asdict, field
import hashlib
from PIL import Image
import io

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ROOT = Path(__file__).parent
INPUT_PDF = PROJECT_ROOT / "input_pdfs" / "messing-draadfittingen.pdf"
OUTPUT_DIR = PROJECT_ROOT / "output"
OUTPUT_JSON = OUTPUT_DIR / "messing_draadfittingen_analysis.json"

# Product detection patterns
PRODUCT_PATTERNS = [
    re.compile(r'\b([A-Z]{2,}\d+[-A-Z0-9]*)\b'),  # Product codes like PE100, HDPE32
    re.compile(r'\b(\d+x\d+(?:x\d+)?)\b', re.IGNORECASE),  # Dimensions like 32x3, 110x10
    re.compile(r'\b(\d+mm)\b', re.IGNORECASE),  # Measurements
    re.compile(r'Ø\s*(\d+)', re.IGNORECASE),  # Diameter symbols
    re.compile(r'\b(PE\s*\d+)\b', re.IGNORECASE),  # PE material codes
]

# Category keywords
CATEGORY_KEYWORDS = {
    'buizen': ['buis', 'buizen', 'pijp', 'pipe', 'tube'],
    'koppelingen': ['koppeling', 'koppel', 'fitting', 'connector', 'connection'],
    'kranen': ['kraan', 'valve', 'tap'],
    'fittings': ['fitting', 'elbow', 'tee', 'reducer', 'flens', 'flange'],
    'hulpstukken': ['hulpstuk', 'accessoire', 'accessory'],
    'gereedschap': ['gereedschap', 'tool', 'machine'],
}

# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class ProductItem:
    """Represents a single product found in the PDF"""
    product_id: str
    page_number: int
    category: str
    description: str
    specifications: Dict[str, str]
    text_snippet: str
    image_hash: Optional[str] = None
    shared_image_with: List[str] = field(default_factory=list)
    coordinates: Optional[Dict] = None
    
@dataclass
class ImageInfo:
    """Information about an image in the PDF"""
    image_hash: str
    page_number: int
    image_index: int
    bbox: Dict
    width: int
    height: int
    products_using_image: List[str] = field(default_factory=list)
    
@dataclass
class PageAnalysis:
    """Analysis results for a single page"""
    page_number: int
    text_content: str
    products_found: List[ProductItem]
    images_found: List[ImageInfo]
    detected_category: str
    word_count: int
    
@dataclass
class PDFAnalysisResults:
    """Complete analysis results for the PDF"""
    pdf_name: str
    total_pages: int
    total_products: int
    total_images: int
    categories: Dict[str, int]
    pages: List[PageAnalysis]
    product_image_mapping: Dict[str, List[str]]
    shared_images: List[Dict]
    
# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def compute_image_hash(image_bytes: bytes) -> str:
    """Compute a hash for an image to detect duplicates"""
    return hashlib.md5(image_bytes).hexdigest()

def extract_specifications(text: str) -> Dict[str, str]:
    """Extract technical specifications from text with proper units"""
    specs = {}
    
    # Diameter with unit preservation
    diam_match = re.search(r'Ø\s*(\d+(?:[.,]\d+)?)\s*(mm|m|cm)?', text, re.IGNORECASE)
    if diam_match:
        value = diam_match.group(1).replace(',', '.')
        unit = diam_match.group(2).lower() if diam_match.group(2) else 'mm'
        specs['diameter'] = f"{value} {unit}"
        specs['diameter_mm'] = value if unit == 'mm' else str(float(value) * (1000 if unit == 'm' else 10))
    
    # Inner diameter
    inner_diam = re.search(r'(?:binnen|inner|ID)(?:\s*diameter|Ø)?\s*:?\s*(\d+(?:[.,]\d+)?)\s*(mm|m|cm)?', text, re.IGNORECASE)
    if inner_diam:
        value = inner_diam.group(1).replace(',', '.')
        unit = inner_diam.group(2).lower() if inner_diam.group(2) else 'mm'
        specs['inner_diameter'] = f"{value} {unit}"
    
    # Outer diameter
    outer_diam = re.search(r'(?:buiten|outer|OD)(?:\s*diameter|Ø)?\s*:?\s*(\d+(?:[.,]\d+)?)\s*(mm|m|cm)?', text, re.IGNORECASE)
    if outer_diam:
        value = outer_diam.group(1).replace(',', '.')
        unit = outer_diam.group(2).lower() if outer_diam.group(2) else 'mm'
        specs['outer_diameter'] = f"{value} {unit}"
    
    # Dimensions (e.g., 32x3) with units
    dim_match = re.search(r'(\d+(?:[.,]\d+)?)\s*x\s*(\d+(?:[.,]\d+)?)(?:\s*x\s*(\d+(?:[.,]\d+)?))?\s*(mm|m|cm)?', text, re.IGNORECASE)
    if dim_match:
        values = [v.replace(',', '.') for v in dim_match.groups()[:3] if v]
        unit = dim_match.group(4).lower() if dim_match.group(4) else 'mm'
        specs['dimension'] = 'x'.join(values) + f' {unit}'
    
    # Wall thickness
    wall_match = re.search(r'(?:wand|wall)(?:\s*dikte|thickness)?\s*:?\s*(\d+(?:[.,]\d+)?)\s*(mm|m|cm)?', text, re.IGNORECASE)
    if wall_match:
        value = wall_match.group(1).replace(',', '.')
        unit = wall_match.group(2).lower() if wall_match.group(2) else 'mm'
        specs['wall_thickness'] = f"{value} {unit}"
    
    # Pressure rating
    press_match = re.search(r'(\d+(?:[.,]\d+)?)\s*bar', text, re.IGNORECASE)
    if press_match:
        specs['pressure'] = f"{press_match.group(1).replace(',', '.')} bar"
        specs['pressure_bar'] = press_match.group(1).replace(',', '.')
    
    # Working pressure
    work_press = re.search(r'(?:werk|working)(?:\s*druk|pressure)?\s*:?\s*(\d+(?:[.,]\d+)?)\s*bar', text, re.IGNORECASE)
    if work_press:
        specs['working_pressure'] = f"{work_press.group(1).replace(',', '.')} bar"
    
    # Material with grade
    material_match = re.search(r'\b(PE\s*\d+|HDPE|MDPE|LDPE|PVC-U|PVC|PP|PPR)\b', text, re.IGNORECASE)
    if material_match:
        specs['material'] = material_match.group(1).upper()
    
    # Length with units
    length_match = re.search(r'(?:lengte|length)?\s*:?\s*(\d+(?:[.,]\d+)?)\s*(m|meter|metres?|mm)', text, re.IGNORECASE)
    if length_match:
        value = length_match.group(1).replace(',', '.')
        unit = 'm' if 'meter' in length_match.group(2).lower() or length_match.group(2).lower() == 'm' else 'mm'
        specs['length'] = f"{value} {unit}"
        specs['length_m'] = value if unit == 'm' else str(float(value) / 1000)
    
    # SDR (Standard Dimension Ratio)
    sdr_match = re.search(r'SDR\s*(\d+(?:[.,]\d+)?)', text, re.IGNORECASE)
    if sdr_match:
        specs['sdr'] = f"SDR {sdr_match.group(1).replace(',', '.')}"
    
    # PN Rating (Pressure Nominal)
    pn_match = re.search(r'PN\s*(\d+(?:[.,]\d+)?)', text, re.IGNORECASE)
    if pn_match:
        specs['pn_rating'] = f"PN {pn_match.group(1).replace(',', '.')}"
    
    # Temperature range
    temp_match = re.search(r'(-?\d+)\s*°C?\s*(?:tot|to|-|\.\.\.)\s*\+?(\d+)\s*°C', text, re.IGNORECASE)
    if temp_match:
        specs['temperature_range'] = f"{temp_match.group(1)}°C to {temp_match.group(2)}°C"
    
    return specs

def detect_category(text: str) -> str:
    """Detect product category based on text content"""
    text_lower = text.lower()
    
    category_scores = defaultdict(int)
    for category, keywords in CATEGORY_KEYWORDS.items():
        for keyword in keywords:
            count = text_lower.count(keyword.lower())
            category_scores[category] += count
    
    if category_scores:
        return max(category_scores.items(), key=lambda x: x[1])[0]
    
    return 'onbekend'  # Unknown

def extract_product_codes(text: str) -> List[str]:
    """Extract potential product codes from text"""
    codes = set()
    
    for pattern in PRODUCT_PATTERNS:
        matches = pattern.findall(text)
        codes.update(matches)
    
    return sorted(list(codes))

def extract_table_data(page) -> List[Dict]:
    """Extract table data with headers for better categorization"""
    table_products = []
    
    try:
        tables = page.extract_tables()
        if not tables:
            return table_products
        
        print(f"    → Found {len(tables)} tables on page")
        
        for table_idx, table in enumerate(tables):
            if not table or len(table) < 2:  # Need at least header + 1 row
                print(f"    → Table {table_idx}: Skipped (too small or empty)")
                continue
            
            print(f"    → Table {table_idx}: {len(table)} rows, {len(table[0]) if table else 0} columns")
            
            # First row is typically the header
            headers = [str(cell).strip() if cell else '' for cell in table[0]]
            
            # Track last known diameter for rows with empty diameter column
            last_diameter = None
            diameter_sequence = []
            
            # Process each data row
            for row_idx, row in enumerate(table[1:], start=1):
                if not row or all(not cell for cell in row):
                    continue
                
                row_data = {}
                for col_idx, (header, cell) in enumerate(zip(headers, row)):
                    if cell and str(cell).strip():
                        cell_value = str(cell).strip()
                        
                        # Use header if available, otherwise use column index
                        if header and header != 'None':
                            clean_header = header.lower().replace(' ', '_').replace('.', '').replace(',', '')
                            row_data[clean_header] = cell_value
                        else:
                            # Empty header - use column index
                            row_data[f'col_{col_idx}'] = cell_value
                
                # Special handling for diameter column (col_0)
                # If col_0 is present and numeric, update last_diameter
                if 'col_0' in row_data and row_data['col_0'].isdigit():
                    last_diameter = row_data['col_0']
                    diameter_sequence.append(last_diameter)
                # If col_0 is missing but row has data, infer next diameter
                elif 'col_0' not in row_data and row_data and last_diameter:
                    # This row is part of a sequence - infer the next diameter
                    # Common diameter sequences: 20, 25, 32, 40, 50, 63, 75, 90, 110, 125...
                    standard_sequence = [20, 25, 32, 40, 50, 63, 75, 90, 110, 125, 140, 160, 180, 200, 225, 250, 280, 315, 355, 400, 450, 500]
                    try:
                        last_idx = standard_sequence.index(int(last_diameter))
                        if last_idx + 1 < len(standard_sequence):
                            inferred_diameter = str(standard_sequence[last_idx + 1])
                            row_data['col_0'] = inferred_diameter
                            row_data['col_0_inferred'] = 'true'
                            last_diameter = inferred_diameter
                            diameter_sequence.append(inferred_diameter)
                    except (ValueError, IndexError):
                        pass
                
                # Extract specifications from the row data
                specs = {}
                description_parts = []
                
                # First, store ALL columns as raw data (critical for safety specs)
                for key, value in row_data.items():
                    # Store the original column with cleaned key
                    specs[f'table_{key}'] = value
                
                # Now parse specific critical specifications with units
                for key, value in row_data.items():
                    
                    # CRITICAL: col_0 often contains nominal diameter (when header is empty)
                    if key == 'col_0':
                        # Check if it's a diameter (numeric value)
                        num_match = re.search(r'^(\d+(?:[.,]\d+)?)$', value)
                        if num_match:
                            specs['diameter'] = f"{num_match.group(1)} mm"
                            specs['diameter_mm'] = num_match.group(1).replace(',', '.')
                            description_parts.append(f"Ø{num_match.group(1)}mm")
                    
                    # CRITICAL: Gas pressure (gas column)
                    if key == 'gas':
                        num_match = re.search(r'(\d+)', value)
                        if num_match:
                            specs['gas_pressure'] = f"{num_match.group(1)} bar"
                            specs['gas_pressure_bar'] = num_match.group(1).replace(',', '.')
                    
                    # CRITICAL: Water pressure (max water pressure in bar)
                    if key == 'water' or key == 'water_pressure':
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            specs['water_pressure'] = f"{num_match.group(1).replace(',', '.')} bar"
                            specs['water_pressure_bar'] = num_match.group(1).replace(',', '.')
                    # CRITICAL: Nominal diameter / Inner diameter (Binnen, ID, Nom)
                    if any(term in key for term in ['nom', 'binnen', 'inner', 'binnendiameter', 'binnenmaat', 'id']) and 'buiten' not in key:
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            specs['inner_diameter'] = f"{num_match.group(1).replace(',', '.')} mm"
                            specs['inner_diameter_mm'] = num_match.group(1).replace(',', '.')
                            description_parts.append(f"Binnen Ø{num_match.group(1)}mm")
                    
                    # CRITICAL: Buitenmaat (inner-outer range) like "16,9-17,4 mm"
                    if key == 'buitenmaat':
                        range_match = re.search(r'(\d+(?:[.,]\d+)?)\s*-\s*(\d+(?:[.,]\d+)?)', value)
                        if range_match:
                            inner = float(range_match.group(1).replace(',', '.'))
                            outer = float(range_match.group(2).replace(',', '.'))
                            wall = outer - inner
                            specs['inner_diameter'] = f"{inner} mm"
                            specs['inner_diameter_mm'] = str(inner)
                            specs['outer_diameter'] = f"{outer} mm"
                            specs['outer_diameter_mm'] = str(outer)
                            specs['wall_thickness'] = f"{wall:.2f} mm"
                            specs['wall_thickness_mm'] = f"{wall:.2f}"
                            specs['dimension'] = f"{outer}x{wall:.2f} mm"
                            description_parts.append(f"ID{inner}-OD{outer}mm")
                    
                    # CRITICAL: Maten (metric × imperial) like "20 mm x 1/2""
                    elif key == 'maten':
                        # Format: "20 mm x 1/2""
                        maten_match = re.search(r'(\d+)\s*mm\s*x\s*([0-9/]+)"', value)
                        if maten_match:
                            diameter_mm = maten_match.group(1)
                            wall_imperial = maten_match.group(2)
                            specs['diameter'] = f"{diameter_mm} mm"
                            specs['diameter_mm'] = diameter_mm
                            specs['wall_thickness_imperial'] = f'{wall_imperial}"'
                            specs['wall_thickness_imperial_value'] = wall_imperial
                            description_parts.append(f"Ø{diameter_mm}mm × {wall_imperial}\"")
                    
                    # CRITICAL: PE Maat (PE pipe size)
                    elif key == 'pe_maat' or key == 'pemaat':
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            specs['pe_size'] = f"{num_match.group(1)} mm"
                            specs['pe_size_mm'] = num_match.group(1).replace(',', '.')
                    
                    # CRITICAL: Aansluitmaat (connection size) like "1" - DN25"
                    elif key == 'aansluitmaat':
                        connection_match = re.search(r'([0-9/]+)"\s*-\s*DN\s*(\d+)', value)
                        if connection_match:
                            imperial_size = connection_match.group(1)
                            dn_size = connection_match.group(2)
                            specs['connection_size_imperial'] = f'{imperial_size}"'
                            specs['connection_dn'] = f"DN {dn_size}"
                            specs['connection_dn_mm'] = dn_size
                    
                    # CRITICAL: Maat (outer × wall in mm) like "110 x 4.2"
                    elif key == 'maat' and 'binnen' not in key and 'buiten' not in key:
                        # Parse dimension like "110 x 4.2"
                        dim_match = re.search(r'(\d+(?:[.,]\d+)?)\s*x\s*(\d+(?:[.,]\d+)?)', value)
                        if dim_match:
                            specs['dimension'] = f"{dim_match.group(1)}x{dim_match.group(2)} mm"
                            specs['outer_diameter'] = f"{dim_match.group(1)} mm"
                            specs['outer_diameter_mm'] = dim_match.group(1).replace(',', '.')
                            specs['wall_thickness'] = f"{dim_match.group(2)} mm"
                            specs['wall_thickness_mm'] = dim_match.group(2).replace(',', '.')
                            description_parts.append(value)
                        else:
                            # Just a diameter
                            num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                            if num_match:
                                specs['diameter'] = f"{num_match.group(1)} mm"
                                specs['diameter_mm'] = num_match.group(1).replace(',', '.')
                                description_parts.append(f"Ø{num_match.group(1)}mm")
                    
                    # General outer diameter/size columns
                    elif any(term in key for term in ['size', 'buiten', 'outer', 'od', 'diameter', 'ø']) and 'binnen' not in key and 'inner' not in key and 'aansluitmaat' not in key and key != 'maat':
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            specs['diameter'] = f"{num_match.group(1)} mm"
                            specs['diameter_mm'] = num_match.group(1).replace(',', '.')
                            description_parts.append(f"Ø{num_match.group(1)}mm")
                    
                    # CRITICAL: Burst pressure (barstdruk, max druk, maximum druk)
                    if any(term in key for term in ['barst', 'burst', 'max_druk', 'maximum_druk', 'maxdruk']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            specs['burst_pressure'] = f"{num_match.group(1).replace(',', '.')} bar"
                            specs['burst_pressure_bar'] = num_match.group(1).replace(',', '.')
                    
                    # CRITICAL: Working pressure (werkdruk)
                    elif any(term in key for term in ['werk', 'working']) and any(term in key for term in ['druk', 'pressure']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            specs['working_pressure'] = f"{num_match.group(1).replace(',', '.')} bar"
                            specs['working_pressure_bar'] = num_match.group(1).replace(',', '.')
                    
                    # General pressure / PN rating
                    elif any(term in key for term in ['druk', 'pressure', 'bar', 'pn']) and 'max' not in key:
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            if 'pn' in key:
                                specs['pn_rating'] = f"PN {num_match.group(1)}"
                            else:
                                specs['pressure'] = f"{num_match.group(1)} bar"
                                specs['pressure_bar'] = num_match.group(1).replace(',', '.')
                    
                    # CRITICAL: Weight per meter (gewicht per meter, g/m, kg/m)
                    if any(term in key for term in ['gewicht', 'weight', 'g/m', 'kg/m']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            # Determine unit from context
                            if 'g/m' in key or 'gram' in key or 'gr/m' in key or ('g' in key and 'm' in key):
                                specs['weight_per_meter'] = f"{num_match.group(1).replace(',', '.')} g/m"
                                specs['weight_per_meter_g'] = num_match.group(1).replace(',', '.')
                            elif 'kg/m' in key or 'kilogram' in key or 'kg' in key:
                                specs['weight_per_meter'] = f"{num_match.group(1).replace(',', '.')} kg/m"
                                specs['weight_per_meter_kg'] = num_match.group(1).replace(',', '.')
                            else:
                                # Default to g/m if unit unclear
                                specs['weight_per_meter'] = f"{num_match.group(1).replace(',', '.')} g/m"
                                specs['weight_per_meter_g'] = num_match.group(1).replace(',', '.')
                    
                    # CRITICAL: Roll length / Tube length (rollengte, rol, coil)
                    if any(term in key for term in ['rol', 'roll', 'coil', 'rollengte']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)\s*(m|mm)?', value, re.IGNORECASE)
                        if num_match:
                            unit = num_match.group(2) if num_match.group(2) else 'm'
                            specs['roll_length'] = f"{num_match.group(1).replace(',', '.')} {unit}"
                            specs['roll_length_m'] = num_match.group(1).replace(',', '.')
                    
                    # General length columns
                    elif any(term in key for term in ['lengte', 'length']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)\s*(m|mm)?', value, re.IGNORECASE)
                        if num_match:
                            unit = num_match.group(2) if num_match.group(2) else 'm'
                            specs['length'] = f"{num_match.group(1).replace(',', '.')} {unit}"
                            specs['length_m'] = num_match.group(1).replace(',', '.')
                    
                    # Material columns
                    if any(term in key for term in ['material', 'type', 'kwaliteit', 'quality']):
                        specs['material'] = value.upper()
                        description_parts.append(value)
                    
                    # CRITICAL: Welding time (lastijd) - electrofusion welding
                    if 'lastijd' in key or 'welding_time' in key:
                        num_match = re.search(r'(\d+)', value)
                        if num_match:
                            specs['welding_time'] = f"{num_match.group(1)} s"
                            specs['welding_time_seconds'] = num_match.group(1)
                    
                    # CRITICAL: Waiting time (wachttijd, wachttijd2)
                    if 'wachttijd' in key or 'waiting_time' in key:
                        num_match = re.search(r'(\d+)', value)
                        if num_match:
                            if '2' in key:
                                specs['waiting_time_2'] = f"{num_match.group(1)} min"
                                specs['waiting_time_2_minutes'] = num_match.group(1)
                            else:
                                specs['waiting_time'] = f"{num_match.group(1)} min"
                                specs['waiting_time_minutes'] = num_match.group(1)
                    
                    # CRITICAL: Cooling time (koeltijd)
                    if 'koeltijd' in key or 'cooling_time' in key:
                        num_match = re.search(r'(\d+)', value)
                        if num_match:
                            specs['cooling_time'] = f"{num_match.group(1)} min"
                            specs['cooling_time_minutes'] = num_match.group(1)
                    
                    # CRITICAL: Electrical resistance (weerstand)
                    if 'weerstand' in key or 'resistance' in key:
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            specs['resistance'] = f"{num_match.group(1).replace(',', '.')} Ω"
                            specs['resistance_ohm'] = num_match.group(1).replace(',', '.')
                    
                    # CRITICAL: Voltage (spanning)
                    if 'spanning' in key or key == 'voltage':
                        num_match = re.search(r'(\d+)', value)
                        if num_match:
                            specs['voltage'] = f"{num_match.group(1)} V"
                            specs['voltage_v'] = num_match.group(1)
                    
                    # GPS Traceability
                    if 'gps' in key or 'traceability' in key:
                        if value.lower() in ['ja', 'yes', 'true', '1']:
                            specs['gps_traceability'] = 'Yes'
                        elif value.lower() in ['nee', 'no', 'false', '0']:
                            specs['gps_traceability'] = 'No'
                        else:
                            specs['gps_traceability'] = value
                    
                    # SDR columns
                    if 'sdr' in key:
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            specs['sdr'] = f"SDR {num_match.group(1)}"
                            specs['sdr_value'] = num_match.group(1).replace(',', '.')
                    
                    # Part/order numbers
                    if any(term in key for term in ['bestelnr', 'order', 'artikel', 'code', 'item']):
                        specs['order_number'] = value
                        description_parts.append(f"Order: {value}")
                
                if specs or description_parts:
                    table_products.append({
                        'table_index': table_idx,
                        'row_index': row_idx,
                        'specifications': specs,
                        'description_parts': description_parts,
                        'raw_data': row_data
                    })
    
    except Exception as e:
        print(f"  Warning: Error extracting table data: {e}")
    
    return table_products

def find_products_in_text(text: str, page_num: int, category: str) -> List[ProductItem]:
    """Identify individual products from text content"""
    products = []
    
    # Split text into potential product blocks (by double newlines or significant spacing)
    blocks = re.split(r'\n\s*\n|\n{3,}', text)
    
    for block_idx, block in enumerate(blocks):
        if len(block.strip()) < 10:  # Skip very short blocks
            continue
        
        # Extract product codes from this block
        codes = extract_product_codes(block)
        
        if codes:
            # Create a product for the primary code
            primary_code = codes[0]
            specs = extract_specifications(block)
            
            # Extract a clean description (first meaningful line)
            lines = [line.strip() for line in block.split('\n') if line.strip()]
            description = ' '.join(lines[:2])  # Take first 2 lines as description
            
            product = ProductItem(
                product_id=f"P{page_num:03d}_{block_idx:03d}_{primary_code}",
                page_number=page_num,
                category=category,
                description=description[:200],  # Limit description length
                specifications=specs,
                text_snippet=block[:300],  # Keep snippet for context
            )
            
            products.append(product)
    
    return products

def extract_images_from_page(page, page_num: int) -> List[ImageInfo]:
    """Extract all images from a page with metadata"""
    images = []
    
    try:
        if hasattr(page, 'images'):
            for img_idx, img in enumerate(page.images):
                try:
                    # Extract image bbox
                    bbox = {
                        'x0': img.get('x0', 0),
                        'y0': img.get('y0', 0),
                        'x1': img.get('x1', 0),
                        'y1': img.get('y1', 0),
                    }
                    
                    # Try to extract the actual image data
                    # This is a simplified approach - in reality, we'd need to render the page
                    # For now, we'll use the bbox and metadata
                    image_info = ImageInfo(
                        image_hash=f"img_p{page_num}_i{img_idx}_{hash(str(bbox))}",
                        page_number=page_num,
                        image_index=img_idx,
                        bbox=bbox,
                        width=int(bbox['x1'] - bbox['x0']),
                        height=int(bbox['y1'] - bbox['y0']),
                    )
                    
                    images.append(image_info)
                    
                except Exception as e:
                    print(f"  Warning: Could not process image {img_idx} on page {page_num}: {e}")
                    continue
    except Exception as e:
        print(f"  Warning: Could not extract images from page {page_num}: {e}")
    
    return images

def link_products_to_images(products: List[ProductItem], images: List[ImageInfo]) -> None:
    """Link products to their associated images based on proximity"""
    if not images:
        return
    
    for product in products:
        # For simplicity, assign the first image on the page
        # In a more sophisticated version, we'd use spatial proximity
        if images:
            closest_image = images[0]  # Simplified: take first image
            product.image_hash = closest_image.image_hash
            closest_image.products_using_image.append(product.product_id)

# ============================================================================
# MAIN ANALYSIS FUNCTION
# ============================================================================

def analyze_pdf() -> PDFAnalysisResults:
    """
    Main function to analyze the PE-buizen PDF
    Returns comprehensive analysis results
    """
    print(f"\n{'='*70}")
    print(f"ANALYZING PDF: {INPUT_PDF.name}")
    print(f"{'='*70}\n")
    
    if not INPUT_PDF.exists():
        raise FileNotFoundError(f"PDF not found: {INPUT_PDF}")
    
    pages_analysis = []
    all_products = []
    all_images = []
    category_counts = defaultdict(int)
    
    with pdfplumber.open(INPUT_PDF) as pdf:
        total_pages = len(pdf.pages)
        print(f"Total pages: {total_pages}\n")
        
        for page_num, page in enumerate(pdf.pages, start=1):
            print(f"Processing page {page_num}/{total_pages}...")
            
            # Extract text
            text = page.extract_text() or ""
            word_count = len(text.split())
            
            # Detect category for this page
            page_category = detect_category(text)
            category_counts[page_category] += 1
            
            # Extract table data first (more structured)
            table_data = extract_table_data(page)
            
            # Collect all products for this page
            page_products = []
            
            # Convert table data to products
            for table_item in table_data:
                specs = table_item['specifications']
                desc_parts = table_item['description_parts']
                
                # Create product ID
                order_num = specs.get('order_number', f"T{table_item['table_index']}R{table_item['row_index']}")
                product_id = f"P{page_num:03d}_TBL{table_item['table_index']}_{order_num}"
                
                # Build description
                if desc_parts:
                    description = ' - '.join(desc_parts)
                else:
                    description = f"Table product from page {page_num}"
                
                # Enhance category based on table context
                enhanced_category = page_category
                if specs.get('material'):
                    mat = specs['material'].upper()
                    if 'HDPE' in mat:
                        enhanced_category = 'hdpe_buizen'
                    elif 'LDPE' in mat:
                        enhanced_category = 'ldpe_buizen'
                
                product = ProductItem(
                    product_id=product_id,
                    page_number=page_num,
                    category=enhanced_category,
                    description=description[:200],
                    specifications=specs,
                    text_snippet=f"Table {table_item['table_index']}, Row {table_item['row_index']}",
                )
                page_products.append(product)
                all_products.append(product)
            
            # Find products in text (for non-table content)
            text_products = find_products_in_text(text, page_num, page_category)
            page_products.extend(text_products)
            all_products.extend(text_products)
            
            # Extract images
            images = extract_images_from_page(page, page_num)
            all_images.extend(images)
            
            # Link products to images (link both table and text products)
            link_products_to_images(page_products, images)
            
            # Create page analysis with ALL products from this page
            page_analysis = PageAnalysis(
                page_number=page_num,
                text_content=text[:500] + "..." if len(text) > 500 else text,  # Truncate for summary
                products_found=page_products,  # Now includes BOTH table and text products
                images_found=images,
                detected_category=page_category,
                word_count=word_count,
            )
            pages_analysis.append(page_analysis)
            
            print(f"  > Found {len(page_products)} products ({len(table_data)} from tables), {len(images)} images")
            print(f"  > Category: {page_category}")
            print(f"  > Word count: {word_count}")
    
    # Analyze shared images
    image_to_products = defaultdict(list)
    for product in all_products:
        if product.image_hash:
            image_to_products[product.image_hash].append(product.product_id)
    
    shared_images = [
        {
            'image_hash': img_hash,
            'product_count': len(prod_ids),
            'products': prod_ids
        }
        for img_hash, prod_ids in image_to_products.items()
        if len(prod_ids) > 1
    ]
    
    # Update products with shared image information
    for shared_img in shared_images:
        img_hash = shared_img['image_hash']
        prod_ids = shared_img['products']
        
        for product in all_products:
            if product.image_hash == img_hash:
                product.shared_image_with = [pid for pid in prod_ids if pid != product.product_id]
    
    # Create final results
    results = PDFAnalysisResults(
        pdf_name=INPUT_PDF.name,
        total_pages=total_pages,
        total_products=len(all_products),
        total_images=len(all_images),
        categories=dict(category_counts),
        pages=pages_analysis,
        product_image_mapping=dict(image_to_products),
        shared_images=shared_images,
    )
    
    return results

def save_results(results: PDFAnalysisResults) -> None:
    """Save analysis results to JSON file"""
    OUTPUT_DIR.mkdir(exist_ok=True)
    
    # Convert dataclasses to dictionaries
    results_dict = {
        'pdf_name': results.pdf_name,
        'total_pages': results.total_pages,
        'total_products': results.total_products,
        'total_images': results.total_images,
        'categories': results.categories,
        'pages': [
            {
                'page_number': page.page_number,
                'text_content': page.text_content,
                'products_found': [asdict(p) for p in page.products_found],
                'images_found': [asdict(img) for img in page.images_found],
                'detected_category': page.detected_category,
                'word_count': page.word_count,
            }
            for page in results.pages
        ],
        'product_image_mapping': results.product_image_mapping,
        'shared_images': results.shared_images,
    }
    
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(results_dict, f, indent=2, ensure_ascii=False)
    
    print(f"\n{'='*70}")
    print(f"DONE: Results saved to: {OUTPUT_JSON}")
    print(f"{'='*70}")

def print_summary(results: PDFAnalysisResults) -> None:
    """Print a human-readable summary of the analysis"""
    print(f"\n{'='*70}")
    print(f"ANALYSIS SUMMARY")
    print(f"{'='*70}\n")
    
    print(f"PDF Name: {results.pdf_name}")
    print(f"Total Pages: {results.total_pages}")
    print(f"Total Products Found: {results.total_products}")
    print(f"Total Images Found: {results.total_images}")
    
    print(f"\nCategories Distribution:")
    for category, count in sorted(results.categories.items(), key=lambda x: x[1], reverse=True):
        print(f"  • {category}: {count} pages")
    
    print(f"\nShared Images:")
    print(f"  • {len(results.shared_images)} images are shared between multiple products")
    
    if results.shared_images:
        print(f"\nTop Shared Images:")
        for idx, shared in enumerate(sorted(results.shared_images, key=lambda x: x['product_count'], reverse=True)[:5], 1):
            print(f"  {idx}. Image {shared['image_hash'][:16]}... used by {shared['product_count']} products")
            print(f"     Products: {', '.join(shared['products'][:3])}")
            if len(shared['products']) > 3:
                print(f"     ... and {len(shared['products']) - 3} more")
    
    print(f"\nPage-by-Page Summary:")
    for page in results.pages[:10]:  # Show first 10 pages
        print(f"  Page {page.page_number}: {len(page.products_found)} products, "
              f"{len(page.images_found)} images, category: {page.detected_category}")
    
    if len(results.pages) > 10:
        print(f"  ... and {len(results.pages) - 10} more pages")
    
    print()

# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    try:
        # Run analysis
        results = analyze_pdf()
        
        # Print summary
        print_summary(results)
        
        # Save results
        save_results(results)
        
        print(f"\nANALYSIS COMPLETE! Check {OUTPUT_JSON} for detailed results.\n")
        
    except Exception as e:
        print(f"\nERROR during analysis: {e}")
        import traceback
        traceback.print_exc()
        exit(1)
