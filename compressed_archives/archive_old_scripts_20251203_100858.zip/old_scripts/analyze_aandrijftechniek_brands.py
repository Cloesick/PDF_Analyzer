"""
Intelligent Aandrijftechniek Catalog Brand & Series Analysis
Extracts brands, series, and properties from catalog data
"""

import json
import re
from pathlib import Path
from collections import defaultdict

# Paths
INPUT_JSON = Path(r"C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop\public\data\catalogs\catalogus-aandrijftechniek-150922.json")
OUTPUT_DIR = Path(r"C:\Users\prova\Documents\Projects\PDF_Analyzer\output")
OUTPUT_JSON = OUTPUT_DIR / "catalogus_aandrijftechniek_150922_by_brand_series.json"
OUTPUT_GROUPED = OUTPUT_DIR / "catalogus_aandrijftechniek_150922_grouped_by_brand.json"
WEBSHOP_DATA = Path(r"C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop\public\data\aandrijftechniek-grouped.json")

# Brand definitions from user's data
BRANDS = ["NTN", "FK", "NTN-SNR", "SNR", "SKF", "BTC", "Walterscheid", "Bondioli & Pavesi", "Optibelt"]

# Series patterns from the user's text
SERIES_PATTERNS = {
    # Lagers en Lagerhuizen - Zelfinstellende Lagerblokken
    "NTN STAAND GIETIJZEREN LAGERBLOK P200 - P300": {
        "brand": "NTN",
        "type": "Staand Lagerblok",
        "material": "gietijzer",
        "series": "P200 - P300",
        "category": "Zelfinstellende Lagerblokken",
        "sku_prefixes": ["RLNUCP"]
    },
    "FK STAAND GIETIJZEREN LAGERBLOK P200 - P300": {
        "brand": "FK",
        "type": "Staand Lagerblok",
        "material": "gietijzer",
        "series": "P200 - P300",
        "category": "Zelfinstellende Lagerblokken",
        "sku_prefixes": ["RLFUCP"]
    },
    "NTN-SNR STAAND GIETIJZEREN LAGERBLOK PW200 (PAE200)": {
        "brand": "NTN-SNR",
        "type": "Staand Lagerblok",
        "material": "gietijzer",
        "series": "PW200 (PAE200)",
        "category": "Zelfinstellende Lagerblokken",
        "sku_prefixes": ["RLNUCPW", "RLSUCPAE"]
    },
    "FK STAAND GIETIJZEREN LAGERBLOK PW200 (PAE200)": {
        "brand": "FK",
        "type": "Staand Lagerblok",
        "material": "gietijzer",
        "series": "PW200 (PAE200)",
        "category": "Zelfinstellende Lagerblokken",
        "sku_prefixes": ["RLFUCPW"]
    },
    "NTN-SNR VIERKANT GIETIJZEREN FLENSLAGERBLOK F200 - F300": {
        "brand": "NTN-SNR",
        "type": "Flenslagerblok Vierkant",
        "material": "gietijzer",
        "series": "F200 - F300",
        "category": "Zelfinstellende Lagerblokken",
        "sku_prefixes": ["RLNUCF", "RLSUCF", "RLNUKF"]
    },
    "FK VIERKANT GIETIJZEREN FLENSLAGERBLOK F200": {
        "brand": "FK",
        "type": "Flenslagerblok Vierkant",
        "material": "gietijzer",
        "series": "F200",
        "category": "Zelfinstellende Lagerblokken",
        "sku_prefixes": ["RLFUCF"]
    },
    "NTN ROND GIETIJZEREN FLENSLAGERBLOK FC200": {
        "brand": "NTN",
        "type": "Flenslagerblok Rond",
        "material": "gietijzer",
        "series": "FC200",
        "category": "Zelfinstellende Lagerblokken",
        "sku_prefixes": ["RLNUCFC"]
    },
    "NTN OVAAL GIETIJZEREN FLENSLAGERBLOK FL200-FL300": {
        "brand": "NTN",
        "type": "Flenslagerblok Ovaal",
        "material": "gietijzer",
        "series": "FL200 - FL300",
        "category": "Zelfinstellende Lagerblokken",
        "sku_prefixes": ["RLNUCFL"]
    },
    "FK OVAAL GIETIJZEREN FLENSLAGERBLOK FL200 - FL300": {
        "brand": "FK",
        "type": "Flenslagerblok Ovaal",
        "material": "gietijzer",
        "series": "FL200 - FL300",
        "category": "Zelfinstellende Lagerblokken",
        "sku_prefixes": ["RLFUCFL"]
    },
    # Spanlagers
    "NTN-SNR SPANLAGER UC200": {
        "brand": "NTN-SNR",
        "type": "Spanlager",
        "series": "UC200",
        "category": "Spanlagers",
        "sku_prefixes": ["RLNUC"]
    },
    "SKF SPANLAGER YAR": {
        "brand": "SKF",
        "type": "Spanlager",
        "series": "YAR",
        "category": "Spanlagers",
        "sku_prefixes": ["SKFYAR"]
    },
    # Kogellagers
    "NTN-SNR GROEFKOGELLAGER": {
        "brand": "NTN-SNR",
        "type": "Groefkogellager",
        "series": "6000 serie",
        "category": "Kogellagers",
        "sku_prefixes": ["RLN6", "RLS6"]
    },
    "SKF GROEFKOGELLAGER": {
        "brand": "SKF",
        "type": "Groefkogellager",
        "series": "6000 serie",
        "category": "Kogellagers",
        "sku_prefixes": ["SKF6"]
    },
    # Kegellagers
    "NTN-SNR KEGELLAGER": {
        "brand": "NTN-SNR",
        "type": "Kegellager",
        "series": "30000 serie",
        "category": "Kegellagers",
        "sku_prefixes": ["RLN3", "RLS3"]
    },
    # Kettingaandrijvingen
    "BTC BS ROLLENKETTING SIMPLEX": {
        "brand": "BTC",
        "type": "Rollenketting Simplex",
        "series": "BS",
        "category": "Kettingaandrijvingen",
        "sku_prefixes": ["RKKBS"]
    },
    "BTC ASA ROLLENKETTING": {
        "brand": "BTC",
        "type": "Rollenketting",
        "series": "ASA",
        "category": "Kettingaandrijvingen",
        "sku_prefixes": ["RKKASA", "RKSASA"]
    },
    # Aandrijfassen
    "WALTERSCHEID W-SERIE": {
        "brand": "Walterscheid",
        "type": "Aandrijfas",
        "series": "W-serie",
        "category": "Aandrijfassen",
        "sku_prefixes": ["CARDW"]
    },
    "WALTERSCHEID WWE-SERIE": {
        "brand": "Walterscheid",
        "type": "Aandrijfas Groothoek",
        "series": "WWE-serie",
        "category": "Aandrijfassen",
        "sku_prefixes": ["CARDWWE"]
    },
    # Aandrijfriemen
    "OPTIBELT V-RIEM": {
        "brand": "Optibelt",
        "type": "V-Riem",
        "series": "Klassiek",
        "category": "Aandrijfriemen",
        "sku_prefixes": ["VRA", "VRB", "VRC"]
    },
}

def detect_brand_and_series(sku):
    """Detect brand and series from SKU pattern"""
    
    # Try to match against known patterns
    for series_name, info in SERIES_PATTERNS.items():
        for prefix in info.get("sku_prefixes", []):
            if sku.startswith(prefix):
                return info
    
    # Fallback brand detection
    if sku.startswith("RLN") or sku.startswith("RLS"):
        return {"brand": "NTN-SNR", "category": "Lagers", "type": "Lager"}
    elif sku.startswith("RLF"):
        return {"brand": "FK", "category": "Lagers", "type": "Lager"}
    elif sku.startswith("SKF"):
        return {"brand": "SKF", "category": "Lagers", "type": "Lager"}
    elif sku.startswith("CARD"):
        return {"brand": "Walterscheid", "category": "Aandrijfassen", "type": "Aandrijfas"}
    elif sku.startswith("CARK") or sku.startswith("CARG") or sku.startswith("CARS"):
        return {"brand": "Walterscheid", "category": "Aandrijfassen", "type": "Onderdeel"}
    elif sku.startswith("RKK") or sku.startswith("RKS"):
        return {"brand": "BTC", "category": "Kettingaandrijvingen", "type": "Ketting"}
    elif sku.startswith("VR"):
        return {"brand": "Optibelt", "category": "Aandrijfriemen", "type": "Riem"}
    elif sku.startswith("OK"):
        return {"brand": "Diverse", "category": "Oliekeerringen", "type": "Oliekeerring"}
    elif sku.startswith("CARBU"):
        return {"brand": "Walterscheid", "category": "Aandrijfassen", "type": "Profielbuis"}
    
    return {"brand": "Onbekend", "category": "Diverse", "type": "Product"}

def extract_properties_from_sku(sku):
    """Extract technical properties from SKU"""
    properties = {}
    
    # Extract numbers (often diameter, size, etc.)
    numbers = re.findall(r'\d+', sku)
    if numbers:
        properties["size_code"] = numbers[-1] if numbers else None
    
    # Detect type markers
    if 'UCP' in sku:
        properties["type"] = "Staand Lagerblok"
    elif 'UCF' in sku:
        properties["type"] = "Flenslagerblok"
    elif 'UCFL' in sku:
        properties["type"] = "Flenslagerblok Ovaal"
    elif 'UCFC' in sku:
        properties["type"] = "Flenslagerblok Rond"
    
    return properties

def main():
    print("=" * 80)
    print("AANDRIJFTECHNIEK BRAND & SERIES ANALYSIS")
    print("=" * 80)
    
    # Load existing data
    print("\n📖 Loading existing catalog data...")
    with open(INPUT_JSON, 'r', encoding='utf-8') as f:
        products = json.load(f)
    print(f"   ✓ Loaded {len(products)} products")
    
    # Analyze and enrich products
    print("\n🔍 Analyzing brands and series...")
    enriched_products = []
    brand_stats = defaultdict(int)
    category_stats = defaultdict(int)
    series_stats = defaultdict(int)
    
    for product in products:
        sku = product.get("sku", "")
        
        # Detect brand and series
        detection = detect_brand_and_series(sku)
        brand = detection.get("brand", "Onbekend")
        category = detection.get("category", "Diverse")
        product_type = detection.get("type", "Product")
        series = detection.get("series", "")
        
        # Extract properties
        properties = extract_properties_from_sku(sku)
        
        # Enrich product
        product["brand"] = brand
        product["product_type"] = product_type
        product["series"] = series
        product["subcategory"] = category
        
        # Generate better name
        if series:
            product["name"] = f"{brand} {product_type} {sku}"
            product["description"] = f"{brand} {product_type} uit de {series} serie"
        else:
            product["name"] = f"{brand} {product_type} {sku}"
            product["description"] = f"{brand} {product_type}"
        
        # Add extracted properties to attributes
        if not product.get("attributes"):
            product["attributes"] = {}
        product["attributes"].update(properties)
        
        # Update metadata
        if detection.get("material"):
            product["attributes"]["material"] = detection["material"]
        
        enriched_products.append(product)
        
        # Stats
        brand_stats[brand] += 1
        category_stats[category] += 1
        if series:
            series_stats[f"{brand} - {series}"] += 1
    
    print(f"   ✓ Analyzed {len(enriched_products)} products")
    
    # Save enriched products
    print("\n💾 Saving enriched catalog...")
    OUTPUT_DIR.mkdir(exist_ok=True)
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(enriched_products, f, indent=2, ensure_ascii=False)
    print(f"   ✓ Saved to: {OUTPUT_JSON}")
    
    # Create grouped structure by brand and series
    print("\n📊 Creating grouped structure by brand and series...")
    grouped = defaultdict(lambda: defaultdict(list))
    
    for product in enriched_products:
        brand = product.get("brand", "Onbekend")
        series = product.get("series", "Overig")
        category = product.get("subcategory", "Diverse")
        
        group_key = f"{brand} - {category}"
        if series:
            group_key = f"{brand} - {series}"
        
        grouped[brand][group_key].append(product)
    
    # Format grouped output
    output_groups = []
    for brand, series_dict in sorted(grouped.items()):
        for series_name, products_list in sorted(series_dict.items()):
            # Get representative product for group info
            rep_product = products_list[0]
            
            group = {
                "group_id": series_name.lower().replace(" ", "-").replace("--", "-"),
                "group_name": series_name,
                "brand": brand,
                "category": rep_product.get("subcategory", "Diverse"),
                "series": rep_product.get("series", ""),
                "product_type": rep_product.get("product_type", "Product"),
                "product_count": len(products_list),
                "media": [],
                "variants": []
            }
            
            # Collect all images from variants
            all_images = []
            for prod in products_list:
                if prod.get("image_paths"):
                    all_images.extend(prod["image_paths"])
                elif prod.get("imageUrl"):
                    all_images.append(prod["imageUrl"])
            
            # Deduplicate and add to group
            unique_images = list(dict.fromkeys(all_images))
            if unique_images:
                group["media"] = [{"url": img, "role": "main" if i == 0 else "gallery", "type": "image"} 
                                  for i, img in enumerate(unique_images[:10])]  # Max 10 images
            
            # Add variants
            for prod in products_list:
                variant = {
                    "sku": prod["sku"],
                    "name": prod["name"],
                    "attributes": prod.get("attributes", {}),
                    "specs": prod.get("specs", []),
                    "image_url": prod.get("imageUrl"),
                    "pages": prod.get("source_pages", [])
                }
                group["variants"].append(variant)
            
            output_groups.append(group)
    
    # Save grouped output
    with open(OUTPUT_GROUPED, 'w', encoding='utf-8') as f:
        json.dump(output_groups, f, indent=2, ensure_ascii=False)
    print(f"   ✓ Created {len(output_groups)} product groups")
    print(f"   ✓ Saved to: {OUTPUT_GROUPED}")
    
    # Copy to webshop
    print("\n🌐 Copying to webshop...")
    with open(WEBSHOP_DATA, 'w', encoding='utf-8') as f:
        json.dump(output_groups, f, indent=2, ensure_ascii=False)
    print(f"   ✓ Saved to: {WEBSHOP_DATA}")
    
    # Print statistics
    print("\n" + "=" * 80)
    print("📈 ANALYSIS RESULTS")
    print("=" * 80)
    
    print(f"\n🏭 BRANDS ({len(brand_stats)} brands):")
    for brand, count in sorted(brand_stats.items(), key=lambda x: -x[1]):
        print(f"   • {brand:20s} : {count:4d} products")
    
    print(f"\n📦 CATEGORIES ({len(category_stats)} categories):")
    for cat, count in sorted(category_stats.items(), key=lambda x: -x[1]):
        print(f"   • {cat:30s} : {count:4d} products")
    
    print(f"\n📋 TOP SERIES ({min(15, len(series_stats))} series):")
    for series, count in sorted(series_stats.items(), key=lambda x: -x[1])[:15]:
        print(f"   • {series:50s} : {count:4d} products")
    
    print(f"\n✅ SUMMARY:")
    print(f"   • Total Products     : {len(enriched_products)}")
    print(f"   • Total Groups       : {len(output_groups)}")
    print(f"   • Brands Identified  : {len(brand_stats)}")
    print(f"   • Categories         : {len(category_stats)}")
    print(f"   • Product Series     : {len([s for s in series_stats if series_stats[s] > 1])}")
    
    print("\n" + "=" * 80)
    print("✅ BRAND & SERIES ANALYSIS COMPLETE!")
    print("=" * 80)

if __name__ == "__main__":
    main()
