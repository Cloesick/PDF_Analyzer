"""
Deep Analysis of Unmatched Products
====================================
Find patterns in unmatched products to improve coverage
"""
import json
from pathlib import Path
from collections import defaultdict, Counter
import re

PROJECT_ROOT = Path(__file__).parent
PRODUCTS_JSON = PROJECT_ROOT / "output" / "products_ready_for_webshop.json"
EXTRACTED_JSON = PROJECT_ROOT / "output" / "makita_extracted_products.json"

def main():
    print("=" * 80)
    print("DEEP ANALYSIS OF UNMATCHED PRODUCTS")
    print("=" * 80)
    
    # Load data
    with open(PRODUCTS_JSON, 'r', encoding='utf-8') as f:
        all_products = json.load(f)
    
    with open(EXTRACTED_JSON, 'r', encoding='utf-8') as f:
        extracted_images = json.load(f)
    
    makita_products = [p for p in all_products if 'makita-catalogus-2022-nl' in p.get('pdf_source', '')]
    
    # Build image SKU set
    image_skus = set()
    for entry in extracted_images:
        image_skus.add(entry['sku'])
    
    # Find unmatched products
    unmatched = [p for p in makita_products if p['sku'] not in image_skus]
    matched = [p for p in makita_products if p['sku'] in image_skus]
    
    print(f"\n📊 Dataset:")
    print(f"   Total Makita products: {len(makita_products)}")
    print(f"   ✅ Matched: {len(matched)} (52.9%)")
    print(f"   ❌ Unmatched: {len(unmatched)} (47.1%)")
    
    # PATTERN 1: SKU Structure Analysis
    print("\n" + "=" * 80)
    print("1. SKU STRUCTURE PATTERNS")
    print("=" * 80)
    
    def categorize_sku(sku):
        if re.match(r'^[A-Z]{2,4}\d{3,4}[A-Z]*$', sku):
            return 'Standard (e.g., DHS680, GA7082)'
        elif re.match(r'^\d{5,6}$', sku):
            return 'Numeric (e.g., 28606, 13568)'
        elif re.match(r'^\d{6}-\d$', sku):
            return 'Part number (e.g., 199009-8)'
        elif re.match(r'^[A-Z]{2}\d{3}[A-Z]{2}\d{3}$', sku):
            return 'Long format (e.g., TD001GD201)'
        elif 'RT' in sku or 'ZJ' in sku or 'ZK' in sku:
            return 'Kit/Set suffix'
        else:
            return 'Other'
    
    unmatched_patterns = Counter([categorize_sku(p['sku']) for p in unmatched])
    matched_patterns = Counter([categorize_sku(p['sku']) for p in matched])
    
    print("\n📊 Unmatched SKU Patterns:")
    for pattern, count in unmatched_patterns.most_common():
        total = count + matched_patterns.get(pattern, 0)
        pct = (count / total * 100) if total > 0 else 0
        print(f"   {pattern:30s} | {count:4d} unmatched ({pct:.1f}% of this type)")
    
    # PATTERN 2: Page Distribution
    print("\n" + "=" * 80)
    print("2. PAGE DISTRIBUTION ANALYSIS")
    print("=" * 80)
    
    unmatched_pages = defaultdict(list)
    for p in unmatched:
        pages = p.get('source', {}).get('pages', [])
        for page in pages:
            unmatched_pages[page].append(p['sku'])
    
    print("\n📄 Pages with most unmatched products:")
    for page, skus in sorted(unmatched_pages.items(), key=lambda x: -len(x[1]))[:15]:
        print(f"   Page {page:3d} | {len(skus):3d} unmatched products")
        if page <= 5:
            print(f"           → Sample: {', '.join(skus[:3])}")
    
    # PATTERN 3: SKU Suffix Analysis
    print("\n" + "=" * 80)
    print("3. SKU SUFFIX ANALYSIS")
    print("=" * 80)
    
    def extract_base_and_suffix(sku):
        # Try to split SKU into base + suffix
        match = re.match(r'^([A-Z]{2,4}\d{3,4})([A-Z]{0,10})$', sku)
        if match:
            return match.group(1), match.group(2)
        return sku, ''
    
    suffix_stats = Counter()
    unmatched_with_suffix = []
    
    for p in unmatched:
        base, suffix = extract_base_and_suffix(p['sku'])
        if suffix:
            suffix_stats[suffix] += 1
            unmatched_with_suffix.append((p['sku'], base, suffix))
    
    print(f"\n🔍 Found {len(unmatched_with_suffix)} unmatched SKUs with suffixes")
    print("\n📊 Most common suffixes in unmatched products:")
    for suffix, count in suffix_stats.most_common(15):
        print(f"   {suffix:10s} | {count:3d} products")
    
    # Check if base SKUs exist in images
    print("\n💡 Checking if base SKUs exist in images...")
    base_matches = []
    for sku, base, suffix in unmatched_with_suffix[:30]:
        if base in image_skus:
            base_matches.append((sku, base, suffix))
    
    print(f"\n✨ Found {len(base_matches)} unmatched products where base SKU has images!")
    for sku, base, suffix in base_matches[:20]:
        print(f"   {sku:15s} → Base {base:10s} has images (suffix: {suffix})")
    
    # PATTERN 4: Similar SKUs
    print("\n" + "=" * 80)
    print("4. NEAR-MATCH ANALYSIS")
    print("=" * 80)
    
    from difflib import SequenceMatcher
    
    def similar(a, b):
        return SequenceMatcher(None, a, b).ratio()
    
    near_matches = []
    for p in unmatched[:100]:  # Sample
        sku = p['sku']
        best_match = None
        best_ratio = 0
        
        for img_sku in image_skus:
            ratio = similar(sku, img_sku)
            if 0.75 <= ratio < 0.85:  # Just below current threshold
                if ratio > best_ratio:
                    best_ratio = ratio
                    best_match = img_sku
        
        if best_match:
            near_matches.append((sku, best_match, best_ratio))
    
    print(f"\n🔍 Found {len(near_matches)} near-matches (75-84% similar):")
    for sku, match, ratio in near_matches[:20]:
        print(f"   {sku:15s} ≈ {match:15s} | {ratio*100:.1f}% similar")
    
    # PATTERN 5: Kit Detection
    print("\n" + "=" * 80)
    print("5. KIT/BUNDLE ANALYSIS")
    print("=" * 80)
    
    kit_indicators = ['RTJ', 'SAX', 'TJ', 'ZJ', 'ZK', 'RJ', 'PT', 'RFX', 'RMJ']
    kit_products = [p for p in unmatched if any(ind in p['sku'] for ind in kit_indicators)]
    
    print(f"\n📦 Found {len(kit_products)} potential kit/bundle products:")
    print(f"   These often don't have individual photos")
    for p in kit_products[:15]:
        print(f"   {p['sku']:15s} | Page {p.get('source', {}).get('pages', [None])[0]}")
    
    # RECOMMENDATIONS
    print("\n" + "=" * 80)
    print("ACTIONABLE RECOMMENDATIONS")
    print("=" * 80)
    
    print(f"\n1️⃣  LOWER FUZZY THRESHOLD (75% instead of 85%)")
    print(f"   → Could match {len(near_matches)} more products")
    
    print(f"\n2️⃣  ADD BASE SKU MATCHING")
    print(f"   → Match product variants to base SKU images")
    print(f"   → Could match {len(base_matches)} more products")
    
    print(f"\n3️⃣  AGGRESSIVE EXTRACTION")
    print(f"   → Lower quality thresholds further")
    print(f"   → Focus on pages 2-10 (index pages have many products)")
    
    print(f"\n4️⃣  MULTI-IMAGE SUPPORT")
    print(f"   → Allow products to have multiple images")
    print(f"   → {matched_patterns.get('Standard (e.g., DHS680, GA7082)', 0)} matched products could have galleries")
    
    print(f"\n5️⃣  SKIP KIT PRODUCTS")
    print(f"   → Mark {len(kit_products)} kit products as expected-no-image")
    print(f"   → Adjust coverage calculations to exclude them")
    
    # Estimated impact
    potential_gain = len(near_matches) + len(base_matches)
    new_matched = len(matched) + potential_gain
    new_coverage = new_matched / len(makita_products) * 100
    
    print(f"\n🎯 POTENTIAL IMPACT:")
    print(f"   Current coverage:     {len(matched)}/{len(makita_products)} (52.9%)")
    print(f"   Near-matches:         +{len(near_matches)}")
    print(f"   Base SKU matches:     +{len(base_matches)}")
    print(f"   Estimated coverage:   {new_matched}/{len(makita_products)} ({new_coverage:.1f}%)")
    
    # Save analysis
    analysis = {
        'unmatched_patterns': dict(unmatched_patterns),
        'near_matches': near_matches[:50],
        'base_matches': base_matches,
        'kit_products': len(kit_products),
        'estimated_gain': potential_gain
    }
    
    output_path = PROJECT_ROOT / "output" / "unmatched_analysis.json"
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(analysis, f, indent=2)
    
    print(f"\n💾 Analysis saved to: {output_path}")

if __name__ == '__main__':
    main()
