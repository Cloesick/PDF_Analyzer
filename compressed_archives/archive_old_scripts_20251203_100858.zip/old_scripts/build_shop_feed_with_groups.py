"""
Build webshop feed with support for product groups and individual products.

This script generates a unified product feed that includes:
1. Product groups (for table-based products with variants)
2. Individual products (for standalone items)

Product groups share a single image across all variants, improving efficiency
and user experience with a variant selector.
"""
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"

# Input files
GROUPED_PRODUCTS_JSON = OUTPUT_DIR / "abs_persluchtbuizen_grouped.json"
INPUT_JSON = OUTPUT_DIR / "input_pdfs_analysis_v5.json"
SHOP_FEED_JSON = OUTPUT_DIR / "products_for_shop_v2.json"

# Public URL prefix for images
BASE_MEDIA_URL = "https://example.com/media/"

# Map catalog base names to brands
CATALOG_TO_BRAND = {
    "catalogus-abs-persluchtbuizen": "Dema",
    "abs-persluchtbuizen": "Dema",
    "makita-catalogus-2022-nl": "Makita",
    "airpress-catalogus-nl-fr": "Airpress",
    "bronpompen": "Dema",
    "centrifugaalpompen": "Dema",
    "digitale-versie-pompentoebehoren-compressed": "Dema",
    "dompelpompen": "Dema",
    "drukbuizen": "Dema",
}


def transform_product_group(group: Dict[str, Any]) -> Dict[str, Any]:
    """
    Transform a product group into webshop format.
    """
    catalog = group.get("catalog", "")
    brand = CATALOG_TO_BRAND.get(catalog, "Dema")
    family = group.get("family", "")
    
    # Media - shared across all variants
    media: List[Dict[str, Any]] = []
    for item in group.get("media", []):
        media.append({
            "url": item.get("url"),
            "role": item.get("role", "main")
        })
    
    # Build attributes from common properties
    attrs: Dict[str, Any] = {}
    common_props = group.get("common_properties", {})
    for key, value in common_props.items():
        if value is not None and not key.endswith("_display"):
            attrs[key] = value
    
    # Build specs from attributes
    specs = []
    for key, value in attrs.items():
        specs.append({
            "key": key,
            "label": key.replace("_", " ").title(),
            "value": value,
        })
    
    # Transform variants
    variants = []
    for variant in group.get("variants", []):
        variant_props = variant.get("properties", {})
        variant_attrs = {}
        
        # Extract numeric values (not display strings)
        for key, value in variant_props.items():
            if not key.endswith("_display") and value is not None:
                variant_attrs[key] = value
        
        variants.append({
            "sku": variant.get("sku"),
            "label": variant.get("label"),
            "attributes": variant_attrs,
            "page_in_pdf": variant.get("page_in_pdf"),
        })
    
    group_id = group.get("group_id", f"{catalog}:{family}")
    default_sku = group.get("default_variant_sku")
    
    return {
        "id": group_id,
        "type": "product_group",
        "name": group.get("name", f"{family} Series"),
        "brand": brand,
        "catalog": catalog,
        "category": catalog.replace("-", " ").title(),
        "description": f"{group.get('name', family)} - Available in {group.get('variant_count', 0)} variants",
        "family": family,
        "attributes": attrs,
        "specs": specs,
        "media": media,
        "variants": variants,
        "variant_count": len(variants),
        "default_variant_sku": default_sku,
        "price": {
            "amount": None,
            "currency": "EUR",
            "vat_included": True,
            "mode": "request_quote",
            "note": "Price varies by variant"
        },
        "stock": {
            "status": "unknown",
            "quantity": None,
        },
        "seo": {
            "slug": f"{family}-series".lower(),
            "meta_title": f"{group.get('name', family)} | Product Group",
            "meta_description": f"Choose from {group.get('variant_count', 0)} variants of {group.get('name', family)}",
        },
        "source": {
            "page_in_pdf": group.get("page_in_pdf"),
            "type": "table_group",
        },
    }


def load_grouped_products() -> List[Dict[str, Any]]:
    """
    Load grouped products from JSON file.
    """
    if not GROUPED_PRODUCTS_JSON.exists():
        print(f"⚠️  No grouped products found at {GROUPED_PRODUCTS_JSON}")
        return []
    
    with GROUPED_PRODUCTS_JSON.open("r", encoding="utf-8") as f:
        groups = json.load(f)
    
    print(f"📦 Loaded {len(groups)} product groups")
    return groups


def build_catalog_with_groups(catalog_name: str) -> List[Dict[str, Any]]:
    """
    Build a unified catalog feed with product groups and individual products.
    """
    products = []
    
    # Load grouped products for this catalog
    if catalog_name == "abs-persluchtbuizen":
        grouped = load_grouped_products()
        
        print(f"\n🏗️  Processing {len(grouped)} product groups...")
        for group in grouped:
            transformed = transform_product_group(group)
            products.append(transformed)
            
            if len(products) <= 3:
                print(f"   ✓ {transformed['name']} - {transformed['variant_count']} variants")
    
    return products


def main() -> None:
    print("=" * 80)
    print("BUILDING WEBSHOP FEED WITH PRODUCT GROUPS")
    print("=" * 80)
    
    # Build feed for ABS catalog with groups
    print("\n📋 Building ABS catalog with product groups...")
    abs_products = build_catalog_with_groups("abs-persluchtbuizen")
    
    # Save results
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    with SHOP_FEED_JSON.open("w", encoding="utf-8") as f:
        json.dump(abs_products, f, ensure_ascii=False, indent=2)
    
    # Statistics
    print(f"\n📊 FEED STATISTICS:")
    print(f"   Total items in feed:       {len(abs_products)}")
    
    product_groups = [p for p in abs_products if p.get("type") == "product_group"]
    individual_products = [p for p in abs_products if p.get("type") != "product_group"]
    
    print(f"   Product groups:            {len(product_groups)}")
    print(f"   Individual products:       {len(individual_products)}")
    
    if product_groups:
        total_variants = sum(p.get("variant_count", 0) for p in product_groups)
        print(f"   Total variants in groups:  {total_variants}")
        print(f"   Avg variants per group:    {total_variants / len(product_groups):.1f}")
    
    # Show samples
    print(f"\n📋 SAMPLE PRODUCT GROUPS:")
    for product in abs_products[:5]:
        if product.get("type") == "product_group":
            print(f"\n   {product['name']}")
            print(f"   └─ {product['variant_count']} variants")
            print(f"   └─ Default SKU: {product['default_variant_sku']}")
            print(f"   └─ Media items: {len(product.get('media', []))}")
    
    print(f"\n💾 Output saved to: {SHOP_FEED_JSON}")
    print(f"\n{'='*80}")
    print("✅ FEED BUILD COMPLETE")
    print("="*80)
    
    print("\n💡 NEXT STEPS:")
    print("   1. Open product_group_demo.html to see the variant selector in action")
    print("   2. Integrate ProductGroupWithVariants.tsx into your webshop")
    print("   3. Update your API to serve product groups from products_for_shop_v2.json")
    print("   4. Apply this same grouping logic to other catalogs with table-based products")


if __name__ == "__main__":
    main()
