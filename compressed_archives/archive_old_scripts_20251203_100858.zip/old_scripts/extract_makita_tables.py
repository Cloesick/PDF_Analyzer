"""
Extract Makita Product Tables with Vertical Headers
====================================================
Extract product specifications and prices from Makita catalog tables
where:
- First row contains product names/SKUs (starting from column 2)
- Column 0 contains property names (vertical headers)
- Column 1 sometimes contains sub-labels (like "excl. btw")
- Prices are in rows with "Prijs" label
"""
import pdfplumber
from pathlib import Path
import json
import re
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "makita-catalogus-2022-nl.pdf"
OUTPUT_JSON = PROJECT_ROOT / "output" / "makita_table_products.json"

def clean_text(text):
    """Clean extracted text"""
    if not text:
        return ""
    return str(text).strip().replace('\n', ' ').replace('\r', '')

def extract_price(text):
    """Extract numeric price from text like '€ 515,00' or '€ 1.232,99'"""
    if not text:
        return None
    
    # Remove euro symbol and spaces
    text = text.replace('€', '').strip()
    
    # Handle format like "1.232,99" (European format with thousands separator)
    # Remove thousands separator (.)
    text = text.replace('.', '')
    # Replace decimal separator (,) with .
    text = text.replace(',', '.')
    
    # Extract number
    match = re.search(r'(\d+\.?\d*)', text)
    if match:
        try:
            return float(match.group(1))
        except:
            return None
    return None

def is_product_table(table):
    """Check if table contains product specifications"""
    if not table or len(table) < 3:
        return False
    
    # Check if first column contains typical property names
    property_names = ['Spanning', 'Gewicht', 'Toerental', 'Prijs', 'Slagenergie', 
                     'Diameter', 'Capaciteit', 'Vermogen', 'Max.', 'Min.']
    
    for row in table[:10]:  # Check first 10 rows
        if row and row[0]:
            cell = clean_text(row[0])
            for prop_name in property_names:
                if prop_name.lower() in cell.lower():
                    return True
    return False

def find_product_skus_on_page(page_text):
    """Find all product SKUs on the page"""
    # SKU patterns for Makita products
    sku_patterns = [
        r'\b[A-Z]{2,4}\d{3,4}[A-Z]{1,4}\b',  # DHS680RTJ, GA7082, DHK180ZJ
        r'\b\d{6}-\d\b',  # 199009-8
        r'\b[A-Z]{2}\d{3}[A-Z]{2}\d{3}\b',  # TD001GD201
    ]
    
    found_skus = []
    
    # Extract all potential SKUs from the page
    for pattern in sku_patterns:
        matches = re.findall(pattern, page_text)
        found_skus.extend(matches)
    
    # Remove duplicates while preserving order
    seen = set()
    unique_skus = []
    for sku in found_skus:
        if sku not in seen:
            seen.add(sku)
            unique_skus.append(sku)
    
    return unique_skus

def extract_products_from_table(table, page_num, page_text=""):
    """Extract product data from a table with vertical headers"""
    if not table or len(table) < 2:
        return []
    
    products = []
    
    # Row 0 contains property data (like "18 V" for voltage)
    # Product SKUs are in the text ABOVE the table
    header_row = table[0]
    
    # Count how many product columns we have (skip first 2 cols for labels)
    num_products = 0
    for col_idx in range(2, len(header_row)):
        if header_row[col_idx] and clean_text(header_row[col_idx]):
            num_products += 1
    
    if num_products == 0:
        return []
    
    # Try to find SKUs in page text (if available)
    page_skus = find_product_skus_on_page(page_text) if page_text else []
    
    # Match SKUs to product columns
    # We need exactly num_products SKUs
    product_skus = []
    
    if len(page_skus) >= num_products:
        # Use the first num_products SKUs found
        for idx in range(num_products):
            product_skus.append((idx + 2, page_skus[idx]))
    elif len(page_skus) > 0:
        # We have some SKUs but not enough - use what we have and pad with placeholders
        for idx, sku in enumerate(page_skus):
            product_skus.append((idx + 2, sku))
        for idx in range(len(page_skus), num_products):
            product_skus.append((idx + 2, f"UNKNOWN_{page_num}_COL{idx+2}"))
    else:
        # No SKUs found - use placeholders
        for col_idx in range(2, 2 + num_products):
            product_skus.append((col_idx, f"UNKNOWN_{page_num}_COL{col_idx}"))
    
    print(f"\n   Found {len(product_skus)} products in table:")
    for col_idx, sku in product_skus:
        print(f"      Column {col_idx}: {sku}")
    
    # Initialize product data
    for col_idx, sku in product_skus:
        products.append({
            'sku': sku,
            'pdf_source': 'makita-catalogus-2022-nl',
            'page': page_num,
            'column_index': col_idx,
            'properties': {},
            'price_excl_btw_eur': None,
            'price_incl_btw_eur': None
        })
    
    # Extract properties from each row
    for row_idx in range(1, len(table)):
        row = table[row_idx]
        
        if not row or not row[0]:
            continue
        
        # Column 0 = property name
        property_name = clean_text(row[0])
        
        # Column 1 = sub-label (like "excl. btw", "incl. btw")
        sub_label = clean_text(row[1]) if len(row) > 1 else ""
        
        if not property_name:
            property_name = sub_label
            sub_label = ""
        
        # Check if this is a price row
        is_price_excl = 'excl' in property_name.lower() or 'excl' in sub_label.lower()
        is_price_incl = 'incl' in property_name.lower() or 'incl' in sub_label.lower()
        is_price_row = 'prijs' in property_name.lower() or 'price' in property_name.lower()
        
        # Extract values for each product
        for prod_idx, (col_idx, sku) in enumerate(product_skus):
            if col_idx < len(row):
                value = clean_text(row[col_idx])
                
                if value:
                    # Handle price rows specially
                    if is_price_row or is_price_excl or is_price_incl:
                        price = extract_price(value)
                        if price:
                            if is_price_excl or (is_price_row and 'excl' in sub_label.lower()):
                                products[prod_idx]['price_excl_btw_eur'] = price
                                print(f"      {sku}: Price excl. BTW = €{price:.2f}")
                            elif is_price_incl or (is_price_row and 'incl' in sub_label.lower()):
                                products[prod_idx]['price_incl_btw_eur'] = price
                                print(f"      {sku}: Price incl. BTW = €{price:.2f}")
                    else:
                        # Regular property
                        full_property_name = f"{property_name} {sub_label}".strip()
                        products[prod_idx]['properties'][full_property_name] = value
    
    return products

def extract_all_tables():
    """Extract all product tables from the PDF"""
    print("=" * 80)
    print("EXTRACTING MAKITA TABLE DATA")
    print("=" * 80)
    
    all_products = []
    stats = {
        'pages_scanned': 0,
        'tables_found': 0,
        'product_tables': 0,
        'products_extracted': 0,
        'products_with_prices': 0
    }
    
    with pdfplumber.open(PDF_PATH) as pdf:
        total_pages = len(pdf.pages)
        
        for page_num in range(1, total_pages + 1):
            page = pdf.pages[page_num - 1]
            stats['pages_scanned'] += 1
            
            # Progress update every 10 pages
            if page_num % 10 == 0:
                print(f"\n[PROGRESS] Scanned {page_num}/{total_pages} pages...")
                print(f"   Extracted {stats['products_extracted']} products so far")
            
            # Extract tables
            tables = page.extract_tables()
            
            if not tables:
                continue
            
            stats['tables_found'] += len(tables)
            
            # Get page text for SKU extraction
            page_text = page.extract_text() or ""
            
            # Process each table
            for table_idx, table in enumerate(tables):
                if not is_product_table(table):
                    continue
                
                stats['product_tables'] += 1
                print(f"\n[TABLE] Page {page_num}, Table {table_idx + 1}: Product specification table")
                
                # Extract products from this table
                products = extract_products_from_table(table, page_num, page_text)
                
                if products:
                    stats['products_extracted'] += len(products)
                    
                    # Count products with prices
                    for prod in products:
                        if prod['price_excl_btw_eur'] or prod['price_incl_btw_eur']:
                            stats['products_with_prices'] += 1
                    
                    all_products.extend(products)
    
    # Save results
    print(f"\n[SAVING] Saving extracted data...")
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(all_products, f, indent=2, ensure_ascii=False)
    
    # Summary
    print("\n" + "=" * 80)
    print("EXTRACTION COMPLETE")
    print("=" * 80)
    
    print(f"\n[STATISTICS]")
    print(f"   Pages scanned:        {stats['pages_scanned']}")
    print(f"   Tables found:         {stats['tables_found']}")
    print(f"   Product tables:       {stats['product_tables']}")
    print(f"   Products extracted:   {stats['products_extracted']}")
    print(f"   With prices:          {stats['products_with_prices']} ({stats['products_with_prices']/stats['products_extracted']*100:.1f}%)")
    
    print(f"\n[PRICE SUMMARY]")
    prices_excl = [p['price_excl_btw_eur'] for p in all_products if p['price_excl_btw_eur']]
    prices_incl = [p['price_incl_btw_eur'] for p in all_products if p['price_incl_btw_eur']]
    
    if prices_excl:
        print(f"   Prices excl. BTW: {len(prices_excl)} products")
        print(f"   Range: €{min(prices_excl):.2f} - €{max(prices_excl):.2f}")
        print(f"   Average: €{sum(prices_excl)/len(prices_excl):.2f}")
    
    if prices_incl:
        print(f"   Prices incl. BTW: {len(prices_incl)} products")
        print(f"   Range: €{min(prices_incl):.2f} - €{max(prices_incl):.2f}")
        print(f"   Average: €{sum(prices_incl)/len(prices_incl):.2f}")
    
    print(f"\n[OUTPUT] Results saved to: {OUTPUT_JSON}")
    print(f"\n[SUCCESS] Extracted {stats['products_extracted']} products from {stats['product_tables']} tables!")
    
    # Sample output
    if all_products:
        print(f"\n[SAMPLE PRODUCTS] First 3:")
        for prod in all_products[:3]:
            print(f"\n   SKU: {prod['sku']}")
            print(f"   Page: {prod['page']}")
            if prod['price_excl_btw_eur']:
                print(f"   Price excl. BTW: €{prod['price_excl_btw_eur']:.2f}")
            if prod['price_incl_btw_eur']:
                print(f"   Price incl. BTW: €{prod['price_incl_btw_eur']:.2f}")
            print(f"   Properties: {len(prod['properties'])} specs")
            for key, value in list(prod['properties'].items())[:3]:
                print(f"      - {key}: {value}")

if __name__ == '__main__':
    extract_all_tables()
