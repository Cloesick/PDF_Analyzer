"""
Complete Webshop Feed Builder - Merges raw extraction data with linked images
Creates beautiful product data with proper names, descriptions, attributes, and images
"""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"
WEBSHOP_ROOT = Path(r"C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop")

# Input files
RAW_EXTRACTION_JSON = OUTPUT_DIR / "input_pdfs_analysis_v5.json"  # Complete extraction with attributes
LINKED_IMAGES_JSON = OUTPUT_DIR / "products_for_shop.json"  # Has images linked

# Output
WEBSHOP_OUTPUT = WEBSHOP_ROOT / "public" / "data" / "products_for_shop.json"

# Catalog to proper category mapping
CATALOG_CATEGORIES = {
    "abs-persluchtbuizen": "Persluchtbuizen",
    "airpress-catalogus-eng": "Compressoren & Accessoires",
    "airpress-catalogus-nl-fr": "Compressoren & Accessoires",
    "bronpompen": "Bronpompen",
    "catalogus-aandrijftechniek": "Aandrijftechniek",
    "centrifugaalpompen": "Centrifugaalpompen",
    "dompelpompen": "Dompelpompen",
    "drukbuizen": "Drukbuizen",
    "gardena-assortiment": "Tuinartikelen",
    "hogedrukreiniger": "Hogedrukreinigers",
    "industrile-slangen": "Industriële Slangen",
    "kranzle-catalogus": "Hogedrukreinigers Kränzle",
    "kunststof-afvoerleidingen": "Kunststof Afvoerleidingen",
    "makita-catalogus-2022-nl": "Elektrisch Gereedschap Makita",
    "makita-tuinfolder-2022-nl": "Tuingereedschap Makita",
    "messing-draadfittingen": "Messing Fittingen",
    "pe-buizen": "PE Buizen & Hulpstukken",
    "plat-oprolbare-slangen": "Plat Oprolbare Slangen",
    "pomp-specials": "Pomp Specials",
    "pu-afzuigslangen": "PU Afzuigslangen",
    "rvs-draadfittingen": "RVS Fittingen",
    "slangklemmen": "Slangklemmen",
    "slangkoppelingen": "Slangkoppelingen",
    "verzinkte-buizen": "Verzinkte Buizen",
    "zwarte-draad-en-lasfittingen": "Zwarte Draad- & Lasfittingen",
}

# Catalog to brand mapping
CATALOG_BRANDS = {
    "airpress-catalogus-eng": "Airpress",
    "airpress-catalogus-nl-fr": "Airpress",
    "kranzle-catalogus": "Kränzle",
    "makita-catalogus-2022-nl": "Makita",
    "makita-tuinfolder-2022-nl": "Makita",
    "gardena-assortiment": "Gardena",
}


def safe_float(val: Any) -> Optional[float]:
    """Safely convert to float"""
    if val is None or val == "":
        return None
    if isinstance(val, (int, float)):
        return float(val)
    if isinstance(val, str):
        try:
            # Handle formats like "1,5 kW", "230V", "10 bar"
            cleaned = val.replace(",", ".").split()[0]
            return float(cleaned)
        except (ValueError, IndexError):
            return None
    return None


def safe_list(val: Any) -> Optional[List]:
    """Ensure value is a list"""
    if val is None:
        return None
    if isinstance(val, list):
        return val if val else None
    return [val]


def fix_image_url(url: str) -> str:
    """Convert image URL to relative path"""
    if not url:
        return url
    # If already starts with /, it's correct
    if url.startswith("/product-images/"):
        return url
    # Handle ../product-images/ format
    if url.startswith("../product-images/"):
        return url.replace("../product-images/", "/product-images/")
    # Handle example.com format (legacy)
    if "example.com/media/" in url:
        filename = url.split("example.com/media/")[-1]
        # This is a fallback, but likely won't match actual files
        return f"/product-images/{filename}"
    return url


def clean_description(desc: Any) -> Optional[str]:
    """Clean and format description"""
    if not desc or desc == "null":
        return None
    text = str(desc).strip()
    if len(text) < 5:  # Too short
        return None
    # Remove excessive whitespace
    text = " ".join(text.split())
    return text


def derive_product_name(raw_data: Dict, catalog: str, sku: str) -> str:
    """Derive descriptive product name from raw data"""
    
    # Try various name fields
    name_candidates = [
        raw_data.get("product_name"),
        raw_data.get("name"),
        raw_data.get("type"),
        raw_data.get("product_type"),
    ]
    
    for candidate in name_candidates:
        if candidate and isinstance(candidate, str) and len(candidate) > 3:
            # If it's not just the SKU
            if candidate.upper() != sku.upper():
                return candidate.strip()
    
    # Build from attributes
    category = CATALOG_CATEGORIES.get(catalog, catalog.replace("-", " ").title())
    
    # Check product type/specs
    power_kw = safe_float(raw_data.get("power_kw") or raw_data.get("power_kw_derived"))
    voltage_v = safe_float(raw_data.get("voltage_v") or raw_data.get("voltage_derived"))
    flow = safe_float(raw_data.get("flow_m3_hour") or raw_data.get("flow_l_min"))
    
    parts = []
    
    # For compressors
    if "compressor" in category.lower() or "airpress" in catalog.lower():
        parts.append("Compressor")
        parts.append(sku)
        if power_kw:
            parts.append(f"{power_kw}kW")
        return " ".join(parts)
    
    # For pumps
    if "pomp" in category.lower() or "pump" in category.lower():
        parts.append("Pomp")
        parts.append(sku)
        if power_kw:
            parts.append(f"{power_kw}kW")
        return " ".join(parts)
    
    # For Makita tools
    if "makita" in catalog.lower():
        parts.append("Makita")
        parts.append(sku)
        if voltage_v:
            parts.append(f"{int(voltage_v)}V")
        return " ".join(parts)
    
    # Default: Category + SKU
    return f"{category} {sku}"


def build_description_from_data(raw_data: Dict, category: str) -> Optional[str]:
    """Build description from available data"""
    
    # Check if there's already a good description
    existing_desc = clean_description(raw_data.get("description"))
    if existing_desc and len(existing_desc) > 50:
        return existing_desc
    
    # Build from scratch
    parts = []
    
    # Add category context
    parts.append(f"Professioneel product uit de categorie {category}.")
    
    # Add key specifications
    specs = []
    
    # Power
    power_kw = safe_float(raw_data.get("power_kw") or raw_data.get("power_kw_derived"))
    power_hp = safe_float(raw_data.get("power_hp"))
    if power_kw:
        specs.append(f"{power_kw} kW vermogen")
    elif power_hp:
        specs.append(f"{power_hp} HP vermogen")
    
    # Voltage
    voltage = safe_float(raw_data.get("voltage_v") or raw_data.get("voltage_derived"))
    if voltage:
        specs.append(f"{int(voltage)}V spanning")
    
    # Pressure
    pressure = safe_float(raw_data.get("pressure_max_bar"))
    if pressure:
        specs.append(f"max. {pressure} bar druk")
    
    # Flow
    flow_m3 = safe_float(raw_data.get("flow_m3_hour") or raw_data.get("flow_m3_hour_derived"))
    flow_lmin = safe_float(raw_data.get("flow_l_min"))
    if flow_m3:
        specs.append(f"{flow_m3} m³/h debiet")
    elif flow_lmin:
        specs.append(f"{flow_lmin} L/min debiet")
    
    # Tank/Volume
    tank = safe_float(raw_data.get("tank_volume_l") or raw_data.get("volume_l"))
    if tank:
        specs.append(f"{int(tank)}L tank")
    
    # Weight
    weight = safe_float(raw_data.get("weight_kg"))
    if weight:
        specs.append(f"{weight}kg gewicht")
    
    if specs:
        parts.append("Specificaties: " + ", ".join(specs) + ".")
    
    # Materials
    materials = raw_data.get("materials")
    if materials:
        mat_list = materials if isinstance(materials, list) else [materials]
        parts.append(f"Materiaal: {', '.join(str(m) for m in mat_list)}.")
    
    return " ".join(parts) if len(parts) > 1 else None


def extract_attributes(raw_data: Dict) -> Dict[str, Any]:
    """Extract all relevant attributes from raw data"""
    attrs = {}
    
    # Power attributes
    for key in ["power_kw", "power_kw_derived", "power_hp"]:
        val = safe_float(raw_data.get(key))
        if val is not None:
            attr_key = key.replace("_derived", "")
            if attr_key not in attrs:
                attrs[attr_key] = val
    
    # Voltage
    for key in ["voltage_v", "voltage_derived"]:
        val = safe_float(raw_data.get(key))
        if val is not None and "voltage_v" not in attrs:
            attrs["voltage_v"] = val
    
    # Pressure
    for key in ["pressure_max_bar", "pressure_min_bar", "pressure_bar"]:
        val = safe_float(raw_data.get(key))
        if val is not None:
            attrs[key] = val
    
    # Flow
    for key in ["flow_m3_hour", "flow_m3_hour_derived", "flow_l_min", "debiet_m3_h"]:
        val = safe_float(raw_data.get(key))
        if val is not None:
            attr_key = key.replace("_derived", "")
            if attr_key not in attrs:
                attrs[attr_key] = val
    
    # Dimensions
    for key in ["diameter_mm", "length_mm", "width_mm", "height_mm", "dimensions_mm"]:
        val = safe_float(raw_data.get(key))
        if val is not None:
            attrs[key] = val
    
    # Other numeric attributes
    for key in ["weight_kg", "tank_volume_l", "volume_l", "noise_db_a", "rpm", 
                "cable_length_m", "head_m", "particle_size_mm", "wall_thickness_mm"]:
        val = safe_float(raw_data.get(key))
        if val is not None:
            attrs[key] = val
    
    # String/list attributes
    for key in ["materials", "connection_types", "series", "product_type"]:
        val = raw_data.get(key)
        if val:
            attrs[key] = val
    
    # Size inch (can be string or number)
    size_inch = raw_data.get("size_inch") or raw_data.get("connection_inch")
    if size_inch:
        attrs["size_inch"] = size_inch
    
    # Dimensions list (for variants)
    dims_list = raw_data.get("dimensions_mm_list")
    if dims_list and isinstance(dims_list, list) and dims_list:
        attrs["dimensions_mm_list"] = sorted(set(safe_float(d) for d in dims_list if safe_float(d) is not None))
    
    return attrs


def merge_product_data(raw_data: Dict, linked_data: Dict) -> Dict[str, Any]:
    """Merge raw extraction data with linked image data"""
    
    sku = raw_data.get("sku")
    catalog = raw_data.get("catalog_name", "").replace(".pdf", "")
    
    # Get proper category and brand
    category = CATALOG_CATEGORIES.get(catalog, catalog.replace("-", " ").title())
    brand = CATALOG_BRANDS.get(catalog)
    
    # Derive name and description
    name = derive_product_name(raw_data, catalog, sku)
    description = build_description_from_data(raw_data, category)
    
    # Extract attributes
    attributes = extract_attributes(raw_data)
    
    # Get images from linked data - prefer image_paths array (has correct filenames)
    media = []
    image_paths = []
    
    if linked_data:
        # Use image_paths array if available (has actual extracted filenames)
        if linked_data.get("image_paths"):
            for idx, path in enumerate(linked_data["image_paths"]):
                url = fix_image_url(path)
                media.append({
                    "url": url,
                    "role": "main" if idx == 0 else "gallery",
                    "type": "image",
                    "format": "webp"
                })
                image_paths.append(url)
        # Fallback to media array
        elif linked_data.get("media"):
            for img in linked_data["media"]:
                url = fix_image_url(img.get("url", ""))
                media.append({
                    "url": url,
                    "role": img.get("role", "gallery"),
                    "type": "image",
                    "format": "webp"
                })
                image_paths.append(url)
    
    # Get PDF info - try multiple sources
    pdf_source = raw_data.get("pdf_source") or (raw_data.get("source", {}).get("pdf_sources", [None])[0] if raw_data.get("source") else None)
    if not pdf_source and linked_data:
        pdf_sources_list = linked_data.get("source", {}).get("pdf_sources", [])
        pdf_source = pdf_sources_list[0] if pdf_sources_list else None
    
    pages = raw_data.get("merged_pdf_page", [])
    if not pages and raw_data.get("source"):
        pages = raw_data.get("source", {}).get("pages", [])
    if not pages and linked_data:
        pages = linked_data.get("source", {}).get("pages", [])
    if isinstance(pages, (int, float)):
        pages = [int(pages)]
    
    # Handle price
    price = safe_float(raw_data.get("price") or raw_data.get("price_eur"))
    
    # Build product
    product = {
        "id": f"{catalog}:{sku}",
        "sku": sku,
        "name": name,
        "brand": brand,
        "catalog": catalog,
        "product_category": category,
        "category": category,
        "description": description,
        "pdf_source": pdf_source,
        "source_pages": pages,
        "imageUrl": media[0]["url"] if media else None,
        "media": media,
        "image_paths": image_paths,
        "price": price,
        "inStock": True if price else None,
        "priceMode": "fixed" if price else "request_quote",
    }
    
    # Add all attributes as flat fields
    product.update(attributes)
    
    # Build specs array for display
    specs = []
    for key, value in attributes.items():
        if value is not None and key not in ["materials", "connection_types", "dimensions_mm_list"]:
            label = key.replace("_", " ").replace("m3", "m³").title()
            if isinstance(value, float):
                specs.append({"label": label, "value": f"{value:.1f}".rstrip('0').rstrip('.')})
            else:
                specs.append({"label": label, "value": str(value)})
    
    product["specs"] = specs
    
    return product


def main():
    print("🔧 Building Complete Webshop Feed...")
    print(f"📂 Reading raw extraction: {RAW_EXTRACTION_JSON.name}")
    print(f"📂 Reading linked images: {LINKED_IMAGES_JSON.name}")
    
    # Load raw extraction data
    if not RAW_EXTRACTION_JSON.exists():
        print(f"❌ Error: {RAW_EXTRACTION_JSON} not found!")
        return
    
    with RAW_EXTRACTION_JSON.open("r", encoding="utf-8") as f:
        raw_products = json.load(f)
    print(f"📊 Loaded {len(raw_products)} raw products")
    
    # Load linked images
    linked_by_sku = {}
    if LINKED_IMAGES_JSON.exists():
        with LINKED_IMAGES_JSON.open("r", encoding="utf-8") as f:
            linked_products = json.load(f)
        linked_by_sku = {p["sku"]: p for p in linked_products}
        print(f"🖼️  Loaded {len(linked_by_sku)} products with linked images")
    
    # Merge data
    final_products = []
    products_with_images = 0
    products_with_descriptions = 0
    products_with_attributes = 0
    
    for raw in raw_products:
        sku = raw.get("sku")
        if not sku:
            continue
        
        linked = linked_by_sku.get(sku)
        product = merge_product_data(raw, linked)
        final_products.append(product)
        
        if product.get("media"):
            products_with_images += 1
        if product.get("description"):
            products_with_descriptions += 1
        if product.get("specs"):
            products_with_attributes += 1
    
    # Sort by catalog then SKU
    final_products.sort(key=lambda x: (x.get("catalog", ""), x.get("sku", "")))
    
    # Write to webshop
    WEBSHOP_OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with WEBSHOP_OUTPUT.open("w", encoding="utf-8") as f:
        json.dump(final_products, f, ensure_ascii=False, indent=2)
    
    print(f"\n✅ Success!")
    print(f"📝 Wrote {len(final_products)} products to:")
    print(f"   {WEBSHOP_OUTPUT}")
    print(f"\n📊 Statistics:")
    print(f"   🖼️  With images: {products_with_images} ({products_with_images/len(final_products)*100:.1f}%)")
    print(f"   📝 With descriptions: {products_with_descriptions} ({products_with_descriptions/len(final_products)*100:.1f}%)")
    print(f"   📊 With attributes: {products_with_attributes} ({products_with_attributes/len(final_products)*100:.1f}%)")
    print(f"   📦 Categories: {len(set(p['product_category'] for p in final_products))}")
    print(f"   🏷️  Brands: {len(set(p['brand'] for p in final_products if p['brand']))}")
    
    # Show sample with good data
    print(f"\n📋 Sample product:")
    sample = next((p for p in final_products if p.get("media") and p.get("specs")), final_products[0])
    print(f"   SKU: {sample['sku']}")
    print(f"   Name: {sample['name']}")
    print(f"   Category: {sample['product_category']}")
    print(f"   Brand: {sample.get('brand', 'N/A')}")
    print(f"   Images: {len(sample.get('media', []))}")
    print(f"   Specs: {len(sample.get('specs', []))}")
    print(f"   Price: {sample.get('price') or 'Request Quote'}")
    if sample.get("specs")[:3]:
        print(f"   Top specs: {', '.join(s['label'] + ': ' + str(s['value']) for s in sample['specs'][:3])}")


if __name__ == "__main__":
    main()
