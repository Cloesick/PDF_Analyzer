"""
Extract Makita Product Properties from Tables
==============================================
Parse tables in the Makita catalog to extract product specifications

Strategy:
1. Find tables on each page
2. Identify property names (first column)
3. Map columns to SKUs (from headers/nearby text)
4. Extract all specifications
5. Map to standard fields (voltage, power, weight, etc.)
"""

import pdfplumber
import re
import json
from pathlib import Path
from collections import defaultdict

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "makita-catalogus-2022-nl.pdf"
OUTPUT_JSON = PROJECT_ROOT / "output" / "makita_properties_extracted.json"

# Property name mappings (Dutch → English)
PROPERTY_MAP = {
    # Voltage / Power
    'spanning': 'voltage',
    'vermogen': 'power',
    'opgenomen vermogen': 'power_input',
    'afgegeven vermogen': 'power_output',
    
    # Physical
    'gewicht': 'weight',
    'afmetingen': 'dimensions',
    'diameter': 'diameter',
    'lengte': 'length',
    'breedte': 'width',
    'hoogte': 'height',
    
    # Performance
    'toerental': 'rpm',
    'slagenergie': 'impact_energy',
    'slagfrequentie': 'impact_frequency',
    'koppel': 'torque',
    'max. koppel': 'max_torque',
    'capaciteit': 'capacity',
    'debiet': 'flow_rate',
    'druk': 'pressure',
    'max. druk': 'max_pressure',
    
    # Noise / Vibration
    'geluidsniveau': 'noise_level',
    'geluidsvermogen': 'sound_power',
    'triax. vibratie': 'vibration',
    'triaxiale vibratiewaarde': 'vibration',
    'vibratie': 'vibration',
    
    # Battery
    'bijgeleverde accu\'s': 'included_batteries',
    'bijgeleverde accus': 'included_batteries',
    'accu': 'battery',
    
    # Dimensions / Capacity
    'max. ø': 'max_diameter',
    'max. ø beton': 'max_concrete_diameter',
    'max. ø hout': 'max_wood_diameter',
    'max. ø staal': 'max_steel_diameter',
    'zaagcapaciteit': 'cutting_capacity',
    'zaagblad': 'saw_blade',
    'schijfdiameter': 'disc_diameter',
    'diameter mengblad': 'mixing_blade_diameter',
    'aansluiting': 'connection',
    'slaglengte': 'stroke_length',
    
    # Misc
    'prijs excl. btw': 'price_excl_vat',
    'prijs incl. btw': 'price_incl_vat',
    'prijs excl. btw in €': 'price_excl_vat',
    'prijs incl. btw in €': 'price_incl_vat',
}

# Makita SKU patterns (from earlier)
SKU_PATTERNS = [
    r'\b[A-Z]{2,4}\d{3,4}[A-Z]*\b',
    r'\b\d{5,6}\b',
    r'\b\d{6}-\d\b',
    r'\b[A-Z]{2}\d{3}[A-Z]{2}\d{3}\b',
    r'\b[A-Z]{3}\d{3}[A-Z]{2,3}\b',
]

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def extract_skus_from_text(text):
    """Extract potential SKUs from text"""
    skus = set()
    for pattern in SKU_PATTERNS:
        matches = re.findall(pattern, text)
        skus.update(matches)
    return skus

def normalize_property_name(name):
    """Convert property name to standard English key"""
    if not name:
        return None
    
    name_lower = str(name).lower().strip()
    
    # Direct mapping
    if name_lower in PROPERTY_MAP:
        return PROPERTY_MAP[name_lower]
    
    # Partial matching
    for dutch, english in PROPERTY_MAP.items():
        if dutch in name_lower:
            return english
    
    # Fallback: keep original but clean it
    return name_lower.replace(' ', '_').replace('.', '').replace('(', '').replace(')', '')

def clean_value(value):
    """Clean extracted value"""
    if value is None or value == '':
        return None
    
    value = str(value).strip()
    
    # Remove None strings
    if value.lower() == 'none' or value == '':
        return None
    
    return value

def parse_table(table, page_text=''):
    """
    Parse a table and extract products with their properties
    
    Returns: list of {sku, properties_dict}
    """
    if not table or len(table) < 2:
        return []
    
    products = []
    
    # First column usually has property names
    # Other columns have values for different products
    
    # Try to find SKUs in table headers (first few rows)
    header_skus = []
    for row in table[:3]:  # Check first 3 rows for SKUs
        for cell in row[1:]:  # Skip first column (property names)
            if cell:
                skus_found = extract_skus_from_text(str(cell))
                header_skus.extend(skus_found)
    
    # If no SKUs in table, try nearby page text
    if not header_skus:
        header_skus = list(extract_skus_from_text(page_text))[:10]  # Limit to 10
    
    num_product_cols = len(table[0]) - 1 if table[0] else 0
    
    # Initialize products
    for i in range(num_product_cols):
        sku = header_skus[i] if i < len(header_skus) else f"unknown_col_{i}"
        products.append({
            'sku': sku,
            'properties': {},
            'raw_specs': []
        })
    
    # Extract properties from each row
    for row in table:
        if not row or len(row) < 2:
            continue
        
        # First cell is property name
        prop_name_raw = clean_value(row[0])
        if not prop_name_raw:
            continue
        
        prop_name = normalize_property_name(prop_name_raw)
        if not prop_name:
            continue
        
        # Other cells are values for each product
        for i, cell in enumerate(row[1:]):
            if i >= len(products):
                break
            
            value = clean_value(cell)
            if value:
                products[i]['properties'][prop_name] = value
                products[i]['raw_specs'].append(f"{prop_name_raw}: {value}")
    
    # Filter out products with no properties
    products = [p for p in products if p['properties'] and p['sku'] != 'unknown']
    
    return products

# ============================================================================
# MAIN EXTRACTION
# ============================================================================

def extract_properties():
    """Extract all properties from Makita catalog"""
    
    print("=" * 80)
    print("MAKITA PROPERTY EXTRACTION")
    print("=" * 80)
    
    pdf = pdfplumber.open(PDF_PATH)
    print(f"\n📄 Processing: {PDF_PATH.name}")
    print(f"   Total pages: {len(pdf.pages)}")
    
    all_products = defaultdict(lambda: {'properties': {}, 'raw_specs': [], 'pages': []})
    stats = {
        'pages_processed': 0,
        'tables_found': 0,
        'tables_parsed': 0,
        'products_found': set(),
        'properties_extracted': 0
    }
    
    # Process each page
    for page_num in range(1, len(pdf.pages) + 1):
        page = pdf.pages[page_num - 1]
        
        # Get page text for SKU extraction
        page_text = page.extract_text() or ''
        
        # Extract tables
        tables = page.extract_tables()
        
        if not tables:
            stats['pages_processed'] += 1
            continue
        
        stats['tables_found'] += len(tables)
        
        # Parse each table
        for table_idx, table in enumerate(tables):
            products_in_table = parse_table(table, page_text)
            
            if not products_in_table:
                continue
            
            stats['tables_parsed'] += 1
            
            # Merge properties for each product
            for product in products_in_table:
                sku = product['sku']
                stats['products_found'].add(sku)
                
                # Merge properties (later values override earlier ones)
                all_products[sku]['properties'].update(product['properties'])
                all_products[sku]['raw_specs'].extend(product['raw_specs'])
                all_products[sku]['pages'].append(page_num)
                
                stats['properties_extracted'] += len(product['properties'])
        
        stats['pages_processed'] += 1
        
        # Progress update
        if page_num % 20 == 0:
            print(f"   Processed {page_num}/{len(pdf.pages)} pages | {len(stats['products_found'])} products | {stats['tables_parsed']} tables")
    
    pdf.close()
    
    # Convert to list format
    products_list = []
    for sku, data in all_products.items():
        products_list.append({
            'sku': sku,
            'properties': data['properties'],
            'raw_specifications': list(set(data['raw_specs'])),  # Remove duplicates
            'found_on_pages': sorted(set(data['pages']))
        })
    
    # Save results
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(products_list, f, indent=2, ensure_ascii=False)
    
    # Print summary
    print("\n" + "=" * 80)
    print("EXTRACTION COMPLETE")
    print("=" * 80)
    
    print(f"\n📊 Statistics:")
    print(f"   Pages processed:      {stats['pages_processed']}")
    print(f"   Tables found:         {stats['tables_found']}")
    print(f"   Tables parsed:        {stats['tables_parsed']}")
    print(f"   Products with props:  {len(stats['products_found'])}")
    print(f"   Total properties:     {stats['properties_extracted']}")
    
    # Show sample
    print(f"\n🔍 Sample Products:")
    for product in products_list[:5]:
        print(f"\n   SKU: {product['sku']}")
        print(f"   Properties: {len(product['properties'])}")
        print(f"   Sample props: {list(product['properties'].keys())[:5]}")
    
    print(f"\n💾 Saved to: {OUTPUT_JSON}")
    
    return products_list

if __name__ == '__main__':
    extract_properties()
