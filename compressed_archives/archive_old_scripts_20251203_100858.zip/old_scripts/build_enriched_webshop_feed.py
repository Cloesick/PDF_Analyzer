"""
Enhanced Webshop Feed Builder
Enriches products_for_shop.json with proper names, descriptions, and attributes
Creates beautiful product data with size variants, proper categorization, and UX-friendly formatting
"""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"
WEBSHOP_ROOT = Path(r"C:\Users\prova\Documents\Projects\DemaWebshop\dema-webshop")

# Input: Current products with images linked
LINKED_PRODUCTS_JSON = OUTPUT_DIR / "products_for_shop.json"

# Output: Enriched products for webshop
WEBSHOP_OUTPUT = WEBSHOP_ROOT / "public" / "data" / "products_for_shop.json"

# Catalog to proper category mapping
CATALOG_CATEGORIES = {
    "abs-persluchtbuizen": "Persluchtbuizen",
    "airpress-catalogus-eng": "Compressoren & Accessoires",
    "airpress-catalogus-nl-fr": "Compressoren & Accessoires",
    "bronpompen": "Bronpompen",
    "catalogus-aandrijftechniek": "Aandrijftechniek",
    "centrifugaalpompen": "Centrifugaalpompen",
    "dompelpompen": "Dompelpompen",
    "drukbuizen": "Drukbuizen",
    "gardena-assortiment": "Tuinartikelen",
    "hogedrukreiniger": "Hogedrukreinigers",
    "industrile-slangen": "Industriële Slangen",
    "kranzle-catalogus": "Hogedrukreinigers Kränzle",
    "kunststof-afvoerleidingen": "Kunststof Afvoerleidingen",
    "makita-catalogus-2022-nl": "Elektrisch Gereedschap Makita",
    "makita-tuinfolder-2022-nl": "Tuingereedschap Makita",
    "messing-draadfittingen": "Messing Fittingen",
    "pe-buizen": "PE Buizen & Hulpstukken",
    "plat-oprolbare-slangen": "Plat Oprolbare Slangen",
    "pomp-specials": "Pomp Specials",
    "pu-afzuigslangen": "PU Afzuigslangen",
    "rvs-draadfittingen": "RVS Fittingen",
    "slangklemmen": "Slangklemmen",
    "slangkoppelingen": "Slangkoppelingen",
    "verzinkte-buizen": "Verzinkte Buizen",
    "zwarte-draad-en-lasfittingen": "Zwarte Draad- & Lasfittingen",
}

# Catalog to brand mapping
CATALOG_BRANDS = {
    "airpress-catalogus-eng": "Airpress",
    "airpress-catalogus-nl-fr": "Airpress",
    "kranzle-catalogus": "Kränzle",
    "makita-catalogus-2022-nl": "Makita",
    "makita-tuinfolder-2022-nl": "Makita",
    "gardena-assortiment": "Gardena",
}


def normalize_float(val: Any) -> Optional[float]:
    """Safely convert to float"""
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return float(val)
    if isinstance(val, str):
        try:
            return float(val.replace(",", ".").split()[0])
        except (ValueError, IndexError):
            return None
    return None


def fix_image_url(url: str, catalog: str, sku: str) -> str:
    """Convert image URL from example.com to relative path"""
    if not url or url.startswith("/") or url.startswith("http://localhost"):
        return url
    
    # Extract filename from URL
    if "example.com/media/" in url:
        filename = url.split("example.com/media/")[-1]
        # Reconstruct proper path
        return f"/product-images/{catalog}.pdf/{filename}"
    
    return url


def derive_product_name(item: Dict[str, Any]) -> str:
    """Derive a descriptive product name from available data"""
    sku = item.get("sku", "")
    catalog = item.get("catalog", "")
    category = item.get("category", "")
    
    # Try to create a meaningful name
    # If we have attributes that suggest what it is
    attrs = item.get("attributes", {})
    
    # For pumps
    if any(x in category.lower() for x in ["pomp", "pump"]):
        power = attrs.get("power_kw")
        if power:
            return f"Pomp {sku} - {power}kW"
        return f"Pomp {sku}"
    
    # For compressors
    if "compressor" in category.lower():
        power = attrs.get("power_kw")
        tank = attrs.get("tank_volume_l")
        if power and tank:
            return f"Compressor {sku} - {power}kW {tank}L"
        elif power:
            return f"Compressor {sku} - {power}kW"
        return f"Compressor {sku}"
    
    # For pipes/hoses
    if any(x in category.lower() for x in ["buis", "slang", "pipe", "hose"]):
        size = attrs.get("diameter_mm") or attrs.get("size_inch")
        if size:
            return f"{category} {sku} - {size}mm"
        return f"{category} {sku}"
    
    # For fittings
    if any(x in category.lower() for x in ["fitting", "koppeling"]):
        return f"Koppeling {sku}"
    
    # For Makita tools
    if "makita" in catalog.lower():
        voltage = attrs.get("voltage_v")
        if voltage:
            return f"Makita {sku} - {voltage}V"
        return f"Makita {sku}"
    
    # Default: Category + SKU
    if category and category != catalog:
        return f"{category} {sku}"
    
    return sku


def generate_description(item: Dict[str, Any]) -> Optional[str]:
    """Generate a basic description from attributes"""
    desc_parts = []
    attrs = item.get("attributes", {})
    category = item.get("category", "")
    
    # Add category context
    if category:
        desc_parts.append(f"Professioneel product uit de categorie {category}.")
    
    # Add key specs
    specs = []
    if attrs.get("power_kw"):
        specs.append(f"{attrs['power_kw']}kW vermogen")
    if attrs.get("voltage_v"):
        specs.append(f"{attrs['voltage_v']}V spanning")
    if attrs.get("pressure_max_bar"):
        specs.append(f"{attrs['pressure_max_bar']} bar druk")
    if attrs.get("flow_m3_hour"):
        specs.append(f"{attrs['flow_m3_hour']} m³/h debiet")
    if attrs.get("tank_volume_l"):
        specs.append(f"{attrs['tank_volume_l']}L tank")
    
    if specs:
        desc_parts.append("Kenmerken: " + ", ".join(specs) + ".")
    
    # Add material info
    materials = attrs.get("materials")
    if materials:
        mat_str = ", ".join(materials) if isinstance(materials, list) else str(materials)
        desc_parts.append(f"Materiaal: {mat_str}.")
    
    return " ".join(desc_parts) if desc_parts else None


def extract_dimensions_variants(items: List[Dict[str, Any]]) -> List[float]:
    """Extract list of dimension variants from items sharing same base SKU"""
    dimensions = []
    for item in items:
        attrs = item.get("attributes", {})
        # Check various dimension fields
        for key in ["diameter_mm", "size_mm", "dimension_mm", "length_mm"]:
            val = attrs.get(key)
            if val and isinstance(val, (int, float)):
                dimensions.append(float(val))
    
    return sorted(set(dimensions)) if dimensions else []


def enrich_product(item: Dict[str, Any]) -> Dict[str, Any]:
    """Enrich a single product with better data"""
    catalog = item.get("catalog", "")
    sku = item.get("sku", "")
    
    # Fix category
    proper_category = CATALOG_CATEGORIES.get(catalog, item.get("category", ""))
    
    # Fix brand
    brand = CATALOG_BRANDS.get(catalog, item.get("brand"))
    
    # Fix image URLs
    media = []
    for img in item.get("media", []):
        fixed_url = fix_image_url(img.get("url", ""), catalog, sku)
        media.append({
            "url": fixed_url,
            "role": img.get("role", "gallery"),
            "type": "image",
            "format": "webp"
        })
    
    # Create image_paths array for compatibility
    image_paths = [img["url"] for img in media]
    
    # Derive better name
    name = derive_product_name(item)
    
    # Generate description if missing
    description = item.get("description") or generate_description(item)
    
    # Build enriched product
    enriched = {
        "id": item.get("id", f"{catalog}:{sku}"),
        "sku": sku,
        "name": name,
        "brand": brand,
        "catalog": catalog,
        "product_category": proper_category,
        "category": proper_category,  # Alias for compatibility
        "description": description,
        "pdf_source": item.get("source", {}).get("pdf_sources", [None])[0],
        "source_pages": item.get("source", {}).get("pages", []),
        "imageUrl": media[0]["url"] if media else None,
        "media": media,
        "image_paths": image_paths,
        "price": item.get("price", {}).get("amount"),
        "inStock": True if item.get("price", {}).get("amount") else None,
    }
    
    # Add all attributes as flat fields for filtering
    attrs = item.get("attributes", {})
    for key, value in attrs.items():
        enriched[key] = value
    
    # Add price block
    price_data = item.get("price", {})
    if price_data.get("mode") == "request_quote" or not price_data.get("amount"):
        enriched["priceMode"] = "request_quote"
    else:
        enriched["priceMode"] = "fixed"
    
    # Add dimensions list if multiple sizes
    # (This would come from grouping logic, but we'll add it if present)
    if "dimensions_mm_list" in item:
        enriched["dimensions_mm_list"] = item["dimensions_mm_list"]
    
    # Add specs array
    specs = []
    for key, value in attrs.items():
        if value is not None:
            label = key.replace("_", " ").title()
            specs.append({
                "label": label,
                "value": str(value)
            })
    enriched["specs"] = specs
    
    return enriched


def group_by_base_sku(products: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    """Group products that might be variants (same base SKU, different sizes)"""
    groups = defaultdict(list)
    
    for product in products:
        sku = product.get("sku", "")
        # Simple grouping: products with similar SKUs (base letters)
        # For now, just use full SKU as key
        # Advanced: could parse out size suffixes
        groups[sku].append(product)
    
    return groups


def main():
    print("🔧 Building Enriched Webshop Feed...")
    print(f"📂 Reading from: {LINKED_PRODUCTS_JSON}")
    
    if not LINKED_PRODUCTS_JSON.exists():
        print(f"❌ Error: {LINKED_PRODUCTS_JSON} not found!")
        return
    
    # Load linked products (with images)
    with LINKED_PRODUCTS_JSON.open("r", encoding="utf-8") as f:
        raw_products = json.load(f)
    
    print(f"📊 Loaded {len(raw_products)} products")
    
    # Enrich each product
    enriched_products = []
    products_with_images = 0
    
    for item in raw_products:
        enriched = enrich_product(item)
        enriched_products.append(enriched)
        
        if enriched.get("media") and len(enriched["media"]) > 0:
            products_with_images += 1
    
    # Sort by catalog then SKU
    enriched_products.sort(key=lambda x: (x.get("catalog", ""), x.get("sku", "")))
    
    # Write to webshop
    WEBSHOP_OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with WEBSHOP_OUTPUT.open("w", encoding="utf-8") as f:
        json.dump(enriched_products, f, ensure_ascii=False, indent=2)
    
    print(f"\n✅ Success!")
    print(f"📝 Wrote {len(enriched_products)} products to:")
    print(f"   {WEBSHOP_OUTPUT}")
    print(f"🖼️  Products with images: {products_with_images} ({products_with_images/len(enriched_products)*100:.1f}%)")
    print(f"📦 Categories: {len(set(p['product_category'] for p in enriched_products))}")
    print(f"🏷️  Brands: {len(set(p['brand'] for p in enriched_products if p['brand']))}")
    
    # Show sample
    print(f"\n📋 Sample enriched product:")
    sample = next((p for p in enriched_products if p.get("media")), enriched_products[0])
    print(f"   SKU: {sample['sku']}")
    print(f"   Name: {sample['name']}")
    print(f"   Category: {sample['product_category']}")
    print(f"   Images: {len(sample.get('media', []))}")
    print(f"   Price: {sample.get('price') or 'Request Quote'}")


if __name__ == "__main__":
    main()
