"""
Smart Makita Table Extraction with Property Translation and Icons
Extracts tables, translates Dutch properties to English, and adds icons
"""
import pdfplumber
import json
import re
from pathlib import Path
from property_translation_config import (
    translate_property_name, 
    get_property_icon, 
    get_value_icon
)

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "output"

def extract_price(text):
    """Extract price from European format"""
    if not text:
        return None
    text = str(text).replace('€', '').replace('.', '').replace(',', '.').strip()
    match = re.search(r'(\d+\.?\d*)', text)
    if match:
        try:
            return float(match.group(1))
        except:
            return None
    return None

def find_product_skus_on_page(page_text):
    """Find product SKUs from page text"""
    sku_patterns = [
        r'\b[A-Z]{2,4}\d{3,4}[A-Z]{1,4}\d{0,3}\b',
        r'\b[A-Z]{2}\d{3}[A-Z]{2}\d{3}\b',
        r'\b\d{6}-\d\b',
    ]
    
    found_skus = []
    for pattern in sku_patterns:
        matches = re.findall(pattern, page_text)
        found_skus.extend(matches)
    
    # Remove duplicates while preserving order
    seen = set()
    unique_skus = []
    for sku in found_skus:
        if sku not in seen:
            seen.add(sku)
            unique_skus.append(sku)
    
    return unique_skus

def clean_property_value(value):
    """Clean property value"""
    if not value:
        return None
    
    value_str = str(value).strip()
    
    # Remove empty values
    if value_str in ['', '-', 'None', 'N/A', 'n.v.t.']:
        return None
    
    return value_str

def extract_products_from_table(table, page_num, page_skus):
    """Extract products from a vertical header table"""
    if not table or len(table) < 2:
        return []
    
    products = []
    
    # Detect table structure
    first_row = table[0]
    if not first_row or len(first_row) < 3:
        return []
    
    # Count product columns (start from column 2, column 0 is property name, column 1 is sub-label)
    num_products = sum(1 for cell in first_row[2:] if cell and str(cell).strip())
    
    if num_products == 0:
        return []
    
    # Extract products column by column
    for col_idx in range(2, 2 + num_products):
        # Get SKU
        if (col_idx - 2) < len(page_skus):
            sku = page_skus[col_idx - 2]
        else:
            sku = f"UNKNOWN_{page_num}_COL{col_idx}"
        
        product = {
            'sku': sku,
            'page': page_num,
            'column_index': col_idx,
            'properties': {},
            'properties_translated': {},  # English translations
            'properties_with_icons': {},  # Properties with icons
            'price_excl_btw_eur': None,
            'price_incl_btw_eur': None
        }
        
        # Extract properties row by row
        for row in table[1:]:
            if not row or len(row) < 2:
                continue
            
            # Property name is in column 0
            prop_name_dutch = str(row[0]).strip() if row[0] else ""
            
            # Sub-label is in column 1 (optional)
            sub_label = str(row[1]).strip() if len(row) > 1 and row[1] else ""
            
            # Combine property name with sub-label
            if sub_label and sub_label != prop_name_dutch:
                full_prop_dutch = f"{prop_name_dutch} {sub_label}".strip()
            else:
                full_prop_dutch = prop_name_dutch
            
            if not full_prop_dutch:
                continue
            
            # Get value for this product column
            if col_idx < len(row):
                value = clean_property_value(row[col_idx])
                
                if value:
                    # Translate property name
                    prop_name_english = translate_property_name(full_prop_dutch)
                    
                    # Get icons
                    prop_icon = get_property_icon(prop_name_english, value)
                    value_icon = get_value_icon(value)
                    
                    # Check for price
                    prop_lower = full_prop_dutch.lower()
                    if 'prijs' in prop_lower or 'price' in prop_lower:
                        price = extract_price(value)
                        if price:
                            if 'excl' in prop_lower:
                                product['price_excl_btw_eur'] = price
                            elif 'incl' in prop_lower:
                                product['price_incl_btw_eur'] = price
                    else:
                        # Store in all three formats
                        product['properties'][full_prop_dutch] = value
                        product['properties_translated'][prop_name_english] = value
                        
                        # Format with icons
                        if value_icon:
                            product['properties_with_icons'][prop_name_english] = f"{prop_icon} {value} {value_icon}"
                        else:
                            product['properties_with_icons'][prop_name_english] = f"{prop_icon} {value}"
        
        products.append(product)
    
    return products

def extract_pdf_tables(pdf_path, catalog_name):
    """Extract tables from PDF with smart property translation"""
    print("="*80)
    print(f"SMART TABLE EXTRACTION: {catalog_name}")
    print("="*80)
    
    all_products = []
    
    # Better table settings for column detection
    table_settings = {
        "vertical_strategy": "lines_strict",
        "horizontal_strategy": "lines_strict",
        "snap_tolerance": 3,
        "join_tolerance": 3,
        "edge_min_length": 3,
        "min_words_vertical": 1,
        "min_words_horizontal": 1,
    }
    
    with pdfplumber.open(pdf_path) as pdf:
        total_pages = len(pdf.pages)
        print(f"\nProcessing {total_pages} pages...")
        print(f"Using strict line-based table detection...")
        
        for page_num in range(total_pages):
            page = pdf.pages[page_num]
            page_text = page.extract_text() or ""
            
            # Try with settings first
            tables = page.extract_tables(table_settings)
            
            # Fallback to default if no tables found
            if not tables:
                tables = page.extract_tables()
            
            if not tables:
                continue
            
            # Find SKUs on page
            page_skus = find_product_skus_on_page(page_text)
            
            if (page_num + 1) % 10 == 0:
                print(f"  Page {page_num + 1}/{total_pages}")
            
            # Process each table
            for table_idx, table in enumerate(tables):
                products = extract_products_from_table(table, page_num + 1, page_skus)
                
                if products:
                    print(f"  Page {page_num + 1}, Table {table_idx + 1}: {len(products)} products")
                    all_products.extend(products)
    
    return all_products

def main():
    """Extract tables from both Makita PDFs"""
    catalogs = [
        (PROJECT_ROOT / "input_pdfs" / "makita-catalogus-2022-nl.pdf", "makita-catalogus-2022-nl"),
        (PROJECT_ROOT / "input_pdfs" / "makita-tuinfolder-2022-nl.pdf", "makita-tuinfolder-2022-nl"),
    ]
    
    all_results = {}
    
    for pdf_path, catalog_name in catalogs:
        if not pdf_path.exists():
            print(f"\n[SKIP] {pdf_path.name} - not found")
            continue
        
        products = extract_pdf_tables(pdf_path, catalog_name)
        
        # Save results
        output_file = OUTPUT_DIR / f"{catalog_name}_products_translated.json"
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(products, f, indent=2, ensure_ascii=False)
        
        all_results[catalog_name] = len(products)
        
        print(f"\n[SAVED] {output_file}")
        print(f"[EXTRACTED] {len(products)} products with translated properties")
    
    # Print summary
    print("\n" + "="*80)
    print("EXTRACTION COMPLETE")
    print("="*80)
    print(f"\nTotal products extracted: {sum(all_results.values())}")
    for catalog, count in all_results.items():
        print(f"  {catalog}: {count} products")
    
    # Show sample
    if all_results:
        first_catalog = list(catalogs)[0][1]
        sample_file = OUTPUT_DIR / f"{first_catalog}_products_translated.json"
        
        if sample_file.exists():
            with open(sample_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if data:
                    print("\n" + "="*80)
                    print("SAMPLE PRODUCT (with icons)")
                    print("="*80)
                    sample = data[0]
                    print(f"\nSKU: {sample['sku']}")
                    print(f"Page: {sample['page']}")
                    
                    if sample.get('properties_with_icons'):
                        print("\nProperties (with icons):")
                        for prop, value in list(sample['properties_with_icons'].items())[:5]:
                            print(f"  {value}")
                    
                    if sample.get('price_excl_btw_eur'):
                        print(f"\n💰 Price excl. VAT: €{sample['price_excl_btw_eur']}")

if __name__ == '__main__':
    main()
