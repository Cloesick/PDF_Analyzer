"""
IMPROVED MAKITA TABLE EXTRACTOR
================================
Specifically handles comparison tables with format:
- Row 1: SKUs as column headers (DF002GZ01, DF002GD201, etc.)
- Column 1: Property names (Spanning, Max. koppel, etc.)
- Cells: Property values

Output: Beautiful structured JSON with icons
"""

import pdfplumber
import json
import re
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "makita-catalogus-2022-nl.pdf"
OUTPUT_JSON = PROJECT_ROOT / "output" / "makita_products_beautiful.json"

# Property mapping with icons
PROPERTY_MAP = {
    'spanning': {'key': 'voltage', 'icon': '⚡', 'label': ''},
    'voltage': {'key': 'voltage', 'icon': '⚡', 'label': ''},
    
    'max. koppel zacht / hard': {'key': 'torque', 'icon': '🔧', 'label': 'Torque'},
    'max. koppel': {'key': 'torque', 'icon': '🔧', 'label': 'Torque'},
    
    'boorkop': {'key': 'chuck_size', 'icon': '🎯', 'label': ''},
    'boor capaciteit': {'key': 'drill_capacity', 'icon': '🎯', 'label': ''},
    
    'klopboorfunctie': {'key': 'hammer_drill', 'icon': '🔨', 'label': '', 'type': 'bool'},
    
    'bijgeleverde accu\'s': {'key': 'batteries', 'icon': '🔋', 'label': ''},
    'bijgeleverde accu': {'key': 'batteries', 'icon': '🔋', 'label': ''},
    'accu': {'key': 'batteries', 'icon': '🔋', 'label': ''},
    
    'lader': {'key': 'charger', 'icon': '🔌', 'label': ''},
    
    'gewicht': {'key': 'weight', 'icon': '⚖️', 'label': ''},
    
    'prijs in € excl. btw': {'key': 'price_excl', 'icon': '💶', 'label': '(ex)', 'type': 'price'},
    'incl. btw': {'key': 'price_incl', 'icon': '💶', 'label': '(incl)', 'type': 'price'},
    
    'vermogen': {'key': 'power', 'icon': '⚡', 'label': ''},
    'toerental': {'key': 'rpm', 'icon': '🔄', 'label': 'RPM'},
    'toeren': {'key': 'rpm', 'icon': '🔄', 'label': 'RPM'},
    
    'zaagcapaciteit': {'key': 'saw_capacity', 'icon': '📏', 'label': ''},
    'zaagblad': {'key': 'blade', 'icon': '⚙️', 'label': ''},
    'schijf': {'key': 'disc', 'icon': '◯', 'label': ''},
}

# Exclude batteries/chargers
EXCLUDE_PATTERNS = [
    r'^BL\d+', r'^DC\d+', r'^ADP', r'^DEAADP',
]

def is_tool(sku):
    """Check if SKU is a tool"""
    if not sku or len(sku) < 4:
        return False
    for pattern in EXCLUDE_PATTERNS:
        if re.match(pattern, sku.upper()):
            return False
    return bool(re.match(r'^[A-Z]{2,4}\d{3,4}[A-Z]{0,4}\d{0,3}$', sku.upper()))

def parse_price(text):
    """Extract price"""
    if not text:
        return None
    text = str(text).replace('€', '').replace('.', '').replace(',', '.').strip()
    match = re.search(r'(\d+\.?\d*)', text)
    return float(match.group(1)) if match else None

def parse_bool(text):
    """Parse boolean"""
    if not text:
        return False
    text = str(text).strip().lower()
    return text not in ['', '-', 'nee', 'no']

def clean_value(text):
    """Clean value"""
    if not text:
        return None
    text = str(text).strip()
    return None if text in ['', '-', 'None'] else text

def find_property(prop_name):
    """Find property config"""
    if not prop_name:
        return None
    prop_lower = prop_name.lower().strip()
    for key, config in PROPERTY_MAP.items():
        if key in prop_lower:
            return config
    return None

def extract_from_table(table, page_num):
    """Extract products from single table"""
    if not table or len(table) < 3:  # Need header + at least 2 property rows
        return []
    
    # Find SKU row (usually first row)
    header_row = None
    sku_row_idx = None
    
    for idx, row in enumerate(table[:5]):  # Check first 5 rows
        if not row:
            continue
        
        # Look for SKUs in this row
        skus_found = []
        for cell in row[1:]:  # Skip first column
            if cell and is_tool(str(cell).strip()):
                skus_found.append(str(cell).strip())
        
        if len(skus_found) >= 2:  # Found comparison table with multiple products
            header_row = row
            sku_row_idx = idx
            break
    
    if not header_row:
        return []
    
    # Extract SKUs with their column positions
    sku_columns = []
    for col_idx, cell in enumerate(header_row):
        if col_idx == 0:  # Skip property name column
            continue
        if cell and is_tool(str(cell).strip()):
            sku_columns.append({
                'sku': str(cell).strip(),
                'col_idx': col_idx,
                'specs': {},
                'display': {},
                'page': page_num
            })
    
    if not sku_columns:
        return []
    
    # Extract properties from remaining rows
    for row_idx in range(sku_row_idx + 1, len(table)):
        row = table[row_idx]
        if not row or len(row) < 2:
            continue
        
        prop_name = row[0]
        if not prop_name:
            continue
        
        prop_config = find_property(str(prop_name))
        if not prop_config:
            continue
        
        # Extract value for each product
        for product in sku_columns:
            col_idx = product['col_idx']
            if col_idx < len(row):
                value = row[col_idx]
                
                # Parse based on type
                prop_type = prop_config.get('type', 'text')
                if prop_type == 'price':
                    parsed = parse_price(value)
                elif prop_type == 'bool':
                    parsed = parse_bool(value)
                else:
                    parsed = clean_value(value)
                
                if parsed is not None:
                    key = prop_config['key']
                    icon = prop_config['icon']
                    label = prop_config.get('label', '')
                    
                    # Store raw value
                    product['specs'][key] = parsed
                    
                    # Create display value
                    if prop_type == 'bool':
                        display = f"{icon} {'Yes' if parsed else 'No'}"
                    elif prop_type == 'price':
                        display = f"{icon} € {parsed:.2f} {label}".strip()
                    else:
                        display = f"{icon} {parsed}"
                        if label:
                            display += f" ({label})"
                    
                    product['display'][key] = display
    
    # Filter products with specifications
    products = [p for p in sku_columns if p['specs']]
    
    return products

def extract_all_products():
    """Extract all products from PDF"""
    print("="*80)
    print("IMPROVED MAKITA TABLE EXTRACTOR")
    print("="*80)
    
    all_products = {}  # SKU -> product dict
    stats = {'tables': 0, 'products': 0}
    
    print(f"\n📄 Processing: {PDF_PATH.name}\n")
    
    with pdfplumber.open(PDF_PATH) as pdf:
        for page_num, page in enumerate(pdf.pages, 1):
            tables = page.extract_tables()
            
            if not tables:
                continue
            
            for table in tables:
                stats['tables'] += 1
                products = extract_from_table(table, page_num)
                
                if products:
                    print(f"  ✅ Page {page_num}: Found {len(products)} products")
                    for p in products:
                        print(f"     {p['sku']}: {list(p['specs'].keys())}")
                        
                        # Merge if duplicate
                        if p['sku'] in all_products:
                            all_products[p['sku']]['specs'].update(p['specs'])
                            all_products[p['sku']]['display'].update(p['display'])
                        else:
                            all_products[p['sku']] = p
                            stats['products'] += 1
            
            if page_num % 20 == 0:
                print(f"\n  📊 Progress: {page_num} pages, {len(all_products)} unique products\n")
    
    # Create output
    output = {
        'metadata': {
            'source': 'makita-catalogus-2022-nl',
            'total_products': len(all_products),
            'tables_processed': stats['tables']
        },
        'products': list(all_products.values())
    }
    
    # Save
    OUTPUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print(f"\n{'='*80}")
    print("✅ EXTRACTION COMPLETE")
    print(f"{'='*80}")
    print(f"\nStatistics:")
    print(f"  Tables processed:  {stats['tables']}")
    print(f"  Products extracted: {len(all_products)}")
    print(f"\n💾 Saved to: {OUTPUT_JSON}")
    
    # Show samples
    print(f"\n📦 Sample Products:\n")
    for sku, product in list(all_products.items())[:3]:
        print(f"┌{'─'*40}┐")
        print(f"│ Model: {sku:34s} │")
        print(f"│{' '*40}│")
        for value in product['display'].values():
            print(f"│ {value:38s} │")
        print(f"└{'─'*40}┘\n")
    
    return output

if __name__ == "__main__":
    extract_all_products()
