"""
Analyze Makita Product Properties Extraction
=============================================
Check if product specifications are being extracted correctly
"""
import json
from pathlib import Path
from collections import Counter, defaultdict

PROJECT_ROOT = Path(__file__).parent
# Use the updated file with linked images
PRODUCTS_JSON = PROJECT_ROOT / "output" / "products_with_makita_images.json"
# Fall back to original if updated doesn't exist
if not PRODUCTS_JSON.exists():
    PRODUCTS_JSON = PROJECT_ROOT / "output" / "products_ready_for_webshop.json"

def analyze_properties():
    print("=" * 80)
    print("MAKITA PRODUCT PROPERTIES ANALYSIS")
    print("=" * 80)
    
    # Load products
    print("\n📦 Loading products...")
    with open(PRODUCTS_JSON, 'r', encoding='utf-8') as f:
        all_products = json.load(f)
    
    makita = [p for p in all_products if 'makita-catalogus-2022-nl' in p.get('pdf_source', '')]
    print(f"   Found {len(makita)} Makita products")
    
    # Analyze properties
    print("\n📊 Property Coverage Analysis:")
    print("-" * 80)
    
    # Common fields
    common_fields = [
        'sku', 'name', 'description', 'product_category', 
        'pdf_source', 'source_pages', 'image_url'
    ]
    
    # Technical properties
    tech_properties = [
        'voltage', 'power_w', 'power_kw', 'power_hp',
        'rpm', 'speed_rpm', 'torque_nm',
        'weight_kg', 'dimensions_mm', 'diameter_mm',
        'capacity_ah', 'battery_voltage',
        'max_pressure_bar', 'flow_rate',
        'noise_level_db', 'vibration'
    ]
    
    # Attributes
    attribute_keys = set()
    specs_keys = set()
    
    # Statistics
    stats = defaultdict(int)
    property_coverage = {}
    
    for product in makita:
        # Check common fields
        for field in common_fields:
            if product.get(field):
                stats[f'has_{field}'] += 1
        
        # Check technical properties
        for prop in tech_properties:
            if product.get(prop):
                stats[f'has_{prop}'] += 1
        
        # Check attributes
        attrs = product.get('attributes', {})
        if attrs:
            stats['has_attributes'] += 1
            attribute_keys.update(attrs.keys())
        
        # Check specs
        specs = product.get('specifications', [])
        if specs:
            stats['has_specifications'] += 1
            for spec in specs:
                if isinstance(spec, dict):
                    specs_keys.update(spec.keys())
    
    # Calculate coverage percentages
    total = len(makita)
    
    print("\n🔹 Common Fields:")
    for field in common_fields:
        count = stats.get(f'has_{field}', 0)
        pct = (count / total * 100) if total > 0 else 0
        status = "✅" if pct > 80 else "⚠️" if pct > 50 else "❌"
        print(f"   {status} {field:20s}: {count:4d}/{total} ({pct:5.1f}%)")
    
    print("\n🔹 Technical Properties:")
    for prop in tech_properties:
        count = stats.get(f'has_{prop}', 0)
        if count > 0:
            pct = (count / total * 100)
            status = "✅" if pct > 50 else "⚠️" if pct > 10 else "💡"
            print(f"   {status} {prop:20s}: {count:4d}/{total} ({pct:5.1f}%)")
    
    print(f"\n🔹 Structured Data:")
    attrs_count = stats.get('has_attributes', 0)
    specs_count = stats.get('has_specifications', 0)
    print(f"   Products with attributes:     {attrs_count}/{total} ({attrs_count/total*100:.1f}%)")
    print(f"   Products with specifications: {specs_count}/{total} ({specs_count/total*100:.1f}%)")
    
    if attribute_keys:
        print(f"\n   📋 Attribute keys found ({len(attribute_keys)}):")
        for key in sorted(attribute_keys)[:20]:
            print(f"      - {key}")
        if len(attribute_keys) > 20:
            print(f"      ... and {len(attribute_keys) - 20} more")
    
    if specs_keys:
        print(f"\n   📋 Specification keys found ({len(specs_keys)}):")
        for key in sorted(specs_keys)[:20]:
            print(f"      - {key}")
    
    # Sample products
    print("\n" + "=" * 80)
    print("SAMPLE PRODUCTS (Detailed View)")
    print("=" * 80)
    
    # Show 5 random products with their full data
    import random
    samples = random.sample(makita, min(5, len(makita)))
    
    for i, product in enumerate(samples, 1):
        print(f"\n🔍 Sample {i}: {product.get('sku', 'Unknown')}")
        name = product.get('name') or 'N/A'
        desc = product.get('description') or 'N/A'
        print(f"   Name: {str(name)[:70]}")
        print(f"   Description: {str(desc)[:70]}")
        print(f"   Category: {product.get('product_category', 'N/A')}")
        print(f"   Page: {product.get('source_pages', ['?'])[0] if product.get('source_pages') else '?'}")
        print(f"   Image: {'✅ Yes' if product.get('image_url') else '❌ No'}")
        
        # Technical properties
        tech_found = []
        for prop in tech_properties:
            if product.get(prop):
                tech_found.append(f"{prop}={product[prop]}")
        if tech_found:
            print(f"   Tech props: {', '.join(tech_found[:3])}")
            if len(tech_found) > 3:
                print(f"               {', '.join(tech_found[3:6])}")
        
        # Attributes
        attrs = product.get('attributes', {})
        if attrs:
            print(f"   Attributes ({len(attrs)}): {list(attrs.keys())[:5]}")
        
        # Specs
        specs = product.get('specifications', [])
        if specs:
            print(f"   Specs ({len(specs)}): {specs[:2]}")
    
    # Identify missing properties
    print("\n" + "=" * 80)
    print("RECOMMENDATIONS")
    print("=" * 80)
    
    issues = []
    
    # Check for low coverage
    for field in common_fields:
        count = stats.get(f'has_{field}', 0)
        pct = (count / total * 100) if total > 0 else 0
        if pct < 90:
            issues.append(f"Low {field} coverage: {pct:.1f}%")
    
    if attrs_count < total * 0.5:
        issues.append(f"Only {attrs_count/total*100:.1f}% have attributes")
    
    if specs_count < total * 0.5:
        issues.append(f"Only {specs_count/total*100:.1f}% have specifications")
    
    if issues:
        print("\n⚠️  Issues Found:")
        for issue in issues:
            print(f"   - {issue}")
        
        print("\n💡 Recommendations:")
        print("   1. Check if Makita catalog has tables with specs")
        print("   2. Verify table extraction is working")
        print("   3. Map technical specs to proper fields")
        print("   4. Consider re-running extraction with table focus")
    else:
        print("\n✅ All properties look good!")
    
    print("\n" + "=" * 80)

if __name__ == '__main__':
    analyze_properties()
