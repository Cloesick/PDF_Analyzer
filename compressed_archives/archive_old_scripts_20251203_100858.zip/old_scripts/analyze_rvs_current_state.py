"""
Analyze RVS Draadfittingen Current State
=========================================
Check current coverage of images and properties
"""
import json
from pathlib import Path
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
PRODUCTS_JSON = PROJECT_ROOT / "output" / "products_ready_for_webshop.json"

def analyze_rvs():
    print("=" * 80)
    print("RVS DRAADFITTINGEN - CURRENT STATE ANALYSIS")
    print("=" * 80)
    
    # Load products
    print("\n📦 Loading products...")
    with open(PRODUCTS_JSON, 'r', encoding='utf-8') as f:
        all_products = json.load(f)
    
    # Find RVS draadfittingen products
    rvs_products = [p for p in all_products if 'rvs-draadfittingen' in p.get('pdf_source', '').lower()]
    
    if not rvs_products:
        # Try alternative patterns
        rvs_products = [p for p in all_products if any(x in p.get('product_category', '').lower() for x in ['rvs', 'draadfitting'])]
    
    print(f"   Found {len(rvs_products)} RVS draadfittingen products")
    
    if len(rvs_products) == 0:
        print("\n❌ No RVS draadfittingen products found!")
        print("\n🔍 Searching for similar products...")
        
        # Show available catalogs
        catalogs = defaultdict(int)
        for p in all_products:
            pdf = p.get('pdf_source', 'unknown')
            if 'rvs' in pdf.lower() or 'draad' in pdf.lower() or 'fitting' in pdf.lower():
                catalogs[pdf] += 1
        
        if catalogs:
            print("\n📚 Found potentially related catalogs:")
            for catalog, count in sorted(catalogs.items(), key=lambda x: x[1], reverse=True):
                print(f"   - {catalog}: {count} products")
        
        # Show sample categories
        categories = defaultdict(int)
        for p in all_products[:1000]:  # Sample first 1000
            cat = p.get('product_category', 'unknown')
            if any(x in cat.lower() for x in ['rvs', 'draad', 'fitting', 'koppeling']):
                categories[cat] += 1
        
        if categories:
            print("\n🏷️  Found potentially related categories:")
            for cat, count in sorted(categories.items(), key=lambda x: x[1], reverse=True)[:10]:
                print(f"   - {cat}: {count} products")
        
        return
    
    # Analyze current state
    stats = {
        'total': len(rvs_products),
        'with_images': 0,
        'with_description': 0,
        'with_attributes': 0,
        'with_specifications': 0,
        'complete': 0,
        'pages': defaultdict(int)
    }
    
    for product in rvs_products:
        if product.get('image_url'):
            stats['with_images'] += 1
        if product.get('description'):
            stats['with_description'] += 1
        if product.get('attributes') and len(product['attributes']) > 0:
            stats['with_attributes'] += 1
        if product.get('specifications') and len(product['specifications']) > 0:
            stats['with_specifications'] += 1
        
        # Complete if has image AND (attributes OR specs)
        if product.get('image_url') and (product.get('attributes') or product.get('specifications')):
            stats['complete'] += 1
        
        # Track pages
        pages = product.get('source_pages', [])
        for page in pages:
            stats['pages'][page] += 1
    
    # Print summary
    print("\n" + "=" * 80)
    print("CURRENT STATE SUMMARY")
    print("=" * 80)
    
    print(f"\n📊 Coverage:")
    print(f"   Total products:        {stats['total']}")
    print(f"   With images:           {stats['with_images']} ({stats['with_images']/stats['total']*100:.1f}%)")
    print(f"   With description:      {stats['with_description']} ({stats['with_description']/stats['total']*100:.1f}%)")
    print(f"   With attributes:       {stats['with_attributes']} ({stats['with_attributes']/stats['total']*100:.1f}%)")
    print(f"   With specifications:   {stats['with_specifications']} ({stats['with_specifications']/stats['total']*100:.1f}%)")
    print(f"   Complete (img+props):  {stats['complete']} ({stats['complete']/stats['total']*100:.1f}%)")
    
    # Top pages
    print(f"\n📄 Top 10 Pages by Product Count:")
    top_pages = sorted(stats['pages'].items(), key=lambda x: x[1], reverse=True)[:10]
    for page, count in top_pages:
        print(f"   Page {page:3d}: {count:3d} products")
    
    # Sample products
    print(f"\n🔍 Sample Products:")
    for i, product in enumerate(rvs_products[:5], 1):
        pages = product.get('source_pages', [])
        page = pages[0] if pages else '?'
        print(f"   {i}. {product.get('sku', 'Unknown'):20s} | Page {str(page):4s} | {product.get('name', 'N/A')[:50]}")
        print(f"      Image: {'✅' if product.get('image_url') else '❌'} | "
              f"Props: {'✅' if product.get('attributes') or product.get('specifications') else '❌'}")
    
    # Show PDF source
    pdf_sources = set(p.get('pdf_source', 'unknown') for p in rvs_products)
    print(f"\n📚 PDF Sources:")
    for pdf in pdf_sources:
        count = len([p for p in rvs_products if p.get('pdf_source') == pdf])
        print(f"   - {pdf}: {count} products")
    
    print("\n" + "=" * 80)
    print("RECOMMENDATION")
    print("=" * 80)
    print("""
Based on current state, we should:
1. Extract high-quality images from PDF
2. Parse tables for technical specifications
3. Link images to products
4. Extract properties (dimensions, materials, etc.)
5. Merge everything for complete product data
    """)

if __name__ == '__main__':
    analyze_rvs()
