"""
Analyze Makita extracted images to identify non-product images
"""
from pathlib import Path
from PIL import Image
import numpy as np
import cv2
import re

PROJECT_ROOT = Path(__file__).parent
IMAGE_DIR = PROJECT_ROOT / "product-images-by-pdf" / "makita-catalogus-2022-nl"

def analyze_image_content(image_path):
    """Deep analysis of image to determine if it's a product"""
    img = Image.open(image_path)
    img_array = np.array(img.convert('RGB'))
    
    width, height = img.size
    gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
    
    # Check for text/diagram indicators
    edges = cv2.Canny(gray, 50, 150)
    edge_density = np.sum(edges > 0) / (width * height)
    
    # Check color complexity
    r, g, b = img_array[:,:,0], img_array[:,:,1], img_array[:,:,2]
    color_variance = np.std(r) + np.std(g) + np.std(b)
    
    # Check for white background dominance
    white_pixels = np.sum((r > 240) & (g > 240) & (b > 240))
    white_ratio = white_pixels / (width * height)
    
    # Check if mostly grayscale (diagrams tend to be)
    rg_diff = np.mean(np.abs(r.astype(int) - g.astype(int)))
    rb_diff = np.mean(np.abs(r.astype(int) - b.astype(int)))
    is_grayscale = (rg_diff < 10 and rb_diff < 10)
    
    return {
        'width': width,
        'height': height,
        'edge_density': edge_density,
        'color_variance': color_variance,
        'white_ratio': white_ratio,
        'is_grayscale': is_grayscale,
        'area': width * height
    }

def main():
    print("="*80)
    print("ANALYZING MAKITA EXTRACTED IMAGES")
    print("="*80)
    
    images = list(IMAGE_DIR.glob("*.webp"))
    print(f"\nTotal images: {len(images)}")
    
    # Sample analysis
    suspicious = []
    
    print("\nAnalyzing sample images...")
    for idx, img_path in enumerate(images[:50]):  # First 50
        stats = analyze_image_content(img_path)
        
        # Criteria for suspicious images
        is_suspicious = False
        reason = []
        
        if stats['edge_density'] > 0.15:  # Very high edge density = diagram/text
            is_suspicious = True
            reason.append(f"high_edges({stats['edge_density']:.3f})")
        
        if stats['white_ratio'] > 0.85:  # Mostly white = icon/diagram
            is_suspicious = True
            reason.append(f"mostly_white({stats['white_ratio']:.2f})")
        
        if stats['area'] < 25000:  # Very small = icon
            is_suspicious = True
            reason.append(f"small({stats['area']}px)")
        
        if stats['color_variance'] < 30:  # Low color = diagram
            is_suspicious = True
            reason.append(f"low_color({stats['color_variance']:.1f})")
        
        if is_suspicious:
            suspicious.append({
                'filename': img_path.name,
                'reasons': reason,
                'stats': stats
            })
    
    print(f"\n[SUSPICIOUS IMAGES] Found {len(suspicious)} out of 50 sampled")
    
    if suspicious:
        print("\nTop 10 suspicious images:")
        for item in suspicious[:10]:
            print(f"\n  {item['filename']}")
            print(f"    Reasons: {', '.join(item['reasons'])}")
            print(f"    Size: {item['stats']['width']}x{item['stats']['height']}")
            print(f"    Edge density: {item['stats']['edge_density']:.3f}")
            print(f"    White ratio: {item['stats']['white_ratio']:.2f}")
            print(f"    Color variance: {item['stats']['color_variance']:.1f}")
    
    # Check filenames with "voltage" - these seem wrong
    voltage_images = [img for img in images if 'voltage' in img.name.lower()]
    print(f"\n[VOLTAGE IN NAME] Found {len(voltage_images)} images with 'voltage' in filename")
    
    if voltage_images:
        print("\nSample voltage images (likely specs/diagrams):")
        for img in voltage_images[:10]:
            print(f"  - {img.name}")
    
    # Overall statistics
    print("\n" + "="*80)
    print("SUMMARY")
    print("="*80)
    print(f"Total images: {len(images)}")
    print(f"Suspicious (sampled): {len(suspicious)}/50 ({len(suspicious)/50*100:.1f}%)")
    print(f"Images with 'voltage' in name: {len(voltage_images)} ({len(voltage_images)/len(images)*100:.1f}%)")

if __name__ == '__main__':
    main()
