"""
Analyze Makita Catalog Image Extraction
========================================
Diagnostic script to understand current image quality and consistency issues
"""
import json
from pathlib import Path
from collections import defaultdict
from PIL import Image
import numpy as np

PROJECT_ROOT = Path(__file__).parent
OUTPUT_FILE = PROJECT_ROOT / "output" / "products_ready_for_webshop.json"
IMAGES_BY_PDF = PROJECT_ROOT / "product-images-by-pdf" / "makita-catalogus-2022-nl"
IMAGES_IMPROVED = PROJECT_ROOT / "product-images-improved" / "makita-catalogus-2022-nl"
IMAGES_ULTIMATE = PROJECT_ROOT / "product-images-ultimate"

def analyze_image_quality(image_path):
    """Analyze image quality metrics"""
    try:
        img = Image.open(image_path)
        if img.mode != 'RGB':
            img = img.convert('RGB')
        
        img_array = np.array(img)
        
        # Color variance (higher = more colorful)
        r, g, b = img_array[:,:,0], img_array[:,:,1], img_array[:,:,2]
        rg_diff = np.abs(r.astype(int) - g.astype(int))
        rb_diff = np.abs(r.astype(int) - b.astype(int))
        gb_diff = np.abs(g.astype(int) - b.astype(int))
        color_variance = (rg_diff.mean() + rb_diff.mean() + gb_diff.mean()) / 3
        
        # Brightness
        gray = np.mean(img_array, axis=2)
        brightness = gray.mean()
        
        # Contrast (std dev of brightness)
        contrast = gray.std()
        
        # Size
        width, height = img.size
        
        return {
            'width': width,
            'height': height,
            'color_variance': color_variance,
            'brightness': brightness,
            'contrast': contrast,
            'is_bw': color_variance < 15,
            'is_small': width < 200 or height < 200
        }
    except Exception as e:
        return None

def main():
    print("=" * 80)
    print("MAKITA CATALOG IMAGE ANALYSIS")
    print("=" * 80)
    
    # Load products
    print("\n📦 Loading product data...")
    with open(OUTPUT_FILE, 'r', encoding='utf-8') as f:
        all_products = json.load(f)
    
    makita_products = [p for p in all_products if 'makita-catalogus-2022-nl' in p.get('pdf_source', '')]
    print(f"   Found {len(makita_products)} Makita products")
    
    # Analyze images
    print("\n🖼️  Analyzing images...")
    
    stats = {
        'total_products': len(makita_products),
        'with_images': 0,
        'without_images': 0,
        'bw_images': 0,
        'color_images': 0,
        'small_images': 0,
        'large_images': 0,
        'by_page': defaultdict(int),
        'quality_scores': []
    }
    
    products_by_quality = {
        'excellent': [],  # Color, large, good contrast
        'good': [],       # Color or large
        'poor': [],       # B&W or small
        'missing': []     # No image
    }
    
    for product in makita_products:
        sku = product.get('sku', 'unknown')
        image_url = product.get('image_url', '')
        page = product.get('source_pages', [None])[0]
        
        if page:
            stats['by_page'][page] += 1
        
        if not image_url:
            stats['without_images'] += 1
            products_by_quality['missing'].append({
                'sku': sku,
                'name': product.get('name', ''),
                'page': page
            })
            continue
        
        stats['with_images'] += 1
        
        # Try to find actual image file
        image_path = None
        if '/product-images/' in image_url:
            # Extract filename from URL
            filename = image_url.split('/')[-1]
            
            # Check in different folders
            for folder in [IMAGES_BY_PDF, IMAGES_IMPROVED, IMAGES_ULTIMATE]:
                if folder.exists():
                    potential_path = folder / filename
                    if potential_path.exists():
                        image_path = potential_path
                        break
                    # Also check without folder structure
                    for file in folder.rglob(filename):
                        image_path = file
                        break
        
        if image_path and image_path.exists():
            quality = analyze_image_quality(image_path)
            if quality:
                stats['quality_scores'].append(quality)
                
                if quality['is_bw']:
                    stats['bw_images'] += 1
                else:
                    stats['color_images'] += 1
                
                if quality['is_small']:
                    stats['small_images'] += 1
                else:
                    stats['large_images'] += 1
                
                # Categorize quality
                if not quality['is_bw'] and not quality['is_small'] and quality['contrast'] > 40:
                    category = 'excellent'
                elif not quality['is_bw'] or not quality['is_small']:
                    category = 'good'
                else:
                    category = 'poor'
                
                products_by_quality[category].append({
                    'sku': sku,
                    'name': product.get('name', ''),
                    'page': page,
                    'image': str(image_path.name),
                    **quality
                })
    
    # Print summary
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    
    print(f"\n📊 Overall Statistics:")
    print(f"   Total products:        {stats['total_products']}")
    print(f"   With images:           {stats['with_images']} ({stats['with_images']/stats['total_products']*100:.1f}%)")
    print(f"   Without images:        {stats['without_images']} ({stats['without_images']/stats['total_products']*100:.1f}%)")
    
    if stats['with_images'] > 0:
        print(f"\n🎨 Image Quality:")
        print(f"   Color images:          {stats['color_images']} ({stats['color_images']/stats['with_images']*100:.1f}%)")
        print(f"   B&W/Shape images:      {stats['bw_images']} ({stats['bw_images']/stats['with_images']*100:.1f}%)")
        print(f"   Large images (>200px): {stats['large_images']} ({stats['large_images']/stats['with_images']*100:.1f}%)")
        print(f"   Small images (<200px): {stats['small_images']} ({stats['small_images']/stats['with_images']*100:.1f}%)")
    
    if stats['quality_scores']:
        avg_color_var = np.mean([q['color_variance'] for q in stats['quality_scores']])
        avg_contrast = np.mean([q['contrast'] for q in stats['quality_scores']])
        avg_width = np.mean([q['width'] for q in stats['quality_scores']])
        avg_height = np.mean([q['height'] for q in stats['quality_scores']])
        
        print(f"\n📏 Average Metrics:")
        print(f"   Color variance:        {avg_color_var:.1f} (>15 is color, <15 is B&W)")
        print(f"   Contrast:              {avg_contrast:.1f} (>40 is good)")
        print(f"   Image size:            {avg_width:.0f}x{avg_height:.0f} px")
    
    print(f"\n📑 Products by Quality Category:")
    print(f"   Excellent (color, large, good contrast): {len(products_by_quality['excellent'])}")
    print(f"   Good (color or large):                   {len(products_by_quality['good'])}")
    print(f"   Poor (B&W or small):                     {len(products_by_quality['poor'])}")
    print(f"   Missing images:                          {len(products_by_quality['missing'])}")
    
    # Top pages
    print(f"\n📄 Top 10 Pages by Product Count:")
    top_pages = sorted(stats['by_page'].items(), key=lambda x: x[1], reverse=True)[:10]
    for page, count in top_pages:
        print(f"   Page {page:3d}: {count:3d} products")
    
    # Show examples
    print(f"\n🔍 Example Poor Quality Images:")
    for i, prod in enumerate(products_by_quality['poor'][:5], 1):
        print(f"   {i}. {prod['sku']:15s} | Page {prod['page']:3d} | {prod['image']}")
        print(f"      Color variance: {prod['color_variance']:.1f}, Size: {prod['width']}x{prod['height']}")
    
    print(f"\n❌ Example Missing Images:")
    for i, prod in enumerate(products_by_quality['missing'][:10], 1):
        print(f"   {i}. {prod['sku']:15s} | Page {prod.get('page', 'N/A'):3} | {prod['name'][:50]}")
    
    # Save detailed report
    report_path = PROJECT_ROOT / "makita_image_analysis_report.json"
    with open(report_path, 'w', encoding='utf-8') as f:
        json.dump({
            'stats': {k: v for k, v in stats.items() if k != 'quality_scores'},
            'products_by_quality': products_by_quality
        }, f, indent=2)
    
    print(f"\n💾 Detailed report saved to: {report_path}")
    print("\n" + "=" * 80)
    print("RECOMMENDATIONS")
    print("=" * 80)
    print("""
1. Focus on pages with most products (see top pages above)
2. Re-extract B&W images - they might have color versions in PDF
3. Target products without images first
4. Use higher DPI (300+) for better quality
5. Apply GPT filtering to remove non-product images
    """)

if __name__ == '__main__':
    main()
