"""
Exhaustive Makita SKU Extraction
Extracts ALL SKUs with comprehensive info and images from Makita PDFs
"""
import pdfplumber
import json
import re
from pathlib import Path
from PIL import Image
import io
from collections import defaultdict

PROJECT_ROOT = Path(__file__).parent
INPUT_PDFS = PROJECT_ROOT / "input_pdfs"
OUTPUT_DIR = PROJECT_ROOT / "output"
IMAGE_DIR = PROJECT_ROOT / "product-images-by-pdf"

# Comprehensive SKU patterns for Makita products
SKU_PATTERNS = [
    # Standard Makita patterns
    r'\b[A-Z]{2,4}\d{3,4}[A-Z]{0,4}\d{0,3}\b',  # DHS680RTJ, GA7082, SK105DZ
    r'\b[A-Z]{2}\d{3}[A-Z]{2}\d{3}\b',          # TD001GD201, PT001GD101
    r'\b[A-Z]{3}\d{3}[A-Z]{2,3}\b',             # DUC307ZX2, DCL280FZW
    
    # Variations with dashes/spaces
    r'\b[A-Z]{2,4}\d{3,4}[-\s][A-Z]{1,3}\d{0,2}\b',
    
    # Garden tools specific
    r'\bDLM\d{3}[A-Z]{0,3}\b',                  # DLM330SM, DLM382Z
    r'\bDUB\d{3}[A-Z]{0,3}\b',                  # DUB186Z
    r'\bDUC\d{3}[A-Z]{0,3}\b',                  # DUC302Z
    
    # Combo kits
    r'\bDK\d{4}[A-Z]\d{3}\b',                   # DK0126G401
    r'\bCLX\d{3}[A-Z]{3}\d\b',                  # CLX206SAX3
    
    # With suffix variations
    r'\b[A-Z]{2,4}\d{3,4}[A-Z]+\d*\b',
]

def clean_sku(sku):
    """Clean and normalize SKU"""
    sku = sku.strip().upper()
    sku = sku.replace(' ', '').replace('-', '')
    # Remove common suffixes that are not part of SKU
    sku = re.sub(r'(RTJ|RMJ|SPE|KIT)$', '', sku)
    return sku

def extract_all_skus_from_text(text):
    """Extract all possible SKUs from text using multiple patterns"""
    if not text:
        return []
    
    found_skus = set()
    
    for pattern in SKU_PATTERNS:
        matches = re.findall(pattern, text)
        for match in matches:
            cleaned = clean_sku(match)
            if len(cleaned) >= 5:  # Minimum length
                found_skus.add(cleaned)
    
    return sorted(list(found_skus))

def is_valid_tool_sku(sku):
    """Check if SKU is for an actual tool (not battery, charger, accessory)"""
    sku_upper = sku.upper()
    
    # Exclude batteries
    if any(pattern in sku_upper for pattern in ['BL1', 'BL4', 'BL6', 'BBLL']):
        return False
    
    # Exclude chargers
    if any(pattern in sku_upper for pattern in ['DC1', 'DC2', 'DC3', 'DC4', 'DC6']):
        return False
    
    # Exclude adapters
    if 'ADP' in sku_upper or 'BEAPDC' in sku_upper:
        return False
    
    # Must start with letters (tool prefix)
    if not re.match(r'^[A-Z]{2,}', sku):
        return False
    
    # Exclude very short or numeric-only patterns
    if len(sku) < 5 or sku.isdigit():
        return False
    
    return True

def extract_page_info(page, page_num):
    """Extract comprehensive info from a page"""
    page_text = page.extract_text() or ""
    
    info = {
        'page_number': page_num + 1,
        'text': page_text,
        'skus': extract_all_skus_from_text(page_text),
        'tables': [],
        'images': [],
        'prices': []
    }
    
    # Extract tables
    try:
        tables = page.extract_tables()
        if tables:
            info['tables'] = tables
    except:
        pass
    
    # Extract prices
    price_patterns = [
        r'€\s*\d+[,\.]\d{2}',
        r'€\s*\d+',
        r'\d+[,\.]\d{2}\s*€',
    ]
    
    for pattern in price_patterns:
        prices = re.findall(pattern, page_text)
        info['prices'].extend(prices)
    
    # Extract images metadata
    try:
        images = page.images
        if images:
            for img in images:
                info['images'].append({
                    'x0': img.get('x0'),
                    'top': img.get('top'),
                    'x1': img.get('x1'),
                    'bottom': img.get('bottom'),
                    'width': img.get('width'),
                    'height': img.get('height'),
                })
    except:
        pass
    
    return info

def extract_images_from_page(page, page_num, pdf_name, output_dir):
    """Extract all images from a page"""
    extracted_images = []
    
    try:
        # Convert page to image
        page_image = page.to_image(resolution=300)
        page_pil = page_image.original
        
        # Get all images on page
        images = page.images
        
        if not images:
            # Save entire page if no discrete images
            filename = f"{pdf_name}_page{page_num+1:03d}.webp"
            output_path = output_dir / filename
            page_pil.save(output_path, 'WEBP', quality=90)
            extracted_images.append(str(output_path))
        else:
            # Extract each image
            for img_idx, img in enumerate(images):
                try:
                    # Get coordinates
                    x0 = img.get('x0', 0)
                    y0 = img.get('top', 0)
                    x1 = img.get('x1', page.width)
                    y1 = img.get('bottom', page.height)
                    
                    # Convert to image coordinates
                    ratio = 300 / 72
                    crop_box = (
                        int(x0 * ratio),
                        int(y0 * ratio),
                        int(x1 * ratio),
                        int(y1 * ratio)
                    )
                    
                    cropped = page_pil.crop(crop_box)
                    
                    # Skip tiny images
                    if cropped.width < 100 or cropped.height < 100:
                        continue
                    
                    filename = f"{pdf_name}_page{page_num+1:03d}_img{img_idx:02d}.webp"
                    output_path = output_dir / filename
                    cropped.save(output_path, 'WEBP', quality=90)
                    extracted_images.append(str(output_path))
                
                except Exception as e:
                    print(f"    Error extracting image {img_idx}: {e}")
                    continue
    
    except Exception as e:
        print(f"  Error processing page {page_num+1}: {e}")
    
    return extracted_images

def process_pdf_exhaustively(pdf_path):
    """Process a PDF exhaustively to extract all SKUs and info"""
    pdf_name = pdf_path.stem
    
    print(f"\n{'='*80}")
    print(f"PROCESSING: {pdf_name}")
    print(f"{'='*80}")
    
    # Create output directory for images
    image_output_dir = IMAGE_DIR / pdf_name
    image_output_dir.mkdir(parents=True, exist_ok=True)
    
    all_skus = {}
    page_data = []
    
    with pdfplumber.open(pdf_path) as pdf:
        total_pages = len(pdf.pages)
        print(f"Total pages: {total_pages}")
        
        for page_num, page in enumerate(pdf.pages):
            if (page_num + 1) % 10 == 0:
                print(f"  Processing page {page_num + 1}/{total_pages}...")
            
            # Extract page info
            page_info = extract_page_info(page, page_num)
            page_data.append(page_info)
            
            # Extract images
            images = extract_images_from_page(page, page_num, pdf_name, image_output_dir)
            page_info['extracted_images'] = images
            
            # Map SKUs to this page
            for sku in page_info['skus']:
                if not is_valid_tool_sku(sku):
                    continue
                
                if sku not in all_skus:
                    all_skus[sku] = {
                        'sku': sku,
                        'pdf_source': pdf_name,
                        'pages': [],
                        'images': [],
                        'tables': [],
                        'prices': [],
                        'properties': {}
                    }
                
                all_skus[sku]['pages'].append(page_num + 1)
                all_skus[sku]['images'].extend(images)
                all_skus[sku]['tables'].extend(page_info['tables'])
                all_skus[sku]['prices'].extend(page_info['prices'])
        
        print(f"  ✅ Completed processing {total_pages} pages")
        print(f"  Found {len(all_skus)} unique tool SKUs")
        print(f"  Extracted images saved to: {image_output_dir}")
    
    return {
        'pdf_name': pdf_name,
        'total_pages': total_pages,
        'skus': all_skus,
        'page_data': page_data
    }

def extract_properties_from_tables(sku_data):
    """Extract properties from tables for a SKU"""
    properties = {}
    
    for table in sku_data.get('tables', []):
        if not table:
            continue
        
        # Try to find this SKU in table
        for row in table:
            if not row:
                continue
            
            row_text = ' '.join([str(cell) for cell in row if cell])
            
            if sku_data['sku'] in row_text.upper():
                # Found row with this SKU, extract properties
                for i, cell in enumerate(row):
                    if cell and str(cell).strip():
                        properties[f'col_{i}'] = str(cell).strip()
    
    return properties

def main():
    print("="*80)
    print("EXHAUSTIVE MAKITA SKU EXTRACTION")
    print("="*80)
    
    # Find all Makita PDFs
    makita_pdfs = list(INPUT_PDFS.glob("makita*.pdf"))
    
    if not makita_pdfs:
        print("\n❌ No Makita PDFs found in input_pdfs/")
        return
    
    print(f"\nFound {len(makita_pdfs)} Makita PDF(s)")
    for pdf in makita_pdfs:
        print(f"  - {pdf.name}")
    
    # Process each PDF
    all_results = []
    
    for pdf_path in makita_pdfs:
        result = process_pdf_exhaustively(pdf_path)
        all_results.append(result)
        
        # Extract properties for each SKU
        for sku, sku_data in result['skus'].items():
            props = extract_properties_from_tables(sku_data)
            sku_data['properties'].update(props)
    
    # Combine all SKUs
    combined_skus = {}
    total_images = 0
    
    for result in all_results:
        for sku, data in result['skus'].items():
            if sku not in combined_skus:
                combined_skus[sku] = data
            else:
                # Merge data
                combined_skus[sku]['pages'].extend(data['pages'])
                combined_skus[sku]['images'].extend(data['images'])
                combined_skus[sku]['tables'].extend(data['tables'])
                combined_skus[sku]['prices'].extend(data['prices'])
        
        total_images += sum(len(data['images']) for data in result['skus'].values())
    
    # Save comprehensive results
    output_file = OUTPUT_DIR / "exhaustive_makita_extraction.json"
    
    output_data = {
        'extraction_date': str(Path(__file__).stat().st_mtime),
        'pdfs_processed': [r['pdf_name'] for r in all_results],
        'total_pages': sum(r['total_pages'] for r in all_results),
        'total_skus': len(combined_skus),
        'total_images': total_images,
        'skus': combined_skus,
        'detailed_results': all_results
    }
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, indent=2, ensure_ascii=False)
    
    # Generate summary report
    print("\n" + "="*80)
    print("EXTRACTION COMPLETE")
    print("="*80)
    
    print(f"\n📊 SUMMARY:")
    print(f"  PDFs processed: {len(all_results)}")
    print(f"  Total pages scanned: {sum(r['total_pages'] for r in all_results)}")
    print(f"  Unique tool SKUs found: {len(combined_skus)}")
    print(f"  Total images extracted: {total_images}")
    
    # SKU categories
    print(f"\n📦 SKU BREAKDOWN:")
    sku_prefixes = defaultdict(int)
    for sku in combined_skus.keys():
        prefix = re.match(r'^[A-Z]+', sku)
        if prefix:
            sku_prefixes[prefix.group(0)] += 1
    
    for prefix, count in sorted(sku_prefixes.items(), key=lambda x: x[1], reverse=True)[:10]:
        print(f"  {prefix}: {count} SKUs")
    
    # Image statistics
    skus_with_images = sum(1 for data in combined_skus.values() if data['images'])
    skus_without_images = len(combined_skus) - skus_with_images
    
    print(f"\n📸 IMAGE COVERAGE:")
    print(f"  SKUs with images: {skus_with_images}")
    print(f"  SKUs without images: {skus_without_images}")
    print(f"  Coverage: {(skus_with_images/len(combined_skus)*100):.1f}%")
    
    # Price coverage
    skus_with_prices = sum(1 for data in combined_skus.values() if data['prices'])
    
    print(f"\n💰 PRICE COVERAGE:")
    print(f"  SKUs with prices: {skus_with_prices}")
    print(f"  SKUs without prices: {len(combined_skus) - skus_with_prices}")
    print(f"  Coverage: {(skus_with_prices/len(combined_skus)*100):.1f}%")
    
    print(f"\n💾 OUTPUT:")
    print(f"  JSON: {output_file}")
    print(f"  Images: {IMAGE_DIR}")
    
    # Sample SKUs
    print(f"\n📋 SAMPLE SKUs (first 20):")
    for i, (sku, data) in enumerate(list(combined_skus.items())[:20]):
        img_count = len(data['images'])
        page_count = len(set(data['pages']))
        price_count = len(data['prices'])
        print(f"  {sku}: {page_count} pages, {img_count} images, {price_count} prices")
    
    if len(combined_skus) > 20:
        print(f"  ... and {len(combined_skus) - 20} more")
    
    print(f"\n✅ Exhaustive extraction complete!")

if __name__ == '__main__':
    main()
