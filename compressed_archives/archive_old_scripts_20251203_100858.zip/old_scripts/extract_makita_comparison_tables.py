"""
MAKITA COMPARISON TABLE EXTRACTOR
==================================
Extracts product comparison tables and converts them to structured JSON
with icons and clean formatting for frontend display.

Example output:
{
  "sku": "DF002GD201",
  "specifications": {
    "voltage": "36 V (40Vmax)",
    "torque": "30 / 64 Nm",
    "chuck_size": "1,5 - 13 mm",
    "hammer_drill": false,
    "batteries": "2 x BL4025",
    "charger": "DC40RA",
    "weight": "2.5 kg",
    "price_excl": 485.00,
    "price_incl": 586.85
  },
  "display": {
    "voltage": "⚡ 36 V (40Vmax)",
    "torque": "🔧 30 / 64 Nm (Torque)",
    "chuck_size": "🎯 1,5 - 13 mm",
    "hammer_drill": "🔨 No",
    "batteries": "🔋 2 x BL4025",
    "charger": "🔌 DC40RA",
    "weight": "⚖️ 2.5 kg",
    "price": "💶 € 485.00 (ex)"
  }
}
"""

import pdfplumber
import json
import re
from pathlib import Path
from collections import defaultdict

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "makita-catalogus-2022-nl.pdf"
OUTPUT_JSON = PROJECT_ROOT / "output" / "makita_products_structured.json"

# Property name mapping (Dutch -> English + Icon)
PROPERTY_MAPPING = {
    # Voltage
    'spanning': {'key': 'voltage', 'icon': '⚡', 'type': 'text'},
    'voltage': {'key': 'voltage', 'icon': '⚡', 'type': 'text'},
    
    # Torque
    'max. koppel zacht / hard': {'key': 'torque', 'icon': '🔧', 'label': 'Torque', 'type': 'text'},
    'max. koppel': {'key': 'torque', 'icon': '🔧', 'label': 'Torque', 'type': 'text'},
    'koppel': {'key': 'torque', 'icon': '🔧', 'label': 'Torque', 'type': 'text'},
    
    # Chuck/Drill size
    'boorkop': {'key': 'chuck_size', 'icon': '🎯', 'type': 'text'},
    'boor capaciteit': {'key': 'drill_capacity', 'icon': '🎯', 'type': 'text'},
    
    # Hammer drill
    'klopboorfunctie': {'key': 'hammer_drill', 'icon': '🔨', 'type': 'boolean'},
    
    # Batteries
    'bijgeleverde accu\'s': {'key': 'batteries', 'icon': '🔋', 'type': 'text'},
    'accu': {'key': 'batteries', 'icon': '🔋', 'type': 'text'},
    
    # Charger
    'lader': {'key': 'charger', 'icon': '🔌', 'type': 'text'},
    
    # Weight
    'gewicht': {'key': 'weight', 'icon': '⚖️', 'type': 'text'},
    
    # Power
    'vermogen': {'key': 'power', 'icon': '⚡', 'type': 'text'},
    'max. vermogen': {'key': 'max_power', 'icon': '⚡', 'type': 'text'},
    
    # Speed
    'toerental': {'key': 'speed', 'icon': '🔄', 'label': 'RPM', 'type': 'text'},
    'toeren': {'key': 'speed', 'icon': '🔄', 'label': 'RPM', 'type': 'text'},
    'max. toerental': {'key': 'max_speed', 'icon': '🔄', 'label': 'RPM', 'type': 'text'},
    
    # Capacity
    'zaagcapaciteit': {'key': 'saw_capacity', 'icon': '📏', 'type': 'text'},
    'slagcapaciteit': {'key': 'stroke_capacity', 'icon': '📏', 'type': 'text'},
    'zaagblad': {'key': 'blade_size', 'icon': '⚙️', 'type': 'text'},
    
    # Dimensions
    'schijf': {'key': 'disc_size', 'icon': '◯', 'type': 'text'},
    'diameter': {'key': 'diameter', 'icon': '◯', 'type': 'text'},
    
    # Tank/Capacity
    'tank inhoud': {'key': 'tank_capacity', 'icon': '🗜️', 'type': 'text'},
    'inhoud': {'key': 'capacity', 'icon': '🗜️', 'type': 'text'},
    
    # Pressure
    'max. druk': {'key': 'max_pressure', 'icon': '💨', 'type': 'text'},
    'druk': {'key': 'pressure', 'icon': '💨', 'type': 'text'},
    
    # Price
    'prijs in € excl. btw': {'key': 'price_excl', 'icon': '💶', 'label': '(ex)', 'type': 'price'},
    'incl. btw': {'key': 'price_incl', 'icon': '💶', 'label': '(incl)', 'type': 'price'},
}

# SKU patterns (actual tools only, exclude batteries/chargers)
TOOL_SKU_PATTERNS = [
    r'\b[A-Z]{2,4}\d{3,4}[A-Z]{1,4}\d{0,3}\b',
    r'\b[A-Z]{2}\d{3}[A-Z]{2}\d{3}\b',
]

EXCLUDE_SKU_PATTERNS = [
    r'^BL\d+', r'^DC\d+', r'^ADP\d+', r'^DEAADP', r'^AD\d+',
    r'^PDC\d+', r'^BPS\d+', r'^BEAPDC', r'^PV\d+', r'^DK\d+',
    r'^RC\d+', r'^PL\d+', r'^ER\d+', r'^AA\d+', r'^N\d+-\d+$',
    r'^\d+-\d+$', r'^\d{5,6}$', r'^[A-Z]\d{1,2}$', r'^IPX\d+$',
]

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def is_tool_sku(sku):
    """Check if SKU is an actual tool (not battery/charger/accessory)"""
    if not sku or len(sku) < 4:
        return False
    
    sku_upper = sku.upper().strip()
    
    # Check exclusions
    for pattern in EXCLUDE_SKU_PATTERNS:
        if re.match(pattern, sku_upper):
            return False
    
    # Check tool patterns
    for pattern in TOOL_SKU_PATTERNS:
        if re.match(pattern, sku_upper):
            return True
    
    return False

def extract_skus_from_text(text):
    """Extract tool SKUs from text"""
    skus = set()
    for pattern in TOOL_SKU_PATTERNS:
        matches = re.findall(pattern, text.upper())
        skus.update(matches)
    
    # Filter to only tools
    tool_skus = [sku for sku in skus if is_tool_sku(sku)]
    return tool_skus

def normalize_property_name(name):
    """Normalize property name for matching"""
    if not name:
        return ''
    return name.lower().strip().replace('\n', ' ')

def parse_boolean_value(value):
    """Parse boolean values"""
    if not value:
        return False
    
    value_str = str(value).strip().lower()
    
    # Positive indicators
    if value_str in ['ja', 'yes', '✓', 'x', '●', '•']:
        return True
    
    # Negative indicators
    if value_str in ['nee', 'no', '-', '']:
        return False
    
    return bool(value_str)

def parse_price(value):
    """Parse price from text"""
    if not value:
        return None
    
    value_str = str(value).replace('€', '').replace('.', '').replace(',', '.').strip()
    match = re.search(r'(\d+\.?\d*)', value_str)
    if match:
        try:
            return float(match.group(1))
        except:
            return None
    return None

def clean_value(value, value_type='text'):
    """Clean and format value based on type"""
    if not value or str(value).strip() in ['', '-', 'None', 'N/A', 'n.v.t.']:
        return None
    
    value_str = str(value).strip()
    
    if value_type == 'boolean':
        return parse_boolean_value(value_str)
    elif value_type == 'price':
        return parse_price(value_str)
    else:
        return value_str

def map_property(property_name, value):
    """Map Dutch property name to English key with icon"""
    normalized_name = normalize_property_name(property_name)
    
    # Find matching property
    for dutch_name, config in PROPERTY_MAPPING.items():
        if dutch_name in normalized_name:
            key = config['key']
            icon = config['icon']
            value_type = config.get('type', 'text')
            label = config.get('label', '')
            
            # Clean value based on type
            cleaned_value = clean_value(value, value_type)
            
            if cleaned_value is None:
                continue
            
            # Format display value
            if value_type == 'boolean':
                display_value = f"{icon} {'Yes' if cleaned_value else 'No'}"
            elif value_type == 'price':
                display_value = f"{icon} € {cleaned_value:.2f} {label}".strip()
            else:
                display_value = f"{icon} {cleaned_value}"
                if label:
                    display_value += f" ({label})"
            
            return {
                'key': key,
                'value': cleaned_value,
                'display': display_value.strip()
            }
    
    return None

# ============================================================================
# TABLE EXTRACTION
# ============================================================================

def extract_products_from_table(table, page_num):
    """
    Extract products from comparison table where:
    - First row contains SKUs (product models)
    - First column contains property names
    - Cells contain property values for each product
    """
    if not table or len(table) < 2:
        return []
    
    products = []
    
    # Extract SKUs from first row (skip first cell which is the header)
    header_row = table[0]
    skus = []
    
    for cell in header_row[1:]:  # Skip first column (property name column)
        if cell:
            # Try to extract SKU from cell
            cell_skus = extract_skus_from_text(str(cell))
            if cell_skus:
                skus.append(cell_skus[0])
            else:
                skus.append(None)
        else:
            skus.append(None)
    
    # Filter to valid tool SKUs
    valid_columns = [(i, sku) for i, sku in enumerate(skus) if sku and is_tool_sku(sku)]
    
    if not valid_columns:
        return []
    
    # Initialize products
    for col_idx, sku in valid_columns:
        products.append({
            'sku': sku,
            'page': page_num,
            'specifications': {},
            'display': {}
        })
    
    # Extract properties from each row
    for row in table[1:]:
        if not row or len(row) < 2:
            continue
        
        property_name = row[0]
        if not property_name:
            continue
        
        # Process each product column
        for product_idx, (col_idx, sku) in enumerate(valid_columns):
            value_cell_idx = col_idx + 1  # +1 because we skipped first column
            
            if value_cell_idx < len(row):
                value = row[value_cell_idx]
                
                # Map property
                mapped = map_property(property_name, value)
                
                if mapped:
                    products[product_idx]['specifications'][mapped['key']] = mapped['value']
                    products[product_idx]['display'][mapped['key']] = mapped['display']
    
    # Filter out products with no specifications
    products = [p for p in products if p['specifications']]
    
    return products

def extract_makita_products():
    """Extract all Makita products from comparison tables"""
    
    print("="*80)
    print("MAKITA COMPARISON TABLE EXTRACTOR")
    print("="*80)
    
    if not PDF_PATH.exists():
        print(f"❌ PDF not found: {PDF_PATH}")
        return
    
    all_products = []
    stats = {
        'pages_processed': 0,
        'tables_found': 0,
        'products_extracted': 0
    }
    
    print(f"\n📄 Processing: {PDF_PATH.name}\n")
    
    with pdfplumber.open(PDF_PATH) as pdf:
        for page_num, page in enumerate(pdf.pages, 1):
            stats['pages_processed'] += 1
            
            # Extract tables
            tables = page.extract_tables()
            
            if not tables:
                continue
            
            stats['tables_found'] += len(tables)
            
            # Process each table
            for table_idx, table in enumerate(tables):
                products = extract_products_from_table(table, page_num)
                
                if products:
                    print(f"  ✅ Page {page_num}, Table {table_idx+1}: Found {len(products)} products")
                    for product in products:
                        print(f"     - {product['sku']}: {len(product['specifications'])} specs")
                    
                    all_products.extend(products)
                    stats['products_extracted'] += len(products)
            
            # Progress update
            if page_num % 20 == 0:
                print(f"\n  📊 Progress: Processed {page_num} pages, found {stats['products_extracted']} products\n")
    
    # Create SKU-indexed structure
    products_by_sku = {}
    for product in all_products:
        sku = product['sku']
        if sku not in products_by_sku:
            products_by_sku[sku] = product
        else:
            # Merge specifications if duplicate
            products_by_sku[sku]['specifications'].update(product['specifications'])
            products_by_sku[sku]['display'].update(product['display'])
    
    # Create output structure
    output = {
        'metadata': {
            'source': 'makita-catalogus-2022-nl',
            'total_products': len(products_by_sku),
            'pages_processed': stats['pages_processed'],
            'tables_processed': stats['tables_found']
        },
        'products': list(products_by_sku.values())
    }
    
    # Save JSON
    OUTPUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    # Summary
    print(f"\n{'='*80}")
    print("✅ EXTRACTION COMPLETE")
    print(f"{'='*80}")
    print(f"\n📊 Statistics:")
    print(f"   Pages processed:   {stats['pages_processed']}")
    print(f"   Tables found:      {stats['tables_found']}")
    print(f"   Products extracted: {len(products_by_sku)}")
    print(f"\n💾 Output saved to: {OUTPUT_JSON}")
    
    # Show sample products
    print(f"\n📦 Sample Products:")
    for i, product in enumerate(list(products_by_sku.values())[:3], 1):
        print(f"\n{i}. {product['sku']}:")
        for key, value in product['display'].items():
            print(f"   {value}")
    
    print(f"\n{'='*80}\n")
    
    return output

if __name__ == "__main__":
    extract_makita_products()
