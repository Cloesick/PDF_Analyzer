"""
Analyze Makita Image Matching Issues
=====================================
Investigate unmatched products and extra SKUs
"""
import json
from pathlib import Path
from collections import defaultdict
from difflib import SequenceMatcher

PROJECT_ROOT = Path(__file__).parent
PRODUCTS_JSON = PROJECT_ROOT / "output" / "products_ready_for_webshop.json"
EXTRACTED_JSON = PROJECT_ROOT / "output" / "makita_extracted_products.json"

def similar(a, b):
    """Calculate similarity ratio between two strings"""
    return SequenceMatcher(None, a, b).ratio()

def main():
    print("=" * 80)
    print("MAKITA IMAGE MATCHING ANALYSIS")
    print("=" * 80)
    
    # Load data
    print("\n📦 Loading data...")
    with open(PRODUCTS_JSON, 'r', encoding='utf-8') as f:
        all_products = json.load(f)
    
    with open(EXTRACTED_JSON, 'r', encoding='utf-8') as f:
        extracted_images = json.load(f)
    
    makita_products = [p for p in all_products if 'makita-catalogus-2022-nl' in p.get('pdf_source', '')]
    print(f"   {len(makita_products)} Makita products")
    print(f"   {len(extracted_images)} extracted image entries")
    
    # Build mappings
    sku_to_images = defaultdict(list)
    for entry in extracted_images:
        sku_to_images[entry['sku']].append(entry)
    
    product_skus = {p['sku']: p for p in makita_products}
    image_skus = set(sku_to_images.keys())
    
    # 1. INVESTIGATE PAGE 2 PRODUCTS
    print("\n" + "=" * 80)
    print("1. PAGE 2 PRODUCTS INVESTIGATION")
    print("=" * 80)
    
    page2_products = [p for p in makita_products if 2 in p.get('source', {}).get('pages', [])]
    print(f"\n📄 Found {len(page2_products)} products on page 2")
    
    # Check where these SKUs appear elsewhere
    print("\n🔍 Checking if page 2 SKUs appear on other pages...")
    page2_multipage = []
    for prod in page2_products[:20]:
        pages = prod.get('source', {}).get('pages', [])
        if len(pages) > 1:
            page2_multipage.append(prod)
            print(f"   ✓ {prod['sku']:15s} | Pages: {pages}")
    
    print(f"\n📊 {len(page2_multipage)} out of {len(page2_products)} page-2 products appear on multiple pages")
    
    # Check if any page 2 SKUs have images on other pages
    page2_with_images = []
    for prod in page2_products[:20]:
        sku = prod['sku']
        if sku in image_skus:
            img_pages = set(img['page_num'] for img in sku_to_images[sku])
            page2_with_images.append((sku, img_pages))
            print(f"   🖼️  {sku:15s} | Has images on pages: {sorted(img_pages)}")
    
    print(f"\n✅ {len(page2_with_images)} page-2 products have images on other pages")
    
    # 2. ANALYZE 66 EXTRA SKUs
    print("\n" + "=" * 80)
    print("2. EXTRA SKU ANALYSIS")
    print("=" * 80)
    
    extra_skus = image_skus - set(product_skus.keys())
    print(f"\n📊 Analyzing {len(extra_skus)} SKUs found in images but not in products...")
    
    # Categorize extra SKUs
    battery_codes = []
    part_numbers = []
    potential_products = []
    
    for sku in sorted(extra_skus):
        images = sku_to_images[sku]
        sample_img = images[0]
        
        # Check if it's a battery code (all digits, 5-6 chars)
        if sku.isdigit() and len(sku) in [5, 6]:
            # Common battery capacities
            if sku in ['10000', '11000', '12000', '14000', '15000', '16000', '17000', '18000', '20000', '22000']:
                battery_codes.append((sku, len(images), sample_img['skus_in_image']))
            else:
                part_numbers.append((sku, len(images), sample_img['skus_in_image']))
        else:
            # Might be a real product
            potential_products.append((sku, len(images), sample_img['skus_in_image']))
    
    print(f"\n🔋 Battery/Capacity Codes: {len(battery_codes)}")
    for sku, count, related in battery_codes[:10]:
        print(f"   {sku:15s} | {count} images | Related: {related[:3]}")
    
    print(f"\n🔢 Part Numbers: {len(part_numbers)}")
    for sku, count, related in part_numbers[:10]:
        print(f"   {sku:15s} | {count} images | Related: {related[:3]}")
    
    print(f"\n📦 Potential Products: {len(potential_products)}")
    for sku, count, related in potential_products[:15]:
        print(f"   {sku:15s} | {count} images | Related: {related[:3]}")
    
    # 3. FUZZY MATCHING OPPORTUNITIES
    print("\n" + "=" * 80)
    print("3. FUZZY MATCHING ANALYSIS")
    print("=" * 80)
    
    print("\n🔍 Looking for similar SKUs between products and images...")
    
    unmatched_product_skus = set(product_skus.keys()) - image_skus
    fuzzy_matches = []
    
    for prod_sku in list(unmatched_product_skus)[:100]:  # Sample
        best_match = None
        best_ratio = 0
        
        for img_sku in extra_skus:
            ratio = similar(prod_sku, img_sku)
            if ratio > best_ratio and ratio >= 0.8:  # 80% similarity
                best_ratio = ratio
                best_match = img_sku
        
        if best_match:
            fuzzy_matches.append((prod_sku, best_match, best_ratio))
    
    print(f"\n✨ Found {len(fuzzy_matches)} potential fuzzy matches (80%+ similarity):")
    for prod_sku, img_sku, ratio in fuzzy_matches[:20]:
        print(f"   {prod_sku:15s} ≈ {img_sku:15s} | {ratio*100:.1f}% similar")
    
    # 4. QUALITY THRESHOLD ANALYSIS
    print("\n" + "=" * 80)
    print("4. IMAGE QUALITY THRESHOLD ANALYSIS")
    print("=" * 80)
    
    print("\n📊 Current extracted images quality distribution:")
    
    variances = [img['color_variance'] for img in extracted_images]
    edge_densities = [img['edge_density'] for img in extracted_images]
    
    print(f"\n🎨 Color Variance:")
    print(f"   Min:    {min(variances):.1f}")
    print(f"   Max:    {max(variances):.1f}")
    print(f"   Avg:    {sum(variances)/len(variances):.1f}")
    print(f"   Current threshold: 15.0")
    
    print(f"\n📐 Edge Density:")
    print(f"   Min:    {min(edge_densities):.4f}")
    print(f"   Max:    {max(edge_densities):.4f}")
    print(f"   Avg:    {sum(edge_densities)/len(edge_densities):.4f}")
    print(f"   Current threshold: 0.02")
    
    # Count how many would be added with lower thresholds
    lower_variance = sum(1 for v in variances if 10 <= v < 15)
    lower_edge = sum(1 for e in edge_densities if 0.015 <= e < 0.02)
    
    print(f"\n💡 Potential additional images with lower thresholds:")
    print(f"   Color variance 10-15: Would add ~{lower_variance * 15} images (estimated)")
    print(f"   Edge density 0.015-0.02: Would add ~{lower_edge * 12} images (estimated)")
    
    # RECOMMENDATIONS
    print("\n" + "=" * 80)
    print("RECOMMENDATIONS")
    print("=" * 80)
    
    print(f"\n1️⃣  PAGE 2 ISSUE:")
    print(f"   ✓ Page 2 is an index/overview page without actual photos")
    print(f"   ✓ Many products appear on other pages with images")
    print(f"   → These are already being matched correctly!")
    
    print(f"\n2️⃣  EXTRA SKUs:")
    print(f"   🔋 {len(battery_codes)} are battery capacity codes (safe to ignore)")
    print(f"   🔢 {len(part_numbers)} are part numbers (accessories, not main products)")
    print(f"   📦 {len(potential_products)} might be valid products to add")
    
    print(f"\n3️⃣  FUZZY MATCHING:")
    print(f"   ✨ {len(fuzzy_matches)} SKUs could match with fuzzy logic")
    print(f"   → Implement fuzzy matching for better coverage")
    
    print(f"\n4️⃣  QUALITY THRESHOLDS:")
    print(f"   Current: Very strict (only high-quality photos)")
    print(f"   → Could lower slightly to get more images")
    print(f"   ⚠️  Risk: May include some non-product images")
    
    # Save analysis
    analysis = {
        'page2_products': len(page2_products),
        'page2_multipage': len(page2_multipage),
        'battery_codes': len(battery_codes),
        'part_numbers': len(part_numbers),
        'potential_products': potential_products,
        'fuzzy_matches': fuzzy_matches,
        'quality_stats': {
            'variance_min': min(variances),
            'variance_max': max(variances),
            'variance_avg': sum(variances)/len(variances),
            'edge_min': min(edge_densities),
            'edge_max': max(edge_densities),
            'edge_avg': sum(edge_densities)/len(edge_densities)
        }
    }
    
    output_path = PROJECT_ROOT / "output" / "makita_matching_analysis.json"
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(analysis, f, indent=2)
    
    print(f"\n💾 Full analysis saved to: {output_path}")

if __name__ == '__main__':
    main()
