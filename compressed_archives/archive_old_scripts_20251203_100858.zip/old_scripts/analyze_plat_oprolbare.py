"""
PLAT-OPROLBARE-SLANGEN PDF ANALYZER
====================================

Comprehensive analysis script for plat-oprolbare-slangen.pdf that:
- Extracts all text content organized by page
- Identifies and categorizes products (hoses/slangen)
- Tracks which products share the same images
- Creates a structured data output with product relationships

Author: PDF Analyzer System
"""

import pdfplumber
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, asdict, field
import hashlib

# ============================================================================
# CONFIGURATION
# ============================================================================

PROJECT_ROOT = Path(__file__).parent
INPUT_PDF = PROJECT_ROOT / "input_pdfs" / "plat-oprolbare-slangen.pdf"
OUTPUT_DIR = PROJECT_ROOT / "output"
OUTPUT_JSON = OUTPUT_DIR / "plat_oprolbare_analysis.json"

# Product detection patterns for hoses
PRODUCT_PATTERNS = [
    re.compile(r'\b([A-Z]{2,}\d+[-A-Z0-9]*)\b'),  # Product codes
    re.compile(r'\b(\d+x\d+(?:x\d+)?)\b', re.IGNORECASE),  # Dimensions
    re.compile(r'\b(\d+mm)\b', re.IGNORECASE),  # Measurements
    re.compile(r'Ø\s*(\d+)', re.IGNORECASE),  # Diameter
    re.compile(r'\b(DN\s*\d+)\b', re.IGNORECASE),  # DN sizes
]

# Category keywords for hoses
CATEGORY_KEYWORDS = {
    'platte_slangen': ['plat', 'platte', 'flat', 'lay-flat', 'layflat'],
    'oprolbare_slangen': ['oprolbaar', 'oprol', 'reelable', 'reel'],
    'tuinslangen': ['tuin', 'garden', 'tuinslang'],
    'zuigslangen': ['zuig', 'suction', 'zuigslang'],
    'drukslangen': ['druk', 'pressure', 'drukslang'],
    'spiraalslangen': ['spiraal', 'spiral', 'coil'],
    'koppelingen': ['koppeling', 'coupling', 'connector', 'fitting'],
    'accessoires': ['accessoire', 'accessory', 'toebehoren', 'hulpstuk'],
}

# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class ProductItem:
    """Represents a single product found in the PDF"""
    product_id: str
    page_number: int
    category: str
    description: str
    specifications: Dict[str, str]
    text_snippet: str
    image_hash: Optional[str] = None
    shared_image_with: List[str] = field(default_factory=list)
    coordinates: Optional[Dict] = None
    
@dataclass
class ImageInfo:
    """Information about an image in the PDF"""
    image_hash: str
    page_number: int
    image_index: int
    bbox: Dict
    width: int
    height: int
    products_using_image: List[str] = field(default_factory=list)
    
@dataclass
class PageAnalysis:
    """Analysis results for a single page"""
    page_number: int
    text_content: str
    products_found: List[ProductItem]
    images_found: List[ImageInfo]
    detected_category: str
    word_count: int
    
@dataclass
class PDFAnalysisResults:
    """Complete analysis results for the PDF"""
    pdf_name: str
    total_pages: int
    total_products: int
    total_images: int
    categories: Dict[str, int]
    pages: List[PageAnalysis]
    product_image_mapping: Dict[str, List[str]]
    shared_images: List[Dict]
    
# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def compute_image_hash(image_bytes: bytes) -> str:
    """Compute a hash for an image to detect duplicates"""
    return hashlib.md5(image_bytes).hexdigest()

def extract_specifications(text: str) -> Dict[str, str]:
    """Extract technical specifications from text with proper units"""
    specs = {}
    
    # Diameter with unit preservation
    diam_match = re.search(r'Ø\s*(\d+(?:[.,]\d+)?)\s*(mm|m|cm)?', text, re.IGNORECASE)
    if diam_match:
        value = diam_match.group(1).replace(',', '.')
        unit = diam_match.group(2).lower() if diam_match.group(2) else 'mm'
        specs['diameter'] = f"{value} {unit}"
        specs['diameter_mm'] = value if unit == 'mm' else str(float(value) * (1000 if unit == 'm' else 10))
    
    # Inner diameter
    inner_diam = re.search(r'(?:binnen|inner|ID)(?:\s*diameter|Ø)?\s*:?\s*(\d+(?:[.,]\d+)?)\s*(mm|m|cm)?', text, re.IGNORECASE)
    if inner_diam:
        value = inner_diam.group(1).replace(',', '.')
        unit = inner_diam.group(2).lower() if inner_diam.group(2) else 'mm'
        specs['inner_diameter'] = f"{value} {unit}"
    
    # Outer diameter  
    outer_diam = re.search(r'(?:buiten|outer|OD)(?:\s*diameter|Ø)?\s*:?\s*(\d+(?:[.,]\d+)?)\s*(mm|m|cm)?', text, re.IGNORECASE)
    if outer_diam:
        value = outer_diam.group(1).replace(',', '.')
        unit = outer_diam.group(2).lower() if outer_diam.group(2) else 'mm'
        specs['outer_diameter'] = f"{value} {unit}"
    
    # Dimensions (e.g., 32x3) with units
    dim_match = re.search(r'(\d+(?:[.,]\d+)?)\s*x\s*(\d+(?:[.,]\d+)?)(?:\s*x\s*(\d+(?:[.,]\d+)?))?\s*(mm|m|cm)?', text, re.IGNORECASE)
    if dim_match:
        values = [v.replace(',', '.') for v in dim_match.groups()[:3] if v]
        unit = dim_match.group(4).lower() if dim_match.group(4) else 'mm'
        specs['dimension'] = 'x'.join(values) + f' {unit}'
    
    # Pressure rating with units
    press_match = re.search(r'(\d+(?:[.,]\d+)?)\s*bar', text, re.IGNORECASE)
    if press_match:
        specs['pressure'] = f"{press_match.group(1).replace(',', '.')} bar"
        specs['pressure_bar'] = press_match.group(1).replace(',', '.')
    
    # Working pressure
    work_press = re.search(r'(?:werk|working)(?:\s*druk|pressure)?\s*:?\s*(\d+(?:[.,]\d+)?)\s*bar', text, re.IGNORECASE)
    if work_press:
        specs['working_pressure'] = f"{work_press.group(1).replace(',', '.')} bar"
    
    # Burst pressure (CRITICAL)
    burst_press = re.search(r'(?:barst|burst)(?:\s*druk|pressure)?\s*:?\s*(\d+(?:[.,]\d+)?)\s*bar', text, re.IGNORECASE)
    if burst_press:
        specs['burst_pressure'] = f"{burst_press.group(1).replace(',', '.')} bar"
        specs['burst_pressure_bar'] = burst_press.group(1).replace(',', '.')
    
    # Weight per meter (CRITICAL)
    weight_match = re.search(r'(?:gewicht|weight)(?:\s*per\s*meter|/m)?\s*:?\s*(\d+(?:[.,]\d+)?)\s*(g|kg)?', text, re.IGNORECASE)
    if weight_match:
        value = weight_match.group(1).replace(',', '.')
        unit = weight_match.group(2).lower() if weight_match.group(2) else 'g'
        if unit == 'kg':
            specs['weight_per_meter'] = f"{value} kg/m"
            specs['weight_per_meter_kg'] = value
        else:
            specs['weight_per_meter'] = f"{value} g/m"
            specs['weight_per_meter_g'] = value
    
    # Material
    material_match = re.search(r'\b(PVC|TPU|PE|PP|rubber|polyester|nylon)\b', text, re.IGNORECASE)
    if material_match:
        specs['material'] = material_match.group(1).upper()
    
    # Length with units
    length_match = re.search(r'(?:lengte|length)?\s*:?\s*(\d+(?:[.,]\d+)?)\s*(m|meter|metres?|mm)', text, re.IGNORECASE)
    if length_match:
        value = length_match.group(1).replace(',', '.')
        unit = 'm' if 'meter' in length_match.group(2).lower() or length_match.group(2).lower() == 'm' else 'mm'
        specs['length'] = f"{value} {unit}"
        specs['length_m'] = value if unit == 'm' else str(float(value) / 1000)
    
    # Roll length
    roll_length = re.search(r'rol(?:lengte)?\s*:?\s*(\d+(?:[.,]\d+)?)\s*(m|mm)?', text, re.IGNORECASE)
    if roll_length:
        value = roll_length.group(1).replace(',', '.')
        unit = roll_length.group(2) if roll_length.group(2) else 'm'
        specs['roll_length'] = f"{value} {unit}"
    
    # Temperature range
    temp_match = re.search(r'(-?\d+)\s*°C?\s*(?:tot|to|-|\.\.\.)\s*\+?(\d+)\s*°C', text, re.IGNORECASE)
    if temp_match:
        specs['temperature_range'] = f"{temp_match.group(1)}°C to {temp_match.group(2)}°C"
    
    # DN size
    dn_match = re.search(r'\bDN\s*(\d+)', text, re.IGNORECASE)
    if dn_match:
        specs['dn_size'] = f"DN {dn_match.group(1)}"
    
    # Color
    color_match = re.search(r'\b(blauw|rood|groen|geel|zwart|wit|oranje|blue|red|green|yellow|black|white|orange)\b', text, re.IGNORECASE)
    if color_match:
        specs['color'] = color_match.group(1).lower()
    
    return specs

def extract_table_data(page) -> List[Dict]:
    """Extract table data with headers for better categorization"""
    table_products = []
    
    try:
        tables = page.extract_tables()
        if not tables:
            return table_products
        
        print(f"    → Found {len(tables)} tables on page")
        
        for table_idx, table in enumerate(tables):
            if not table or len(table) < 2:  # Need at least header + 1 row
                print(f"    → Table {table_idx}: Skipped (too small or empty)")
                continue
            
            print(f"    → Table {table_idx}: {len(table)} rows, {len(table[0]) if table else 0} columns")
            
            # First row is typically the header
            headers = [str(cell).strip() if cell else '' for cell in table[0]]
            
            # Process each data row
            for row_idx, row in enumerate(table[1:], start=1):
                if not row or all(not cell for cell in row):
                    continue
                
                row_data = {}
                for col_idx, (header, cell) in enumerate(zip(headers, row)):
                    if cell:
                        cell_value = str(cell).strip()
                        if header and cell_value:
                            # Clean header name
                            clean_header = header.lower().replace(' ', '_').replace('.', '')
                            row_data[clean_header] = cell_value
                
                # Extract specifications from the row data
                specs = {}
                description_parts = []
                
                # First, store ALL columns as raw data (critical for safety specs)
                for key, value in row_data.items():
                    # Store the original column with cleaned key
                    specs[f'table_{key}'] = value
                
                # Now parse specific critical specifications with units
                for key, value in row_data.items():
                    
                    # CRITICAL: Inner diameter
                    if any(term in key for term in ['binnen', 'inner', 'id']) and 'buiten' not in key:
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            specs['inner_diameter'] = f"{num_match.group(1).replace(',', '.')} mm"
                            specs['inner_diameter_mm'] = num_match.group(1).replace(',', '.')
                    
                    # CRITICAL: Outer diameter
                    if any(term in key for term in ['buiten', 'outer', 'od', 'diameter', 'ø']) and 'binnen' not in key:
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            specs['outer_diameter'] = f"{num_match.group(1).replace(',', '.')} mm"
                            specs['outer_diameter_mm'] = num_match.group(1).replace(',', '.')
                    
                    # CRITICAL: Burst pressure
                    if any(term in key for term in ['barst', 'burst']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            specs['burst_pressure'] = f"{num_match.group(1).replace(',', '.')} bar"
                            specs['burst_pressure_bar'] = num_match.group(1).replace(',', '.')
                    
                    # CRITICAL: Working pressure
                    elif any(term in key for term in ['werk', 'working']) and 'druk' in key:
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            specs['working_pressure'] = f"{num_match.group(1).replace(',', '.')} bar"
                            specs['working_pressure_bar'] = num_match.group(1).replace(',', '.')
                    
                    # General pressure
                    elif any(term in key for term in ['druk', 'pressure', 'bar']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            specs['pressure'] = f"{num_match.group(1).replace(',', '.')} bar"
                            specs['pressure_bar'] = num_match.group(1).replace(',', '.')
                    
                    # CRITICAL: Weight per meter
                    if any(term in key for term in ['gewicht', 'weight']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            if 'g/m' in key or 'gram' in key:
                                specs['weight_per_meter'] = f"{num_match.group(1).replace(',', '.')} g/m"
                                specs['weight_per_meter_g'] = num_match.group(1).replace(',', '.')
                            elif 'kg' in key:
                                specs['weight_per_meter'] = f"{num_match.group(1).replace(',', '.')} kg/m"
                                specs['weight_per_meter_kg'] = num_match.group(1).replace(',', '.')
                    
                    # CRITICAL: Wall thickness (wanddikte)
                    if any(term in key for term in ['wanddikte', 'wall_thickness']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            specs['wall_thickness'] = f"{num_match.group(1).replace(',', '.')} mm"
                            specs['wall_thickness_mm'] = num_match.group(1).replace(',', '.')
                    
                    # CRITICAL: Tensile strength (treksterkte)
                    if any(term in key for term in ['treksterkte', 'tensile', 'trek']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            if 'ton' in key or 't' in value.lower():
                                specs['tensile_strength'] = f"{num_match.group(1).replace(',', '.')} ton"
                                specs['tensile_strength_ton'] = num_match.group(1).replace(',', '.')
                            else:
                                specs['tensile_strength'] = f"{num_match.group(1).replace(',', '.')} N"
                    
                    # Length / Roll length
                    if any(term in key for term in ['lengte', 'length', 'rol']):
                        num_match = re.search(r'(\d+(?:[.,]\d+)?)', value)
                        if num_match:
                            specs['length'] = f"{num_match.group(1).replace(',', '.')} m"
                            specs['length_m'] = num_match.group(1).replace(',', '.')
                    
                    # Material
                    if any(term in key for term in ['material', 'type']):
                        specs['material'] = value.upper()
                        description_parts.append(value)
                    
                    # Order numbers
                    if any(term in key for term in ['bestelnr', 'order', 'artikel', 'code']):
                        specs['order_number'] = value
                        description_parts.append(f"Order: {value}")
                
                if specs or description_parts:
                    table_products.append({
                        'table_index': table_idx,
                        'row_index': row_idx,
                        'specifications': specs,
                        'description_parts': description_parts,
                        'raw_data': row_data
                    })
    
    except Exception as e:
        print(f"  Warning: Error extracting table data: {e}")
    
    return table_products

def detect_category(text: str) -> str:
    """Detect product category based on text content"""
    text_lower = text.lower()
    
    category_scores = defaultdict(int)
    for category, keywords in CATEGORY_KEYWORDS.items():
        for keyword in keywords:
            count = text_lower.count(keyword.lower())
            category_scores[category] += count
    
    if category_scores:
        return max(category_scores.items(), key=lambda x: x[1])[0]
    
    return 'slangen_algemeen'  # General hoses

def extract_product_codes(text: str) -> List[str]:
    """Extract potential product codes from text"""
    codes = set()
    
    for pattern in PRODUCT_PATTERNS:
        matches = pattern.findall(text)
        codes.update(matches)
    
    return sorted(list(codes))

def find_products_in_text(text: str, page_num: int, category: str) -> List[ProductItem]:
    """Identify individual products from text content"""
    products = []
    
    # Split text into potential product blocks
    blocks = re.split(r'\n\s*\n|\n{3,}', text)
    
    for block_idx, block in enumerate(blocks):
        if len(block.strip()) < 10:  # Skip very short blocks
            continue
        
        # Extract product codes from this block
        codes = extract_product_codes(block)
        
        if codes or any(keyword in block.lower() for keywords in CATEGORY_KEYWORDS.values() for keyword in keywords):
            # Create a product entry
            primary_code = codes[0] if codes else f"PROD_{block_idx}"
            specs = extract_specifications(block)
            
            # Extract a clean description
            lines = [line.strip() for line in block.split('\n') if line.strip()]
            description = ' '.join(lines[:2])  # Take first 2 lines
            
            product = ProductItem(
                product_id=f"P{page_num:03d}_{block_idx:03d}_{primary_code}",
                page_number=page_num,
                category=category,
                description=description[:200],  # Limit description length
                specifications=specs,
                text_snippet=block[:300],  # Keep snippet for context
            )
            
            products.append(product)
    
    return products

def extract_images_from_page(page, page_num: int) -> List[ImageInfo]:
    """Extract all images from a page with metadata"""
    images = []
    
    try:
        if hasattr(page, 'images'):
            for img_idx, img in enumerate(page.images):
                try:
                    # Extract image bbox
                    bbox = {
                        'x0': img.get('x0', 0),
                        'y0': img.get('y0', 0),
                        'x1': img.get('x1', 0),
                        'y1': img.get('y1', 0),
                    }
                    
                    image_info = ImageInfo(
                        image_hash=f"img_p{page_num}_i{img_idx}_{hash(str(bbox))}",
                        page_number=page_num,
                        image_index=img_idx,
                        bbox=bbox,
                        width=int(bbox['x1'] - bbox['x0']),
                        height=int(bbox['y1'] - bbox['y0']),
                    )
                    
                    images.append(image_info)
                    
                except Exception as e:
                    print(f"  Warning: Could not process image {img_idx} on page {page_num}: {e}")
                    continue
    except Exception as e:
        print(f"  Warning: Could not extract images from page {page_num}: {e}")
    
    return images

def link_products_to_images(products: List[ProductItem], images: List[ImageInfo]) -> None:
    """Link products to their associated images based on proximity"""
    if not images:
        return
    
    for product in products:
        # For simplicity, assign the first image on the page
        if images:
            closest_image = images[0]
            product.image_hash = closest_image.image_hash
            closest_image.products_using_image.append(product.product_id)

# ============================================================================
# MAIN ANALYSIS FUNCTION
# ============================================================================

def analyze_pdf() -> PDFAnalysisResults:
    """
    Main function to analyze the plat-oprolbare-slangen PDF
    Returns comprehensive analysis results
    """
    print(f"\n{'='*70}")
    print(f"ANALYZING PDF: {INPUT_PDF.name}")
    print(f"{'='*70}\n")
    
    if not INPUT_PDF.exists():
        raise FileNotFoundError(f"PDF not found: {INPUT_PDF}")
    
    pages_analysis = []
    all_products = []
    all_images = []
    category_counts = defaultdict(int)
    
    with pdfplumber.open(INPUT_PDF) as pdf:
        total_pages = len(pdf.pages)
        print(f"Total pages: {total_pages}\n")
        
        for page_num, page in enumerate(pdf.pages, start=1):
            print(f"Processing page {page_num}/{total_pages}...")
            
            # Extract text
            text = page.extract_text() or ""
            word_count = len(text.split())
            
            # Detect category for this page
            page_category = detect_category(text)
            category_counts[page_category] += 1
            
            # Extract table data first (more structured)
            table_data = extract_table_data(page)
            
            # Collect all products for this page
            page_products = []
            
            # Convert table data to products
            for table_item in table_data:
                specs = table_item['specifications']
                desc_parts = table_item['description_parts']
                
                # Create product ID
                order_num = specs.get('order_number', f"T{table_item['table_index']}R{table_item['row_index']}")
                product_id = f"P{page_num:03d}_TBL{table_item['table_index']}_{order_num}"
                
                # Build description
                if desc_parts:
                    description = ' - '.join(desc_parts)
                else:
                    description = f"Table product from page {page_num}"
                
                product = ProductItem(
                    product_id=product_id,
                    page_number=page_num,
                    category=page_category,
                    description=description[:200],
                    specifications=specs,
                    text_snippet=f"Table {table_item['table_index']}, Row {table_item['row_index']}",
                )
                page_products.append(product)
                all_products.append(product)
            
            # Find products in text (for non-table content)
            text_products = find_products_in_text(text, page_num, page_category)
            page_products.extend(text_products)
            all_products.extend(text_products)
            
            # Extract images
            images = extract_images_from_page(page, page_num)
            all_images.extend(images)
            
            # Link products to images (link both table and text products)
            link_products_to_images(page_products, images)
            
            # Create page analysis with ALL products from this page
            page_analysis = PageAnalysis(
                page_number=page_num,
                text_content=text[:500] + "..." if len(text) > 500 else text,
                products_found=page_products,  # Now includes BOTH table and text products
                images_found=images,
                detected_category=page_category,
                word_count=word_count,
            )
            pages_analysis.append(page_analysis)
            
            print(f"  > Found {len(page_products)} products ({len(table_data)} from tables), {len(images)} images")
            print(f"  ✓ Category: {page_category}")
            print(f"  ✓ Word count: {word_count}")
    
    # Analyze shared images
    image_to_products = defaultdict(list)
    for product in all_products:
        if product.image_hash:
            image_to_products[product.image_hash].append(product.product_id)
    
    shared_images = [
        {
            'image_hash': img_hash,
            'product_count': len(prod_ids),
            'products': prod_ids
        }
        for img_hash, prod_ids in image_to_products.items()
        if len(prod_ids) > 1
    ]
    
    # Update products with shared image information
    for shared_img in shared_images:
        img_hash = shared_img['image_hash']
        prod_ids = shared_img['products']
        
        for product in all_products:
            if product.image_hash == img_hash:
                product.shared_image_with = [pid for pid in prod_ids if pid != product.product_id]
    
    # Create final results
    results = PDFAnalysisResults(
        pdf_name=INPUT_PDF.name,
        total_pages=total_pages,
        total_products=len(all_products),
        total_images=len(all_images),
        categories=dict(category_counts),
        pages=pages_analysis,
        product_image_mapping=dict(image_to_products),
        shared_images=shared_images,
    )
    
    return results

def save_results(results: PDFAnalysisResults) -> None:
    """Save analysis results to JSON file"""
    OUTPUT_DIR.mkdir(exist_ok=True)
    
    # Convert dataclasses to dictionaries
    results_dict = {
        'pdf_name': results.pdf_name,
        'total_pages': results.total_pages,
        'total_products': results.total_products,
        'total_images': results.total_images,
        'categories': results.categories,
        'pages': [
            {
                'page_number': page.page_number,
                'text_content': page.text_content,
                'products_found': [asdict(p) for p in page.products_found],
                'images_found': [asdict(img) for img in page.images_found],
                'detected_category': page.detected_category,
                'word_count': page.word_count,
            }
            for page in results.pages
        ],
        'product_image_mapping': results.product_image_mapping,
        'shared_images': results.shared_images,
    }
    
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(results_dict, f, indent=2, ensure_ascii=False)
    
    print(f"\n{'='*70}")
    print(f"✓ Results saved to: {OUTPUT_JSON}")
    print(f"{'='*70}")

def print_summary(results: PDFAnalysisResults) -> None:
    """Print a human-readable summary of the analysis"""
    print(f"\n{'='*70}")
    print(f"ANALYSIS SUMMARY")
    print(f"{'='*70}\n")
    
    print(f"PDF Name: {results.pdf_name}")
    print(f"Total Pages: {results.total_pages}")
    print(f"Total Products Found: {results.total_products}")
    print(f"Total Images Found: {results.total_images}")
    
    print(f"\nCategories Distribution:")
    for category, count in sorted(results.categories.items(), key=lambda x: x[1], reverse=True):
        print(f"  • {category}: {count} pages")
    
    print(f"\nShared Images:")
    print(f"  • {len(results.shared_images)} images are shared between multiple products")
    
    if results.shared_images:
        print(f"\nTop Shared Images:")
        for idx, shared in enumerate(sorted(results.shared_images, key=lambda x: x['product_count'], reverse=True)[:5], 1):
            print(f"  {idx}. Image {shared['image_hash'][:16]}... used by {shared['product_count']} products")
            print(f"     Products: {', '.join(shared['products'][:3])}")
            if len(shared['products']) > 3:
                print(f"     ... and {len(shared['products']) - 3} more")
    
    print(f"\nPage-by-Page Summary:")
    for page in results.pages[:10]:
        print(f"  Page {page.page_number}: {len(page.products_found)} products, "
              f"{len(page.images_found)} images, category: {page.detected_category}")
    
    if len(results.pages) > 10:
        print(f"  ... and {len(results.pages) - 10} more pages")
    
    print()

# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    try:
        # Run analysis
        results = analyze_pdf()
        
        # Print summary
        print_summary(results)
        
        # Save results
        save_results(results)
        
        print(f"\n✓ Analysis complete! Check {OUTPUT_JSON} for detailed results.\n")
        
    except Exception as e:
        print(f"\n✗ Error during analysis: {e}")
        import traceback
        traceback.print_exc()
        exit(1)
