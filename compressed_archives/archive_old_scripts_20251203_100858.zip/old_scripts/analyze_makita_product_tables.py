"""
Analyze Makita Product Specification Tables
============================================
Focus on finding tables with product specs and prices
"""
import pdfplumber
from pathlib import Path
import json
import re

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "makita-catalogus-2022-nl.pdf"

def analyze_product_pages():
    """Analyze pages 3-30 to find product specification tables"""
    print("=" * 80)
    print("ANALYZING MAKITA PRODUCT SPECIFICATION TABLES")
    print("=" * 80)
    
    with pdfplumber.open(PDF_PATH) as pdf:
        # Check pages that typically have products (skip index page 2)
        for page_num in [3, 4, 5, 6, 7, 8, 10, 15, 20, 25, 30]:
            if page_num > len(pdf.pages):
                break
                
            page = pdf.pages[page_num - 1]
            
            print(f"\n{'='*80}")
            print(f"PAGE {page_num}")
            print(f"{'='*80}")
            
            # Extract all text first to understand structure
            text = page.extract_text()
            
            # Look for price indicators in text
            if text and ('excl' in text.lower() or 'incl' in text.lower() or 'btw' in text.lower()):
                print(f"\n[PRICES FOUND] Page contains pricing information")
                
                # Show lines with price-related keywords
                lines = text.split('\n')
                price_lines = [line for line in lines if 'excl' in line.lower() or 'incl' in line.lower() or 'btw' in line.lower() or re.search(r'\d+[,\.]\d{2}', line)]
                
                if price_lines:
                    print(f"\nPrice-related lines (first 10):")
                    for line in price_lines[:10]:
                        print(f"   {line}")
            
            # Try table extraction
            tables = page.extract_tables()
            
            if tables:
                print(f"\n[OK] Found {len(tables)} table(s)")
                
                # Focus on larger tables (likely spec tables)
                for table_idx, table in enumerate(tables):
                    if len(table) > 2:  # Only interested in tables with multiple rows
                        print(f"\n--- TABLE {table_idx + 1} ---")
                        print(f"Size: {len(table)} rows x {len(table[0]) if table else 0} cols")
                        
                        # Show first row (potential product names)
                        if table:
                            print(f"\nRow 0 (Header/Products):")
                            for idx, cell in enumerate(table[0]):
                                if cell:
                                    cell_str = str(cell).strip()
                                    if cell_str:
                                        print(f"  Col {idx}: '{cell_str}'")
                            
                            # Show first few rows
                            print(f"\nFirst 8 rows:")
                            for row_idx in range(min(8, len(table))):
                                row_data = []
                                for cell in table[row_idx]:
                                    cell_str = str(cell).strip() if cell else ''
                                    row_data.append(cell_str[:20] if len(cell_str) > 20 else cell_str)
                                print(f"  Row {row_idx}: {row_data[:6]}")
                        
                        print()
            else:
                print(f"\n[NO TABLES] Using text extraction instead")
                
                # Show sample text
                if text:
                    lines = text.split('\n')[:20]
                    print(f"\nFirst 20 lines:")
                    for idx, line in enumerate(lines):
                        if line.strip():
                            print(f"  {idx}: {line[:80]}")

if __name__ == '__main__':
    analyze_product_pages()
