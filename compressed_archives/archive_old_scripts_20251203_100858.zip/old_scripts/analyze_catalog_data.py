"""
Unified Catalog Data Analysis Tool for PDF_Analyzer

Combines product analysis, SKU coverage, and PDF coverage statistics.

Usage:
    python analyze_catalog_data.py --products
    python analyze_catalog_data.py --sku-coverage
    python analyze_catalog_data.py --pdf-coverage
    python analyze_catalog_data.py --all
"""

import json
import argparse
import pdfplumber
import re
from pathlib import Path
from collections import defaultdict, Counter
from typing import Iterator, Dict, Any


PROJECT_ROOT = Path(__file__).parent
INPUT_FOLDER = PROJECT_ROOT / "input_pdfs"
OUTPUT_DIR = PROJECT_ROOT / "output"


# ============================================================================
# 1. PRODUCT DATA ANALYSIS
# ============================================================================
def analyze_products(json_path: Path = None):
    """Analyze product data quality and statistics"""
    if json_path is None:
        json_path = OUTPUT_DIR / "products_ready_for_webshop.json"
    
    print("\n" + "=" * 80)
    print("PRODUCT DATA ANALYSIS")
    print("=" * 80)
    
    # Load products
    print(f"\n📂 Loading: {json_path.name}")
    with open(json_path, 'r', encoding='utf-8') as f:
        products = json.load(f)
    
    print(f"✅ Loaded {len(products):,} products")
    
    # Basic statistics
    print(f"\n📊 BASIC STATISTICS:")
    print(f"   Total products:           {len(products):,}")
    
    # Catalog breakdown
    catalogs = Counter(p.get('catalog', 'unknown') for p in products)
    print(f"   Unique catalogs:          {len(catalogs)}")
    
    print(f"\n📦 PRODUCTS BY CATALOG:")
    for catalog, count in sorted(catalogs.items(), key=lambda x: x[1], reverse=True):
        print(f"   {catalog:<40} {count:>6,} products")
    
    # Property coverage
    print(f"\n🔍 PROPERTY COVERAGE:")
    properties = ['name', 'sku', 'images', 'attributes', 'specs']
    for prop in properties:
        count = sum(1 for p in products if p.get(prop))
        percentage = (count / len(products)) * 100
        print(f"   {prop:<20} {count:>6,} / {len(products):,} ({percentage:5.1f}%)")
    
    # Image coverage
    with_images = sum(1 for p in products if p.get('images'))
    without_images = len(products) - with_images
    print(f"\n🖼️  IMAGE COVERAGE:")
    print(f"   Products with images:     {with_images:,} ({100*with_images/len(products):.1f}%)")
    print(f"   Products without images:  {without_images:,} ({100*without_images/len(products):.1f}%)")
    
    # Sample products
    print(f"\n📋 SAMPLE PRODUCTS (first 3):")
    for p in products[:3]:
        print(f"\n   SKU: {p.get('sku')}")
        print(f"      Name: {p.get('name', 'N/A')[:50]}")
        print(f"      Catalog: {p.get('catalog', 'N/A')}")
        print(f"      Images: {len(p.get('images', []))} images")
        print(f"      Specs: {len(p.get('specs', {}))} specs")
    
    print(f"\n{'='*80}")
    print("✅ PRODUCT ANALYSIS COMPLETE")
    print("="*80)


# ============================================================================
# 2. SKU COVERAGE ANALYSIS
# ============================================================================

SKU_PATTERNS = [
    re.compile(r'\b([A-Z]{2,}\d+[-A-Z0-9]*)\b'),
    re.compile(r'\b(\d{5,}(?:-[A-Z0-9]+)?)\b'),
    re.compile(r'\b(X\d+)\b'),
    re.compile(r'\b([A-Z]{1,2}\s?\d{2,}[-A-Z0-9/]*)\b'),
    re.compile(r'\b(\d+-\d+(?:-[A-Z]+)?)\b')
]

def find_all_skus(text: str) -> set:
    """Extract all SKUs from text"""
    if not text:
        return set()
    skus = set()
    for pattern in SKU_PATTERNS:
        matches = pattern.findall(text)
        skus.update(matches)
    return skus

def analyze_sku_coverage(max_pdfs: int = 3):
    """Analyze SKU coverage - compare extracted vs available"""
    print("\n" + "=" * 80)
    print("SKU COVERAGE ANALYSIS")
    print("=" * 80)
    
    # Load extracted data
    products_file = OUTPUT_DIR / "products_ready_for_webshop.json"
    if not products_file.exists():
        print(f"❌ File not found: {products_file}")
        return
    
    print(f"\n📂 Loading: {products_file.name}")
    with open(products_file, 'r', encoding='utf-8') as f:
        extracted_data = json.load(f)
    
    # Group by PDF source
    extracted_skus_by_pdf = defaultdict(set)
    for product in extracted_data:
        pdf_name = product.get('pdf_source', 'unknown')
        extracted_skus_by_pdf[pdf_name].add(product.get('sku'))
    
    print(f"✅ Loaded {len(extracted_data):,} products")
    
    # Analyze PDFs
    pdf_files = sorted(INPUT_FOLDER.glob("*.pdf"))[:max_pdfs]
    
    if not pdf_files:
        print(f"\n⚠️  No PDF files found in {INPUT_FOLDER}")
        return
    
    print(f"\n📄 Analyzing {len(pdf_files)} PDF files...")
    
    total_found = 0
    total_extracted = 0
    total_missing = 0
    
    for pdf_path in pdf_files:
        pdf_name = pdf_path.name
        print(f"\n{'='*80}")
        print(f"📄 {pdf_name}")
        print(f"{'='*80}")
        
        try:
            # Find all SKUs in PDF
            all_skus = set()
            with pdfplumber.open(pdf_path) as pdf:
                print(f"   Scanning {len(pdf.pages)} pages...")
                for page in pdf.pages:
                    text = page.extract_text() or ""
                    skus = find_all_skus(text)
                    all_skus.update(skus)
            
            # Compare with extracted
            extracted = extracted_skus_by_pdf.get(pdf_name, set())
            missing = all_skus - extracted
            
            print(f"\n   📊 RESULTS:")
            print(f"   Total SKUs found:      {len(all_skus):,}")
            print(f"   SKUs extracted:        {len(extracted):,}")
            print(f"   Missing SKUs:          {len(missing):,}")
            
            if len(all_skus) > 0:
                coverage = (len(extracted) / len(all_skus)) * 100
                print(f"   Coverage:              {coverage:.1f}%")
            
            if missing and len(missing) <= 20:
                print(f"\n   🔍 Missing SKUs:")
                for sku in sorted(missing):
                    print(f"      • {sku}")
            elif missing:
                print(f"\n   🔍 Missing SKUs (showing first 20):")
                for sku in sorted(missing)[:20]:
                    print(f"      • {sku}")
            
            total_found += len(all_skus)
            total_extracted += len(extracted)
            total_missing += len(missing)
            
        except Exception as e:
            print(f"   ❌ Error analyzing {pdf_name}: {str(e)}")
    
    # Summary
    print(f"\n{'='*80}")
    print(f"📊 OVERALL SUMMARY:")
    print(f"   Total SKUs found:      {total_found:,}")
    print(f"   Total extracted:       {total_extracted:,}")
    print(f"   Total missing:         {total_missing:,}")
    if total_found > 0:
        print(f"   Overall coverage:      {100*total_extracted/total_found:.1f}%")
    print("="*80)


# ============================================================================
# 3. PDF COVERAGE STATISTICS
# ============================================================================
def analyze_pdf_coverage():
    """Analyze image coverage statistics per PDF catalog"""
    print("\n" + "=" * 80)
    print("PDF/CATALOG COVERAGE ANALYSIS")
    print("=" * 80)
    
    products_file = OUTPUT_DIR / "products_ready_for_webshop.json"
    
    if not products_file.exists():
        print(f"❌ File not found: {products_file}")
        return
    
    print(f"\n📂 Loading: {products_file.name}")
    with open(products_file, 'r', encoding='utf-8') as f:
        products = json.load(f)
    
    print(f"✅ Loaded {len(products):,} products")
    
    # Calculate coverage per catalog
    total_by_cat = Counter(p.get('catalog', 'unknown') for p in products)
    with_images_by_cat = Counter(
        p.get('catalog', 'unknown') 
        for p in products 
        if p.get('images') and len(p.get('images', [])) > 0
    )
    
    # Group by coverage tier
    coverage_tiers = {
        '0% (No Images)': [],
        '1-25%': [],
        '26-50%': [],
        '51-75%': [],
        '76-100%': []
    }
    
    for cat in total_by_cat:
        total = total_by_cat[cat]
        with_img = with_images_by_cat.get(cat, 0)
        cov = (with_img / total * 100) if total > 0 else 0
        
        if cov == 0:
            coverage_tiers['0% (No Images)'].append((cat, total))
        elif cov <= 25:
            coverage_tiers['1-25%'].append((cat, total, cov))
        elif cov <= 50:
            coverage_tiers['26-50%'].append((cat, total, cov))
        elif cov <= 75:
            coverage_tiers['51-75%'].append((cat, total, cov))
        else:
            coverage_tiers['76-100%'].append((cat, total, cov))
    
    # Print breakdown
    print(f"\n📊 COVERAGE BREAKDOWN BY TIER:\n")
    
    for tier, catalogs in coverage_tiers.items():
        if catalogs:
            print(f"   {tier}:")
            count = len(catalogs)
            products_in_tier = sum(c[1] for c in catalogs)
            print(f"      Catalogs: {count}")
            print(f"      Products: {products_in_tier:,}")
            print()
            
            if tier == '0% (No Images)':
                for cat, total in sorted(catalogs, key=lambda x: x[1], reverse=True)[:10]:
                    print(f"         - {cat:<40} ({total:,} products)")
            else:
                for cat, total, cov in sorted(catalogs, key=lambda x: x[2]):
                    print(f"         - {cat:<40} ({total:,} products, {cov:.1f}%)")
            print()
    
    # Overall statistics
    total_products = sum(total_by_cat.values())
    total_with_images = sum(with_images_by_cat.values())
    overall_coverage = (total_with_images / total_products * 100) if total_products > 0 else 0
    
    print(f"{'='*80}")
    print(f"📊 OVERALL IMAGE COVERAGE:")
    print(f"   Total products:        {total_products:,}")
    print(f"   Products with images:  {total_with_images:,}")
    print(f"   Overall coverage:      {overall_coverage:.1f}%")
    print("="*80)


# ============================================================================
# MAIN CLI
# ============================================================================
def main():
    parser = argparse.ArgumentParser(
        description='Unified Catalog Data Analysis Tool',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python analyze_catalog_data.py --all
  python analyze_catalog_data.py --products
  python analyze_catalog_data.py --sku-coverage
  python analyze_catalog_data.py --pdf-coverage
        """
    )
    
    parser.add_argument('--all', action='store_true', help='Run all analyses')
    parser.add_argument('--products', action='store_true', help='Analyze product data quality')
    parser.add_argument('--sku-coverage', action='store_true', help='Analyze SKU coverage')
    parser.add_argument('--pdf-coverage', action='store_true', help='Analyze PDF/catalog coverage')
    parser.add_argument('--max-pdfs', type=int, default=3, help='Max PDFs to analyze for SKU coverage')
    
    args = parser.parse_args()
    
    # If no arguments, show help
    if not any(vars(args).values()):
        parser.print_help()
        return
    
    print("\n🔍 PDF ANALYZER - CATALOG DATA ANALYSIS")
    print("=" * 80)
    
    # Run selected analyses
    if args.all or args.products:
        analyze_products()
    
    if args.all or args.sku_coverage:
        analyze_sku_coverage(max_pdfs=args.max_pdfs)
    
    if args.all or args.pdf_coverage:
        analyze_pdf_coverage()
    
    print("\n" + "=" * 80)
    print("🎉 ANALYSIS COMPLETE!")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()
