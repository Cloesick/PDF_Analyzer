"""
Analyze image quality metrics from Makita catalog to find optimal thresholds
"""
import fitz
from PIL import Image
import cv2
import numpy as np
from pathlib import Path
import io

PDF_PATH = Path(__file__).parent / "input_pdfs" / "makita-catalogus-2022-nl.pdf"

def detect_gradient(img_array):
    """Detect if image is a gradient"""
    height, width = img_array.shape[:2]
    h_gradients = []
    for y in [height//4, height//2, 3*height//4]:
        row = img_array[y, :]
        color_diffs = np.abs(np.diff(row.astype(float), axis=0))
        h_gradients.append(np.mean(color_diffs))
    
    v_gradients = []
    for x in [width//4, width//2, 3*width//4]:
        col = img_array[:, x]
        color_diffs = np.abs(np.diff(col.astype(float), axis=0))
        v_gradients.append(np.mean(color_diffs))
    
    avg_gradient = (np.mean(h_gradients) + np.mean(v_gradients)) / 2
    all_h_diffs = []
    all_v_diffs = []
    for y in range(0, height, max(1, height//10)):
        row = img_array[y, :]
        all_h_diffs.extend(np.abs(np.diff(row.astype(float), axis=0)).flatten())
    for x in range(0, width, max(1, width//10)):
        col = img_array[:, x]
        all_v_diffs.extend(np.abs(np.diff(col.astype(float), axis=0)).flatten())
    
    smoothness = np.std(all_h_diffs + all_v_diffs)
    gradient_score = avg_gradient / (smoothness + 1)
    return gradient_score

def calculate_texture_complexity(gray):
    """Calculate texture complexity"""
    try:
        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        mean_filter = cv2.blur(gray.astype(float), (5, 5))
        sq_diff = (gray.astype(float) - mean_filter) ** 2
        local_var = cv2.blur(sq_diff, (5, 5))
        texture_score = np.mean(np.sqrt(local_var))
        normalized_score = texture_score / 100.0
        if np.isnan(normalized_score) or np.isinf(normalized_score):
            return 0.0
        return normalized_score
    except:
        return 0.0

def analyze_images():
    doc = fitz.open(PDF_PATH)
    
    metrics = []
    sample_count = 0
    max_samples = 50  # Analyze first 50 product-sized images
    
    print("Analyzing images...")
    
    for page_num in range(min(20, len(doc))):  # Check first 20 pages
        page = doc[page_num]
        image_list = page.get_images()
        
        for img_idx, img in enumerate(image_list):
            if sample_count >= max_samples:
                break
                
            xref = img[0]
            try:
                base_image = doc.extract_image(xref)
                image_bytes = base_image["image"]
                pil_image = Image.open(io.BytesIO(image_bytes))
                
                width, height = pil_image.size
                area = width * height
                
                # Only analyze reasonable-sized images
                if width < 100 or height < 100 or area < 10000:
                    continue
                
                img_array = np.array(pil_image.convert('RGB'))
                gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
                
                # Calculate metrics
                r, g, b = img_array[:,:,0], img_array[:,:,1], img_array[:,:,2]
                rg_diff = np.abs(r.astype(int) - g.astype(int))
                rb_diff = np.abs(r.astype(int) - b.astype(int))
                gb_diff = np.abs(g.astype(int) - b.astype(int))
                color_variance = (rg_diff.mean() + rb_diff.mean() + gb_diff.mean()) / 3
                
                edges = cv2.Canny(gray, 50, 150)
                edge_density = np.count_nonzero(edges) / area
                
                texture = calculate_texture_complexity(gray)
                gradient = detect_gradient(img_array)
                
                aspect_ratio = max(width, height) / min(width, height)
                
                metrics.append({
                    'page': page_num + 1,
                    'size': f'{width}x{height}',
                    'area': area,
                    'aspect_ratio': aspect_ratio,
                    'color_variance': color_variance,
                    'edge_density': edge_density,
                    'texture': texture,
                    'gradient': gradient
                })
                
                sample_count += 1
                
            except Exception as e:
                continue
        
        if sample_count >= max_samples:
            break
    
    doc.close()
    
    # Sort and display
    print(f"\n=== ANALYZED {len(metrics)} IMAGES ===\n")
    
    print("Top 10 by Texture Complexity:")
    sorted_by_texture = sorted(metrics, key=lambda x: x['texture'], reverse=True)
    for i, m in enumerate(sorted_by_texture[:10], 1):
        print(f"{i}. Page {m['page']} - {m['size']} - Texture: {m['texture']:.3f}, Gradient: {m['gradient']:.3f}, Variance: {m['color_variance']:.1f}")
    
    print("\nBottom 10 by Texture Complexity:")
    for i, m in enumerate(sorted_by_texture[-10:], 1):
        print(f"{i}. Page {m['page']} - {m['size']} - Texture: {m['texture']:.3f}, Gradient: {m['gradient']:.3f}, Variance: {m['color_variance']:.1f}")
    
    print("\nTop 10 by Gradient Score:")
    sorted_by_gradient = sorted(metrics, key=lambda x: x['gradient'], reverse=True)
    for i, m in enumerate(sorted_by_gradient[:10], 1):
        print(f"{i}. Page {m['page']} - {m['size']} - Gradient: {m['gradient']:.3f}, Texture: {m['texture']:.3f}, Variance: {m['color_variance']:.1f}")
    
    # Statistics
    textures = [m['texture'] for m in metrics]
    gradients = [m['gradient'] for m in metrics]
    variances = [m['color_variance'] for m in metrics]
    
    print(f"\n=== STATISTICS ===")
    print(f"Texture Complexity:")
    print(f"  Min: {min(textures):.3f}, Max: {max(textures):.3f}, Mean: {np.mean(textures):.3f}, Median: {np.median(textures):.3f}")
    print(f"Gradient Score:")
    print(f"  Min: {min(gradients):.3f}, Max: {max(gradients):.3f}, Mean: {np.mean(gradients):.3f}, Median: {np.median(gradients):.3f}")
    print(f"Color Variance:")
    print(f"  Min: {min(variances):.1f}, Max: {max(variances):.1f}, Mean: {np.mean(variances):.1f}, Median: {np.median(variances):.1f}")

if __name__ == "__main__":
    analyze_images()
