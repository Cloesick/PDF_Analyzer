"""
Extract Makita Tuinfolder (Garden Tools) PDF
- Better image filtering to avoid specs/diagrams
- Extract tables with vertical headers
- Extract prices and properties
"""
import fitz  # PyMuPDF
import pdfplumber
from PIL import Image
import cv2
import numpy as np
from pathlib import Path
import json
import io
import re

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "makita-tuinfolder-2022-nl.pdf"
OUTPUT_IMAGES = PROJECT_ROOT / "product-images-by-pdf" / "makita-tuinfolder-2022-nl"
OUTPUT_JSON = PROJECT_ROOT / "output" / "makita_tuinfolder_extracted.json"
TABLE_JSON = PROJECT_ROOT / "output" / "makita_tuinfolder_tables.json"

CATALOG_NAME = "makita-tuinfolder-2022-nl"
IMAGE_DPI = 300
WEBP_QUALITY = 90

# STRICT filtering - only actual product photos
MIN_IMAGE_AREA = 40000  # Larger minimum
MIN_IMAGE_WIDTH = 180
MIN_IMAGE_HEIGHT = 180
MAX_ASPECT_RATIO = 2.5  # More restrictive
MIN_COLOR_VARIANCE = 25  # Higher variance = real photos
MIN_EDGE_DENSITY = 0.02
MIN_CONTENT_RATIO = 0.15  # Minimum non-white content

def is_product_image(pil_image):
    """Strict filtering for actual product photos only"""
    img_array = np.array(pil_image.convert('RGB'))
    width, height = pil_image.size
    
    # Size check
    if width < MIN_IMAGE_WIDTH or height < MIN_IMAGE_HEIGHT:
        return False, {'reason': 'too_small', 'size': f'{width}x{height}'}
    
    if width * height < MIN_IMAGE_AREA:
        return False, {'reason': 'insufficient_area', 'area': width * height}
    
    # Aspect ratio check
    aspect_ratio = max(width, height) / min(width, height)
    if aspect_ratio > MAX_ASPECT_RATIO:
        return False, {'reason': 'extreme_aspect', 'ratio': aspect_ratio}
    
    # Convert to grayscale and other color spaces
    gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
    
    # Color complexity check
    r, g, b = img_array[:,:,0], img_array[:,:,1], img_array[:,:,2]
    color_variance = np.std(r) + np.std(g) + np.std(b)
    
    if color_variance < MIN_COLOR_VARIANCE:
        return False, {'reason': 'low_color_variance', 'variance': color_variance}
    
    # Edge density (real photos have moderate edges)
    edges = cv2.Canny(gray, 50, 150)
    edge_density = np.sum(edges > 0) / (width * height)
    
    if edge_density < MIN_EDGE_DENSITY:
        return False, {'reason': 'low_edge_density', 'density': edge_density}
    
    if edge_density > 0.25:  # Too many edges = diagram/text
        return False, {'reason': 'excessive_edges', 'density': edge_density}
    
    # White background check
    white_pixels = np.sum((r > 240) & (g > 240) & (b > 240))
    white_ratio = white_pixels / (width * height)
    
    if white_ratio > 0.92:  # Almost all white
        return False, {'reason': 'mostly_white', 'ratio': white_ratio}
    
    # Content ratio (non-white pixels)
    content_ratio = 1 - white_ratio
    if content_ratio < MIN_CONTENT_RATIO:
        return False, {'reason': 'insufficient_content', 'ratio': content_ratio}
    
    # Brightness check
    avg_brightness = np.mean(gray)
    if avg_brightness > 250:  # Too bright = empty
        return False, {'reason': 'too_bright', 'brightness': avg_brightness}
    
    return True, {
        'color_variance': color_variance,
        'edge_density': edge_density,
        'white_ratio': white_ratio,
        'content_ratio': content_ratio
    }

def extract_images_from_pdf():
    """Extract product images from PDF"""
    print("="*80)
    print("EXTRACTING MAKITA TUINFOLDER IMAGES")
    print("="*80)
    
    OUTPUT_IMAGES.mkdir(parents=True, exist_ok=True)
    
    doc = fitz.open(PDF_PATH)
    extracted_images = []
    stats = {
        'total_images': 0,
        'extracted': 0,
        'filtered': 0,
        'filter_reasons': {}
    }
    
    print(f"\nProcessing {len(doc)} pages...")
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        image_list = page.get_images()
        
        if (page_num + 1) % 5 == 0:
            print(f"  Page {page_num + 1}/{len(doc)} - Extracted {stats['extracted']} products")
        
        for img_idx, img in enumerate(image_list):
            stats['total_images'] += 1
            xref = img[0]
            
            try:
                base_image = doc.extract_image(xref)
                image_bytes = base_image["image"]
                pil_image = Image.open(io.BytesIO(image_bytes))
                
                # Filter
                is_product, metrics = is_product_image(pil_image)
                
                if not is_product:
                    stats['filtered'] += 1
                    reason = metrics.get('reason', 'unknown')
                    stats['filter_reasons'][reason] = stats['filter_reasons'].get(reason, 0) + 1
                    continue
                
                # Save image
                sku_placeholder = f"{stats['extracted']:05d}"
                filename = f"{sku_placeholder}_{CATALOG_NAME}_p{page_num+1:03d}_img{img_idx:02d}.webp"
                filepath = OUTPUT_IMAGES / filename
                
                pil_image.save(filepath, 'WEBP', quality=WEBP_QUALITY)
                
                extracted_images.append({
                    'filename': filename,
                    'page': page_num + 1,
                    'index': img_idx,
                    'metrics': metrics
                })
                
                stats['extracted'] += 1
                
            except Exception as e:
                continue
    
    doc.close()
    
    print("\n" + "="*80)
    print("IMAGE EXTRACTION COMPLETE")
    print("="*80)
    print(f"\nStatistics:")
    print(f"  Total images found: {stats['total_images']}")
    print(f"  Product images: {stats['extracted']}")
    print(f"  Filtered out: {stats['filtered']}")
    print(f"\nFilter breakdown:")
    for reason, count in sorted(stats['filter_reasons'].items(), key=lambda x: x[1], reverse=True):
        print(f"  {reason}: {count}")
    
    return extracted_images

def extract_tables_from_pdf():
    """Extract product tables"""
    print("\n" + "="*80)
    print("EXTRACTING PRODUCT TABLES")
    print("="*80)
    
    products = []
    
    with pdfplumber.open(PDF_PATH) as pdf:
        total_pages = len(pdf.pages)
        
        for page_num in range(total_pages):
            page = pdf.pages[page_num]
            page_text = page.extract_text() or ""
            tables = page.extract_tables()
            
            if not tables:
                continue
            
            # Find product SKUs in page text
            sku_patterns = [
                r'\b[A-Z]{2,4}\d{3,4}[A-Z]{1,4}\b',  # DUH483Z, DLM462Z
                r'\b[A-Z]{2}\d{3}[A-Z]{2}\d{3}\b',    # UC010GT101
            ]
            
            page_skus = []
            for pattern in sku_patterns:
                matches = re.findall(pattern, page_text)
                page_skus.extend(matches)
            
            # Remove duplicates
            page_skus = list(dict.fromkeys(page_skus))
            
            for table_idx, table in enumerate(tables):
                if len(table) < 3:
                    continue
                
                # Check if it's a spec table (first column has property names)
                first_col = [row[0] for row in table if row and row[0]]
                has_props = any(prop in ' '.join(first_col).lower() 
                              for prop in ['spanning', 'gewicht', 'capaciteit', 'vermogen'])
                
                if not has_props:
                    continue
                
                # Count product columns (columns 2+)
                if not table or not table[0]:
                    continue
                
                num_products = sum(1 for cell in table[0][2:] if cell and str(cell).strip())
                
                if num_products == 0:
                    continue
                
                print(f"\n  Page {page_num + 1}, Table {table_idx + 1}: {num_products} products")
                
                # Extract products
                for col_idx in range(2, 2 + num_products):
                    sku = page_skus[col_idx - 2] if (col_idx - 2) < len(page_skus) else f"PROD_P{page_num+1}_C{col_idx}"
                    
                    product = {
                        'sku': sku,
                        'page': page_num + 1,
                        'properties': {},
                        'price_excl_btw_eur': None,
                        'price_incl_btw_eur': None
                    }
                    
                    # Extract properties
                    for row in table[1:]:
                        if not row or not row[0]:
                            continue
                        
                        prop_name = str(row[0]).strip()
                        sub_label = str(row[1]).strip() if len(row) > 1 else ""
                        
                        if col_idx < len(row):
                            value = str(row[col_idx]).strip()
                            
                            if value:
                                # Check for price
                                if 'prijs' in prop_name.lower() or 'price' in prop_name.lower():
                                    if 'excl' in (prop_name + sub_label).lower():
                                        price = extract_price(value)
                                        if price:
                                            product['price_excl_btw_eur'] = price
                                    elif 'incl' in (prop_name + sub_label).lower():
                                        price = extract_price(value)
                                        if price:
                                            product['price_incl_btw_eur'] = price
                                else:
                                    full_prop = f"{prop_name} {sub_label}".strip()
                                    product['properties'][full_prop] = value
                    
                    products.append(product)
    
    print(f"\n[COMPLETE] Extracted {len(products)} products from tables")
    return products

def extract_price(text):
    """Extract price from European format"""
    if not text:
        return None
    text = str(text).replace('€', '').replace('.', '').replace(',', '.').strip()
    match = re.search(r'(\d+\.?\d*)', text)
    if match:
        try:
            return float(match.group(1))
        except:
            return None
    return None

def main():
    # Extract images
    images = extract_images_from_pdf()
    
    # Extract tables
    products = extract_tables_from_pdf()
    
    # Save results
    with open(TABLE_JSON, 'w', encoding='utf-8') as f:
        json.dump(products, f, indent=2, ensure_ascii=False)
    
    print(f"\n[SAVED]")
    print(f"  Tables: {TABLE_JSON}")
    print(f"  Images: {OUTPUT_IMAGES}")
    print(f"\n[SUMMARY]")
    print(f"  Product images: {len(images)}")
    print(f"  Product specs: {len(products)}")

if __name__ == '__main__':
    main()
