"""
MAKITA BATTERY PRODUCTS EXTRACTOR
==================================
Extracts batteries, powerpacks, chargers, and adapters in structured table format

Output includes:
- SKU
- Product Name
- Specifications/Content
- Price (Excl. VAT)
- Price (Incl. VAT)

Categories:
1. Batteries (Li-ion battery products)
2. Powerpacks (Kits with batteries + chargers)
3. Chargers & Adapters
"""

import pdfplumber
import json
import re
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
PDF_PATH = PROJECT_ROOT / "input_pdfs" / "makita-catalogus-2022-nl.pdf"
OUTPUT_JSON = PROJECT_ROOT / "output" / "makita_battery_products.json"
OUTPUT_TABLE = PROJECT_ROOT / "output" / "makita_battery_table.txt"

VAT_RATE = 1.21

# Battery product patterns
BATTERY_PATTERNS = {
    'batteries': [
        r'BL\d{4}[A-Z]?',  # BL4020, BL4025, BL4040, BL4050F, BL4080F
        r'\d{3}[A-Z]\d{2}-\d',  # 191L29-0, 191B36-3, etc.
    ],
    'powerpacks': [
        r'\d{3}[A-Z]\d{2}-\d',  # 191V07-0, 191J81-6, etc.
        r'XGT.*Powerpack',
    ],
    'chargers': [
        r'DC\d{2}R[AB]',  # DC40RA, DC40RB
        r'\d{3}[A-Z]\d{2}-\d',  # 191E07-8, 191N09-8
    ],
    'adapters': [
        r'ADP\d{3}',  # ADP10, ADP001
        r'DEAADP\d{3}[A-Z]?',  # DEAADP001G
        r'\d{3}[A-Z]\d{2}-\d',  # 191C10-7
    ]
}

# Keywords for categorization
CATEGORY_KEYWORDS = {
    'batteries': ['li-ion battery', 'lithium', 'accu', 'battery bl'],
    'powerpacks': ['powerpack', 'kit', 'makpac'],
    'chargers': ['charger', 'lader', 'charging'],
    'adapters': ['adapter', 'usb-adapter', 'charging adapter']
}

def extract_sku(text):
    """Extract SKU from text"""
    # Try all battery-related patterns
    for category, patterns in BATTERY_PATTERNS.items():
        for pattern in patterns:
            matches = re.findall(pattern, text.upper())
            if matches:
                return matches[0]
    return None

def extract_voltage(text):
    """Extract voltage specification"""
    # 40Vmax, 36V, 18V, 14.4V
    match = re.search(r'(\d+\.?\d*)\s*V\s*(?:max)?', text, re.IGNORECASE)
    return match.group(0) if match else None

def extract_capacity(text):
    """Extract battery capacity (Ah)"""
    match = re.search(r'(\d+\.?\d*)\s*Ah', text, re.IGNORECASE)
    return match.group(0) if match else None

def extract_weight(text):
    """Extract weight"""
    match = re.search(r'(\d+\.?\d*)\s*kg', text, re.IGNORECASE)
    return match.group(0) if match else None

def extract_charge_time(text):
    """Extract charging time"""
    match = re.search(r'(\d+)\s*min(?:uten)?', text, re.IGNORECASE)
    if match:
        return f"{match.group(1)} min charge"
    return None

def extract_price(text):
    """Extract price from text"""
    # Match € 125,00 or € 125.00 or €125
    match = re.search(r'€\s*(\d+[.,]\d+|\d+)', text)
    if match:
        price_str = match.group(1).replace(',', '.')
        try:
            return float(price_str)
        except:
            pass
    return None

def categorize_product(text, sku=None):
    """Determine product category"""
    text_lower = text.lower()
    
    # Check for explicit keywords
    if any(kw in text_lower for kw in CATEGORY_KEYWORDS['powerpacks']):
        return 'powerpacks'
    elif any(kw in text_lower for kw in CATEGORY_KEYWORDS['chargers']):
        return 'chargers'
    elif any(kw in text_lower for kw in CATEGORY_KEYWORDS['adapters']):
        return 'adapters'
    elif any(kw in text_lower for kw in CATEGORY_KEYWORDS['batteries']):
        return 'batteries'
    
    # Check SKU patterns
    if sku:
        sku_upper = sku.upper()
        if sku_upper.startswith('BL'):
            return 'batteries'
        elif sku_upper.startswith('DC'):
            return 'chargers'
        elif 'ADP' in sku_upper:
            return 'adapters'
    
    return 'batteries'  # Default

def extract_product_name(text, sku):
    """Extract product name"""
    text_lower = text.lower()
    
    # Li-ion battery
    if 'li-ion' in text_lower or 'lithium' in text_lower:
        # Find battery model (BL4020, etc.)
        bl_match = re.search(r'BL\d{4}[A-Z]?', text, re.IGNORECASE)
        if bl_match:
            return f"Li-ion battery {bl_match.group(0).upper()}"
    
    # Powerpack
    if 'powerpack' in text_lower:
        # Try to find capacity
        capacity = extract_capacity(text)
        if capacity:
            return f"XGT Powerpack {capacity}"
        return "XGT Powerpack"
    
    # Charger
    if 'duo' in text_lower and 'charger' in text_lower:
        return "Duo fast charger DC40RB"
    elif 'charger' in text_lower or 'lader' in text_lower:
        return "Charger DC40RA"
    
    # Adapter
    if 'usb' in text_lower:
        return "ADP001 USB Adapter"
    elif 'adapter' in text_lower:
        if 'lxt' in text_lower or '14.4v' in text_lower or '18v' in text_lower:
            return "ADP10 Charging Adapter"
        return "Charging Adapter"
    
    return f"Product {sku}"

def build_specifications(text):
    """Build specifications string"""
    specs = []
    
    # Voltage
    voltage = extract_voltage(text)
    if voltage:
        specs.append(voltage)
    
    # Capacity
    capacity = extract_capacity(text)
    if capacity:
        specs.append(capacity)
    
    # Weight
    weight = extract_weight(text)
    if weight:
        specs.append(weight)
    
    # Charge time
    charge_time = extract_charge_time(text)
    if charge_time:
        specs.append(charge_time)
    
    # Check for special mentions
    text_lower = text.lower()
    if 'makpac' in text_lower:
        specs.append("Includes MAKPAC case")
    if 'duo' in text_lower and 'charger' in text_lower:
        specs.append("Simultaneous charging")
    if '4 batteries' in text_lower or '4x' in text_lower:
        specs.append("4 Batteries")
    if '2 batteries' in text_lower or '2x' in text_lower:
        specs.append("2 Batteries")
    
    return " • ".join(specs) if specs else "See specifications"

def extract_battery_products():
    """Extract battery products from Makita catalog"""
    
    print("="*80)
    print("MAKITA BATTERY PRODUCTS EXTRACTOR")
    print("="*80)
    
    products = {
        'batteries': [],
        'powerpacks': [],
        'chargers': [],
        'adapters': []
    }
    
    print(f"\n📄 Processing: {PDF_PATH.name}\n")
    
    with pdfplumber.open(PDF_PATH) as pdf:
        for page_num, page in enumerate(pdf.pages, 1):
            text = page.extract_text() or ""
            
            # Look for battery-related keywords
            text_lower = text.lower()
            if not any(kw in text_lower for kw in ['battery', 'accu', 'charger', 'lader', 'powerpack', 'adapter', 'bl40', 'bl18', 'dc40']):
                continue
            
            # Extract tables
            tables = page.extract_tables()
            
            # Also process text line by line
            lines = text.split('\n')
            
            for i, line in enumerate(lines):
                line_upper = line.upper()
                
                # Look for SKU patterns
                sku = extract_sku(line)
                if not sku:
                    continue
                
                # Get context (surrounding lines)
                context_start = max(0, i - 2)
                context_end = min(len(lines), i + 3)
                context = ' '.join(lines[context_start:context_end])
                
                # Categorize
                category = categorize_product(context, sku)
                
                # Extract product name
                product_name = extract_product_name(context, sku)
                
                # Extract specifications
                specifications = build_specifications(context)
                
                # Extract prices
                price_excl = extract_price(context)
                price_incl = None
                
                if price_excl:
                    # Look for second price in context
                    prices = re.findall(r'€\s*(\d+[.,]\d+|\d+)', context)
                    if len(prices) >= 2:
                        try:
                            price_incl = float(prices[1].replace(',', '.'))
                        except:
                            price_incl = price_excl * VAT_RATE
                    else:
                        price_incl = price_excl * VAT_RATE
                
                # Check if already exists
                if any(p['sku'] == sku for p in products[category]):
                    continue
                
                product = {
                    'sku': sku,
                    'product_name': product_name,
                    'specifications': specifications,
                    'price_excl': price_excl,
                    'price_incl': price_incl,
                    'page': page_num
                }
                
                products[category].append(product)
                print(f"  ✅ Page {page_num}: {category.title()} - {sku} - {product_name}")
            
            if page_num % 20 == 0:
                print(f"\n  📊 Scanned {page_num} pages\n")
    
    # Create output
    total_products = sum(len(products[cat]) for cat in products)
    
    output = {
        'metadata': {
            'source': 'makita-catalogus-2022-nl',
            'total_products': total_products,
            'categories': {
                'batteries': len(products['batteries']),
                'powerpacks': len(products['powerpacks']),
                'chargers': len(products['chargers']),
                'adapters': len(products['adapters'])
            }
        },
        'products': products
    }
    
    # Save JSON
    OUTPUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    # Create formatted table
    create_table_output(products)
    
    # Summary
    print(f"\n{'='*80}")
    print("✅ EXTRACTION COMPLETE")
    print(f"{'='*80}")
    print(f"\n📊 Statistics:")
    print(f"   Batteries:        {len(products['batteries'])}")
    print(f"   Powerpacks:       {len(products['powerpacks'])}")
    print(f"   Chargers:         {len(products['chargers'])}")
    print(f"   Adapters:         {len(products['adapters'])}")
    print(f"   Total:            {total_products}")
    print(f"\n💾 Output:")
    print(f"   JSON:  {OUTPUT_JSON}")
    print(f"   Table: {OUTPUT_TABLE}")
    print(f"\n{'='*80}\n")
    
    return output

def create_table_output(products):
    """Create formatted table output"""
    
    lines = []
    lines.append("="*120)
    lines.append("MAKITA BATTERY PRODUCTS - STRUCTURED TABLE")
    lines.append("="*120)
    
    for category in ['batteries', 'powerpacks', 'chargers', 'adapters']:
        if not products[category]:
            continue
        
        lines.append(f"\n{'='*120}")
        lines.append(f"{category.upper()}")
        lines.append("="*120)
        lines.append(f"{'SKU':<15} {'Product Name':<40} {'Specifications':<35} {'Ex VAT':<12} {'Incl VAT':<12}")
        lines.append("-"*120)
        
        for product in products[category]:
            sku = product['sku']
            name = product['product_name'][:39]
            specs = product['specifications'][:34]
            price_ex = f"€ {product['price_excl']:.2f}" if product['price_excl'] else "N/A"
            price_in = f"€ {product['price_incl']:.2f}" if product['price_incl'] else "N/A"
            
            lines.append(f"{sku:<15} {name:<40} {specs:<35} {price_ex:<12} {price_in:<12}")
    
    lines.append("\n" + "="*120)
    
    # Save to file
    with open(OUTPUT_TABLE, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))
    
    # Print sample
    print("\n📋 Sample Table Output:\n")
    for line in lines[:30]:
        print(line)

if __name__ == "__main__":
    extract_battery_products()
