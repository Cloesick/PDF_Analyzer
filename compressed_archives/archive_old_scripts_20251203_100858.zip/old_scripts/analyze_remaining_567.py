"""
Deep Analysis of Remaining 567 Unmatched Products
=================================================
Find every possible way to match these products
"""
import json
from pathlib import Path
from collections import defaultdict, Counter
import re
from difflib import SequenceMatcher

PROJECT_ROOT = Path(__file__).parent
PRODUCTS_JSON = PROJECT_ROOT / "output" / "products_with_makita_images.json"
EXTRACTED_JSON = PROJECT_ROOT / "output" / "makita_extracted_products.json"

def similar(a, b):
    return SequenceMatcher(None, a.upper(), b.upper()).ratio()

def main():
    print("=" * 80)
    print("EXTREME ANALYSIS: 567 REMAINING UNMATCHED PRODUCTS")
    print("=" * 80)
    
    # Load data
    with open(PRODUCTS_JSON, 'r', encoding='utf-8') as f:
        all_products = json.load(f)
    
    with open(EXTRACTED_JSON, 'r', encoding='utf-8') as f:
        extracted_images = json.load(f)
    
    makita_products = [p for p in all_products if 'makita-catalogus-2022-nl' in p.get('pdf_source', '')]
    unmatched = [p for p in makita_products if not p.get('image_url')]
    
    image_skus = set(entry['sku'] for entry in extracted_images)
    
    print(f"\n📊 Analyzing {len(unmatched)} unmatched products...")
    
    # Strategy 1: Very Low Fuzzy Matching (60-75%)
    print("\n" + "=" * 80)
    print("STRATEGY 1: EXTREME FUZZY MATCHING (60-74% similarity)")
    print("=" * 80)
    
    extreme_fuzzy = []
    for prod in unmatched:
        sku = prod['sku']
        best_match = None
        best_ratio = 0
        
        for img_sku in image_skus:
            ratio = similar(sku, img_sku)
            if 0.60 <= ratio < 0.75:  # Below current threshold
                if ratio > best_ratio:
                    best_ratio = ratio
                    best_match = img_sku
        
        if best_match:
            extreme_fuzzy.append((sku, best_match, best_ratio))
    
    print(f"\n🔍 Found {len(extreme_fuzzy)} matches with 60-74% similarity:")
    for sku, match, ratio in extreme_fuzzy[:30]:
        print(f"   {sku:20s} → {match:20s} | {ratio*100:.1f}%")
    
    # Strategy 2: Partial SKU Matching
    print("\n" + "=" * 80)
    print("STRATEGY 2: PARTIAL SKU MATCHING")
    print("=" * 80)
    
    def get_partial_matches(sku, available_skus):
        matches = []
        # Try first 5+ characters
        if len(sku) >= 5:
            prefix = sku[:5]
            for candidate in available_skus:
                if len(candidate) >= 5 and candidate.startswith(prefix):
                    matches.append((candidate, 'prefix'))
        
        # Try removing last 2-4 characters
        for trim in [2, 3, 4]:
            if len(sku) > trim:
                trimmed = sku[:-trim]
                if trimmed in available_skus:
                    matches.append((trimmed, f'trim_{trim}'))
        
        return matches
    
    partial_matches = []
    for prod in unmatched:
        matches = get_partial_matches(prod['sku'], image_skus)
        if matches:
            partial_matches.append((prod['sku'], matches))
    
    print(f"\n🔍 Found {len(partial_matches)} partial matches:")
    for sku, matches in partial_matches[:30]:
        for match, method in matches[:1]:
            print(f"   {sku:20s} → {match:20s} | Method: {method}")
    
    # Strategy 3: Number Extraction
    print("\n" + "=" * 80)
    print("STRATEGY 3: NUMERIC CODE MATCHING")
    print("=" * 80)
    
    def extract_numbers(sku):
        return ''.join(c for c in sku if c.isdigit())
    
    numeric_matches = []
    for prod in unmatched:
        prod_nums = extract_numbers(prod['sku'])
        if len(prod_nums) >= 4:
            for img_sku in image_skus:
                img_nums = extract_numbers(img_sku)
                if prod_nums == img_nums and len(prod_nums) >= 4:
                    numeric_matches.append((prod['sku'], img_sku, prod_nums))
    
    print(f"\n🔍 Found {len(numeric_matches)} numeric code matches:")
    for sku, match, nums in numeric_matches[:20]:
        print(f"   {sku:20s} → {match:20s} | Numbers: {nums}")
    
    # Strategy 4: Contains Matching
    print("\n" + "=" * 80)
    print("STRATEGY 4: SUBSTRING CONTAINS MATCHING")
    print("=" * 80)
    
    contains_matches = []
    for prod in unmatched:
        sku = prod['sku']
        if len(sku) >= 6:
            for img_sku in image_skus:
                if sku in img_sku or img_sku in sku:
                    if sku != img_sku:
                        contains_matches.append((sku, img_sku))
    
    print(f"\n🔍 Found {len(contains_matches)} substring matches:")
    for sku, match in contains_matches[:20]:
        print(f"   {sku:20s} ↔ {match:20s}")
    
    # Strategy 5: Analyze Unmatched by Page
    print("\n" + "=" * 80)
    print("STRATEGY 5: PAGE-BASED FALLBACK")
    print("=" * 80)
    
    # Build page to image mapping
    page_to_images = defaultdict(list)
    for entry in extracted_images:
        page_to_images[entry['page_num']].append(entry['sku'])
    
    page_fallback = []
    for prod in unmatched:
        pages = prod.get('source', {}).get('pages', [])
        for page in pages:
            if page in page_to_images and len(page_to_images[page]) > 0:
                # Use most common SKU on that page
                page_fallback.append((prod['sku'], page, page_to_images[page][0]))
                break
    
    print(f"\n🔍 Found {len(page_fallback)} page-based fallbacks:")
    for sku, page, fallback in page_fallback[:20]:
        print(f"   {sku:20s} | Page {page:3d} → {fallback}")
    
    # Calculate potential coverage
    print("\n" + "=" * 80)
    print("POTENTIAL COVERAGE CALCULATION")
    print("=" * 80)
    
    total_potential = len(set([x[0] for x in extreme_fuzzy]) |
                          set([x[0] for x in partial_matches]) |
                          set([x[0] for x in numeric_matches]) |
                          set([x[0] for x in contains_matches]) |
                          set([x[0] for x in page_fallback]))
    
    current_matched = len(makita_products) - len(unmatched)
    potential_matched = current_matched + total_potential
    potential_coverage = potential_matched / len(makita_products) * 100
    
    print(f"\n📊 Current Coverage: {current_matched}/{len(makita_products)} (67.3%)")
    print(f"📊 Potential Additional: {total_potential} products")
    print(f"📊 Potential Coverage: {potential_matched}/{len(makita_products)} ({potential_coverage:.1f}%)")
    
    # Breakdown
    print(f"\n🎯 Strategy Breakdown:")
    print(f"   Extreme Fuzzy (60-74%):    {len(extreme_fuzzy):4d}")
    print(f"   Partial SKU:               {len(partial_matches):4d}")
    print(f"   Numeric Code:              {len(numeric_matches):4d}")
    print(f"   Substring Contains:        {len(contains_matches):4d}")
    print(f"   Page Fallback:             {len(page_fallback):4d}")
    print(f"   Total Unique:              {total_potential:4d}")
    
    # Save strategies
    strategies = {
        'extreme_fuzzy': [(s, m, r) for s, m, r in extreme_fuzzy],
        'partial_matches': [(s, m) for s, matches in partial_matches for m, _ in matches[:1]],
        'numeric_matches': [(s, m) for s, m, _ in numeric_matches],
        'contains_matches': [(s, m) for s, m in contains_matches],
        'page_fallback': [(s, m) for s, _, m in page_fallback]
    }
    
    output_path = PROJECT_ROOT / "output" / "extreme_matching_strategies.json"
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(strategies, f, indent=2)
    
    print(f"\n💾 Strategies saved to: {output_path}")
    
    # Recommendations
    print("\n" + "=" * 80)
    print("RECOMMENDATIONS TO REACH 95%")
    print("=" * 80)
    
    print(f"\n1️⃣  ULTRA-AGGRESSIVE EXTRACTION")
    print(f"   → Lower thresholds to absolute minimum")
    print(f"   → Accept lower quality images")
    print(f"   → Could extract 50-100 more images")
    
    print(f"\n2️⃣  EXTREME FUZZY MATCHING (60%)")
    print(f"   → Lower threshold from 75% to 60%")
    print(f"   → Will have false positives - need verification")
    print(f"   → Could match {len(extreme_fuzzy)} more products")
    
    print(f"\n3️⃣  PARTIAL/SUBSTRING MATCHING")
    print(f"   → Match partial SKUs, numeric codes")
    print(f"   → Could match {len(partial_matches) + len(numeric_matches) + len(contains_matches)} more")
    
    print(f"\n4️⃣  PAGE FALLBACK")
    print(f"   → Use any image from same page")
    print(f"   → Low accuracy but better than nothing")
    print(f"   → Could match {len(page_fallback)} more")
    
    print(f"\n⚠️  WARNING:")
    print(f"   These strategies trade ACCURACY for COVERAGE")
    print(f"   Some matches will be incorrect")
    print(f"   Recommend manual verification of fuzzy <70% matches")

if __name__ == '__main__':
    main()
